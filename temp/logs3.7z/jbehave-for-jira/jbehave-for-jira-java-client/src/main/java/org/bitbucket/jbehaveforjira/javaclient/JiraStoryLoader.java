package org.bitbucket.jbehaveforjira.javaclient;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.jbehave.core.io.StoryLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * @author Maryna Stasyuk
 */
public class JiraStoryLoader implements StoryLoader {

    private final Logger log = LoggerFactory.getLogger(getClass());

    private String jiraBaseUrl;

    private String projectKey;

    private String username;

    private String password;

    private String downloadedStoriesDir = "src/test/resources/jira_stories";

    private String loadStoryPath = "rest/jbehave-for-jira/1.0/find/for-path/";

    public JiraStoryLoader(String jiraBaseUrl, String projectKey, String username, String password) {
        this.jiraBaseUrl = jiraBaseUrl;
        this.projectKey = projectKey;
        this.username = username;
        this.password = password;
    }

    @Override
    public String loadStoryAsText(String storyPath) {

        URI jiraSearchUrl = null;
        try {
            String fullPath = jiraBaseUrl + "/" + loadStoryPath;
            fullPath += storyPath;
            fullPath += "?os_username=" + this.username
                    + "&os_password=" + this.password
                    + "&versionInPath=true" + "&asString=true";
            log.debug("full story path is - " + fullPath);
            jiraSearchUrl = new URI(fullPath);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        Client client = Client.create();
        WebResource res = client.resource(jiraSearchUrl);
        ClientResponse response = res.type(MediaType.APPLICATION_JSON).get(ClientResponse.class);
        log.info("response - " + response);

        if (response.getStatus() == 200) {
            String story = response.getEntity(String.class);
            return story;
        } else {
            int status = response.getStatus();
            Response.StatusType statusInfo = response.getStatusInfo();
            throw new RuntimeException("Error occurred while trying to find Jira story paths. " +
                    "Response status was - " + status + ", status info - " + statusInfo);
        }

    }

    private void writeModelToFile(String storyPath, String storyModel) {

        PrintWriter pw = null;
        try {
            File storiesDir = new File(downloadedStoriesDir);
            File outFile = new File(storiesDir, storyPath);
            outFile.getParentFile().mkdirs();
            FileWriter fw = new FileWriter(outFile.getAbsoluteFile());
            pw = new PrintWriter(fw);
            pw.print(storyModel);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (pw != null) {
                pw.close();
            }
        }

    }

}
