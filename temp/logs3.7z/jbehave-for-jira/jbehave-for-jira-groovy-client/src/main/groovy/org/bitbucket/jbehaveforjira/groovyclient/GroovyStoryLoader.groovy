package org.bitbucket.jbehaveforjira.groovyclient
import com.sun.jersey.api.client.Client
import com.sun.jersey.api.client.ClientResponse
import com.sun.jersey.api.client.WebResource
import org.apache.commons.lang.Validate
import org.jbehave.core.io.StoryLoader

import javax.ws.rs.core.MediaType
import javax.ws.rs.core.Response
import java.util.regex.Matcher
import java.util.regex.Pattern
/**
 * @author Maryna Pristrom
 */
public class GroovyStoryLoader implements StoryLoader {

    private String downloadedStoriesDir = "src/test/resources/jira_stories";

    private String basePostUrl;

    private String loginParams;

    private final boolean outputStoriesToFile;

    public GroovyStoryLoader(String jiraBaseUrl, String projectKey, String jiraUsername, String jiraPassword,
                             boolean outputStoriesToFile) {
        this(jiraBaseUrl, projectKey, jiraUsername, jiraPassword, outputStoriesToFile, "target/jira_stories/");
    }

    public GroovyStoryLoader(String jiraBaseUrl, String projectKey, String username, String password,
                             boolean outputStoriesToFile, String outputStoriesDir) {
        basePostUrl = jiraBaseUrl + "/rest/jbehave-for-jira/1.0/find/for-path/";
        loginParams = "?os_username=" + username + "&os_password=" + password;
        this.outputStoriesToFile = outputStoriesToFile;
        this.downloadedStoriesDir = outputStoriesDir;
    }

    @Override
    public String loadStoryAsText(String storyPath) {

        URI jiraSearchUrl = null;
        try {
            String fullPath = basePostUrl + storyPath + loginParams + "&versionInPath=true&asString=true";
            jiraSearchUrl = new URI(fullPath);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        Client client = Client.create();
        WebResource res = client.resource(jiraSearchUrl);
        ClientResponse response = res.type(MediaType.APPLICATION_JSON).get(ClientResponse.class);

        if (response.getStatus() == 200) {
            String story = response.getEntity(String.class);
            if (this.outputStoriesToFile) {
                writeModelToFile(storyPath, story);
            }
            return story;
        } else {
            int status = response.getStatus();
            Response.StatusType statusInfo = response.getStatusInfo();
            throw new RuntimeException("Error occurred while trying to find Jira story paths. " +
                    "Response status was - " + status + ", status info - " + statusInfo);
        }

    }

    private void writeModelToFile(String storyPath, String storyModel) {

        // extract story path without version
        String regexPattern = "(.*)(\\.[0-9]*)(\\.story)";
        Pattern p = Pattern.compile(regexPattern);
        Matcher matcher = p.matcher(storyPath);
        Validate.isTrue(matcher.matches());
        String storyPathWithoutVersion = matcher.group(1) + matcher.group(3);

        PrintWriter pw = null;
        try {
            File storiesDir = new File(downloadedStoriesDir);
            File outFile = new File(storiesDir, storyPathWithoutVersion);
            outFile.getParentFile().mkdirs();
            FileWriter fw = new FileWriter(outFile.getAbsoluteFile());
            pw = new PrintWriter(fw);
            pw.print(storyModel);
        } catch (IOException e) {
            throw new RuntimeException("Error occurred while trying to write story to file for story path - " + storyPath, e);
        } finally {
            if (pw != null) {
                pw.close();
            }
        }

    }

}
