function StoryController() {

    var debugOn = true;

    var debug = function (msg) {
        if (debugOn) {
            console.log(msg);
        }
    }

    var error = function (msg) {
        console.error(msg);
    }

    var info = function (msg) {
        console.info(msg);
    }

    var storyController = this;
    var pageUtils = new PageUtils();
    var restService = new RestService();
    var msgBar = new MsgBar();
    var tableAligner = new TableAligner();
    var editorUtils = new EditorUtils();
    var textUtils = new TextUtils();
    var stepDocUtils = new StepDocUtils();
    var prefs = new PreferencesModel();
    storyController.prefs = prefs;
    this.buttonHandler = new ButtonHandler();

    var editor = undefined;
    var loadedStory = undefined;
    var stepDocs = undefined;

    var storyChanged = false;

    // initialization sequence
    restService.getUserPreferences(function (fetchedPreferences) {
        prefs = fetchedPreferences;
        restService.fetchStepDocs(pageUtils.getProjectKey(), function (foundStepDocs) {
            stepDocs = foundStepDocs;
            restService.loadStory(pageUtils.getProjectKey(), pageUtils.getIssueKey(), function (fetchedStory) {
                editor = storyController.initEditor();
                storyController.showStory(fetchedStory);
            });
        });
    });

    this.initEditor = function () {
        // initialize story panel
        var storyPanelContent = execspec.viewissuepage.showstory.renderStoryPanel();
        AJS.$("#story-panel").html(storyPanelContent);

        // initialize cm editor
        CodeMirror.commands.autocomplete = function (cm) {
            cm.showHint({hint: CodeMirror.hint.jbehave});
        }
        var editor = CodeMirror.fromTextArea(document.getElementById("storyTextArea"), {
            mode: "jbehave",
//            lineComment: "!--",
            lineNumbers: prefs.showLineNumbers,
            extraKeys: {
                "Ctrl-Space": "autocomplete",

                Tab: function (cm) {
                    var spaces = Array(cm.getOption("indentUnit") + 1).join(" ");
                    cm.replaceSelection(spaces, "end", "+input");
                },

                // commenting
                "Ctrl-/": function (cm) {

                    console.log("commenting!");

                    var startOfSelection = cm.getCursor(true);
                    var endOfSelection = cm.getCursor(false);

                    var curLine = cm.getLine(startOfSelection.line);
                    console.log("curLine - " + curLine);

                    var from = {line: startOfSelection.line, ch: startOfSelection.ch};
                    var to = {line: endOfSelection.line, ch: endOfSelection.ch};
                    var options = new Object();

                    if (curLine.substring(0, 1) == "|") {
                        options.lineComment = "|--";
                    } else {
                        options.lineComment = "!--";
                    }

                    options.padding = "";

                    if (curLine.substring(0, 3) == options.lineComment) {
                        cm.uncomment(from, to, options);
                    } else {
                        cm.lineComment(from, to, options);
                    }
                }
//                "F11": function(cm) {
//                    cm.setOption("fullScreen", !cm.getOption("fullScreen"));
//                },
//                "Esc": function(cm) {
//                    if (cm.getOption("fullScreen")) cm.setOption("fullScreen", false);
//                }
            }
        });

        editor.on("change", storyController.onEditorChangeHandler);

        return editor;
    }

    this.onEditorChangeHandler = function (editor, changeObj) {
        debug("> onEditorChangeHandler");

        if (storyChanged == false) {
            msgBar.showSaveCancelMsg();
        }
        storyChanged = true;

        editorUtils.remarkStepsOnChange(changeObj);

        debug("# onEditorChangeHandler");
    }

    this.onUserPreferencesUpdated = function () {
        restService.getUserPreferences(function (fetchedPreferences) {
            prefs = fetchedPreferences;
            storyController.prefs = prefs;
            if (prefs.showLineNumbers) {
                editor.setOption("lineNumbers", true);
            } else {
                editor.setOption("lineNumbers", false);
            }
        });
    }

    this.showStory = function (storyModel) {

        debug("> showStory");

        editor.off("change", storyController.onEditorChangeHandler);
        editor.setValue(storyModel.asString);
        editor.on("change", storyController.onEditorChangeHandler);

        loadedStory = storyModel;
        storyChanged = false;

        editor.setOption("readOnly", false);

        debug("# showStory");

        var stepStartingLine = editorUtils.findStepStartingLineAfter(-1);
        while (stepStartingLine > -1) {
            var stepEndingLine = editorUtils.findLastStepLineFrom(stepStartingLine);
            editorUtils.remarkStepBetween(stepStartingLine, stepEndingLine);
            if (stepEndingLine >= editor.lineCount()) {
                stepStartingLine = -1;
            } else {
                stepStartingLine = editorUtils.findStepStartingLineAfter(stepEndingLine);
            }
        }

        if (storyModel.version != null) {
            // this is NOT a new story, so check and show any story reports
            restService.findStoryReports(pageUtils.getProjectKey(), pageUtils.getIssueKey(),
                function (storyReportsPayload) {
                    debug("> findStoryReports.callback");
                    if (storyReportsPayload != undefined && storyReportsPayload.storyTestReports.length != 0) {
                        debug("found storyReportsPayload - " + JSON.stringify(storyReportsPayload, null, "\t"));
                        storyController.showStoryReports(storyReportsPayload.storyTestReports);
                    } else {
                        debug("no story reports were found for project");
                    }
                    debug("# findStoryReports.callback");
                }
            );
        }
    }

    this.showStoryReports = function (storyTestReports) {

        debug("> showStoryReports");

        var templateParam = new Object();
        templateParam.storyTestReports = storyTestReports;
        templateParam.currentStoryVersion = loadedStory.version;

        var storyReportsContent = execspec.viewissuepage.showstoryreports.renderStoryReports(templateParam);

        AJS.$('#storyReportsPanel').html(storyReportsContent);
        AJS.tabs.setup();

        // assign expand triggers for failure traces
        AJS.$('.failure-trace-expander-trigger').each(function (index, element) {

            AJS.$(element).click(function(eventObject) {
                if (eventObject.preventDefault) {
                    eventObject.preventDefault();
                } else {
                    eventObject.returnValue = false;
                }
                var target = eventObject.target;
                var targetNode = AJS.$(target)[0];
                var traceContainer = AJS.$(targetNode).siblings(".jb-story-report-failure-trace-container")[0];
                AJS.$(traceContainer).toggle();
                var replaceText =targetNode.getAttribute("replace-text");
                var currentHtml = AJS.$(targetNode).html();
                AJS.$(targetNode).html(replaceText);
                targetNode.setAttribute("replace-text", currentHtml);
            });

        });

        debug("# showStoryReports");
    }

    function PageUtils() {

        var issueKey = null;
        var projectKey = null;

        this.getIssueKey = function () {
            if (issueKey == null) {
                issueKey = AJS.$.trim(AJS.$("#key-val").text());
            }
            return  issueKey;
        };

        this.getProjectKey = function () {
            if (projectKey == null) {
                var issueKey = this.getIssueKey();
                if (issueKey) {
                    projectKey = issueKey.match("[A-Z]*")[0];
                }
            }
            return projectKey;
        };
    }

    function PreferencesModel() {
        this.showLineNumbers = false;
        this.autoAlignTables = true;
        this.autoInsertTabularFields = true;
    }

    function StoryModel() {
        this.projectKey = null;
        this.issueKey = null;
        this.version = null;
        this.asString = null;
    }

    function StoryReportModel() {
        this.environment = "";
        this.storyPath = "";
        this.storyVersion = "";
        this.status = "";
        this.totalScenarios = "";
        this.totalScenariosPassed = "";
        this.totalScenariosFailed = "";
        this.totalScenariosPending = "";
        this.totalScenariosSkipped = "";
        this.totalScenariosNotPerformed = "";
        this.htmlReport = "";
    }

    function MsgBar() {

        this.clear = function () {
            AJS.$("#storyMsgBar").empty();
        }

        this.showSaveCancelMsg = function () {
            var saveCancelContent = execspec.viewissuepage.showstory.renderSaveCancelMsg();
            AJS.$("#storyMsgBar").empty();
            AJS.messages.warning("#storyMsgBar", {
                title: null,
                id: "storyWarningMsg",
                body: saveCancelContent,
                closeable: false
            });
        }

        this.showSavingMsg = function () {
            var waitingMsg = execspec.viewissuepage.showstory.renderWaitingMessage();
            AJS.$('#storyEditedMsgContainer').html(waitingMsg);
        }

        this.showSuccessMessage = function (saveCancelMsg) {

            AJS.$("#storyMsgBar").empty();
            AJS.messages.success("#storyMsgBar", {
                title: null,
                fadeout: true,
                delay: 3000,
                body: saveCancelMsg,
                closeable: true
            });
        }
    }

    function RestService() {

        var restPathBase = "/jira/rest/jbehave-for-jira/1.0/";

        this.getUserPreferences = function (callback) {
            var urlString = restPathBase + "preferences/for-user";
            AJS.$.ajax({
                type: "GET",
                url: urlString,
//                async: false,
                success: function (data, textStatus, jqXHR) {
                    info("User preferences fetched successfully");
                    callback(data);
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    error("An error occurred while trying to fetch user preferences, textStatus - "
                        + textStatus + " errorThrown - " + errorThrown + ". Will use default values for user preferences.");
                    callback(new PreferencesModel());
                }
            });
        }

        this.loadStory = function (projectKey, issueKey, callback) {

            var urlString = restPathBase + "find/for-issue/" + projectKey + "/" + issueKey;
            var jqxhr = AJS.$.getJSON(urlString);

            var successCallback = function (storyPayload, status, xhr) {

                if (storyPayload != undefined) {
                    debug("found storyPayload - " + JSON.stringify(storyPayload, null, "\t"));
                } else {
                    debug("no story found for project - " + projectKey + ", issue - " + issueKey);
                    storyPayload = new StoryModel();
                    storyPayload.projectKey = pageUtils.getProjectKey();
                    storyPayload.issueKey = pageUtils.getIssueKey();
                    storyPayload.asString = "";
                }

                callback(storyPayload);
            }

            jqxhr.done(successCallback);

            jqxhr.fail(function (data, status, xhr) {
                error("fail, received data - " + data);
                error("xhr.status - " + xhr.status);
            });
        }

        this.findStoryReports = function (projectKey, issueKey, callBack) {

            var urlString = restPathBase + "story-test/find/" + projectKey + "/" + issueKey;

            var jqxhr = AJS.$.getJSON(urlString);

            var successCallback = function (data, status, xhr) {
                callBack(data);
            }
            jqxhr.done(successCallback);

            jqxhr.fail(function (data, status, xhr) {
                console.error("fail, received data - " + data);
                console.error("xhr.status - " + xhr.status);
            });
        }

        this.fetchStepDocs = function (projectKey, callback) {

            var pathStepDocs = restPathBase + "step-doc/for-project/" + projectKey;
            AJS.$.ajax({
                type: "GET",
                url: pathStepDocs,
                contentType: "text/plain; charset=utf-8",
                success: function (data, status, xhr) {
                    callback(data.stepDocs);
                },
                dataType: "json"
//                async: false
            });
        }

        this.saveOrUpdateStory = function (storyModel) {

            var successCallback = function (savedStory, status, xhr) {
                var jsonStory = JSON.stringify(savedStory, null, "\t");
                debug("saved story:\n" + jsonStory);

                msgBar.showSuccessMessage("Story was saved successfully!");
                storyController.showStory(savedStory);
                debug("# saveOrUpdateStory callback");
            }

            var saveUrl = restPathBase + "crud/save/" + storyModel.projectKey + "/" + storyModel.issueKey;
            if (storyModel.version != undefined && storyModel.version != "") {
                saveUrl += "?version=" + storyModel.version;
            }

            var storyPayload = JSON.stringify(storyModel, null, "\t");
            debug("sending story payload:\n" + storyPayload);

            AJS.$.ajax({
                type: "POST",
                url: saveUrl,
                contentType: "text/plain; charset=utf-8",
                success: successCallback,
                data: storyPayload,
                dataType: "json"
            });

        }
    }

    function TableAligner() {

        this.alignTableBetween = function (tableStartLine, tableEndLine) {

            debug("> alignTableBetween");

            editor.off("change", storyController.onEditorChangeHandler);

            // get max width for columns
            var maxColumnWidths = [];
            editor.getDoc().eachLine(tableStartLine, tableEndLine + 1, function (lineHandle) {
                    var lineText = lineHandle.text;
                    lineText = lineText.replace(/\s+$/g, ''); // trim any trailing spaces
                    if (lineText.substring("|--".length) == "|--") {
                        // ignore table comment line
                    } else if (lineText.length == 0) {
                        // ignore empty lines
                    } else {
                        var tokens = lineText.split("|");
                        for (var i = 0; i < tokens.length; i++) {
                            var token = tokens[i];
                            token = token.replace(/\s+$/g, ''); // trim any trailing spaces
                            var currentMax = maxColumnWidths[i];
                            if (currentMax == null || token.length > currentMax) {
                                var newMax = token.length;
                                maxColumnWidths[i] = newMax;
                            }
                        }
                    }
                }
            );

            var cursorPosBefore = editor.getCursor(true);

            var tokenTrimmedBy = 0;

            // align columns
            editor.getDoc().eachLine(tableStartLine, tableEndLine + 1, function (lineHandle) {
                    var lineText = lineHandle.text;
                    lineText = lineText.replace(/\s+$/g, ''); // trim any trailing spaces
                    var currentLine = lineHandle.lineNo();
                    if (lineText.substring("|--".length) == "|--") {
                        // ignore table comment line
                    } else if (lineText.length == 0) {
                        // ignore empty lines
                    } else {
                        var tokens = lineText.split("|");
                        var pos = 0;
                        for (var i = 0; i < tokens.length; i++) {
                            var isFirstToken = i == 0;
                            var isLastToken = i == (tokens.length - 1);
                            var token = tokens[i];
                            var originalTokenLength = token.length;
                            if (!isFirstToken) {
                                pos++; // for '|'
                            }
                            var tokenStartCh = pos;
                            var tokenEndCh = tokenStartCh + token.length;
                            var difference = maxColumnWidths[i] - token.length;
                            if (difference > 0 && !isFirstToken && !isLastToken) {

                                var spaces = "";
                                while (difference > 0) {
                                    spaces = spaces + " ";
                                    difference--;
                                }
                                // replace old token with new
                                editor.getDoc().replaceRange(spaces,
                                    {line: currentLine, ch: tokenEndCh},
                                    {line: currentLine, ch: tokenEndCh});

                                pos += token.length + spaces.length;

                            } else if (difference < 0 && !isFirstToken && !isLastToken) {
                                // this is the case when token has whitespace at the end
                                // so we trim the whitespace
                                token = token.replace(/\s+$/g, ''); // trim any trailing spaces
                                // after trimming the difference must be zero
                                difference = maxColumnWidths[i] - token.length;
                                if (difference < 0) {
                                    console.error("Error occurred while trying to align table line - " + currentLine + ", length of token - "
                                        + token + " was longer than maximum length for its column");
                                    pos += token.length;
                                } else {
                                    // we replace the original token with the trimmed one
                                    // but we may need to pad still following our trimming
                                    var spaces = "";
                                    while (difference > 0) {
                                        spaces = spaces + " ";
                                        difference--;
                                    }
                                    // replace old token with new one, which may also be padded
                                    var replaceToken = token + spaces;
                                    tokenTrimmedBy = originalTokenLength - replaceToken.length;
                                    editor.getDoc().replaceRange(replaceToken,
                                        {line: currentLine, ch: tokenStartCh},
                                        {line: currentLine, ch: tokenEndCh});
                                    pos += replaceToken.length;
                                }
                            } else {
                                pos += token.length;
                            }
                        }
                    }
                }
            );

            var cursorPosAfter = editor.getCursor(true);
            if (cursorPosBefore.line != cursorPosAfter.line || cursorPosBefore.ch != cursorPosAfter.ch) {
                // cursor has been moved, set it back to original position before alignment
                if (cursorPosAfter.ch > cursorPosBefore.ch) {
//                if (tokenTrimmedBy == 0) {
                    editor.setCursor(cursorPosBefore);
                }
            }

            editor.on("change", storyController.onEditorChangeHandler);

            debug("# alignTableBetween");
        }

        this.alignTablesInWholeDoc = function () {

            debug("> alignTablesInWholeDoc");

            var tableStartLine = null;
            var currentLine;
            var previousLine;
            editor.getDoc().eachLine(function (lineHandle) {
                if (currentLine != null) {
                    previousLine = currentLine;
                }
                currentLine = lineHandle.lineNo();
                var lineText = lineHandle.text;
                lineText = lineText.replace(/\s+$/g, ''); // trim any trailing spaces
                if (lineText.substr(0, 1) == "|") {
                    // inside table line
                    if (tableStartLine == null) {
                        tableStartLine = lineHandle.lineNo();
                    }
                } else if (tableStartLine != null) {
                    // we were already in the table before
                    var tableEndLine = previousLine;
                    if (tableEndLine > tableStartLine) {
                        storyController.alignTableBetween(tableStartLine, tableEndLine);
                    }
                    tableStartLine = null;
                }
            });

            debug("# alignTablesInWholeDoc");
        }

        this.realignStepTableParameters = function (stepStartLine, stepEndLine) {

            debug("> realignStepTableParameters");

            if (prefs.autoAlignTables) {
                var firstTableLine = editorUtils.findTabularParameterStartingLineAfter(stepStartLine, stepEndLine + 1);
                if (firstTableLine != -1) {
                    var lastTableLine = editorUtils.findTabularParameterEndingLineAfter(stepStartLine, stepEndLine + 1);
                    this.alignTableBetween(firstTableLine, lastTableLine);
                }
            } else {
                debug("skipping aligning of table parameters");
            }
            debug("# realignStepTableParameters");
        }


    }

    function TextUtils() {

        this.startsWithExamples = function (text) {
            var regExpPattern = new RegExp("^(Examples:)");
            var matchedResult = regExpPattern.exec(text);
            if (matchedResult != null) {
                return true;
            } else {
                return false;
            }
        }

        this.startsWithScenario = function (text) {
            var regExpPattern = new RegExp("^(Scenario:)\\s");
            var matchedResult = regExpPattern.exec(text);
            return matchedResult != null;
        }

        this.startsWithAfter = function (text) {
            var regExpPattern = new RegExp("^(After:)");
            var matchedResult = regExpPattern.exec(text);
            return matchedResult != null;
        }

        this.startsWithOutcome = function (text) {
            var regExpPattern = new RegExp("^(Outcome:)\\s");
            var matchedResult = regExpPattern.exec(text);
            return matchedResult != null;
        }

        this.startsWithGivenWhenThen = function (text) {
            var regExpPattern = new RegExp("^(Given|When|Then)\\s");
            var matchedResult = regExpPattern.exec(text);
            return matchedResult != null;
        }

        this.startsWithAnd = function (text) {
            var regExpPattern = new RegExp("^(And)\\s");
            var matchedResult = regExpPattern.exec(text);
            return matchedResult != null;
        }

        this.startsWithTableSeparator = function (text) {
            var firstChar = text.substring(0, 1);
            return firstChar == "|";
        }

        this.startsWithTableComment = function (text) {
            var firstChar = text.substring(0, 3);
            return firstChar == "|--";
        }
    }

    function EditorUtils() {

        this.lineStartsWithStepKeyword = function (lineNumber) {

            var lineHandle = editor.getLineHandle(lineNumber);
            if (lineHandle == null) {
                return false;
            } else {
                var lineText = lineHandle.text;
                var regExpPattern = new RegExp("^(Given|When|Then|And)\\s");
                var matchedResult = regExpPattern.exec(lineText);
                if (matchedResult != null) {
                    return true;
                } else {
                    return false;
                }
            }
        }

        this.lineStartsWithAndKeyword = function (lineNumber) {

            var lineHandle = editor.getLineHandle(lineNumber);
            var lineText = lineHandle.text;

            var regExpPattern = new RegExp("^(And)\\s+");
            var matchedResult = regExpPattern.exec(lineText);
            if (matchedResult != null) {
                return true;
            } else {
                return false;
            }
        }

        this.findStepStartingLineBefore = function (lineNumber) {
            var previousLine = lineNumber - 1;
            while (previousLine != -1) {
                if (this.lineStartsWithScenarioOrExamples(previousLine) || this.lineStartsWithOutcome(previousLine)) {
                    return -1;
                } else if (this.lineStartsWithStepKeyword(previousLine)) {
                    return previousLine;
                }
                previousLine--;
            }
            return -1;
        }

        this.findStepStartingLineBeforePosition = function (pos) {
            var lineNumber = pos.line;
            var ch = pos.ch;
            var lineHandle = editor.getLineHandle(lineNumber);
            var lineText = lineHandle.text;
            var partText = lineText.substring(0, ch);
            if (textUtils.startsWithGivenWhenThen(partText) || textUtils.startsWithAnd(partText)) {
                return lineNumber;
            } else {
                return this.findStepStartingLineBefore(lineNumber);
            }

        }

        this.findStepStartingLineInSameScenarioBefore = function (lineNumber) {
            var previousLine = lineNumber - 1;
            while (previousLine != -1) {
                if (this.lineStartsWithStepKeyword(previousLine)) {
                    return previousLine;
                } else if (this.lineStartsWithScenario(previousLine)) {
                    return -1;
                } else {
                    previousLine--;
                }
            }
            return -1;
        }

        this.findStepStartingLineAfter = function (lineNumber) {
            var nextLine = lineNumber + 1;
            var totalLines = editor.lineCount();
            while (nextLine < totalLines) {
                if (this.lineStartsWithStepKeyword(nextLine)) {
                    return nextLine;
                }
                nextLine++;
            }
            return -1;
        }

        this.findTabularParameterStartingLineAfter = function (lineNumber, butNotAtOrAfter) {
            var nextLineNumber = lineNumber + 1;
            while (nextLineNumber < butNotAtOrAfter) {
                var nextLineHandle = editor.getLineHandle(nextLineNumber);
                if (nextLineHandle == null) {
                    return -1;
                } else {
                    if (nextLineHandle.text.substring(0, 1) == "|" && nextLineHandle.text.substring(0, 3) != "|--") {
                        return nextLineNumber;
                    }
                    nextLineNumber++;
                }
            }
            return -1;
        }

        this.findStepStartingLineInSameScenarioAfter = function (lineNumber) {
            var nextLine = lineNumber + 1;
            var totalLines = editor.lineCount();
            while (nextLine < totalLines) {
                if (this.lineStartsWithStepKeyword(nextLine)) {
                    return nextLine;
                } else if (this.lineStartsWithScenarioOrExamples(nextLine)) {
                    return -1;
                }
                nextLine++;
            }
            return -1;
        }

        this.lineStartsWithScenario = function (lineNumber) {

            var lineHandle = editor.getLineHandle(lineNumber);
            var lineText = lineHandle.text;
            return textUtils.startsWithScenario(lineText);
        }

        this.lineStartsWithOutcome = function (lineNumber) {
            var lineHandle = editor.getLineHandle(lineNumber);
            var lineText = lineHandle.text;
            return textUtils.startsWithOutcome(lineText);
        }


        this.lineStartsWithScenarioOrExamples = function (lineNumber) {

            var lineHandle = editor.getLineHandle(lineNumber);
            var lineText = lineHandle.text;
            if (textUtils.startsWithScenario(lineText) || textUtils.startsWithExamples(lineText)) {
                return true;
            } else {
                return false;
            }
        }

        this.lineStartsWithAfterOrOutcome = function (lineNumber) {

            var lineHandle = editor.getLineHandle(lineNumber);
            var lineText = lineHandle.text;
            if (textUtils.startsWithAfter(lineText) || textUtils.startsWithOutcome(lineText)) {
                return true;
            } else {
                return false;
            }
        }

        this.findTabularParameterEndingLineAfter = function (tableStartLine, notAtOrAfter) {
            var nextLineNumber = tableStartLine + 1;
            var lastStepLine = tableStartLine;
            while (nextLineNumber < notAtOrAfter) {
                var nextLineHandle = editor.getLineHandle(nextLineNumber);
                if (nextLineHandle == null) {
                    return lastStepLine;
                } else {
                    if (nextLineHandle.text.length > 0 && nextLineHandle.text.substring(0, 1) != "|") {
                        break;
                    } else {
                        lastStepLine = nextLineNumber;
                        nextLineNumber++;
                    }
                }
            }
            return lastStepLine;
        }

        this.findLastStepLineFrom = function (lineNumber) {

            var nextLineNumber = lineNumber + 1;
            var lineCount = editor.getDoc().lineCount();
            var lastStepLine = lineNumber;
            while (nextLineNumber < lineCount) {
                if (this.lineStartsWithStepKeyword(nextLineNumber)
                    || this.lineStartsWithScenarioOrExamples(nextLineNumber)
                    || this.lineStartsWithAfterOrOutcome(nextLineNumber)) {
                    break;
                } else {
                    lastStepLine = nextLineNumber;
                    nextLineNumber++;
                }
            }

            return lastStepLine;
        }

//        this.findTabularParameterStartingLineBeforePos = function (pos) {
//
//            var line = pos.line;
//            var ch = pos.ch;
//
//            var lineHandle = editor.getLineHandle(line);
//            var lineText = lineHandle.text;
//            var partText = lineText.substring(0, ch);
//
//            var tableStartingLine = -1;
//            if (partText.substring(0, 1) == "|") {
//                // this is a table line
//            } else {
//
//            }
//
//
//        }

        this.remarkStep = function (stepStartLine, stepEndLine, step) {

            debug("> remarkStep");
            debug("stepStartLine - " + stepStartLine + ", stepEndLine - " + stepEndLine);
            debug("step:\n" + step);


            // extract step body i.e. without the starting keyword
            var regExpPattern = new RegExp("(^(Given|When|Then|And)\\s+)([\\s\\S]*)");
            var matchedResult = regExpPattern.exec(step);
            var keyword;
            var stepBody;
            var keywordPart;
            if (matchedResult != null) {
                keywordPart = matchedResult[1];
                keyword = matchedResult[2];
                stepBody = matchedResult[3];
            } else {
                console.log("Failed to match step against expected pattern, step - " + step + ", pattern - " + regExpPattern);
                return;
            }

            var lookingAtLine = stepStartLine;
            while (keyword == "And") {
                // replace it with the previous steps keyword
                var previousStepStartLine = this.findStepStartingLineInSameScenarioBefore(lookingAtLine);

                if (previousStepStartLine != -1) {
                    var previousStepFirstLine = editor.getLineHandle(previousStepStartLine).text;
                    var result = regExpPattern.exec(previousStepFirstLine);
                    keyword = result[2];
                    lookingAtLine = previousStepStartLine;
                } else {
                    // there is no previous step in this same scenario
                    return;
                }
            }

            var findResult = stepDocUtils.findMatchingStepdoc(stepBody, keyword);

            var markerStart = {line: stepStartLine, ch: 0};
            var lastStepLineHandle = editor.getLineHandle(stepEndLine);
            var markerEnd = {line: stepEndLine, ch: lastStepLineHandle.text.length};
            var matchedStepClassName = "matched-step";
            var stepParameterClassName = "step-parameter";

            // remove any matched-step markers
            var markersBefore = editor.getDoc().findMarks(markerStart, markerEnd);
            if (markersBefore.length > 0) {
                // always remove any existing marks, so that we include newly edited text in the marked range
                for (var m = 0; m < markersBefore.length; m++) {
                    var marker = markersBefore[m];
                    var markerClassName = marker.className;
                    if (markerClassName.substring(0, matchedStepClassName.length) == matchedStepClassName
                        || markerClassName.substring(0, stepParameterClassName.length) == stepParameterClassName) {
                        marker.clear();
                    }
                }
            }

            if (findResult != null) {

                var stepDocId = findResult.stepDoc.id;

                // set matched-step markers
                var options = new Object();
                options.className = matchedStepClassName + " " + matchedStepClassName + "-" + stepDocId;
                editor.getDoc().markText(markerStart, markerEnd, options);

                // match any parameters
                // obtain boundaries of any parameters
                var parameterGroupsInfos = [];
                var parameterGroups = findResult.stepDoc.parameterGroups;
                if (parameterGroups.length > 0) {
                    var pos = 0;
                    var lineOffset = keywordPart.split("\n").length - 1;
                    for (var j = 1; j < findResult.result.length; j++) {
                        var matchedGroup = findResult.result[j];
                        if (indexOf(parameterGroups, j) > -1) {
                            var pgi = new Object();
                            pgi.number = j;
                            pgi.text = matchedGroup;
                            pgi.startIndex = pos;
                            pgi.startLineOffset = lineOffset;
                            pgi.endIndex = pos + matchedGroup.length;
                            pgi.endLineOffset = lineOffset + (matchedGroup.split("\n").length - 1);

                            // obtain line number and ch position
                            // start
                            pgi.startLine = stepStartLine + pgi.startLineOffset;
                            var beforeParam = stepBody.substring(0, pgi.startIndex);
                            var lastLineBreakInBefore = beforeParam.lastIndexOf("\n");
                            var parameterStartLineCh;
                            if (lastLineBreakInBefore > -1) {
                                parameterStartLineCh = pgi.startIndex - lastLineBreakInBefore - 1;
                            } else {
                                parameterStartLineCh = pgi.startIndex;
                            }
                            if (pgi.startLineOffset == 0) {
                                // need to add the length of starting word also if on line 1
                                parameterStartLineCh += keywordPart.length;
                            }
                            pgi.startLineCh = parameterStartLineCh;
                            // end
                            pgi.endLine = stepStartLine + pgi.endLineOffset;
                            var includingParam = stepBody.substring(0, pgi.startIndex + pgi.text.length);
                            var lastLineBreakInIncludingParam = includingParam.lastIndexOf("\n");
                            var parameterEndLineCh;
                            if (lastLineBreakInIncludingParam > -1) {
                                parameterEndLineCh = pgi.startIndex + pgi.text.length - lastLineBreakInIncludingParam - 1;
                            } else {
                                parameterEndLineCh = pgi.startIndex + pgi.text.length;
                            }
                            if (pgi.endLineOffset == 0) {
                                // need to add the length of starting word also
                                parameterEndLineCh += keywordPart.length;
                            }
                            pgi.endLineCh = parameterEndLineCh;

                            parameterGroupsInfos.push(pgi);
                        }
                        pos += matchedGroup.length;
                        var linesInGroup = matchedGroup.split(/\n/).length;
                        lineOffset += (linesInGroup - 1);
                    }

                    // mark any step parameters
                    var parameterIndex = 0;
                    for (var k = 0; k < parameterGroupsInfos.length; k++) {
                        var pgi = parameterGroupsInfos[k];
                        var paramStart = {line: pgi.startLine, ch: pgi.startLineCh};
                        var paramEnd = {line: pgi.endLine, ch: pgi.endLineCh};
                        var paramMarkerOptions = new Object();
                        paramMarkerOptions.className = stepParameterClassName + " " + stepParameterClassName + "-" + parameterIndex;
                        editor.getDoc().markText(paramStart, paramEnd, paramMarkerOptions);
                        parameterIndex++;
                    }

                }

            }

            debug("# remarkStep");
        }

        this.remarkStepBetween = function (stepStartLine, stepEndLine) {

            debug("> remarkStepBetween");

            var step = "";
            editor.getDoc().eachLine(stepStartLine, stepEndLine + 1, function (lineHandle) {
                step += lineHandle.text + "\n";
            });

            this.remarkStep(stepStartLine, stepEndLine, step);

            debug("# remarkStepBetween");
        }

        this.remarkStepsOnChange = function (changeObj) {

            debug("> remarkStepsOnChange");

            var from = changeObj.from;
            var to = changeObj.to;

            var fromLine = from.line;
            var toLine = to.line;

            // update toLine if the edited text contains more than one line and the result is greater than current toLine
            var linesInChangedText = changeObj.text.length;
            var toLineAfterChange = fromLine + (linesInChangedText - 1);
            if (toLineAfterChange > toLine) {
                toLine = toLineAfterChange;
            }

            // find a step which starts before or at fromLine
            var stepStartingLine = this.findStepStartingLineBefore(fromLine);
            var scanStartLine;
            if (stepStartingLine > -1) {
                scanStartLine = stepStartingLine;
            } else {
                scanStartLine = fromLine;
            }

            // find scanEndLine
            var scanEndLine = this.findLastStepLineFrom(scanStartLine);
            this.remarkStepBetween(scanStartLine, scanEndLine);
//                tableAligner.realignStepTableParameters(scanStartLine, scanEndLine);
            var nextStepStartLine = this.findStepStartingLineInSameScenarioAfter(scanEndLine);
            var startsWithAnd;
            if (nextStepStartLine != -1) {
                startsWithAnd= this.lineStartsWithAndKeyword(nextStepStartLine);
            }
            while (nextStepStartLine != -1 && (nextStepStartLine <= toLine || startsWithAnd)) {
                scanStartLine = nextStepStartLine;
                scanEndLine = this.findLastStepLineFrom(scanStartLine);
                this.remarkStepBetween(scanStartLine, scanEndLine);
//                        tableAligner.realignStepTableParameters(scanStartLine, scanEndLine);
                nextStepStartLine = this.findStepStartingLineInSameScenarioAfter(scanEndLine);
                if (nextStepStartLine != -1) {
                    startsWithAnd = this.lineStartsWithAndKeyword(nextStepStartLine);
                }
            }

            if (prefs.autoAlignTables) {

                var fromLineHandler = editor.getLineHandle(fromLine);
                var isTableLine = textUtils.startsWithTableSeparator(fromLineHandler.text);
                var tableStartingLine = fromLine;
                if (isTableLine) {
                    // potentially table started before the current from edit line
                    var previousNoneEmptyLine = editorUtils.findNonEmptyLineBefore(fromLine);
                    while (previousNoneEmptyLine != -1) {
                        var previousLineText = editor.getLineHandle(previousNoneEmptyLine).text;
                        if (textUtils.startsWithTableSeparator(previousLineText)) {
                            tableStartingLine = previousNoneEmptyLine;
                            previousNoneEmptyLine = editorUtils.findNonEmptyLineBefore(previousNoneEmptyLine);
                        } else {
                            break;
                        }
                    }
                } else {
                    // this is a not a table line so maybe we have inserted some text that although does not start with a table line, it
                    // contains table lines
                    tableStartingLine = editorUtils.findTabularParameterStartingLineAfter(fromLine, toLine);
                }

                while (tableStartingLine != -1) {
                    // we have found at least one table in the edited text
                    var tableEndingLine = editorUtils.findTabularParameterEndingLineAfter(tableStartingLine, editor.lineCount());
                    if (tableEndingLine > tableStartingLine) {
                        // it actually a table, i.e. more than 1 line of text that starts with a '|'
                        tableAligner.alignTableBetween(tableStartingLine, tableEndingLine);
                    }
                    tableStartingLine = editorUtils.findTabularParameterStartingLineAfter(tableEndingLine, toLine);
                }

                // we are not inside a step, but we maybe modifying the examples table which may need realigning
//                this.remarkStepBetween(scanStartLine, scanEndLine);
            }
            debug("# remarkStepsOnChange");
        }

        this.findNonEmptyLineBefore = function (line) {
            var previousLine = line - 1;
            while (previousLine >= 0) {
                var previousLineHandle = editor.getLineHandle(previousLine);
                if (previousLineHandle == null) {
                    return -1;
                } else {
                    var text = previousLineHandle.text;
                    text = text.replace(/\s+$/g, '');
                    if (text.length > 0) {
                        return previousLine;
                    } else {
                        previousLine++;
                    }
                }
            }
            return -1;
        }

    }

    function StepDocUtils() {

        this.findMatchingStepdoc = function (step, stepType) {

            debug("> findMatchingStepdoc");

            // check if step matches
            var matchedResult = null;
            var matchingStepDoc = null;
            {
                step = step.replace(/\s+$/g, ''); // trim trailing whitespace;

                for (var i = 0; i < stepDocs.length; i++) {
                    var stepDoc = stepDocs[i];
                    if (stepDoc.startingWord == stepType) {
                        // try to see if the step docs pattern matches step body
                        var regExpStr = stepDoc.groupedRegExpPattern;
                        // replace the (.*) with ([\s\S]*) for javascript version of dotall option
                        var replacePattern = new RegExp("\\(\\.\\*\\)", "g");
                        regExpStr = regExpStr.replace(replacePattern, "([\\s\\S]*)");
                        // add start and end chars to match the string exactly
                        regExpStr = "^" + regExpStr + "$";
                        debug("Trying to match the step body against pattern - " + regExpStr);
                        var regExpPattern = new RegExp(regExpStr);
                        var matchedResult = regExpPattern.exec(step);
                        if (matchedResult != null) {
                            debug("Step pattern - " + regExpStr + " matches current step body");
                            matchingStepDoc = stepDoc;
                            return new Object({result: matchedResult, stepDoc: matchingStepDoc});
                            break;
                        }
                    }
                }
            }

            debug("# findMatchingStepdoc");

            return null;
        }
    }

    function ButtonHandler() {

        this.saveStoryHandler = function (event) {

            debug("> saveStoryHandler");
            if (event.preventDefault) {
                event.preventDefault();
            } else {
                event.returnValue = false;
            }

            var storyModel = new StoryModel();
            storyModel.projectKey = loadedStory.projectKey;
            storyModel.issueKey = loadedStory.issueKey;
            storyModel.version = loadedStory.version;
            storyModel.asString = editor.getValue();

            editor.setOption("readOnly", true);
            msgBar.showSavingMsg();

            restService.saveOrUpdateStory(storyModel);
            debug("# saveStoryHandler");
        }

        this.cancelEditHandler = function (event) {
            debug("> cancelEditingStory");
            if (event.preventDefault) {
                event.preventDefault();
            } else {
                event.returnValue = false;
            }
            storyController.showStory(loadedStory);
            msgBar.clear();
            debug("# cancelEditingStory");
        }
    }

    function indexOf(array, elt) {
        for (var i = 0; i < array.length; ++i)
            if (array[i] == elt) return i;
        return -1;
    }

//    var indexOf = function(needle) {
//        if(typeof Array.prototype.indexOf === 'function') {
//            indexOf = Array.prototype.indexOf;
//        } else {
//            indexOf = function(needle) {
//                var i = -1, index = -1;
//
//                for(i = 0; i < this.length; i++) {
//                    if(this[i] === needle) {
//                        index = i;
//                        break;
//                    }
//                }
//
//                return index;
//            };
//        }
//
//        return indexOf.call(this, needle);
//    }
}


var storyController;
AJS.$(function () {

    storyController = new StoryController();

    // handling page updates in response to inline editing of other jira fields
    JIRA.bind(JIRA.Events.NEW_CONTENT_ADDED, function (e, context, reason) {
        if (reason != "inlineEditStarted ") {
            storyController = new StoryController();
        }
//        if (reason == JIRA.CONTENT_ADDED_REASON.pageLoad) {
//        if (storyController == null) {
//            var ctr = new StoryController();
//            ctr.init();
//        }
//        }
    });
});
