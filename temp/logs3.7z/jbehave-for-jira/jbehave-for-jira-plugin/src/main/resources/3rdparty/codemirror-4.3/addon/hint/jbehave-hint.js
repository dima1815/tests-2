// CodeMirror, copyright (c) by Marijn Haverbeke and others
// Distributed under an MIT license: http://codemirror.net/LICENSE

(function (mod) {
    if (typeof exports == "object" && typeof module == "object") // CommonJS
        mod(require("../../lib/codemirror"));
    else if (typeof define == "function" && define.amd) // AMD
        define(["../../lib/codemirror"], mod);
    else // Plain browser env
        mod(CodeMirror);
})(function (CodeMirror) {
    "use strict";

    var stepDocs = null;
    AJS.$(function () {
        var issueKey = AJS.$.trim(AJS.$("#key-val").text());
        if (issueKey) {
            var projectKey = issueKey.match("[A-Z]*")[0];
            var restPathBase = "/jira/rest/jbehave-for-jira/1.0/";
            var pathStepDocs = restPathBase + "step-doc/for-project/" + projectKey;
            AJS.$.ajax({
                type: "GET",
                url: pathStepDocs,
                contentType: "text/plain; charset=utf-8",
                success: function (data, status, xhr) {
                    stepDocs = data.stepDocs;
                },
                dataType: "json"
//                async: false
            });
        } else {
            console.error("Failed to fetch step docs from server");
        }
    });

    CodeMirror.registerHelper("hint", "jbehave", function (editor, options) {

        options.completeSingle = false;
        options.closeOnUnfocus = false;

        var wordPattern = /[\w$]+/;

        var cursor = editor.getCursor();
        var doc = editor.getDoc();

        var globalFromCh = 0;
        var globalToCh = cursor.ch;
        var curLine = editor.getLine(cursor.line);
        var cursorPos = cursor.ch;
        var currentText = curLine.slice(0, cursorPos);
        var list = [];
        var currentToken = editor.getTokenAt(cursor);
        var currentState = currentToken.state;

        var hint;

        /**
         * Meta
         */
        hint = "Meta:";
        if (currentState.allowMeta && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-meta-title'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Meta field - @
         */
        hint = "@";
        if (currentState.allowMetaField && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-meta-field'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Meta field - skip
         */
        hint = "@skip";
        if (currentState.allowMetaField && cursorPos == 1 && hint.indexOf(currentText) == 0) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-meta-field'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Meta field - ignored
         */
        hint = "@ignored true";
        if (currentState.allowMetaField && cursorPos == 1 && hint.indexOf(currentText) == 0) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-meta-field'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Meta field - author
         */
        hint = "@author ";
        if (currentState.allowMetaField && cursorPos == 1 && hint.indexOf(currentText) == 0) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-meta-field'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Meta field - themes
         */
        hint = "@themes ";
        if (currentState.allowMetaField && cursorPos == 1 && hint.indexOf(currentText) == 0) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-meta-field'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Narrative title
         */
        hint = "Narrative:";
        if (currentState.allowNarrative && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-narrative-title'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Narrative - In order to
         */
        hint = "In order to ";
        if (currentState.allowNarrativeInOrderTo && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-narrative-field-keyword'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Narrative - As a
         */
        hint = "As a ";
        if (currentState.allowNarrativeAsA && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-narrative-field-keyword'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Narrative - I want to
         */
        hint = "I want to ";
        if (currentState.allowNarrativeIWantTo && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-narrative-field-keyword'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Lifecycle
         */
        hint = "Lifecycle:";
        if (currentState.allowLifecycle && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-lifecycle'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Lifecycle - Before
         */
        hint = "Before:";
        if (currentState.allowLifecycleBefore && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-lifecycle-before'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Lifecycle - After
         */
        hint = "After:";
        if (currentState.allowLifecycleAfter && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-lifecycle-after'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Lifecycle - Outcome
         */
        hint = "Outcome: ";
        if (currentState.allowLifecycleOutcome && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-lifecycle-outcome-keyword'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Lifecycle - Outcome value
         */
        if (currentState.inLifecycleOutcome && currentToken.type != null){

            var currentToken = currentState.current;

            hint = "ANY";
            if (currentToken == "Outcome: " || hint.indexOf(currentToken) == 0) {
                var stepHint = new Object();
                stepHint.text = hint;
                stepHint.render = function (element, data, self) {
                    element.innerHTML = "<span class='cm-jb-story-lifecycle-outcome-value'>" + self.text + "</span>";
                };
                var stepHintFrom;
                if (currentToken == "Outcome: ") {
                    stepHintFrom = cursor.ch;
                } else {
                    stepHintFrom = cursor.ch - currentToken.length;
                }
                stepHint.from = CodeMirror.Pos(cursor.line, stepHintFrom);
                var stepHintTo = cursor.ch;
                stepHint.to = CodeMirror.Pos(cursor.line, stepHintTo);
                globalFromCh = stepHint.from.ch;
                globalToCh = stepHint.to.ch;
                list.push(stepHint);
            }
            hint = "SUCCESS";
            if (currentToken == "Outcome: " || hint.indexOf(currentToken) == 0) {
                var stepHint = new Object();
                stepHint.text = hint;
                stepHint.render = function (element, data, self) {
                    element.innerHTML = "<span class='cm-jb-story-lifecycle-outcome-value'>" + self.text + "</span>";
                };
                var stepHintFrom;
                if (currentToken == "Outcome: ") {
                    stepHintFrom = cursor.ch;
                } else {
                    stepHintFrom = cursor.ch - currentToken.length;
                }
                stepHint.from = CodeMirror.Pos(cursor.line, stepHintFrom);
                var stepHintTo = cursor.ch;
                stepHint.to = CodeMirror.Pos(cursor.line, stepHintTo);
                globalFromCh = stepHint.from.ch;
                globalToCh = stepHint.to.ch;
                list.push(stepHint);
            }
            hint = "FAILURE";
            if (currentToken == "Outcome: " || hint.indexOf(currentToken) == 0) {
                var stepHint = new Object();
                stepHint.text = hint;
                stepHint.render = function (element, data, self) {
                    element.innerHTML = "<span class='cm-jb-story-lifecycle-outcome-value'>" + self.text + "</span>";
                };
                var stepHintFrom;
                if (currentToken == "Outcome: ") {
                    stepHintFrom = cursor.ch;
                } else {
                    stepHintFrom = cursor.ch - currentToken.length;
                }
                stepHint.from = CodeMirror.Pos(cursor.line, stepHintFrom);
                var stepHintTo = cursor.ch;
                stepHint.to = CodeMirror.Pos(cursor.line, stepHintTo);
                globalFromCh = stepHint.from.ch;
                globalToCh = stepHint.to.ch;
                list.push(stepHint);
            }

        }

        /**
         * Scenario:
         */
        hint = "Scenario:";
        if (currentState.allowScenario && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-scenario-keyword'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Given
         */
        hint = "Given ";
        if (currentState.allowSteps && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-step-keyword'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * When
         */
        hint = "When ";
        if (currentState.allowSteps && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-step-keyword'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * Then
         */
        hint = "Then ";
        if (currentState.allowSteps && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-step-keyword'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }

        /**
         * And
         */
        hint = "And ";
        if (currentState.allowAndStep && (cursorPos == 0 || hint.indexOf(currentText) == 0)) {
            var stepHint = new Object();
            stepHint.text = hint;
            stepHint.render = function (element, data, self) {
                element.innerHTML = "<span class='cm-jb-story-step-keyword'>" + self.text + "</span>";
            };
            list.push(stepHint);
        }


        var lineHandle = doc.getLineHandle(cursor.line);
        var lineTextSoFar = lineHandle.text.substring(0, cursor.ch);
        var lineTextTrimmed = lineTextSoFar.replace(/\s+$/g, '');
        var stepKeyword = currentState.currentStepKeyword;
        if (lineTextTrimmed.length > 0 && stepKeyword != null) {

            /**
             * hint on steps
             */
            for (var k = 0; k < stepDocs.length; k++) {
                var stepDoc = stepDocs[k];

                if (stepDoc.startingWord == stepKeyword) {

                    var stepStartingKeyword = currentState.stepStartingKeyword;

                    var stepPatternWithKeyword = stepStartingKeyword + stepDoc.pattern;
                    if (stepPatternWithKeyword.substr(0, lineTextSoFar.length) == lineTextSoFar) {
                        var stepHint = new Object();
                        stepHint.text = stepStartingKeyword;
                        if (storyController.prefs != null && storyController.prefs.autoInsertTabularFields && stepDoc.extendedPattern != null) {
                            stepHint.text += stepDoc.extendedPattern;
                        } else {
                            stepHint.text += stepDoc.pattern;
                        }
                        var pattern = stepDoc.pattern;
                        var regExpPattern = new RegExp("(\\$[^\\s]*)", "g");
                        pattern = pattern.replace(regExpPattern, "<span class='cm-jb-story-step-body matched-step step-parameter'>$1</span>");
                        stepHint.markedPattern = pattern;
                        stepHint.stepStartingKeyword = stepStartingKeyword;
                        stepHint.stepDoc = stepDoc;
                        stepHint.render = function (element, data, self) {
                            element.innerHTML =
                                "<span class='cm-jb-story-step-keyword matched-step'>" + self.stepStartingKeyword + "</span>"
                                + self.markedPattern;
                        };
                        list.push(stepHint);
                    }
                }
            }

            // hint on parameters
            var matchedStepClassName = "matched-step";
            var stepParameterClassName = "step-parameter";
            var startOfCursorLine = {line: cursor.line, ch: 0};
            var cursorLineHandle = editor.getLineHandle(cursor.line);
            var endOfCursorLine = {line: cursor.line, ch: cursorLineHandle.text.length};
            var markers = editor.getDoc().findMarks(startOfCursorLine, endOfCursorLine);
            if (markers.length > 0) {
                var foundStepId = null;
                var foundParameterIndex = null;
                for (var m = 0; m < markers.length; m++) {
                    var marker = markers[m];
                    var markerClassName = marker.className;
//                    console.log("marker - " + marker);
                    if (markerClassName.substring(0, matchedStepClassName.length) == matchedStepClassName) {
                        var lastDashPos = markerClassName.lastIndexOf("-");
                        foundStepId = markerClassName.substring(lastDashPos + 1);
                    }
                    if (markerClassName.substring(0, stepParameterClassName.length) == stepParameterClassName) {
                        var lastDashPos = markerClassName.lastIndexOf("-");
                        foundParameterIndex = markerClassName.substring(lastDashPos + 1);
                    }
                }
                if (foundStepId != null && foundParameterIndex != null) {
                    // we can try to hint on parameter value
                    var stepDocWithId = null;
                    for (var k = 0; k < stepDocs.length; k++) {
                        var sd = stepDocs[k];
                        if (sd.id == foundStepId) {
                            stepDocWithId = sd;
                            break;
                        }
                    }
                    if (stepDocWithId != null && stepDocWithId.parameterInfos != null) {
                        var paramInfo = stepDocWithId.parameterInfos[foundParameterIndex];
                        var tabularFieldInfos = paramInfo.tabularFieldInfos;
                        if (tabularFieldInfos != null && tabularFieldInfos.length > 0) {
                            // can try to hint on tabular field names and values
                            // get current tabular column index and value
                            var currentLineHandle = editor.getLineHandle(cursor.line);
                            var currentLineText = currentLineHandle.text;
                            var currentLineTextUpToCursor = currentLineText.substring(0, cursor.ch);
                            if (currentLineTextUpToCursor.substring(0, 1) == "|" && currentLineTextUpToCursor.substring(0, 3) != "|--") {
                                // we subtract 2 here since we always end up with empty token before the first pipe
                                var columnIndex = currentLineTextUpToCursor.split("|").length - 2;
                                var lastPipeIndex = currentLineTextUpToCursor.lastIndexOf("|");
                                var columnStartPos = lastPipeIndex + 1;
                                var columnValue = currentLineTextUpToCursor.substring(columnStartPos);
                                console.log("current column index - " + columnIndex);
                                console.log("current column value - " + columnValue);

                                var isFirstTableLine = true;
                                var actualFirstTableLine = null;
                                var previousLineNum = cursor.line - 1;
                                while (previousLineNum >= 0) {
                                    var previousLine = editor.getLineHandle(previousLineNum);
                                    var previousLineText = previousLine.text;
                                    if (previousLineText.length == 0 || previousLineText.trim().length == 0) {
                                        // empty line, do nothing
                                    } else if (previousLineText.substr(0, 1) == "|" && previousLineText.substr(0, 3) != "|--") {
                                        // current line is not the first line in the table
                                        isFirstTableLine = false;
                                        actualFirstTableLine = previousLineText;
                                    } else {
                                        // non empty and non table line
                                        break;
                                    }
                                    previousLineNum--;
                                }

                                if (isFirstTableLine) {
                                    // hint on field names
                                    for (var t = 0; t < tabularFieldInfos.length; t++) {
                                        var tabularFieldInfo = tabularFieldInfos[t];
                                        var tabularFieldName = tabularFieldInfo.fieldName;
                                        if (columnValue.length == 0 || tabularFieldName.substring(0, columnValue.length) == columnValue) {
                                            // do the hint on field name
                                            var stepHint = new Object();
                                            stepHint.text = tabularFieldName;
                                            stepHint.html = "<span class='cm-jb-story-step-body matched-step step-parameter'>" + tabularFieldName + "</span>";
                                            stepHint.render = function (element, data, self) {
                                                element.innerHTML = self.html;
                                            };
                                            stepHint.from = CodeMirror.Pos(cursor.line, columnStartPos);
                                            stepHint.to = CodeMirror.Pos(cursor.line, columnStartPos + columnValue.length);
                                            list.push(stepHint);
                                            globalFromCh = stepHint.from.ch;
                                            globalToCh = stepHint.to.ch;
                                        }
                                    }
                                } else {
                                    // try to hint on any field allowed values
                                    // get column name for our current column value
                                    var fieldNames = actualFirstTableLine.split("|").slice(1);
                                    var fieldName = fieldNames[columnIndex];
                                    if (fieldName != null && fieldName.trim().length > 0) { // we could be hinting on column index which "exceeds" number of column headers
                                        fieldName = fieldName.trim();
                                        for (var t = 0; t < tabularFieldInfos.length; t++) {
                                            var tabularFieldInfo = tabularFieldInfos[t];
                                            var tabularFieldName = tabularFieldInfo.fieldName;

                                            if (tabularFieldName == fieldName) {
                                                // we have found matching parameter info, hint on allowed values if present
                                                var fieldAllowedValues = tabularFieldInfo.allowedValues;
                                                if (fieldAllowedValues != null && fieldAllowedValues.length > 0) {
                                                    for (var d = 0; d < fieldAllowedValues.length; d++) {
                                                        var fieldAllowedValue = fieldAllowedValues[d];
                                                        if (columnValue.length == 0 || fieldAllowedValue.substring(0, columnValue.length) == columnValue) {
                                                            // do the hint on field allowed value
                                                            var stepHint = new Object();
                                                            stepHint.text = fieldAllowedValue;
                                                            stepHint.html = "<span class='cm-jb-story-step-body matched-step step-parameter'>" + fieldAllowedValue + "</span>";
                                                            stepHint.render = function (element, data, self) {
                                                                element.innerHTML = self.html;
                                                            };
                                                            stepHint.from = CodeMirror.Pos(cursor.line, columnStartPos);
                                                            stepHint.to = CodeMirror.Pos(cursor.line, columnStartPos + columnValue.length);
                                                            list.push(stepHint);
                                                            globalFromCh = stepHint.from.ch;
                                                            globalToCh = stepHint.to.ch;
                                                        }
                                                    }
                                                }
                                            }

                                        }
                                    }

                                }
                            } else {
                                // we are in table comment line, do not hint anything
                            }
                        }

                    } else {
                        console.error("Failed to find step doc with id - " + foundStepId);
                    }
                }
            }
        }

        return {
            list: list,
            from: CodeMirror.Pos(cursor.line, globalFromCh),
            to: CodeMirror.Pos(cursor.line, globalToCh)
        };
    });
});
