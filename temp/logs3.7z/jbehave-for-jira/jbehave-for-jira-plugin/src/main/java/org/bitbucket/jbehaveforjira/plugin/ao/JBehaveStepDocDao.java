package org.bitbucket.jbehaveforjira.plugin.ao;

import com.atlassian.activeobjects.external.ActiveObjects;
import net.java.ao.Query;
import org.jbehave.core.steps.StepType;

import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;

public final class JBehaveStepDocDao {

    private final ActiveObjects ao;

    public JBehaveStepDocDao(ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }

    public JBehaveStepDoc create() {
        return ao.create(JBehaveStepDoc.class);
    }

    public void delete(JBehaveStepDoc stepDoc) {
        ao.delete(stepDoc);
    }

    public JBehaveStepDoc get(Integer id) {
        return ao.get(JBehaveStepDoc.class, id);
    }

    public List<JBehaveStepDoc> findAll() {
        return newArrayList(ao.find(JBehaveStepDoc.class));
    }

    public List<JBehaveStepDoc> findAllForProject(String projectKey) {
        String[] params = new String[]{projectKey};
        Query query = Query.select().where("PROJECT_KEY = ?", params);
        JBehaveStepDoc[] result = ao.find(JBehaveStepDoc.class, query);
        return newArrayList(result);
    }

    public List<JBehaveStepDoc> findByTypeForProject(StepType stepType, String projectKey) {
        String[] params = new String[]{projectKey, stepType.name()};
        Query query = Query.select().where("PROJECT_KEY = ? AND STEP_TYPE = ?", params);
        JBehaveStepDoc[] result = ao.find(JBehaveStepDoc.class, query);
        return newArrayList(result);
    }
}
