package org.bitbucket.jbehaveforjira.plugin.dto.preferences;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class UserPreferencesDTO {

    private boolean showLineNumbers;

    private boolean autoAlignTables;

    private boolean autoInsertTabularFields;

    public boolean isShowLineNumbers() {
        return showLineNumbers;
    }

    public void setShowLineNumbers(boolean showLineNumbers) {
        this.showLineNumbers = showLineNumbers;
    }

    public boolean isAutoAlignTables() {
        return autoAlignTables;
    }

    public void setAutoAlignTables(boolean autoAlignTables) {
        this.autoAlignTables = autoAlignTables;
    }

    public boolean isAutoInsertTabularFields() {
        return autoInsertTabularFields;
    }

    public void setAutoInsertTabularFields(boolean autoInsertTabularFields) {
        this.autoInsertTabularFields = autoInsertTabularFields;
    }
}
