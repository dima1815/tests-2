package org.bitbucket.jbehaveforjira.plugin.service;

import org.apache.commons.lang.Validate;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStepDoc;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStepDocDao;
import org.bitbucket.jbehaveforjira.plugin.dto.stepdoc.StepDocDTO;
import org.bitbucket.jbehaveforjira.plugin.dto.stepdoc.StepDocDTOUtils;

import java.util.ArrayList;
import java.util.List;

public class StepDocsServiceImpl implements StepDocsService {

    private final JBehaveStepDocDao stepDocDao;

    public StepDocsServiceImpl(JBehaveStepDocDao stepDocDao) {
        this.stepDocDao = stepDocDao;
    }

    @Override
    public void createStepDocs(String projectKey, List<StepDocDTO> stepDocs) {

        Validate.notEmpty(projectKey);

        List<JBehaveStepDoc> allForProject = this.stepDocDao.findAllForProject(projectKey);
        for (JBehaveStepDoc stepDoc : allForProject) {
            stepDocDao.delete(stepDoc);
        }

        for (StepDocDTO stepDocDTO : stepDocs) {
            JBehaveStepDoc stepDoc = stepDocDao.create();
            stepDoc.setProjectKey(projectKey);
            StepDocDTOUtils.fromDTOToModel(stepDocDTO, stepDoc);
            stepDoc.save();
        }

    }

    @Override
    public List<StepDocDTO> findForProject(String projectKey) {

        List<JBehaveStepDoc> allForProject = this.stepDocDao.findAllForProject(projectKey);
        return toDTOs(allForProject);
    }

    private List<StepDocDTO> toDTOs(List<JBehaveStepDoc> allForProject) {
        List<StepDocDTO> stepDocDTOs = new ArrayList<StepDocDTO>(allForProject.size());

        for (JBehaveStepDoc stepDoc : allForProject) {
            StepDocDTO stepDocDTO = StepDocDTOUtils.fromModelToDTO(stepDoc);
            stepDocDTOs.add(stepDocDTO);
        }

        return stepDocDTOs;
    }

}
