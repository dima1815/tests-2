package org.bitbucket.jbehaveforjira.plugin.dto.stepdoc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class StepDocDTO {

    private Integer id;
    private String startingWord;
    private String pattern;
    private String resolvedPattern;
    private String groupedRegExpPattern;
    private String stepClassName;
    private String stepMethodSignature;
    private List<Integer> paramBoundInPattern;
    private String extendedPattern;
    private List<Integer> paramBoundInExtendPattern;

    private List<Integer> parameterGroups = new ArrayList<Integer>();

    private List<ParameterInfo> parameterInfos = new ArrayList<ParameterInfo>();

    protected StepDocDTO() {
    }

    public List<Integer> getParamBoundInPattern() {
        return paramBoundInPattern;
    }

    public void setParamBoundInPattern(List<Integer> paramBoundInPattern) {
        this.paramBoundInPattern = paramBoundInPattern;
    }

    public String getExtendedPattern() {
        return extendedPattern;
    }

    public void setExtendedPattern(String extendedPattern) {
        this.extendedPattern = extendedPattern;
    }

    public List<Integer> getParamBoundInExtendPattern() {
        return paramBoundInExtendPattern;
    }

    public void setParamBoundInExtendPattern(List<Integer> paramBoundInExtendPattern) {
        this.paramBoundInExtendPattern = paramBoundInExtendPattern;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStepClassName() {
        return stepClassName;
    }

    public void setStepClassName(String stepClassName) {
        this.stepClassName = stepClassName;
    }

    public String getStepMethodSignature() {
        return stepMethodSignature;
    }

    public void setStepMethodSignature(String stepMethodSignature) {
        this.stepMethodSignature = stepMethodSignature;
    }

    public List<ParameterInfo> getParameterInfos() {
        return parameterInfos;
    }

    public void setParameterInfos(List<ParameterInfo> parameterInfos) {
        this.parameterInfos = parameterInfos;
    }

    public void setStartingWord(String startingWord) {
        this.startingWord = startingWord;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public void setResolvedPattern(String resolvedPattern) {
        this.resolvedPattern = resolvedPattern;
    }

    public String getStartingWord() {
        return startingWord;
    }

    public String getPattern() {
        return pattern;
    }

    public String getResolvedPattern() {
        return resolvedPattern;
    }

    public String getGroupedRegExpPattern() {
        return groupedRegExpPattern;
    }

    public List<Integer> getParameterGroups() {
        return parameterGroups;
    }

    public void setGroupedRegExpPattern(String groupedRegExpPattern) {
        this.groupedRegExpPattern = groupedRegExpPattern;
    }

    public void setParameterGroups(List<Integer> parameterGroups) {
        this.parameterGroups = parameterGroups;
    }

    @Override
    public String toString() {
        return "StepDocDTO{" +
                "startingWord='" + startingWord + '\'' +
                ", pattern='" + pattern + '\'' +
                ", resolvedPattern='" + resolvedPattern + '\'' +
                ", groupedRegExpPattern='" + groupedRegExpPattern + '\'' +
                ", parameterGroups=" + parameterGroups +
                '}';
    }
}
