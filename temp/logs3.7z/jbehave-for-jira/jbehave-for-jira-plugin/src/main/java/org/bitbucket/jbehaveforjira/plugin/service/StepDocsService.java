package org.bitbucket.jbehaveforjira.plugin.service;

import com.atlassian.activeobjects.tx.Transactional;
import org.bitbucket.jbehaveforjira.plugin.dto.stepdoc.StepDocDTO;

import java.util.List;

@Transactional
public interface StepDocsService {

    void createStepDocs(String projectKey, List<StepDocDTO> stepDocs);

    List<StepDocDTO> findForProject(String projectKey);

}
