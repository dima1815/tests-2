package org.bitbucket.jbehaveforjira.plugin.service;

import com.atlassian.activeobjects.tx.Transactional;
import org.bitbucket.jbehaveforjira.plugin.dto.storyreport.JiraStoryHtml;

import java.util.List;

@Transactional
public interface StoryReportService {

    void addStoryTestReport(String projectKey, String issueKey, JiraStoryHtml storyReportDTO);

    List<JiraStoryHtml> findStoryReports(String projectKey, String issueKey);

    void deleteForIssue(String projectKey, String issueKey);
}
