package org.bitbucket.jbehaveforjira.plugin.conditions;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.project.Project;
import com.atlassian.plugin.PluginParseException;
import com.atlassian.plugin.web.Condition;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStory;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStoryDao;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStoryReport;
import org.apache.commons.lang.Validate;

import java.util.List;
import java.util.Map;

public class JiraIssueHasStoryReportsCondition implements Condition {

    private JBehaveStoryDao storyDao;

    public JiraIssueHasStoryReportsCondition(JBehaveStoryDao storyDao) {

        this.storyDao = storyDao;
    }

    @Override
    public void init(Map<String, String> params) throws PluginParseException {
    }

    @Override
    public boolean shouldDisplay(Map<String, Object> context) {

        Project project = (Project) context.get("project");
        String projectKey = project.getKey();
        Issue issue = (Issue) context.get("issue");
        String isssueKey = issue.getKey();
        List<JBehaveStory> stories = storyDao.findByProjectAndIssueKey(projectKey, isssueKey);

        if (stories.isEmpty()) {
            return false;
        } else {
            // check if there are reports
            Validate.isTrue(stories.size() == 1);
            JBehaveStory story = stories.get(0);
            JBehaveStoryReport[] storyHtmlReports = story.getStoryReports();
            return storyHtmlReports.length != 0;
        }
    }
}
