package org.bitbucket.jbehaveforjira.plugin.dto.stepdoc;


import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStepDoc;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StepDocDTOUtils {

    public static void fromDTOToModel(StepDocDTO stepDocDTO, JBehaveStepDoc stepDoc) {

        stepDoc.setStartingWord(stepDocDTO.getStartingWord());
        stepDoc.setPattern(stepDocDTO.getPattern());
        stepDoc.setRegExpPattern(stepDocDTO.getResolvedPattern());
        stepDoc.setGroupedRegExpPattern(stepDocDTO.getGroupedRegExpPattern());

        List<Integer> parameterGroups = stepDocDTO.getParameterGroups();
        String parameterGroupsAsString = asCommaSepString(parameterGroups);
        stepDoc.setParameterGroups(parameterGroupsAsString);

        // set parameter group infos
        List<ParameterInfo> parameterInfos = stepDocDTO.getParameterInfos();
        if (parameterInfos != null && !parameterInfos.isEmpty()) {
            ObjectMapper mapper = new ObjectMapper();
            String parameterInfosAsString;
            try {
                parameterInfosAsString = mapper.writeValueAsString(parameterInfos);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            stepDoc.setParameterInfos(parameterInfosAsString);
        }

        List<Integer> paramBoundInPattern = stepDocDTO.getParamBoundInPattern();
        String paramBoundInPatternAsString = asCommaSepString(paramBoundInPattern);
        stepDoc.setParamBoundInPattern(paramBoundInPatternAsString);

        String extendedPattern = stepDocDTO.getExtendedPattern();
        stepDoc.setExtendedPattern(extendedPattern);

        List<Integer> paramBoundInExtendPattern = stepDocDTO.getParamBoundInExtendPattern();
        String paramBoundInExtendPatternAsString = asCommaSepString(paramBoundInExtendPattern);
        stepDoc.setParamBoundInExtendPattern(paramBoundInExtendPatternAsString);
    }

    public static StepDocDTO fromModelToDTO(JBehaveStepDoc stepDoc) {

        StepDocDTO stepDocDTO = new StepDocDTO();

        String startingWord = stepDoc.getStartingWord();
        String pattern = stepDoc.getPattern();
        String regExpPattern = stepDoc.getRegExpPattern();
        String groupedRegExpPattern = stepDoc.getGroupedRegExpPattern();
        String parameterGroupsStr = stepDoc.getParameterGroups();

        stepDocDTO.setId(stepDoc.getID());
        stepDocDTO.setStartingWord(startingWord);
        stepDocDTO.setPattern(pattern);
        stepDocDTO.setResolvedPattern(regExpPattern); // TODO - align name in DAO and DTO objects
        stepDocDTO.setGroupedRegExpPattern(groupedRegExpPattern);

        List<Integer> parameterGroups = asListOfInts(parameterGroupsStr);;
        stepDocDTO.setParameterGroups(parameterGroups);

        // set parameter group infos
        String parameterInfosAsString = stepDoc.getParameterInfos();
        if (parameterInfosAsString != null) {
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
            List<ParameterInfo> parameterInfos;
            try {
                parameterInfos = mapper.readValue(parameterInfosAsString,
                        mapper.getTypeFactory().constructCollectionType(List.class, ParameterInfo.class));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            stepDocDTO.setParameterInfos(parameterInfos);
        }

        String paramBoundInPatternAsString = stepDoc.getParamBoundInPattern();
        List<Integer> paramBoundInPattern = asListOfInts(paramBoundInPatternAsString);
        stepDocDTO.setParamBoundInPattern(paramBoundInPattern);

        String extendedPattern = stepDoc.getExtendedPattern();
        stepDocDTO.setExtendedPattern(extendedPattern);

        String paramBoundInExtendPatternAsString = stepDoc.getParamBoundInExtendPattern();
        List<Integer> paramBoundInExtendPattern = asListOfInts(paramBoundInExtendPatternAsString);
        stepDocDTO.setParamBoundInExtendPattern(paramBoundInExtendPattern);

        return stepDocDTO;
    }

    public static List<StepDocDTO> fromModelToDTO(List<JBehaveStepDoc> stepDocs) {

        List<StepDocDTO> results = new ArrayList<StepDocDTO>(stepDocs.size());
        for (JBehaveStepDoc stepDoc : stepDocs) {
            StepDocDTO stepDocDTO = fromModelToDTO(stepDoc);
            results.add(stepDocDTO);
        }

        return results;
    }

    private static String asCommaSepString(List<Integer> listOfInts) {
        StringBuilder sb = new StringBuilder();
        if (listOfInts != null ) {
            for (int i = 0; i < listOfInts.size(); i++) {
                Integer parameterGroup = listOfInts.get(i);
                sb.append(parameterGroup.toString());
                if (i < listOfInts.size() - 1) {
                    sb.append(",");
                }
            }
        }
        String asString = sb.toString();
        return asString;
    }

    private static List<Integer> asListOfInts(String asCommaSepString) {
        List<Integer> asListOfInts;
        if (asCommaSepString != null && !asCommaSepString.isEmpty()) {
            String[] strGroups = asCommaSepString.split(",");
            asListOfInts = new ArrayList<Integer>(strGroups.length);
            for (String strGroup : strGroups) {
                Integer intGroup = Integer.parseInt(strGroup);
                asListOfInts.add(intGroup);
            }
        } else {
            asListOfInts = Collections.emptyList();
        }
        return asListOfInts;
    }
}
