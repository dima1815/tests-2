package org.bitbucket.jbehaveforjira.plugin.ao;

import com.atlassian.activeobjects.external.ActiveObjects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;

public final class JBehaveStoryReportDao {

    private final Logger log = LoggerFactory.getLogger(getClass());

    private final ActiveObjects ao;

    public JBehaveStoryReportDao(ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }

    public JBehaveStoryReport createStoryHtmlReport() {
        return ao.create(JBehaveStoryReport.class);
    }

    public void delete(JBehaveStoryReport storyHtmlReport) {
        ao.delete(storyHtmlReport);
    }

    public JBehaveStoryReport get(Integer id) {
        return ao.get(JBehaveStoryReport.class, id);
    }

    public List<JBehaveStoryReport> findAll() {
        return newArrayList(ao.find(JBehaveStoryReport.class));
    }

}
