package org.bitbucket.jbehaveforjira.plugin.service;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.security.JiraAuthenticationContext;
import org.apache.commons.lang.Validate;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStory;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStoryDao;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStoryReport;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStoryReportDao;
import org.bitbucket.jbehaveforjira.plugin.dto.story.JiraStory;
import org.bitbucket.jbehaveforjira.plugin.dto.story.StoryDTOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class StoryServiceImpl implements StoryService {

    private final Logger log = LoggerFactory.getLogger(getClass());

    private final IssueService is;

    private final JiraAuthenticationContext authenticationContext;

    private final JBehaveStoryDao storyDao;

    private final JBehaveStoryReportDao storyReportDao;

    private final StepDocsService stepDocsSerivce;

    private StoryReportService storyReportService;

    public StoryServiceImpl(JBehaveStoryDao storyDao, JBehaveStoryReportDao storyReportDao,
                            IssueService is,
                            JiraAuthenticationContext authenticationContext,
                            StepDocsService stepDocsSerivce,
                            StoryReportService storyReportService) {
        this.storyDao = storyDao;
        this.storyReportDao = storyReportDao;
        this.is = is;
        this.authenticationContext = authenticationContext;
        this.stepDocsSerivce = stepDocsSerivce;
        this.storyReportService = storyReportService;
    }

    @Override
    public synchronized JiraStory saveOrUpdate(JiraStory storyDTO) {

        String issueKey = storyDTO.getIssueKey();
        User user = authenticationContext.getLoggedInUser();
        IssueService.IssueResult issue = is.getIssue(user, issueKey);
        Validate.notNull(issue, "Could not find issue for key - " + issueKey);

        Long version = storyDTO.getVersion();
        if (version == null) {

            // create
            List<JBehaveStory> byProjectAndIssueKey = storyDao.findByProjectAndIssueKey(storyDTO.getProjectKey(), storyDTO.getIssueKey());
            Validate.isTrue(byProjectAndIssueKey.isEmpty(), "Issue with key - " + storyDTO.getIssueKey() + " already has story attached");
            return this.create(storyDTO, user.getName());

        } else {

            // update
            List<JBehaveStory> byProjectAndIssueKey = storyDao.findByProjectAndIssueKey(storyDTO.getProjectKey(), storyDTO.getIssueKey());
            Validate.isTrue(!byProjectAndIssueKey.isEmpty(), "Editing story failed - issue with key - " + storyDTO.getIssueKey() + " does not have any stories attached");
            Validate.isTrue(byProjectAndIssueKey.size() == 1);

            JBehaveStory story = byProjectAndIssueKey.get(0);
            Long storedVersion = story.getVersion();
            Long receivedVersion = storyDTO.getVersion();
            if (!storedVersion.equals(receivedVersion)) {
                String lastEditedBy = story.getLastEditedBy();
                throw new RuntimeException("Story for issue - " + storyDTO.getIssueKey() + " has been modified by another user (" + lastEditedBy + ").");
            } else {
                return this.update(story, storyDTO, user.getName());
            }

        }
    }

    private JiraStory create(JiraStory storyDTO, String userName) {

        final JBehaveStory story = storyDao.create();
        story.setVersion(1L);
        story.setIssueKey(storyDTO.getIssueKey());
        story.setProjectKey(storyDTO.getProjectKey());
        story.setAsString(storyDTO.getAsString());
        story.setLastEditedBy(userName);
        story.save();

        JiraStory byId = this.findById(story.getID());
        return byId;
    }

    private JiraStory update(JBehaveStory story, JiraStory storyDTO, String userName) {

        long currentVersion = story.getVersion();
        long rolledVersion = currentVersion + 1;
        story.setVersion(rolledVersion);
        story.setAsString(storyDTO.getAsString());

        story.setLastEditedBy(userName);
        story.save();

        JiraStory byId = this.findById(story.getID());
        return byId;
    }

    @Override
    public JiraStory findByProjectAndIssueKey(String projectKey, String issueKey) {

        List<JBehaveStory> byIssueKey = storyDao.findByProjectAndIssueKey(projectKey, issueKey);
        if (byIssueKey.isEmpty()) {
            return null;
        } else if (byIssueKey.size() > 1) {
            throw new RuntimeException("More than one story was found for issue key - " + issueKey);
        } else {

            JBehaveStory story = byIssueKey.get(0);

            JiraStory storyDTO = StoryDTOUtils.toDTO(story);
            return storyDTO;
        }
    }

    @Override
    public List<JiraStory> findByProjectKey(String projectKey) {

        List<JBehaveStory> stories = storyDao.findByProjectKey(projectKey);

        List<JiraStory> storyDTOs = new ArrayList<JiraStory>(stories.size());
        for (JBehaveStory story : stories) {
            JiraStory storyDTO = StoryDTOUtils.toDTO(story);
            storyDTOs.add(storyDTO);
        }

        return storyDTOs;
    }

    @Override
    public JiraStory findById(int storyId) {

        JBehaveStory story = storyDao.get(storyId);

        JiraStory storyModel = StoryDTOUtils.toDTO(story);
        return storyModel;
    }

    @Override
    public void delete(Long storyId) {
        JBehaveStory story = storyDao.get(storyId.intValue());
        deleteStory(story);
    }

    @Override
    public void delete(String projectKey, String issueKey) {
        List<JBehaveStory> stories = storyDao.findByProjectAndIssueKey(projectKey, issueKey);
        for (JBehaveStory story : stories) {
            deleteStory(story);
        }
    }

    private void deleteStory(JBehaveStory story) {

        // delete story reports
        JBehaveStoryReport[] storyTestReports = story.getStoryReports();
        for (JBehaveStoryReport storyTestReport : storyTestReports) {
            storyReportDao.delete(storyTestReport);
        }

        storyDao.delete(story);
    }
}
