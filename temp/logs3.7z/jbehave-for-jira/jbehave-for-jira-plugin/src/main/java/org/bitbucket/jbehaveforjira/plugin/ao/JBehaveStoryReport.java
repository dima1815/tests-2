package org.bitbucket.jbehaveforjira.plugin.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;

@Preload
public interface JBehaveStoryReport extends Entity {

    JBehaveStory getStory();

    void setStory(JBehaveStory story);

    String getEnvironment();

    void setEnvironment(String environment);

    String getStatus();

    void setStatus(String testStatus);

    Long getStoryVersion();

    void setStoryVersion(Long storyVersion);

    String getHtmlReport();

    void setHtmlReport(String htmlReport);

    Integer getTotalScenarios();

    void setTotalScenarios(Integer totalScenarios);

    Integer getTotalScenariosPassed();

    void setTotalScenariosPassed(Integer totalScenariosPassed);

    Integer getTotalScenariosFailed();

    void setTotalScenariosFailed(Integer totalScenariosFailed);

    Integer getTotalScenariosPending();

    void setTotalScenariosPending(Integer totalScenariosPending);

    Integer getTotalScenariosSkipped();

    void setTotalScenariosSkipped(Integer totalScenariosSkipped);

    Integer getTotalScenariosNotPerformed();

    void setTotalScenariosNotPerformed(Integer totalScenariosNotPerformed);
}
