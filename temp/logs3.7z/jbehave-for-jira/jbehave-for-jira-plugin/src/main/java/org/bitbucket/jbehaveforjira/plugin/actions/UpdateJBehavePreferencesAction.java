package org.bitbucket.jbehaveforjira.plugin.actions;

import com.atlassian.core.user.preferences.Preferences;
import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.xsrf.RequiresXsrfCheck;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.preferences.UserPreferencesManager;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import org.ofbiz.core.entity.GenericValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import webwork.action.ActionContext;

import java.util.Map;

public class UpdateJBehavePreferencesAction extends JiraWebActionSupport {

    private static final Logger log = LoggerFactory.getLogger(UpdateJBehavePreferencesAction.class);

    private final static String PARAM_NAME_SHOW_LINE_NUMBERS = "showLineNumbers";
    public final static String PREFERENCE_KEY_SHOW_LINE_NUMBERS = "jbehave.prefs.showLineNumbers";

    private final static String PARAM_NAME_AUTO_ALIGN_TABLES = "autoAlignTables";
    public final static String PREFERENCE_KEY_AUTO_ALIGN_TABLES = "jbehave.prefs.autoAlignTables";

    private final static String PARAM_NAME_AUTO_INSERT_TABLES = "autoInsertTabularFields";
    public final static String PREFERENCE_KEY_AUTO_INSERT_TABLES = "jbehave.prefs.autoInsertTabularFields";

    private Long id;

    private boolean showLineNumbers;

    private boolean autoAlignTables;

    private boolean autoInsertTabularFields;

    private final IssueService issueService;

    private final JiraAuthenticationContext authenticationContext;

    private UserPreferencesManager preferencesManager;

    public UpdateJBehavePreferencesAction(IssueService issueService,
                                          JiraAuthenticationContext authenticationContext,
                                          final UserPreferencesManager preferencesManager) {
        this.issueService = issueService;
        this.authenticationContext = authenticationContext;

        this.preferencesManager = preferencesManager;
    }

    @RequiresXsrfCheck
    protected String doExecute() throws Exception {

        ApplicationUser user = authenticationContext.getUser();
        final Preferences preferences = preferencesManager.getPreferences(user);

        Map parameters = ActionContext.getParameters();

        String[] showLineNumbersParam = (String[]) parameters.get(PARAM_NAME_SHOW_LINE_NUMBERS);
        if (showLineNumbersParam != null && showLineNumbersParam.length > 0 && showLineNumbersParam[0].equals("on")) {
            this.showLineNumbers = true;
        } else{
            this.showLineNumbers = false;
        }
        preferences.setBoolean(PREFERENCE_KEY_SHOW_LINE_NUMBERS, this.showLineNumbers);

        String[] autoAlignTablesParam = (String[]) parameters.get(PARAM_NAME_AUTO_ALIGN_TABLES);
        if (autoAlignTablesParam != null && autoAlignTablesParam.length > 0 && autoAlignTablesParam[0].equals("on")) {
            this.autoAlignTables = true;
        } else {
            this.autoAlignTables = false;
        }
        preferences.setBoolean(PREFERENCE_KEY_AUTO_ALIGN_TABLES, this.autoAlignTables);

        String[] autoInsertTabularFieldsParam = (String[]) parameters.get(PARAM_NAME_AUTO_INSERT_TABLES);
        if (autoInsertTabularFieldsParam != null && autoInsertTabularFieldsParam.length > 0 && autoInsertTabularFieldsParam[0].equals("on")) {
            this.autoInsertTabularFields = true;
        } else {
            this.autoInsertTabularFields = false;
        }
        preferences.setBoolean(PREFERENCE_KEY_AUTO_INSERT_TABLES, this.autoInsertTabularFields);

        // We want to redirect back to the view issue page so
        return returnComplete("/browse/" + this.getIssue().getKey());
    }

    public String doDefault() throws Exception {

        ApplicationUser user = authenticationContext.getUser();
        final Preferences preferences = preferencesManager.getPreferences(user);

        this.showLineNumbers = preferences.getBoolean(PREFERENCE_KEY_SHOW_LINE_NUMBERS);
        this.autoAlignTables = preferences.getBoolean(PREFERENCE_KEY_AUTO_ALIGN_TABLES);
        this.autoInsertTabularFields = preferences.getBoolean(PREFERENCE_KEY_AUTO_INSERT_TABLES);

        return INPUT;
    }

    public GenericValue getProject() {
        return getIssue().getProject();
    }

    public Issue getIssue() {
        return getIssueObject();
    }

    public Issue getIssueObject() {
        final IssueService.IssueResult issueResult = issueService.getIssue(authenticationContext.getLoggedInUser(), id);
        if (!issueResult.isValid()) {
            this.addErrorCollection(issueResult.getErrorCollection());
            return null;
        }

        return issueResult.getIssue();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isShowLineNumbers() {
        return showLineNumbers;
    }

    public void setShowLineNumbers(boolean showLineNumbers) {
        this.showLineNumbers = showLineNumbers;
    }

    public boolean isAutoAlignTables() {
        return autoAlignTables;
    }

    public void setAutoAlignTables(boolean autoAlignTables) {
        this.autoAlignTables = autoAlignTables;
    }

    public boolean isAutoInsertTabularFields() {
        return autoInsertTabularFields;
    }

    public void setAutoInsertTabularFields(boolean autoInsertTabularFields) {
        this.autoInsertTabularFields = autoInsertTabularFields;
    }
}
