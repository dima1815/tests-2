package org.bitbucket.jbehaveforjira.plugin.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;

@Preload
public interface JBehaveStepDoc extends Entity {

    String getProjectKey();

    void setProjectKey(String projectKey);

    String getStartingWord();

    void setStartingWord(String startingWord);

    String getPattern();

    void setPattern(String pattern);

    String getRegExpPattern();

    void setRegExpPattern(String regExpPattern);

    String getGroupedRegExpPattern();

    void setGroupedRegExpPattern(String groupedRegExpPattern);

    String getParameterGroups();

    void setParameterGroups(String parameterGroups);

    String getParameterInfos();

    void setParameterInfos(String parameterInfos);

    String getParamBoundInPattern();

    void setParamBoundInPattern(String paramBoundInPattern);

    String getExtendedPattern();

    void setExtendedPattern(String extendedPattern);

    String getParamBoundInExtendPattern();

    void setParamBoundInExtendPattern(String ParamBoundInExtendPattern);
}
