package org.bitbucket.jbehaveforjira.plugin.rest;

import com.atlassian.core.user.preferences.Preferences;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.preferences.UserPreferencesManager;
import org.bitbucket.jbehaveforjira.plugin.actions.UpdateJBehavePreferencesAction;
import org.bitbucket.jbehaveforjira.plugin.dto.preferences.UserPreferencesDTO;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/preferences")
public class UserPreferencesResource {

    private JiraAuthenticationContext authenticationContext;
    private UserPreferencesManager preferencesManager;

    public UserPreferencesResource(JiraAuthenticationContext authenticationContext,
                                   UserPreferencesManager preferencesManager) {

        this.authenticationContext = authenticationContext;
        this.preferencesManager = preferencesManager;
    }

    @GET
    @Path("/for-user")
    @Produces({MediaType.APPLICATION_JSON})
    public UserPreferencesDTO getForCurrentUser(){

        ApplicationUser user = authenticationContext.getUser();
        final Preferences preferences = preferencesManager.getPreferences(user);

        boolean showLineNumbers = preferences.getBoolean(UpdateJBehavePreferencesAction.PREFERENCE_KEY_SHOW_LINE_NUMBERS);
        boolean autoAlignTables = preferences.getBoolean(UpdateJBehavePreferencesAction.PREFERENCE_KEY_AUTO_ALIGN_TABLES);
        boolean autoInsertTabularFields = preferences.getBoolean(UpdateJBehavePreferencesAction.PREFERENCE_KEY_AUTO_INSERT_TABLES);

        UserPreferencesDTO userPrefs = new UserPreferencesDTO();
        userPrefs.setShowLineNumbers(showLineNumbers);
        userPrefs.setAutoAlignTables(autoAlignTables);
        userPrefs.setAutoInsertTabularFields(autoInsertTabularFields);
        return userPrefs;
    }


}
