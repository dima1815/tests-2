package org.bitbucket.jbehaveforjira.exampleproject;

import org.bitbucket.jbehaveforjira.groovyclient.GroovyStepDocReporter;
import org.bitbucket.jbehaveforjira.groovyclient.GroovyStoryLoader;
import org.bitbucket.jbehaveforjira.groovyclient.GroovyStoryPathsFinder;
import org.bitbucket.jbehaveforjira.groovyclient.GroovyStoryReporter;
import org.bitbucket.jbehaveforjira.javaclient.StoryPathsFinder;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.junit.JUnitStories;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StepdocReporter;
import org.jbehave.core.reporters.StoryReporter;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.CandidateSteps;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.junit.Test;

import java.util.List;

/**
 * @author Maryna Stasyuk
 */
public class BookStoreTest extends JUnitStories {

    private final String jiraUrl = "http://localhost:2990/jira";

    private final String jiraProject = "TESTING";

    private final String environment = "TEST";

    public BookStoreTest() {

        MostUsefulConfiguration configuration = new MostUsefulConfiguration();

        // set custom Jira HTML output format
        configuration.useStoryReporterBuilder(
                new StoryReporterBuilder() {
                    public StoryReporter reporterFor(String storyPath, org.jbehave.core.reporters.Format format) {
                        if (format.equals(org.jbehave.core.reporters.Format.HTML)) {
//                            return new JiraStoryReporter(jiraUrl, jiraProject, "admin", "admin", environment);
                            return new GroovyStoryReporter(jiraUrl, jiraProject, "admin", "admin", environment);
                        } else {
                            return super.reporterFor(storyPath, format);
                        }
                    }
                }
                        .withFailureTrace(true)
                        .withFormats(
                                Format.CONSOLE,
                                Format.HTML,
                                Format.STATS
                        )
        );

        // set Jira story loader
//        JiraStoryLoader jiraLoader = new JiraStoryLoader(jiraUrl, jiraProject, "admin", "admin");
        GroovyStoryLoader jiraLoader = new GroovyStoryLoader(jiraUrl, jiraProject, "admin", "admin", true);
        configuration.useStoryLoader(jiraLoader);

        // set Jira step doc reporter
//        StepdocReporter stepDocReporter = new JiraStepDocReporter(jiraUrl, jiraProject, "admin", "admin");
        StepdocReporter stepDocReporter = new GroovyStepDocReporter(jiraUrl, jiraProject, "admin", "admin");
//        StepdocReporter stepDocReporter = new org.bitbucket.jbehaveforjira.javaclient.GroovyStepDocReporter(jiraUrl, jiraProject);
        configuration.useStepdocReporter(stepDocReporter);

        useConfiguration(configuration);
    }

    @Test
    public void run() throws Throwable {

        Embedder embedder = configuredEmbedder();
        try {
            embedder.runStoriesAsPaths(storyPaths());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // report step docs
            List<CandidateSteps> candidateSteps = embedder.stepsFactory().createCandidateSteps();
            embedder.reportStepdocs(configuration(), candidateSteps);
        }
    }

    @Override
    public InjectableStepsFactory stepsFactory() {
        return new InstanceStepsFactory(configuration(), new BookRelatedSteps());
    }

    @Override
    protected List<String> storyPaths() {

//        JiraStoryPathsFinder storyFinder = new JiraStoryPathsFinder(jiraUrl, jiraProject, "admin", "admin");
        StoryPathsFinder storyFinder = new GroovyStoryPathsFinder(jiraUrl, jiraProject, "admin", "admin");
        List<String> paths = storyFinder.findPaths();
        return paths;
    }
}
