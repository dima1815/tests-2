package org.bitbucket.jbehaveforjira.exampleproject;

import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.When;

import java.util.List;

/**
 * @author Maryna Stasyuk
 */
public class BookRelatedSteps {

    private BookStore bookStore = new BookStore();

    @When("something happens")
    public void whenSomething() {

    }

    @Given("the following book: $book")
    public void givenBook(Book book) {

        bookStore.add(book);
    }

    @Given("the following books: $books")
    public void givenBooks(List<Book> books) {

        bookStore.add(books);
    }

    @Given("a stock of symbol $symbol and a threshold of $threshold")
    @Alias("a stock of symbol <symbol> and a threshold of <threshold>")
    public void aStock(@Named("symbol") String symbol, @Named("threshold") double threshold) {
        // ...
    }

}
