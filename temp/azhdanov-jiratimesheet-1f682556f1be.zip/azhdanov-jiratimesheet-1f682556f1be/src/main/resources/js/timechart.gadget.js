var Time = {};

Time.getTemplate = function(args) {
    var gadget = this;

    var userTitle = gadget.getPref("gadgetTitle") || gadget.getPrefs().getMsg('gadget.timechart.title');
    if (userTitle != null && userTitle != '') {
        gadgets.window.setTitle(userTitle);
    }

    var width = gadgets.window.getViewportDimensions().width || 600;
    var height = width / 2;

    // This is used to pass the name of filter or project to the picker
    gadget.projectOrFilterName = args.timesheet.projectOrFilterName;
    var html = '<div id="placeholder" style="height: ' + height + '; width: ' + width + '"></div>';
    var licenseMsgHtml = args.timesheet.licenseMsgHtml;
    var hasLicense = licenseMsgHtml == null || licenseMsgHtml == '';
    gadget.getView().html(hasLicense ? html : '<div style="padding: 3px 7px">' + licenseMsgHtml + '</div>');

    gadget.showView(false, false);
    if (hasLicense) {
        var data = args.timesheet.entries;

        if (data.length > 0) {
            // see http://people.iola.dk/olau/flot/examples/pie.html
            AJS.$.plot(AJS.$("#placeholder"), data, {
                series: {
                    pie: {
                        show: true,
                        radius: .9,
                        label: {
                            show: true,
                            radius: .8,
                            formatter: function(label, series){
                                return Time.composeTooltip(series.label, series, data);
                            },
                            background: { opacity: 0.8 },
                            threshold: 0.05
                        },
                        offset: {
                            left: -height/2
                        }
                    }
                },
                grid: {
                    color: '#999'
                },
                legend: {
                    show: true,
                    margin: [0, 23],
                    labelFormatter: function(label, series) {
                        return Time.composeLegendTooltip(label, series, data);
                    }
                }
            });
            function wrapLegend() {
                var $legend = AJS.$("#placeholder .legend");
                $legend.find("table tr:first").first()
                    .before("<tr>" +
                                "<td colspan='2'>" +
                                    args.timesheet.chartTitle +
                                "</td>" +
                            "</tr>" +
                            "<tr>" +
                                "<td colspan='2'>" +
                                    args.timesheet.sliderHtml + "<br/>" +
                                "</td>" +
                            "</tr>");    
                $legend.find("table tbody").first()
                    .append("<tr>" +
                                "<td colspan='2'>" +
                                    "<br/>" + gadget.getMsg("gadget.timesheet.total") + ' ' + Time.sumAllHours(data) + ' h' +
                                '</td>' +
                            '</tr>');
            }
            wrapLegend();        
            AJS.$("#placeholder").resize(wrapLegend);
        } else {
            var noDataText = gadget.getMsg('gadget.timesheet.noentries');
            AJS.$("#placeholder")
                    .css('height', '100px')
                    .append("<table style='position: absolute; top: 23px; right: 0; margin-right: 5px; width: " + width / 2.67 + "px;'>" + 
                        "<tr>" +
                            "<td colspan='2'>" +
                                args.timesheet.chartTitle +
                            "</td>" +
                        "</tr>" +
                        "<tr>" +
                            "<td colspan='2'>" +
                                args.timesheet.sliderHtml + "<br/>" +
                            "</td>" +
                        "</tr>" +
                        "<tr>" +
                            "<td colspan='2'>" +
                                noDataText +
                            "</td>" +
                        "</tr></table>");
        }
        TimesheetSlider.slider(gadget);
    }
    AJS.$('.legend > *').width(height * .75);
    gadget.hideLoading();
};

Time.getDescriptor = function(args, gadget, group_timesheet) {
    var gadget = gadget || this;
    var descriptor = {
        fields: [
            {
                userpref: "gadgetTitle",
                label: gadget.getMsg("gadget.pref.label.gadgetTitle"),
                type: "text",
                value: gadget.getPref("gadgetTitle")
            },
            {
                userpref: "num_weeks",
                label: gadget.getMsg("gadget.pref.label.num_weeks"),
                type: "text",
                value: gadget.getPref("num_weeks")
            },
            {
                userpref: "reporting_day",
                label: gadget.getMsg("gadget.pref.label.reporting_day"),
                type: "select",
                selected: gadget.getPref("reporting_day"),
                options: [
                    {label: "", value: ""},
                    {label: gadget.getMsg("gadget.timesheet.today"), value: "0"},
                    {label: gadget.getMsg("gadget.timesheet.Monday"), value: "2"},
                    {label: gadget.getMsg("gadget.timesheet.Tuesday"), value: "3"},
                    {label: gadget.getMsg("gadget.timesheet.Wednesday"), value: "4"},
                    {label: gadget.getMsg("gadget.timesheet.Thursday"), value: "5"},
                    {label: gadget.getMsg("gadget.timesheet.Friday"), value: "6"},
                    {label: gadget.getMsg("gadget.timesheet.Saturday"), value: "7"},
                    {label: gadget.getMsg("gadget.timesheet.Sunday"), value: "1"}
                ]
            },
            {
                userpref: "group",
                label: gadget.getMsg("gadget.pref.label.group"),
                type: "multiselect",
                selected: gadget.getPref("group"),
                options: args.groups.values
            },
            {
                userpref: "excludeGroup",
                label: gadget.getMsg("gadget.pref.label.excludeGroup"),
                type: "multiselect",
                selected: gadget.getPref("excludeGroup"),
                options: args.excludeGroups.values
            },
            {
                userpref: "projectRole",
                label: gadget.getMsg("gadget.pref.label.projectRole"),
                type: "select",
                selected: gadget.getPref("projectRole"),
                options: args.projectRoles.values
            },
            TimesheetUtils.extendProjectOrFilterPicker(gadget, AJS.$.extend(AJS.gadget.fields.projectOrFilterPicker(gadget, "projectOrFilter"),
             {label: gadget.getMsg("gadget.pref.label.projectOrFilter"), description: ""})),
            {
                userpref: "sumSubTasks",
                label: gadget.getMsg("gadget.pref.label.sumSubTasks"),
                type: "select",
                selected: gadget.getPref("sumSubTasks"),
                options: [
                    {label: gadget.getMsg("gadget.timesheet.yes"), value: "true"},
                    {label: gadget.getMsg("gadget.timesheet.no"), value: "false"}
                ]
            },
            {
                userpref: "groupByField",
                label: gadget.getMsg("gadget.pref.label.groupByField"),
                type: "select",
                selected: gadget.getPref("groupByField"),
                options: args.groupByField.values
            },
            AJS.gadget.fields.nowConfigured()
        ]
    };
    
    return descriptor;
};

Time.composeTooltip = function(label, series, data) {
    var tooltipHint = Time.getTooltipHint(data, label);
    var tooltipUrl = Time.getTooltipUrl(data, label);
    var icons = Time.getTooltipIcons(data, label);
    return '<table cellspacing="2px" cellpadding="2px">' +
            '<tr>' +
                Time.prepareHtmlForIcons(icons, "<br/>") +
                '<td>' +
                    Time.prepareLinkForItem(tooltipHint, tooltipUrl, label) + 
                    '<br/>' + Math.round(series.percent) + '%' +
                '</td>' +
            '</tr>' +
            '</table>';
};

Time.composeLegendTooltip = function(label, series, data) {
    var tooltipHint = Time.getTooltipHint(data, label);
    var tooltipUrl = Time.getTooltipUrl(data, label);
    var icons = Time.getTooltipIcons(data, label);
    return '<table>' +
            '<tr>' +
                Time.prepareHtmlForIcons(icons, "") +
                '<td>' + Time.prepareLinkForItem(tooltipHint, tooltipUrl, label) + 
                '&nbsp;(' + Time.calculateHours(series.data[0][1]) + 'h)' +
                 '</td>' +
            '</tr>' +
            '</table>';
};

Time.prepareLinkForItem = function(tooltipHint, tooltipUrl, label) {
    if (tooltipUrl) {
        return '<a title="'+tooltipHint+'" href="'+tooltipUrl+'">' + label + '</a>';
    } else {
        return label;
    }
}

Time.calculateHours = function(seconds) {
    return Math.round(seconds / 36) / 100;
};

Time.getTooltipUrl = function(data, label) {
    var item = Time.getDataItemByLabel(data, label);
    if (item != null) {
        return item.url;
    }
    return "#";
};

Time.getTooltipIcons = function(data, label) {
    var item = Time.getDataItemByLabel(data, label);
    if (item != null) {
        return item.icons;
    }
    return null;
};

Time.getTooltipHint = function(data, label) {
    var item = Time.getDataItemByLabel(data, label);
    if (item != null && item.hint != null) {
        return item.hint;
    }
    return '';
};

Time.getDataItemByLabel = function(data, label) {
    for (var i = 0; i < data.length; i++) {
        if (data[i].label == label) {
            return data[i];
        }
    }
    return null;
};

Time.prepareHtmlForIcons = function(icons, separator) {
    var html = "";
    if (icons != null && icons.length > 0) {
        var width = (separator == '') ? 16 * icons.length : 16;
        html += "<td style='width:"+width+"px'>";
        for (var i = 0; i < icons.length; i++) {
            if (i != 0) {
                html += separator;
            }
            html += '<img src="'+icons[i].url+'" title="'+icons[i].title+'" height="16"/>';
        }
        html += "</td>";
    }
    return html;
};

Time.sumAllHours = function(data) {
    var seconds = 0;
    for (var i = 0; i < data.length; i++) {
        seconds += data[i].data;
    }
    return Time.calculateHours(seconds);
};