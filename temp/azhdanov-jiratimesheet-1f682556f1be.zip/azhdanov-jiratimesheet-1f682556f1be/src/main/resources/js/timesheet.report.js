AJS.$(function($) {
    var $el = $('#subscribe');
    $el.click(function(e) {
        e.preventDefault();
        var href = $el.attr('href');
        $.post(href,
            $.param({decorator: 'none', configureUrl: $el.attr('data-url')}),
            function(data) { // success
                console.log(data);
                if ("ok" == data) {
                    $el.attr('href', $el.attr('data-href')).attr('data-href', href);
                    var text = $el.attr('data-text');
                    var old_text = ('.text', $el).text();
                    $('.text', $el).html(text);
                    $el.attr('data-text', old_text);
                }
            }
        ); 
        return false;
    });
});
