var Calendar = Calendar || {}; // Dynarch Calendar (www.dynarch.com/projects/calendar)

if (typeof(Date.prototype.print) !== 'function') { // patch Date object with Dynarch Calendar functions

    /*  Copyright Mihai Bazon, 2002-2005  |  www.bazon.net/mishoo
     * -----------------------------------------------------------
     *
     * The DHTML Calendar, version 1.0 "It is happening again"
     *
     * Details and latest version at:
     * www.dynarch.com/projects/calendar
     *
     * This script is developed by Dynarch.com.  Visit us at www.dynarch.com.
     *
     * This script is distributed under the GNU Lesser General Public License.
     * Read the entire license text here: http://www.gnu.org/licenses/lgpl.html
     */

    /** Returns the number of day in the year. */
    Date.prototype.getDayOfYear = function() {
        var now = new Date(this.getFullYear(), this.getMonth(), this.getDate(), 0, 0, 0);
        var then = new Date(this.getFullYear(), 0, 0, 0, 0, 0);
        var time = now - then;
        return Math.floor(time / Date.DAY);
    };

    /** Returns the number of the week in year, as defined in ISO 8601. */
    Date.prototype.getWeekNumber = function(startOfWeek) {
        if (Date.useISO8601WeekNumbers) {
            return this.getISO8601WeekNumber();
        } else {
            return this.getSimpleWeekNumber(startOfWeek);
        }
    };

    /* Algorithm taken from: http://www.merlyn.demon.co.uk/weekcalc.htm#NIP
     Blame them for the shit variable and function names. Seriously, WTF?
     This is "Type 1" with a Sun-Sat row.

     Using the simple week counting you need to know
     the start of week so you can do the calculations properly.

     If you don't specify a startOfWeek then Sunday is used.
     */

    Date.prototype.getSimpleWeekNumber = function(startOfWeek)
    {
        function OddWkNo1(D, d1, d2)
        {
            var Yr = D.getFullYear(), Jan1 = new Date(Yr, 0, 1), Q;
            Q = Math.round((D - Jan1) / 86400000);
            if (d1 != null)
            {
                Q -= (7 + d1 - Jan1.getDay()) % 7;
            }
            if (d2 != null)
            {
                Q += d2;
            }
            return [Yr, 1 + Q / 7 | 0, 1 + (7 + Q) % 7];
        }

        return OddWkNo1(this, startOfWeek ? startOfWeek : 6, 6)[1];
//    return OddWkNo1(this, 6, 6)[1];
    };

    Date.prototype.print = function (str) {

        var m = this.getMonth();
        var d = this.getDate();
        var y = this.getFullYear();
        var wn = this.getWeekNumber();
        var w = this.getDay();
        var s = {};
        var hr = this.getHours();
        var pm = (hr >= 12);
        var ir = (pm) ? (hr - 12) : hr;
        var dy = this.getDayOfYear();
        if (ir == 0)
            ir = 12;
        var min = this.getMinutes();
        var sec = this.getSeconds();
        s["%a"] = Calendar._SDN[w]; // abbreviated weekday name [FIXME: I18N]
        s["%A"] = Calendar._DN[w]; // full weekday name
        s["%b"] = Calendar._SMN[m]; // abbreviated month name [FIXME: I18N]

        s["%B"] = Calendar._MN[m]; // full month name
        // FIXME: %c : preferred date and time representation for the current locale
        s["%C"] = 1 + Math.floor(y / 100); // the century number
        s["%d"] = (d < 10) ? ("0" + d) : d; // the day of the month (range 01 to 31)
        s["%e"] = d; // the day of the month (range 1 to 31)
        // FIXME: %D : american date style: %m/%d/%y
        // FIXME: %E, %F, %G, %g, %h (man strftime)
        s["%H"] = (hr < 10) ? ("0" + hr) : hr; // hour, range 00 to 23 (24h format)
        s["%I"] = (ir < 10) ? ("0" + ir) : ir; // hour, range 01 to 12 (12h format)
        s["%j"] = (dy < 100) ? ((dy < 10) ? ("00" + dy) : ("0" + dy)) : dy; // day of the year (range 001 to 366)
        s["%k"] = hr;       // hour, range 0 to 23 (24h format)
        s["%l"] = ir;       // hour, range 1 to 12 (12h format)
        s["%m"] = (m < 9) ? ("0" + (1+m)) : (1+m); // month, range 01 to 12
        s["%M"] = (min < 10) ? ("0" + min) : min; // minute, range 00 to 59
        s["%n"] = "\n";     // a newline character
        s["%p"] = pm ? Calendar._TT["PM"] : Calendar._TT["AM"];
        s["%P"] = pm ? Calendar._TT["PM"] : Calendar._TT["AM"];
        // FIXME: %r : the time in am/pm notation %I:%M:%S %p
        // FIXME: %R : the time in 24-hour notation %H:%M
        s["%R"] = s["%k"] + ":" + s["%M"];



        s["%s"] = Math.floor(this.getTime() / 1000);
        s["%S"] = (sec < 10) ? ("0" + sec) : sec; // seconds, range 00 to 59
        s["%t"] = "\t";     // a tab character
        // FIXME: %T : the time in 24-hour notation (%H:%M:%S)
        s["%U"] = s["%W"] = s["%V"] = (wn < 10) ? ("0" + wn) : wn;
        s["%u"] = w + 1;    // the day of the week (range 1 to 7, 1 = MON)
        s["%w"] = w;        // the day of the week (range 0 to 6, 0 = SUN)
        // FIXME: %x : preferred date representation for the current locale without the time
        // FIXME: %X : preferred time representation for the current locale without the date
        s["%y"] = ('' + y).slice(-2); // year without the century (range 00 to 99)
        s["%Y"] = y;        // year with the century
        s["%%"] = "%";      // a literal '%' character

        var re = /%./g;
        if (!Calendar.is_ie5 && !Calendar.is_khtml)
            return str.replace(re, function (par) { return s[par] || par; });

        var a = str.match(re);
        for (var i = 0; i < a.length; i++) {
            var tmp = s[a[i]];
            if (tmp) {
                re = new RegExp(a[i], 'g');
                str = str.replace(re, tmp);
            }
        }

        return str;
    }
}