jQuery(function($) {

    var Holiday = Backbone.Model.extend({
        idAttribute: "id",
        initialize: function() {
            this.on('change:date', this.changeDate);
            this.changeDate();
        },
        changeDate: function() { // for merge on HolidaysView.save()  
            this.parseDate(this.get('date'));
        },
        // parse a date in yyyy-mm-dd or *-mm-dd format and store them out of attributes
        parseDate: function(input) {
            var parts = input.split('-');
            this.year = parts[0] == '*' ? parts[0] : parseInt(parts[0]);
            this.month = parseInt(parts[1], /* radix */ 10);
            this.day = parseInt(parts[2], /* radix */ 10);
        },
        isHoliday: function(date) {
            return (this.year == '*' || this.year == date.getFullYear()) &&
                this.month == (date.getMonth() + 1) &&
                this.day == date.getDate();
        },
        isFixed: function() {
            return this.year == '*';
        },
        setYear: function(year) {
            this.year = year || '*';
            this.set('date', this.year + '-' +
                    (this.month < 10 ? '0' : '') + this.month + '-' +
                    (this.day < 10 ? '0' : '') + this.day);
        }        
    });

    var HolidayView = Backbone.View.extend({
        tagName: "tr",
        initialize: function(){
            _.bindAll(this, /* underscore < 1.4 */ 'changeName', 'changeFixed', 'render');
            this.render();
        },
        events: {
            'change [name="holiday-name"]': 'changeName',
            'change [name="holiday-fixed"]': 'changeFixed'
        },
        changeName: function() {
            this.model.set("name", $.trim(this.$('[name="holiday-name"]').val()) || '');
        },
        changeFixed: function() {
            var year = this.$('[name="holiday-fixed"]').is(':checked') ? null : this.options.year;
            this.model.setYear(year);
        },
        render: function() {
            var html = _.template(
                    $("#holiday-item-template").html(),
                    _.extend(this.model.toJSON(), {fixed: this.model.isFixed()}));
            this.$el.html( html );
        }
    });

    var Holidays = Backbone.Collection.extend({
        model: Holiday,
        url: contextPath + '/rest/timesheet-gadget/1.0/holidays'
    });

    var HolidaysView = Backbone.View.extend({
        initialize: function() {
            _.bindAll(this, /* underscore < 1.4 */ 'save', 'close', 'keyup', 'removeHoliday', 'render', 'error');
            this.$el.show();
            this.render();
        },
        events: {
            "click #holiday-dialog-save": "save",
            "click #holiday-dialog-cancel": "close",
            "keyup" : "keyup",
            "click #holiday-dialog-remove": "removeHoliday"
        },
        save: function() {
            $('#loading').show();
            var jqXHR = [];
            var holidays = this.options.calendar.model;
            this.model.each(function (holiday) {
                jqXHR.push(holiday.save(null, {success: function(holiday) {
                    if (Backbone.VERSION.match(/^0\.9\.2$/) ) { // backbone-0.9.2
                        existing = holidays.get(holiday.id);
                        if (existing) {
                            holidays.remove(existing);
                        }
                    }
                    holidays.add(holiday, {merge: true});
                }}));
            });
            $.when.apply($, jqXHR).then(this.close, this.error);
            return false; // stop propagation
        },
        close: function() {
            this.$el.hide();
            this.$el.empty();
            this.options.calendar.render();
            return false; // stop propagation
        },
        keyup: function(event) {
            if (event.keyCode == 27) {
                this.close();
            }
        },
        removeHoliday: function() {
            $('#loading').show();
            var jqXHR = [];
            var holidays = this.options.calendar.model;
            this.model.each(function (holiday) {
                jqXHR.push(holiday.destroy({success: function() {
                    holidays.remove(holiday);
                }}));
            });
            $.when.apply($, jqXHR).then(this.close, this.error);
            return false; // stop propagation
        },
        render: function() {
            var calendar = this.options.calendar;
            var date = this.options.date;
            var html = _.template( $("#holidays-dialog-template").html(), {
                date: date.print(calendar.ttDateFormat),
                isNew: this.model.at(0).isNew()
            });
            this.$el.html( html );
            var $el = this.$('table');
            var year = date.getFullYear();
            this.model.each(function (holiday) {
                var holidayView = new HolidayView({model: holiday, year: year});
                $el.append(holidayView.el);
            });
            this.$('input[name="holiday-name"]').focus();
        },
        error: function (jqXHR) {
            $('#loading').hide();
            var data = {message: jqXHR.responseText}
            try {
                data = $.parseJSON(jqXHR.responseText);
            } catch (err) {
                // not a valid json
            }
            var html = _.template( $("#holidays-error-template").html(), {statusMessage: data.message});
            this.$('#holidays-dialog').html( html );
        }
    });

    var HolidaysCalendar = Holidays.extend({
        initialize: function() {
            this.date = new Date();
        },
        getHolidays: function(date, clone) {
            var holidays = new Holidays();
            this.each(function (holiday) {
                if (holiday.isHoliday(date)) {
                    holidays.add(clone ? holiday.clone() : holiday);
                }
            });
            return holidays;
        },
        scrollYear: function(delta) {
            this.date.setFullYear(this.date.getFullYear() + delta);
        }
    });

    var HolidaysCalendarView = Backbone.View.extend({
        initialize: function(){
            _.bindAll(this, /* underscore < 1.4 */ 'edit', 'prev', 'next', 'scrollYear', 'fetchYear', 'monthName', 'dayName', 'isWeekend', 'renderDay', 'reload', 'render');
            this.firstDayOfWeek = Calendar._FD  || 0; // parseInt(this.$el.attr('data-firstdayofweek'))
            Calendar._TT = Calendar._TT || {
                "WEEKEND": '0,6', // this.$el.attr('data-weekend')
                "TT_DATE_FORMAT": "%a, %b %e"
            };
            var weekend = Calendar._TT["WEEKEND"];
            this.weekend = weekend.split(',');
            for (var i = 0; i < this.weekend.length; i++) {
                this.weekend[i] = parseInt(this.weekend[i]);
            }
            var locale = this.$el.attr('data-locale') || 'en_US';
            Calendar._MN = Calendar._MN || ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            this.monthNames = Calendar._MN; 
            Calendar._SDN = Calendar._SDN || ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            this.dayNames = Calendar._SDN; 
            this.ttDateFormat = Calendar._TT["TT_DATE_FORMAT"];
            this.fetchYear();
            Calendar._DN = Calendar._DN || new Array(
                "Sunday",
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday",
                "Sunday"
            );
            Calendar._SMN = Calendar._SMN || new Array(
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
            ); 
        },
        events: {
            "click #holidays-calendar-prev": "prev",
            "click #holidays-calendar-next": "next",
            "click .holidays-calendar-week li.weekday": "edit",
            "mouseover .weekday": "showToolTip",
            "mouseleave .weekday": "hideToolTip"
        },
        // parse a date in yyyy-mm-dd format
        parseDate: function(input) {
            var parts = input.split('-');
            return new Date(parts[0], parts[1] - 1, parts[2]);
        },
        edit: function(event) {
            if (this.holiday_dialog) {
                this.holiday_dialog.close();
            }
            var $el = event.target.nodeName == 'SPAN' ? $(event.target) : $('span', event.target);
            if ($el.length == 0) {
                $el = $(event.target).closest('span');
            }
            var date = $el.attr('data-date');
            var holidays = this.model.getHolidays(this.parseDate(date), /* clone */ true);
            if (holidays.size() == 0) {
                holidays.add(new Holiday({date: date, name: '', locale: ''}));
            }
            this.holiday_dialog = new HolidaysView({
                el: $("#holidays-dialog-container"),
                model: holidays,
                calendar: this,
                date: this.parseDate(date)
            });
            $('#holidays-dialog').offset({top: event.pageY, left: event.pageX});
        },
        showToolTip: function(event) {
            var $el = event.target.nodeName == 'LI' ? $(event.target) : $(event.target).closest('li');
            if (!$el.hasClass('holidays-calendar-tooltip-active')) {
                $el.addClass('holidays-calendar-tooltip-active');
                $('.tooltip', $el).show().offset({top: event.pageY, left: event.pageX});
            }
        },
        hideToolTip: function(event) {
            var $el = event.target.nodeName == 'LI' ? $(event.target) : $(event.target).closest('li');
            if ($el.hasClass('holidays-calendar-tooltip-active')) {
                $el.removeClass('holidays-calendar-tooltip-active');
                $('.tooltip', $el).hide();
            }
        },
        prev: function(event) {
            this.scrollYear(-1);
        },
        next: function(event) {
            this.scrollYear(1);
        },
        scrollYear: function(delta) {
            this.model.scrollYear(delta);
            this.fetchYear();
        },
        fetchYear: function() {
            this.model.fetch({success: this.render, data: {year: this.model.date.getFullYear()}});
        },
        monthName: function(month) {
            return this.monthNames[month];
        },
        dayName: function(day) {
            return this.dayNames[day];
        },
        renderLi: function(text, css) {
            return '<li' + (css ? ' class="' + css + '">' : '>') + text + '</li>';
        },
        isWeekend: function(weekDay) {
            return _.contains(this.weekend, weekDay);
        },
        renderDay: function(weekDay, text, date) {
            var css = this.isWeekend(weekDay) ? 'weekend' : '';
            var data = '';
            if (date) {
                css += css ? ' weekday' : 'weekday';
                data += ' data-date="' + this.formatDate(date) + '"';
                var holidays = this.model.getHolidays(date);
                if (holidays.size() > 0) {
                    var holiday = holidays.at(0);
                    css += ' holiday';
                    data += ' data-holiday-id="' + holiday.get('id') + '"';
                    text += '<div class="tooltip">' + (_.escape(holiday.get('name')) || '&nbsp;') + '</div>';
                }
            }
            return this.renderLi('<span class="day"' + data + '>' + text + '</span>', css);
        },
        formatDate: function(date) {
            var m = date.getMonth() + 1;
            var d = date.getDate();
            return date.getFullYear() + '-' + ((m < 10 ? '0' : '') + m) + '-' + ((d < 10 ? '0' : '') + d);
        },
        reload: function() {
            this.model.fetch({reset:true, success: this.render, data: {year: this.model.date.getFullYear()}});
        },
        render: function() {
            var buf = [];
            var startDate = new Date();
            var endDate = new Date();
            var year = this.model.date.getFullYear();
            buf.push('<div class="holidays-calendar-year">');
            buf.push('<a href="#" id="holidays-calendar-prev"><< prev</a>&nbsp;');
            buf.push('<span>' + this.model.date.getFullYear() + '</span>');
            buf.push('&nbsp;<a href="#" id="holidays-calendar-next">next >></a></br>');
            buf.push('</div>');
            var weekdays = [0, 1, 2, 3, 4, 5, 6];
            for (var i = 0; i < this.firstDayOfWeek; i++) {
                weekdays[6] = weekdays.shift();
            }
            for (var month = 0; month < 12; month++) {
                buf.push('<div class="holidays-calendar-month');
                buf.push((month == 0 || month == 6) ? ' holidays-calendar-month-header">' : '">');
                startDate.setDate(1);
                startDate.setMonth(month);
                startDate.setYear(year);
                endDate.setYear(year);
                endDate.setMonth(month + 1);
                endDate.setDate(0);
                var days = endDate.getDate();
                var weekDay = startDate.getDay();
                buf.push('<span class="month">' + this.monthName(month) + '</span>');
                if (month == 0 || month == 6) {
                    buf.push('<ul class="holidays-calendar-weekdays">');
                    _.each(weekdays, function(day) {
                        buf.push(this.renderDay(1, this.dayName(day % 7)));
                    }, this);
                    buf.push('</ul>');
                }
                buf.push('<ul class="holidays-calendar-week">');
                var monthDay = 0;
                _.each(weekdays, function(day) {
                    if (day == weekDay) {
                        monthDay++; // switch
                    }
                    if (monthDay == 0) {
                        buf.push(this.renderDay(day, '&nbsp;'));
                    } else {
                        startDate.setDate(monthDay++);
                        buf.push(this.renderDay(day, monthDay - 1, startDate));
                    }
                }, this);
                buf.push('</ul>');
                while (monthDay <= days - 7) {
                    buf.push('<ul class="holidays-calendar-week">');
                    _.each(weekdays, function(day) {
                        startDate.setDate(monthDay++);
                        buf.push(this.renderDay(day, monthDay - 1, startDate));
                    }, this);
                    buf.push('</ul>');
                }
                buf.push('<ul class="holidays-calendar-week last-child">');
                _.each(weekdays, function(day) {
                    if (monthDay <= days) {
                        startDate.setDate(monthDay++);
                        buf.push(this.renderDay(day, monthDay - 1, startDate));
                    } else {
                        buf.push(this.renderDay(day, '&nbsp;'));
                    }
                }, this);
                buf.push('</ul>');
                buf.push('</div>');
            }
            buf.push('<div id="holidays-dialog-container"></div>');
            var html = buf.join('');
            // var html = _.template( $("#holidays-calendar-template").html(), {} );
            $('#loading').hide();
            this.$el.html( html );
        }
    });

    var holidays_calendar_view = new HolidaysCalendarView({ el: $("#holidays-calendar-container"), model: new HolidaysCalendar() });

    $("#importUrlButton").click(function(){
        $('#loading').show();
        var $importUrl = $("#importUrl");
        $.ajax({type: 'POST', url: contextPath + "/secure/HolidaysConfiguration!importHolidaysFromUrl.jspa",
                data: $.param({decorator: 'none', importUrl: $importUrl.val()}),
                success: function() {
                    var statusMessage = arguments[0];
                    if (statusMessage) {
                        $("#importUrlError").text(statusMessage)
                        $('#loading').hide();
                    } else { // ok
                        $importUrl.val("");
                        $("#importUrlError").text('');
                        holidays_calendar_view.reload();
                    }
                },
                error: function(readyState, status, statusText) {
                    $('#loading').hide();
                    $("#importUrlError").text(statusText)
                }
        })
    });

    $("#importFile").ajaxfileupload({
        action: contextPath + "/secure/HolidaysConfiguration!importHolidaysFromFile.jspa",
        valid_extensions: ["ics"],
        submit_button: $("#importFileButton"),
        onStart: function() { $('#loading').show(); },
        onComplete: function(response) {
            var $importError = $("#importFileError");
            if ($importError != null) {
                $importError.text("");
            }
            if (!response.status && response.status != null) {
                $importError.text(response.message);
            }
            $("#importFile").val("");
            // reload calendar
            holidays_calendar_view.reload();
        }
    });

});

//Underscore.js 1.4.3
//http://underscorejs.org
//(c) 2009-2012 Jeremy Ashkenas, DocumentCloud Inc.
//Underscore may be freely distributed under the MIT license.

if (typeof _.isObject != 'function') {
    _.isObject = function(obj) {
        return obj === Object(obj);
    };
}

if (typeof _.has != 'function') {
    _.has = function(obj, key) {
        return hasOwnProperty.call(obj, key);
    };
}

if (typeof _.invert != 'function') {
    _.invert = function(obj) {
        var result = {};
        for (var key in obj) if (_.has(obj, key)) result[obj[key]] = key;
        return result;
    };
}

if (typeof _.escape != 'function') {

    // List of HTML entities for escaping.
    var entityMap = {
      escape: {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#x27;',
        '/': '&#x2F;'
      }
    };
    entityMap.unescape = _.invert(entityMap.escape);
    
    // Regexes containing the keys and values listed immediately above.
    var entityRegexes = {
      escape:   new RegExp('[' + _.keys(entityMap.escape).join('') + ']', 'g'),
      unescape: new RegExp('(' + _.keys(entityMap.unescape).join('|') + ')', 'g')
    };
    
    // Functions for escaping and unescaping strings to/from HTML interpolation.
    _.each(['escape', 'unescape'], function(method) {
      _[method] = function(string) {
        if (string == null) return '';
        return ('' + string).replace(entityRegexes[method], function(match) {
          return entityMap[method][match];
        });
      };
    });
}