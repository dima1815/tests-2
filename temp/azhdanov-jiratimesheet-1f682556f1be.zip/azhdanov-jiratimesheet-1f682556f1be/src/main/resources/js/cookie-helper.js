var CookieHelper = {};

// see also https://developer.atlassian.com/display/GADGETS/Gadget+Object+API

CookieHelper.getCookieName = function(gadget, name) {
    var timesheetId = gadget.getPrefs().getModuleId();
    return 'timesheet.' + timesheetId + '.' + name;
};

CookieHelper.getCookie = function(gadget, name, defaultValue) {
    var cookie = CookieHelper.getCookieName(gadget, name);
    return AJS.Cookie.read(cookie, defaultValue);
};

CookieHelper.setCookie = function(gadget, name, value) {
    var cookie = CookieHelper.getCookieName(gadget, name);
    if (value) {
        AJS.Cookie.save(cookie, value);
    } else {
        AJS.Cookie.erase(cookie);
    }
};
    
CookieHelper.getOffset = function(gadget) {
    return parseInt(CookieHelper.getCookie(gadget, 'offset', '0'));
};

CookieHelper.setOffset = function(gadget, offset) {
    CookieHelper.setCookie(gadget, 'offset', offset);
};

CookieHelper.getLockedDate = function(gadget) {
    return CookieHelper.getCookie(gadget, 'lockedDate', '');
};

CookieHelper.setLockedDate = function(gadget, lockDate) {
    CookieHelper.setCookie(gadget, 'lockedDate', lockDate);
};

CookieHelper.hasLockedDate = function(gadget) {
    var cookie = CookieHelper.getLockedDate(gadget);
    return cookie != null && cookie != '';
};

CookieHelper.getMonthView = function(gadget) {
    return CookieHelper.getCookie(gadget, 'monthView', false);
};

CookieHelper.setMonthView = function(gadget, monthView) {
    CookieHelper.setCookie(gadget, 'monthView', monthView);
};