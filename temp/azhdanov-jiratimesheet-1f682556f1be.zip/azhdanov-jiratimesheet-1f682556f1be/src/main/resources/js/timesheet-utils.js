var TimesheetUtils = {};

TimesheetUtils.getISODateString = function(date) {
    var dateStr = date.toJSON();
    var dotPosition = dateStr.indexOf(".");
    if (dotPosition > 0){
        dateStr = dateStr.substring(0, dotPosition);
    }
    else {
        dateStr = dateStr.substring(0, dateStr.indexOf("Z"));
    }
    return dateStr + ".000+0000";
};

TimesheetUtils.getPMFormatTimeString = function(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var time = '';
    var tmpHour = hours > 12 ? hours - 12 : hours;
    if (tmpHour < 10) {
        time += '0';
    }
    time += tmpHour + ":";
    if (minutes < 10) {
        time += '0';
    }
    time += minutes + ' ' + (hours < 12 ? 'AM' : 'PM');
    return time;
};

TimesheetUtils.stopEventPropagation = function(event) {
    if (event) {
        event.cancelBubble = true;
        if (event.stopPropagation) event.stopPropagation();
    }
};

TimesheetUtils.extendProjectOrFilterPicker = function(gadget, projectOrFilterPicker) {
  var origCallback = projectOrFilterPicker.callback;
  var noneSelected = AJS.$("<span/>").attr({id:'filter_projectOrFilter_name'}).addClass("filterpicker-value-name field-value").text(gadget.getMsg("gadget.common.filterid.none.selected"));
  var projectOrFilterClear = AJS.$('<span/>').html(
    '&nbsp;[&nbsp<a id="filter_projectOrfilter_clear"><span>x</span></a>&nbsp]');
  projectOrFilterPicker.callback = function(parentDiv) {
    origCallback(parentDiv);
    AJS.$('#filter_projectOrFilter_name', parentDiv).after(projectOrFilterClear);
    AJS.$('#filter_projectOrfilter_clear', parentDiv).click(function() {
      AJS.$('#filter_projectOrFilter_id', parentDiv).val('');
      AJS.$('#filter_projectOrFilter_name', parentDiv).replaceWith(noneSelected);
    });
  }
  return projectOrFilterPicker;
};

