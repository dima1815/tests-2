var Time = {};

Time.getTemplate = function(args) {
    var gadget = this;

    var userTitle = gadget.getPref("gadgetTitle") || gadget.getPrefs().getMsg('gadget.timesheet.title');
    if (userTitle != null && userTitle != '') {
        gadgets.window.setTitle(userTitle);
    }

    // This is used to pass the name of filter or project to the picker
    gadget.projectOrFilterName = args.timesheet.projectOrFilterName;

    gadget.getView().html(args.timesheet.html);
    gadget.hideLoading();
    AJS.$('.overlay').each(function(i, el) {
      var $el = AJS.$(el);
      $el.parent().hover(function() {
        $el.css('display', 'inline');                                
        var $w = AJS.$('#jira');
        var p = $el.parent().offset();
        p.left += $el.parent().width(); // update position for Chrome
        if ($el.width() + p.left + 20 > $w.width()) {
            p.left = p.left - $el.width();
            if (p.left < 0) {
                p.left = 0;
            }
        }
        $el.offset({left: p.left, top: 0}); // make browser adjust width
        $el.css('display', 'block');
        if ($el.height() + p.top > $w.height()) {
          p.top = $w.height() - $el.height();
          if (p.top < 0) {
            p.top = 0;
          }
        }
        if ($el.width() + p.left > $w.width()) {
          p.left = $w.width() - $el.width();
        }
        $el.offset(p);
      }).mouseleave(function() {
        $el.removeAttr('style'); // reset
      })
    });

    Time.prepareEstimationPopup(gadget);

    AJS.$('.add').each(function(i, el) {
      var $el = AJS.$(el);
      $el.parent().hover(function() {
        $el.show();                                
      }).mouseleave(function() {
        $el.hide();
      })
    });

    TimesheetSlider.slider(gadget);
};

Time.getDescriptor = function(args, gadget, group_timesheet) {
    var gadget = gadget || this;
    var prefs = new gadgets.Prefs();
    var getMsg = function(key) {
        return prefs.getMsg(key);
    };
    var descriptor = {
        fields: [
            {
                userpref: "gadgetTitle",
                label: getMsg("gadget.pref.label.gadgetTitle"),
                type: "text",
                value: gadget.getPref("gadgetTitle")
            },
            {
                userpref: "num_weeks",
                label: getMsg("gadget.pref.label.num_weeks"),
                type: "text",
                value: gadget.getPref("num_weeks")
            },
            {
                userpref: "reporting_day",
                label: getMsg("gadget.pref.label.reporting_day"),
                type: "select",
                selected: gadget.getPref("reporting_day"),
                options: [
                    {label: "", value: ""},
                    {label: getMsg("gadget.timesheet.today"), value: "0"},
                    {label: getMsg("gadget.timesheet.Monday"), value: "2"},
                    {label: getMsg("gadget.timesheet.Tuesday"), value: "3"},
                    {label: getMsg("gadget.timesheet.Wednesday"), value: "4"},
                    {label: getMsg("gadget.timesheet.Thursday"), value: "5"},
                    {label: getMsg("gadget.timesheet.Friday"), value: "6"},
                    {label: getMsg("gadget.timesheet.Saturday"), value: "7"},
                    {label: getMsg("gadget.timesheet.Sunday"), value: "1"}
                ]
            },
            {
                userpref: "user",
                label: getMsg("gadget.pref.label.user"),
                type: "text",
                value: gadget.getPref("user")
            },
            {
                userpref: "group",
                label: getMsg("gadget.pref.label.group"),
                type: "multiselect",
                selected: gadget.getPref("group"),
                options: args.groups.values
            },
            {
                userpref: "excludeGroup",
                label: getMsg("gadget.pref.label.excludeGroup"),
                type: "multiselect",
                selected: gadget.getPref("excludeGroup"),
                options: args.excludeGroups.values
            },
            {
                userpref: "projectRole",
                label: getMsg("gadget.pref.label.projectRole"),
                type: "select",
                selected: gadget.getPref("projectRole"),
                options: args.projectRoles.values
            },
            TimesheetUtils.extendProjectOrFilterPicker(gadget, AJS.$.extend(AJS.gadget.fields.projectOrFilterPicker(gadget, "projectOrFilter"),
             {label: getMsg("gadget.pref.label.projectOrFilter"), description: ""})),
            {
                userpref: "weekends",
                label: getMsg("gadget.pref.label.weekends"),
                type: "select",
                selected: gadget.getPref("weekends"),
                options: [
                    {label: getMsg("gadget.timesheet.yes"), value: "true"},
                    {label: getMsg("gadget.timesheet.no"), value: "false"}
                ]
            },
            {
                userpref: "showDetails",
                label: getMsg("gadget.pref.label.showDetails"),
                type: "select",
                selected: gadget.getPref("showDetails"),
                options: [
                    {label: getMsg("gadget.timesheet.yes"), value: "true"},
                    {label: getMsg("gadget.timesheet.no"), value: "false"}
            ]
            },
            {
                userpref: "sumSubTasks",
                label: getMsg("gadget.pref.label.sumSubTasks"),
                type: "select",
                selected: gadget.getPref("sumSubTasks"),
                options: [
                    {label: getMsg("gadget.timesheet.yes"), value: "true"},
                    {label: getMsg("gadget.timesheet.no"), value: "false"}
                ]
            },
            {
                userpref: "groupByField",
                label: getMsg("gadget.pref.label.groupByField"),
                type: "select",
                selected: gadget.getPref("groupByField"),
                options: args.groupByField.values
            },
            {
                userpref: "moreFields",
                label: getMsg("gadget.pref.label.moreFields"),
                type: "multiselect",
                selected: gadget.getPref("moreFields"),
                options: args.moreFields.values
            },
            AJS.gadget.fields.nowConfigured()
        ]
    };
    
    return descriptor;
};

Time.locationWithReturnUrl = function(url) {
	window.top.location = url + '&returnUrl=' + encodeURIComponent(window.top.location.href);
	return true;
};

Time.prepareEstimationPopup = function(gadget){
    AJS.$('.estimatePopup').each(function(i, el) {
        var $el = AJS.$(el);
        var save = function(e) {
            if ($el.saving) {
                return;
            } else {
                $el.saving = true;
            }
            var issueId = $el.attr('issueid');
            var started = new Date(parseInt($el.attr('started')) + Time.getCurrentTimeMs());
            var $timeSpent = $el.find(".timeSpent");
            var timeSpent = $timeSpent.val();
            var comment = $el.find(".worklogComment").val();
            var url = "/rest/api/2/issue/"+issueId+"/worklog";
            AJS.$.ajax ({
                url: url,
                type: "POST",
                data: JSON.stringify({'comment': comment, 'started': TimesheetUtils.getISODateString(started), 'timeSpent': timeSpent}),
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function() {
                    gadget.showView(true);
                },
                error: function() {
                    delete $el.saving;
                    $timeSpent.addClass("error");
                    setTimeout(function() {
                        $timeSpent.removeClass("error");
                    }, 1000);
                },
                global: false
            });
        };
        var close = function(e){
            $el.removeAttr('style');
            TimesheetUtils.stopEventPropagation(e);
            delete gadget.$previousEl; 
        };
        $el.find('input').keydown(function(e) {
            if (e.keyCode == 13) {
                e.preventDefault();
                save();
            } else if (e.keyCode == 27) {
                e.preventDefault();
                close();
        	}
        });
        var open = function() {
            if (gadget.$previousEl && gadget.$previousEl != $el) {
               gadget.$previousEl.removeAttr('style'); // reset
            } else if (gadget.$previousEl) {
               return;
            }
            gadget.$previousEl = $el; 
            var $w = AJS.$('#jira');
            var p = $el.parent().offset();
            if ($el.width() + p.left + 20 > $w.width()) {
                p.left = p.left - $el.width();
                if (p.left < 0) {
                    p.left = 0;
                }
            }
            $el.offset({left: p.left, top: 0}); // make browser adjust width
            $el.css('display', 'block');
            if ($el.height() + p.top > $w.height()) {
                p.top = p.top - $el.height();
                if (p.top < 0) {
                    p.top = 0;
                }
            }
            $el.offset(p);
            $el.find('.timeSpent').focus().select();
        };
        $el.parent().click(open);
        $el.find(".closePopupBtn").click(close);
    });
};

Time.getCurrentTimeMs = function() {
    var curDate = new Date();
    return (curDate.getHours()*60*60 + curDate.getMinutes()*60) * 1000;
};

Time.addStartDateParameter = function(dateMs, format, url) {
    // FIXME: Date.parse if browser timezone does not match user timezone
    var date = new Date(parseInt(dateMs) + Time.getCurrentTimeMs());
    return url + "&startDate=" + encodeURIComponent(date.print(format));
};