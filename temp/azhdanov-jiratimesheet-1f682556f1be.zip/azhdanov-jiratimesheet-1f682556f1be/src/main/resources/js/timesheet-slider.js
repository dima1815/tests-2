var TimesheetSlider = {};

TimesheetSlider.slider = function(gadget) {
    if (gadget == null) {
        return;
    }
    AJS.$('#prev').click(function () {
        var offset = CookieHelper.getOffset(gadget);
        CookieHelper.setOffset(gadget, offset - 1);
        gadget.showView(true);
    });
    AJS.$('#today').click(function () {
        CookieHelper.setOffset(gadget, 0);
        gadget.showView(true);
    });
    AJS.$('#week').click(function () {
        CookieHelper.setMonthView(gadget, false);
        gadget.showView(true);
    });
    AJS.$('#month').click(function () {
        CookieHelper.setMonthView(gadget, true);
        gadget.showView(true);
    });
    AJS.$('#next').click(function () {
        var offset = CookieHelper.getOffset(gadget);
        CookieHelper.setOffset(gadget, offset + 1);
        gadget.showView(true);
    });

    // locked date functionality
    var $lockBtn = AJS.$('#lockBtn');
    if (CookieHelper.hasLockedDate(gadget)) {
        $lockBtn.addClass("locked");
    }
    $lockBtn.click(function () {
        $lockBtn.toggleClass("locked");
        if ($lockBtn.hasClass("locked")) {
            //do lock
            var reportFirstDate = new Date(parseInt($lockBtn.data('start-date')));
            TimesheetSlider.doLock(gadget, reportFirstDate);
        }
        else {
            //do unlock
            var reportFirstDate = TimesheetSlider.getReportFirstDate(gadget.getPref("reporting_day"), gadget.getPref("num_weeks"), CookieHelper.getMonthView(gadget));
            var newOffset = (new Date(CookieHelper.getLockedDate(gadget)).getTime() - reportFirstDate.getTime()) / 604800000;
            CookieHelper.setOffset(gadget, CookieHelper.getOffset(gadget) + newOffset);
            CookieHelper.setLockedDate(gadget, null);
        }
        gadget.showView(true);
    });
    TimesheetSlider.initCalendar(gadget);
};

TimesheetSlider.doLock = function(gadget, date) {
    var lockDate = new Date(date);
    lockDate.setDate(lockDate.getDate());
    CookieHelper.setLockedDate(gadget, TimesheetUtils.getISODateString(lockDate));
    CookieHelper.setOffset(gadget, 0);
};

TimesheetSlider.getReportFirstDate = function(reportingDay, numOfWeeks, monthView) {
    var firstDate = new Date();
    firstDate.setHours(0,0,0,0);
    if (reportingDay == 0) {
        firstDate.setDate(firstDate.getDate() - 6);
    }
    else {
        while (firstDate.getDay() != reportingDay-1) {
            firstDate.setDate(firstDate.getDate() - 1);
        }
    }
    if (monthView) {
        firstDate.setDate(firstDate.getDate() - numOfWeeks * 7 * 4 + 7);
    } else {
        firstDate.setDate(firstDate.getDate() - (numOfWeeks - 1) * 7);
    }
    return firstDate;
};

TimesheetSlider.initCalendar = function(gadget) {
    Calendar.setup({
        firstDay : 1,
        inputField : 'lockedDate',
        button : 'calendarBtn',
        align : 'Br',
        singleClick : true,
        showsTime : false,
        useISO8601WeekNumbers : false,
        ifFormat : '%Y-%m-%d',
        onSelect : function(calendar, date) {
            TimesheetSlider.doLock(gadget, date);
            gadget.showView(true);
        }
    });
};