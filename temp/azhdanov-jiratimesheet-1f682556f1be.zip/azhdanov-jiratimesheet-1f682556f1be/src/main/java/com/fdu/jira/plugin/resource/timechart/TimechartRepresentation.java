package com.fdu.jira.plugin.resource.timechart;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import java.util.ArrayList;
import java.util.List;

@XmlRootElement
public class TimechartRepresentation {

    @XmlElement
    protected String chartTitle;

    @XmlElement
    protected String licenseMsgHtml;

    @XmlElementWrapper(name = "entries")
    @XmlElement(name = "entry")
    protected List<DataEntryRepresentation> entries = new ArrayList<DataEntryRepresentation>();

    @XmlElement(name = "sliderHtml")
    private String sliderHtml;

    @XmlElement
    private String projectOrFilterName;


    public TimechartRepresentation() {
        // for JAXB
    }

    public TimechartRepresentation(String chartTitle, String sliderHtml, String projectOrFilterName, String licenseMsgHtml) {
        this.chartTitle = chartTitle;
        this.sliderHtml = sliderHtml;
        this.projectOrFilterName = projectOrFilterName;
        this.licenseMsgHtml = licenseMsgHtml;
    }

    public void addEntry(String label, Long spent) {
        addEntry(label, spent, null, null, null);
    }

    public void addEntry(String label, Long spent, String url) {
        addEntry(label, spent, url, null, null);
    }

    public void addEntry(String label, Long spent, String url, String hint, ImageRepresentation[] icons) {
        entries.add(new DataEntryRepresentation(label, spent, url, hint, icons));
    }
}
