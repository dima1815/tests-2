package com.fdu.jira.plugin.resource.timesheet;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;

import com.atlassian.jira.issue.worklog.Worklog;

public class WorklogEntryElement {

    @XmlElement public String comment;
    @XmlElement public Long timeSpent;
    @XmlElement public String author;
    @XmlElement public String authorFullName;
    @XmlElement public Date created;
    @XmlElement public String groupLevel;
    @XmlElement public Date startDate;
    @XmlElement public String updateAuthor;
    @XmlElement public String updateAuthorFullName;
    @XmlElement public Date updated;

    // Required by JAXB
    @SuppressWarnings("unused")
    private WorklogEntryElement() {
    } 

    public WorklogEntryElement(Worklog worklog) {

        this.author = worklog.getAuthor();
        this.authorFullName = worklog.getAuthorFullName();
        this.created = worklog.getCreated();
        this.groupLevel = worklog.getGroupLevel();
        this.comment = worklog.getComment();
        this.startDate = worklog.getStartDate();
        this.updateAuthor = worklog.getUpdateAuthor();
        this.updateAuthorFullName =  worklog.getUpdateAuthorFullName();
        this.timeSpent = worklog.getTimeSpent();
        this.updated = worklog.getUpdated();
    }
}
