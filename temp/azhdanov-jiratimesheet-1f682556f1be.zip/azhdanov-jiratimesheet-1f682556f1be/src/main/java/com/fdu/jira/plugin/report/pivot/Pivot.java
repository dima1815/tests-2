/*
 * Copyright (c) 2002-2004
 * All rights reserved.
 */
package com.fdu.jira.plugin.report.pivot;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.web.FieldVisibilityManager;
import com.atlassian.jira.web.action.ProjectActionSupport;
import com.fdu.jira.plugin.report.AbstractTimebaseReport;
import com.fdu.jira.util.ILicenseUtil;
import com.google.common.collect.ImmutableMap;

import jira.plugin.report.pivot.PivotService;
import jira.plugin.report.pivot.TimePivot;
import jira.plugin.report.timesheet.TimeBase.Options;
import jira.timesheet.plugin.configuration.IConfigurationService;
import webwork.action.ActionContext;

import java.util.EnumSet;
import java.util.Map;
import java.util.TimeZone;

/**
 * Generate a summary of worked hours in a specified period. The time period is
 * divided by the specified value for display.
 */
public class Pivot extends AbstractTimebaseReport<TimePivot> {

    private final PivotService pivotService;

    private TimePivot pivot;

    public Pivot(JiraAuthenticationContext authenticationContext,
            DateTimeFormatterFactory dateTimeFormatterFactory,
            FieldVisibilityManager fieldVisibilityManager,
            TimeZoneManager timeZoneManager,
            ILicenseUtil licenseUtil,
            PivotService pivotService,
            IConfigurationService configurationService) {

        super(authenticationContext,
                dateTimeFormatterFactory,
                fieldVisibilityManager,
                timeZoneManager,
                licenseUtil,
                configurationService);

        this.pivotService = pivotService;
    }

    // Generate the report
    public String generateReport(ProjectActionSupport action, Map params,
        boolean excelView) throws Exception {

        pivot.excelView = excelView;
        pivotService.getTimeSpents(pivot);

        // Pass the issues to the velocity template
        Map<String, Object> velocityParams = pivot.resultParams;

        prepareVelocityParams(velocityParams, pivot);

        velocityParams.put("licenseMgmt", licenseUtil.getLicenseMgmtUrl(ActionContext.getRequest().getContextPath()));
        if (excelView && pivot.showDetails) {
            velocityParams.put("allWorkLogs", pivot.allWorkLogs);
        } else {
            velocityParams.put("workedIssues", pivot.showDetails ? pivot.workedIssues : pivot.workedProjects);
            velocityParams.put("additionalFieldSumByProjectMap", pivot.additionalFieldSumByProjectMap);
            velocityParams.put("workedUsers", pivot.workedUsers);
        }
        velocityParams.put("projectId", pivot.projectId);
        velocityParams.put("filterId", pivot.filterId);
        velocityParams.put("targetGroup", pivot.targetGroup);
        velocityParams.put("excludeTargetGroup", pivot.excludeTargetGroup);
        velocityParams.put("projectGroupedTimeSpents", pivot.projectGroupedByFieldTimeSpents);

        return descriptor.getHtml(excelView && pivot.showDetails ? "excel" : "view", velocityParams);
    }

    protected void init(Map params) {
        User remoteUser = authenticationContext.getLoggedInUser();
        I18nHelper i18n = authenticationContext.getI18nHelper();
        TimeZone timezone = timeZoneManager.getLoggedInUserTimeZone();
        pivot = new TimePivot(remoteUser, timezone, i18n,
                params, EnumSet.of(Options.DATES),
                configurationService);

    }

    // Validate the parameters set by the user.
    public void validate(ProjectActionSupport action, Map params) {
        super.validate(action, params);

        if (pivotService.isForbiddenByTimesheetAuditorsGroup(pivot)) {
            String error = action
                    .getText("project.pivot.userNotInTimesheetAuditorsGroup");
                action.addError("projectid", error);
        }
    }

    @Override
    protected TimePivot getReportObject() {
        return pivot;
    }

    @Override
    protected Map<String, String> getValidationErrorMessages() {
        return ImmutableMap.of("beforeStartDate", "report.pivot.before.startdate");
    }
}
