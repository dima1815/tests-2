package com.fdu.jira.util;

import com.atlassian.jira.util.ParameterUtils;
import jira.timesheet.plugin.configuration.IConfigurationService;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

public final class CalendarUtil {

    public static int getReportingDay(Date lockDate, int reportingDay, boolean monthView, TimeZone timeZone) {
        if (lockDate != null) {
            final Calendar cal = Calendar.getInstance(timeZone);
            cal.setTime(lockDate);
            return cal.get(Calendar.DAY_OF_WEEK);
        } else if (reportingDay == 0 && monthView) {
            final Calendar cal = Calendar.getInstance(timeZone);
            cal.add(Calendar.DAY_OF_WEEK, 1);
            return cal.get(Calendar.DAY_OF_WEEK);
        } else {
            return reportingDay;
        }
    }

    public static void roundByWeekDay(Calendar calendar, int startWeekDay) {
        final Calendar original = (Calendar) calendar.clone();
        calendar.set(Calendar.DAY_OF_WEEK, startWeekDay);
        while (original.before(calendar)) {
            calendar.add(Calendar.DAY_OF_YEAR, -7);
        }
    }

    public static boolean isSameWeek(Calendar cal1, Calendar cal2, int startWeekDay) {
        final Calendar cal1copy = copyAndRound(cal1, startWeekDay);
        final Calendar cal2copy = copyAndRound(cal2, startWeekDay);
        return cal1copy.equals(cal2copy);
    }

    public static Calendar[] getDatesRange(
            int reportingDay, int numOfWeeks, int offset, boolean monthView, TimeZone timezone) {
        return getDatesRange(reportingDay, numOfWeeks, offset, monthView, timezone, null);
    }

    public static Calendar[] getDatesRange(int reportingDay, int numOfWeeks, int offset,
            boolean monthView, TimeZone timezone, final Date start) {
        // Calculate the start and end dates
        final Calendar currentDate = getCalendarFromDate(start, timezone);
        final Calendar endDate = getCalendarFromDate(start, timezone);

        if (monthView) {
            roundByWeekDay(endDate, reportingDay);
            numOfWeeks *= 4;
        } else if (reportingDay != 0 /* today */) {
            endDate.set(Calendar.DAY_OF_WEEK, reportingDay);
        } else {
            endDate.add(Calendar.DAY_OF_MONTH, 1); // include today
        }

        if (endDate.before(currentDate) || reportingDay == currentDate.get(Calendar.DAY_OF_WEEK)) {
            offset += 1;
        }
        // in any case, offset by week!
        endDate.add(Calendar.WEEK_OF_YEAR, offset);
        roundDate(endDate);
        Calendar startDate = Calendar.getInstance(timezone);
        startDate.setTime(endDate.getTime());
        if (start != null) {
            // issue#519: make view begin with start date 
            startDate.add(Calendar.WEEK_OF_YEAR, -1);
            endDate.add(Calendar.WEEK_OF_YEAR, numOfWeeks - 1);
        } else {
            startDate.add(Calendar.WEEK_OF_YEAR, -numOfWeeks);
        }
        return new Calendar[] { startDate, endDate };
    }

    public static void roundDate(Calendar date) {
        date.set(Calendar.HOUR_OF_DAY, 0);
        date.set(Calendar.MINUTE, 0);
        date.set(Calendar.SECOND, 0);
        date.set(Calendar.MILLISECOND, 0);
    }

    public static long getNumOfWeeks(Date startDate, Date endDate,
            Boolean monthView) {
        long startTime = startDate.getTime();
        long endTime = endDate.getTime();
        long diffTime = endTime - startTime;
        long diffDays = diffTime / (1000 * 60 * 60 * 24) + 1;
        long diffWeeks = diffDays / (monthView ? 30 : 7);
        return Math.max(diffWeeks, 1);
    }

    public static boolean isValidTimeInterval(Date startDate, Date endDate, IConfigurationService configurationService) {
        Calendar c = Calendar.getInstance();
        c.setTime(startDate);
        c.add(Calendar.DAY_OF_YEAR, configurationService.getMaxDays());

        // The end date must be before the adjusted date
        return c.getTime().after(endDate);
    }

    // TIME-281: make the same date in target timezone
    public static Calendar convertWorkedTimeDate(Date workedDate,
            TimeZone workedUserTimeZone, TimeZone remoteUserTimeZone) {
        return convertWorkedTimeDate(workedDate, workedUserTimeZone, remoteUserTimeZone, true);
    }

    // TIME-281: make the same date in target timezone
    public static Calendar convertWorkedTimeDate(Date workedDate,
            TimeZone workedUserTimeZone, TimeZone remoteUserTimeZone,
            boolean truncate) {
        Calendar calOrig = Calendar.getInstance(workedUserTimeZone);
        calOrig.setTimeInMillis(workedDate.getTime());
        if (!workedUserTimeZone.equals(remoteUserTimeZone)) {
            calOrig = copyCalendar(calOrig, remoteUserTimeZone);
        }
        if (truncate) { // excel view needs full time
            calOrig.set(Calendar.HOUR_OF_DAY, 0);
            calOrig.set(Calendar.MINUTE, 0);
            calOrig.set(Calendar.SECOND, 0);
            calOrig.set(Calendar.MILLISECOND, 0);
        }
        calOrig.getTime(); // TIME-302: recompute
        return calOrig;
        
    }
    public static Calendar copyCalendar(Calendar source, TimeZone timeZone) {
        Calendar cal = Calendar.getInstance(timeZone);
        cal.set(Calendar.YEAR, source.get(Calendar.YEAR));
        cal.set(Calendar.MONTH, source.get(Calendar.MONTH));
        cal.set(Calendar.DAY_OF_MONTH, source.get(Calendar.DAY_OF_MONTH));
        cal.set(Calendar.HOUR_OF_DAY, source.get(Calendar.HOUR_OF_DAY));
        cal.set(Calendar.MINUTE, source.get(Calendar.MINUTE));
        cal.set(Calendar.SECOND, source.get(Calendar.SECOND));
        cal.set(Calendar.MILLISECOND, source.get(Calendar.MILLISECOND));
        return cal;
    }

    @SuppressWarnings("rawtypes")
    public static Date getIsoDateParam(Map params, String name, TimeZone timezone) {
        String paramValue = ParameterUtils.getStringParam(params, name);
        if (StringUtils.isBlank(paramValue)) {
            return null;
        }
        synchronized (ISO_DATE_FORMAT) {
            try {
                ISO_DATE_FORMAT.setTimeZone(timezone);
                return ISO_DATE_FORMAT.parse(paramValue);
            } catch (ParseException e) {
                log.error("Can't parse date: " + paramValue, e);
                return null; 
            }
        }
        
    }
    
    private static final DateFormat ISO_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private static final Logger log = Logger.getLogger(CalendarUtil.class);

    private static Calendar getCalendarFromDate(Date date, TimeZone timezone) {
        final Calendar calendar = Calendar.getInstance(timezone);
        if (date != null) {
            calendar.setTime(date);
        }
        return calendar;
    }

    private static Calendar copyAndRound(Calendar calendar, int startWeekDay) {
        final Calendar copy = (Calendar) calendar.clone();
        roundDate(copy);
        roundByWeekDay(copy, startWeekDay);
        return copy;
    }
}
