package com.fdu.jira.plugin.resource.timesheet;

import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * JAXB representation.
 */
@XmlRootElement
@SuppressWarnings("unused")
public class MapRepresentation {
    @XmlJavaTypeAdapter(MapAdapter.class)
    private Map<String, String> values;

    private MapRepresentation() {
        // for JAXB
    }

    public MapRepresentation(Map<String, String> values) {
        this.values = values;
    }

}
