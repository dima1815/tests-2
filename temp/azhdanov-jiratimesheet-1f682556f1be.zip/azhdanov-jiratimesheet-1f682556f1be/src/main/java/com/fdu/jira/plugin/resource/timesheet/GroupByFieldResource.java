package com.fdu.jira.plugin.resource.timesheet;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.fdu.jira.plugin.report.timesheet.FieldsValuesGenerator;
import com.fdu.jira.plugin.resource.AbstractResource;

@Path("/groupByField")
public class GroupByFieldResource extends AbstractResource {
    private final JiraAuthenticationContext authenticationContext;

    public GroupByFieldResource(JiraAuthenticationContext authenticationContext) {
        this.authenticationContext = authenticationContext;
        
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response getTimesheet(@Context HttpServletRequest request,
            @QueryParam("additionalFields") Boolean additionalFields) {
        Map<String, Object>  params = new HashMap<String, Object>();
        params.put("User", authenticationContext.getLoggedInUser());
        FieldsValuesGenerator valuesGenerator = new FieldsValuesGenerator();
        FieldsValuesGenerator.Type type = additionalFields != null && additionalFields ? FieldsValuesGenerator.Type.ADDITIONAL_FIELDS_VALUES : FieldsValuesGenerator.Type.GROUP_BY_FIELD_VALUES;
        Map<String, String> values = valuesGenerator.getValues(params, type);
        return getOkResponse(new MapRepresentation(values));
    }
}
