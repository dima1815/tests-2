package com.fdu.jira.plugin.report.timesheet;

import java.util.Map;

import com.atlassian.configurable.ValuesGenerator;

public class AdditionalFieldsValuesGenerator extends FieldsValuesGenerator implements ValuesGenerator {
    public Map<String, String> getValues(Map arg0) {
        return getValues(arg0, FieldsValuesGenerator.Type.ADDITIONAL_FIELDS_VALUES);
    }
}
