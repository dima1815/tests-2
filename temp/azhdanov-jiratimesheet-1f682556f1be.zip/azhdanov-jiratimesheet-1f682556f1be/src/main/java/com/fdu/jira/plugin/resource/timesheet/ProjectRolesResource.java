package com.fdu.jira.plugin.resource.timesheet;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.fdu.jira.plugin.resource.AbstractResource;
import jira.plugin.report.timesheet.ProjectRoleValuesGenerator;

@Path("/projectRoles")
public class ProjectRolesResource extends AbstractResource {
    // because /rest/api/2/project/{projectKey}/role needs projectKey
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response getTimesheet(@Context HttpServletRequest request) {
        ProjectRoleValuesGenerator valuesGenerator = new ProjectRoleValuesGenerator();
        Map<String, String> values = valuesGenerator.getValues(null);
        return getOkResponse(new MapRepresentation(values));
    }
}

