package com.fdu.jira.util;

import org.springframework.util.StringUtils;

import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

public final class WeekendUtil {

    public static String getDefaultWeekend() {
        return composeWeekend(new Integer[]{Calendar.SATURDAY, Calendar.SUNDAY});
    }

    public static String getIslamicWeekend() {
        return composeWeekend(new Integer[]{Calendar.FRIDAY, Calendar.SATURDAY});
    }

    public static String getIndiaWeekend() {
        return String.valueOf(Calendar.SUNDAY);
    }

    public static Set<Integer> getWeekendsAsDays(String value) {
        final HashSet<Integer> result = new HashSet<Integer>();
        for (String day : StringUtils.commaDelimitedListToStringArray(value)) {
            result.add(Integer.valueOf(day));
        }
        return result;
    }

    protected static String composeWeekend(Integer[] days) {
        return StringUtils.arrayToCommaDelimitedString(days);
    }
}
