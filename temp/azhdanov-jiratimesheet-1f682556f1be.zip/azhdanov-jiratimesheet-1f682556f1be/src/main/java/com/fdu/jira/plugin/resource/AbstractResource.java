package com.fdu.jira.plugin.resource;

import com.google.common.base.Throwables;
import org.apache.commons.lang.StringUtils;

import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.Response;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public abstract class AbstractResource {

	protected Response getOkResponse(Object result) {
		return Response.ok(result).cacheControl(getNoCacheControl()).build();
	}

	protected Response getVoidOkResponse() {
        return Response.ok().cacheControl(getNoCacheControl()).build();
	}

    protected CacheControl getNoCacheControl() {
        CacheControl noCache = new CacheControl();
        noCache.setNoCache(true);
        return noCache;
    }

    protected Date getDateParam(String dateParam) {
        if (StringUtils.isNotBlank(dateParam)) {
            try {
                return new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.SSSZ").parse(dateParam);
            } catch (ParseException e) {
                throw Throwables.propagate(e);
            }
        }
        return null;
    }
}
