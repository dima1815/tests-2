package com.fdu.jira.util;

import jira.timesheet.plugin.license.TimesheetLicense;

import com.atlassian.upm.api.util.Option;

public interface ILicenseUtil {

    boolean isLicenseValid();

    void checkLicense();

    boolean isJiraOnDemand();

    String getLicenseStatus(boolean isFreeForJiraOnDemand);

    String getLicenseMgmtUrl(String contextPath);

    Option<TimesheetLicense> getTimesheetLicense();

    Option<TimesheetLicense> setTimesheetLicense(String rawLicense);

}
