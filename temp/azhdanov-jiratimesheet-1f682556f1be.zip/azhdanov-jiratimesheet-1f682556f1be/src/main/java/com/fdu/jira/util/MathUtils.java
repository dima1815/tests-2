package com.fdu.jira.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Mostly copied from {@link org.apache.velocity.runtime.parser.node.MathUtils} class
 * Original source code: http://velocity.apache.org/engine/devel/apidocs/org/apache/velocity/runtime/parser/node/MathUtils.html
 * for jira version 6.2.3+ velocity MathUtils class is available (it can be used and this class should be deleted)
 *
 * @author Roman Boris
 * @since 6/25/2014
 */
public class MathUtils {

    /**
     * The constants are used to determine in which context we have to calculate.
     */
    protected static final int BASE_LONG          = 0;
    protected static final int BASE_DOUBLE        = 2;

    /**
     * The <code>Class</code>-object is key, the maximum-value is the value
     */
    protected static final Map<Class<? extends Number>, BigDecimal> ints = new HashMap<Class<? extends Number>, BigDecimal>();
    static
    {
        ints.put (Byte.class, BigDecimal.valueOf (Byte.MAX_VALUE));
        ints.put (Short.class, BigDecimal.valueOf (Short.MAX_VALUE));
        ints.put (Integer.class, BigDecimal.valueOf (Integer.MAX_VALUE));
        ints.put (Long.class, BigDecimal.valueOf (Long.MAX_VALUE));
        ints.put (BigInteger.class, BigDecimal.valueOf (-1));
    }

    /**
     * The "size" of the number-types - ascending.
     */
    protected static final List<Class<? extends Number>> typesBySize = new ArrayList<Class<? extends Number>>();
    static
    {
        typesBySize.add (Byte.class);
        typesBySize.add (Short.class);
        typesBySize.add (Integer.class);
        typesBySize.add (Long.class);
        typesBySize.add (Float.class);
        typesBySize.add (Double.class);
    }

    /**
     * Convert the given Number to a BigInteger
     * @param n
     * @return The number as BigInteger
     */
    public static BigInteger toBigInteger (Number n)
    {

        if (n instanceof BigInteger)
        {
            return (BigInteger)n;
        }

        return BigInteger.valueOf (n.longValue());

    }

    /**
     * Test, whether the given object is an integer value
     * (Byte, Short, Integer, Long, BigInteger)
     * @param n
     * @return True if n is an integer.
     */
    public static boolean isInteger (Number n)
    {
        return ints.containsKey (n.getClass());
    }

    /**
     * Wrap the given primitive into the given class if the value is in the
     * range of the destination type. If not the next bigger type will be chosen.
     * @param value
     * @param type
     * @return Number object representing the primitive.
     */
    public static Number wrapPrimitive (long value, Class type)
    {
        if (type == Byte.class)
        {
            if (value > Byte.MAX_VALUE || value < Byte.MIN_VALUE)
            {
                type = Short.class;
            }
            else
            {
                // TODO: JDK 1.4+ -> valueOf()
                return (byte) value;
            }
        }
        if (type == Short.class)
        {
            if (value > Short.MAX_VALUE || value < Short.MIN_VALUE)
            {
                type = Integer.class;
            }
            else
            {
                // TODO: JDK 1.4+ -> valueOf()
                return (short) value;
            }
        }
        if (type == Integer.class)
        {
            if (value > Integer.MAX_VALUE || value < Integer.MIN_VALUE)
            {
                type = Long.class;
            }
            else
            {
                // TODO: JDK 1.4+ -> valueOf()
                return (int) value;
            }
        }
        if (type == Long.class)
        {
            // TODO: JDK 1.4+ -> valueOf()
            return value;
        }
        return BigInteger.valueOf(value);
    }

    /**
     * Wrap the result in the object of the bigger type.
     *
     * @param value result of operation (as a long) - used to check size
     * @param op1 first operand of binary operation
     * @param op2 second operand of binary operation
     * @return Number object of appropriate size to fit the value and operators
     */
    private static Number wrapPrimitive (long value, Number op1, Number op2)
    {
        if ( typesBySize.indexOf( op1.getClass()) > typesBySize.indexOf( op2.getClass()))
        {
            return wrapPrimitive( value, op1.getClass());
        }
        return wrapPrimitive( value, op2.getClass());
    }

    /**
     * Find the common Number-type to be used in calculations.
     *
     * @param op1 first operand of binary operation
     * @param op2 second operand of binary operation
     * @return constant indicating type of Number to use in calculations
     */
    private static int findCalculationBase (Number op1, Number op2)
    {
        boolean op1Int = isInteger(op1);
        boolean op2Int = isInteger(op2);

        if (op1Int && op2Int) {
            return BASE_LONG;
        }

        return BASE_DOUBLE;
    }

    /**
     * Add two numbers and return the correct value / type.
     * Overflow detection is done for integer values (byte, short, int, long) only!
     * @param op1
     * @param op2
     * @return Addition result.
     */
    public static Number add (Number op1, Number op2)
    {
        int calcBase = findCalculationBase( op1, op2);
        switch (calcBase)
        {
            case BASE_LONG:
                long l1 = op1.longValue();
                long l2 = op2.longValue();
                long result = l1+l2;

                // Overflow check
                if ((result ^ l1) < 0 && (result ^ l2) < 0)
                {
                    return toBigInteger( op1).add( toBigInteger( op2));
                }
                return wrapPrimitive( result, op1, op2);
            default:
                return op1.doubleValue() + op2.doubleValue();
        }
    }
}
