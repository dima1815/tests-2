package com.fdu.jira.plugin.resource.timechart;

import javax.xml.bind.annotation.XmlElement;

public class DataEntryRepresentation {

    @XmlElement
    protected String label;

    @XmlElement
    protected Long data;

    @XmlElement
    protected String url;

    @XmlElement
    protected String hint;

    @XmlElement
    protected ImageRepresentation[] icons;

    public DataEntryRepresentation() {
        // for JAXB
    }

    public DataEntryRepresentation(String label, Long spent, String url, String hint, ImageRepresentation[] icons) {
        this.label = label;
        this.data = spent;
        this.url = url;
        this.hint = hint;
        this.icons = icons;
    }
}
