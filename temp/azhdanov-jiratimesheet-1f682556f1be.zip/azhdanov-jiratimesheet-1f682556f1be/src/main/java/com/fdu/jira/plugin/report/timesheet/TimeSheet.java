/*
 * Copyright (c) 2002-2004
 * All rights reserved.
 */
package com.fdu.jira.plugin.report.timesheet;

import com.atlassian.jira.config.properties.APKeys;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.web.FieldVisibilityManager;
import com.atlassian.jira.web.action.ProjectActionSupport;
import com.fdu.jira.plugin.report.AbstractTimebaseReport;
import com.fdu.jira.util.ILicenseUtil;
import com.fdu.jira.util.TextUtil;
import com.google.common.collect.ImmutableMap;

import jira.plugin.report.timesheet.TimeBase;
import jira.plugin.report.timesheet.Timesheet;
import jira.plugin.report.timesheet.TimesheetService;
import jira.timesheet.plugin.configuration.IConfigurationService;
import jira.timesheet.plugin.job.FakeRequest;
import jira.timesheet.plugin.job.TimesheetAdapter;
import jira.timesheet.plugin.job.TimesheetJobConfiguration;
import jira.timesheet.plugin.job.TimesheetJobConfigurationManager;
import jira.timesheet.plugin.job.TimesheetSubscriptions;
import webwork.action.ActionContext;

import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;

import static com.atlassian.jira.util.ParameterUtils.getIntParam;
import static com.atlassian.jira.util.ParameterUtils.getBooleanParam;

/**
 * Generate a summary of worked hours in a specified period. The time period is
 * divided by the specified value for display.
 */
public class TimeSheet extends AbstractTimebaseReport<Timesheet> {

    public static final String PARAM_SHOW_INCOMPLETE_MSG = "showIncompleteMessage";
    public static final String PARAM_HIDE_UNSUBSCRIBE_LINK = "hideUnsubscribeLink";
    public static final String PARAM_ALLOW_SUBSCRIBE = "allowSubscribe";
    public static final String PARAM_EMAIL_JOB_CONFIGURATION = "emailJobConfiguration";

    private final TimesheetService timesheetService;
    private Timesheet timesheet;
    private final ApplicationProperties applicationProperties;
    private final TimesheetJobConfigurationManager timesheetJobConfigurationManager;

    public TimeSheet(DateTimeFormatterFactory dateTimeFormatterFactory,
            FieldVisibilityManager fieldVisibilityManager,
            JiraAuthenticationContext authenticationContext,
            TimeZoneManager timeZoneManager,
            ILicenseUtil licenseUtil,
            TimesheetService timesheetService,
            TimesheetJobConfigurationManager timesheetJobConfigurationManager,
            IConfigurationService configurationService,
            ApplicationProperties applicationProperties) {

        super(authenticationContext,
                dateTimeFormatterFactory,
                fieldVisibilityManager,
                timeZoneManager,
                licenseUtil,
                configurationService);

        this.timesheetService = timesheetService;
        this.timesheetJobConfigurationManager = timesheetJobConfigurationManager;
        this.applicationProperties = applicationProperties;
    }

    // Generate the report
    public String generateReport(ProjectActionSupport action, Map params,
        boolean excelView) throws Exception {

        if (timesheet == null) { // ConfigureReport!excelView.jspa and TimesheetJob do not call validate
            init(params);
        }

        timesheet.excelView = excelView;

        // get time spents
        if (timesheet.remoteUser != null) {            
            timesheetService.getTimeSpents(timesheet);
        }

        Map<String, Object> velocityParams = timesheet.resultParams;

        // Pass the issues to the velocity template
        if (excelView) {
            velocityParams.put("allWorkLogs", timesheet.allWorkLogs);
        } else {
            velocityParams.put("weekWorkLog", timesheet.weekWorkLog);
            /* else if (!timesheet.showDetails) {
                velocityParams.put("weekWorkLog", timesheet.weekWorkLogShort);
            }*/
            velocityParams.put("weekTotalTimeSpents", timesheet.weekTotalTimeSpents);
            velocityParams.put("userWeekTotalTimeSpents", timesheet.userWeekTotalTimeSpents);
            velocityParams.put("userIssueTotalTimeSpents", timesheet.userIssueTotalTimeSpents);
            velocityParams.put("projectTimeSpents", timesheet.projectTimeSpents);
            velocityParams.put("projectGroupedTimeSpents", timesheet.projectGroupedByFieldTimeSpents);
            velocityParams.put("additionalFieldSumByProjectMap", timesheet.additionalFieldSumByProjectMap);
        }

        prepareVelocityParams(velocityParams, timesheet);

        velocityParams.put("showDetails", timesheet.showDetails);
        String baseUrl = applicationProperties.getString(APKeys.JIRA_BASEURL);
        velocityParams.put("baseUrl", baseUrl);
        velocityParams.put("licenseMgmt", licenseUtil.getLicenseMgmtUrl(baseUrl));
        HttpServletRequest request = ActionContext.getRequest();
        if (request != null && request.getServletPath().startsWith("/secure/ConfigureReport")) { // report indeed
            Map<String, List<String>> queryParams = TextUtil.getQueryParams("?" + request.getQueryString());
            String queryString = TimesheetSubscriptions.getReportQueryString(queryParams, timesheet.i18n);
            TimesheetJobConfiguration[] jobConfigurations = timesheetJobConfigurationManager.getJobConfigurations(
                    timesheet.remoteUser, TimesheetAdapter.REPORT_KEY, queryString);
            if (jobConfigurations.length > 0) {
                velocityParams.put(PARAM_EMAIL_JOB_CONFIGURATION, jobConfigurations[0]);
            }
            velocityParams.put(PARAM_ALLOW_SUBSCRIBE, licenseUtil.isLicenseValid());
        } else if (request == null) { // rendering report for email
            licenseUtil.checkLicense(); // throws exception if license invalid
            Integer jobConfigurationId = getIntParam(params,
                    TimesheetAdapter.EMAIL_JOB_CONFIGURATION_ID_PARAM, 0);
            TimesheetJobConfiguration jobConfiguration =
                    timesheetJobConfigurationManager.getJobConfiguration(jobConfigurationId);
            velocityParams.put(PARAM_EMAIL_JOB_CONFIGURATION, jobConfiguration);
            FakeRequest req = new FakeRequest(baseUrl);
            velocityParams.put("req", req);
        }

        velocityParams.put(PARAM_SHOW_INCOMPLETE_MSG, getBooleanParam(params, PARAM_SHOW_INCOMPLETE_MSG));
        velocityParams.put(PARAM_HIDE_UNSUBSCRIBE_LINK, getBooleanParam(params, PARAM_HIDE_UNSUBSCRIBE_LINK));

        return descriptor.getHtml(excelView ? "excel" : "view",
                velocityParams);
    }

    protected void init(Map params) {
        User remoteUser = authenticationContext.getLoggedInUser();
        I18nHelper i18n = authenticationContext.getI18nHelper();
        TimeZone timezone = timeZoneManager.getLoggedInUserTimeZone();
        timesheet = new Timesheet(remoteUser, timezone, i18n,
                params,
                EnumSet.of(TimeBase.Options.DATES),
                EnumSet.of(Timesheet.Options.SHOW_WEEKENDS),
                configurationService);
    }

    // Validate the parameters set by the user.
    public void validate(ProjectActionSupport action, Map params) {
        super.validate(action, params);

        if (timesheetService.isForbiddenByTimesheetAuditorsGroup(timesheet)) {
            String error = action
                    .getText("group.timesheet.userNotInTimesheetAuditorsGroup");
            if (timesheet.targetGroup != null) {
                action.addError("targetGroup", error);
            } else if (timesheet.projectRoleId != null) {
                action.addError("projectRoleId", error);
            } else if (timesheet.projectId != null ) {
                action.addError("projectid", error);
            } else { // timesheet.targetUsre != remoteUser
                action.addError("targetUser", error);
            }
        }
    }

    @Override
    protected Map<String, String> getValidationErrorMessages() {
        return ImmutableMap.of("beforeStartDate", "report.timesheet.before.startdate");
    }

    @Override
    protected Timesheet getReportObject() {
        return timesheet;
    }
}
