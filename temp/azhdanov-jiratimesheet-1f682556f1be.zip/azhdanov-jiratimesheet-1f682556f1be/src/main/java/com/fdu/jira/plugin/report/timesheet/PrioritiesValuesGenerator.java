package com.fdu.jira.plugin.report.timesheet;

import java.util.Map;
import java.util.TreeMap;

import com.atlassian.configurable.ValuesGenerator;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.config.ConstantsManager;
import com.atlassian.jira.issue.priority.Priority;
import com.fdu.jira.util.TextUtil;

public class PrioritiesValuesGenerator implements ValuesGenerator {

    public Map<String, String> getValues(Map arg0) {
        Map<String, String> values = new TreeMap<String, String>();
        values.put("", TextUtil.NONE);
        ConstantsManager constantsManager =
            ComponentManager.getComponentInstanceOfType(ConstantsManager.class);

        for (Priority priority : constantsManager.getPriorityObjects()) {
            values.put(priority.getId(), TextUtil.getUnquotedString(priority.getName()));
        }
        return values;
    }

}
