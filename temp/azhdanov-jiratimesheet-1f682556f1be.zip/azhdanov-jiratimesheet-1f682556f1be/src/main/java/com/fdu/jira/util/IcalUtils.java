package com.fdu.jira.util;

import net.fortuna.ical4j.model.Component;
import net.fortuna.ical4j.model.Property;
import org.apache.commons.lang.StringUtils;

/**
 * ICalendar helpers methods.
 *
 * @author Roman Boris
 * @since 9/24/13
 */
public final class IcalUtils {

    public static final String YEARLY_RRULE = "FREQ=YEARLY;INTERVAL=1";

    public static String readValue(Component component, String property) {
        final Property cProp = component.getProperty(property);
        return cProp != null
                ? cProp.getValue()
                : null;
    }

    public static boolean isYearlyRRule(String value) {
        return StringUtils.equals(value, YEARLY_RRULE);
    }
}
