package com.fdu.jira.util;

import com.atlassian.core.util.DateUtils;
import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.jira.datetime.DateTimeFormatter;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.fields.AffectedVersionsSystemField;
import com.atlassian.jira.issue.fields.AssigneeSystemField;
import com.atlassian.jira.issue.fields.ComponentsSystemField;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.fields.Field;
import com.atlassian.jira.issue.fields.FieldManager;
import com.atlassian.jira.issue.fields.FixVersionsSystemField;
import com.atlassian.jira.issue.fields.IssueLinksSystemField;
import com.atlassian.jira.issue.fields.IssueTypeSystemField;
import com.atlassian.jira.issue.fields.LabelsSystemField;
import com.atlassian.jira.issue.fields.OriginalEstimateSystemField;
import com.atlassian.jira.issue.fields.PrioritySystemField;
import com.atlassian.jira.issue.fields.ProjectSystemField;
import com.atlassian.jira.issue.fields.ResolutionSystemField;
import com.atlassian.jira.issue.fields.SecurityLevelSystemField;
import com.atlassian.jira.issue.fields.StatusSystemField;
import com.atlassian.jira.issue.fields.TimeEstimateSystemField;
import com.atlassian.jira.issue.fields.TimeSpentSystemField;
import com.atlassian.jira.issue.fields.TimeTrackingSystemField;
import com.atlassian.jira.issue.fields.layout.field.FieldLayoutItem;
import com.atlassian.jira.issue.fields.layout.field.FieldLayoutManager;
import com.atlassian.jira.issue.issuetype.IssueType;
import com.atlassian.jira.issue.link.IssueLinkManager;
import com.atlassian.jira.issue.link.IssueLinkType;
import com.atlassian.jira.issue.link.LinkCollection;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.issue.search.SearchResults;
import com.atlassian.jira.issue.security.IssueSecurityLevel;
import com.atlassian.jira.issue.security.IssueSecurityLevelManager;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.jelly.tag.admin.CreateCustomField;
import com.atlassian.jira.ofbiz.OfBizValueWrapper;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.user.util.UserUtil;
import com.atlassian.jira.util.Function;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.util.JiraKeyUtils;
import com.atlassian.jira.web.bean.PagerFilter;
import com.atlassian.jira.workflow.JiraWorkflow;
import com.atlassian.jira.workflow.WorkflowManager;
import com.atlassian.velocity.VelocityManager;
import com.opensymphony.util.TextUtils;
import com.opensymphony.workflow.loader.StepDescriptor;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import jira.timesheet.plugin.configuration.IConfigurationService;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.apache.velocity.exception.VelocityException;

public class TextUtil {
    public static final String NO_VALUE_FOR_FIELD = "NoValueForFieldOnIssue";

    private final long secondsPerDay;
	private final long secondsPerWeek;
	private final NumberFormat decimalFormat;
	private final NumberFormat percentFormat;
	private final Pattern servletUrlPattern;
	private final DateFormat dateFormat1;
	private final DateFormat dateFormat2;
	private final Boolean prettyDuration;
	private final String composeIssueLink;
    private final TimeZone loggedInUserTimeZone;
    private final CustomField utilizationField;
    private final CustomField epicLinkField;
    private final CustomField parentIssueField;
    private final SearchService searchService;
	
	private static final Logger log = Logger.getLogger(TextUtil.class);
	private final VelocityManager velocityManager;
        private final IssueLinkManager issueLinkManager;
        private final JiraAuthenticationContext authenticationContext;
        private final UserUtil userUtil;
        private final TimeZoneManager timeZoneManager;
        private final IConfigurationService configurationService;
        private final FieldManager fieldManager;
        private final FieldLayoutManager fieldLayoutManager;
        private final WorkflowManager workflowManager;
        private final IssueSecurityLevelManager securityLevelManager;

        public static final String PROJECT_ROLE_PSEUDO_FIELD_ID = "customfield_projectrole";
        public static final String PROJECT_ROLE_PSEUDO_FIELD_NAME = "Role";
        public static final String WORKED_USER_PSEUDO_FIELD_ID = "customfield_workeduser";
        public static final String WORKED_USER_PSEUDO_FIELD_NAME = "Worked User";
        public static final String WORKLOG_CREATED_PSEUDO_FIELD_ID = "customfield_worklogcreated";
        public static final String WORKLOG_CREATED_PSEUDO_FIELD_NAME = "Worklog Created";
        public static final String GROUP_PSEUDO_FIELD_ID = "customfield_group";
        public static final String GROUP_PSEUDO_FIELD_NAME = "Group";
        public static final String NONE = "None";

        private static final String WORK_UNDER_LIMIT = "workUnderLimit";
        private static final String WORK_OVER_LIMIT = "workOverLimit";
        private static final String GH_PLUGIN_KEY = "com.pyxis.greenhopper.jira";
        private static final String GH_EPIC_LINK_FIELD_KEY = GH_PLUGIN_KEY + ":gh-epic-link";
        private static final Object GH_RANK_FIELD_KEY = GH_PLUGIN_KEY + ":gh-global-rank";
        private static final Object GH_RANK_FIELD_KEY2 = GH_PLUGIN_KEY + ":gh-lexo-rank";
        private static final String GH_SPRINT_FIELD_KEY = GH_PLUGIN_KEY + ":gh-sprint";
        private static final Object LABELS_FIELD_KEY = CreateCustomField.FIELD_TYPE_PREFIX + "labels";

	/**
	 * Instantiate TextUtil object
	 * @param i18nBean
	 */
        // TODO: TextUtil service listening to configuration changes 
	public TextUtil(I18nHelper i18n, TimeZone timezone, IConfigurationService configurationService) {
            this.loggedInUserTimeZone = timezone;
            this.configurationService = configurationService;
            ApplicationProperties ap = ComponentManager.getComponentInstanceOfType(ApplicationProperties.class);
            velocityManager = ComponentManager.getComponentInstanceOfType(VelocityManager.class);
            issueLinkManager = ComponentManager.getComponentInstanceOfType(IssueLinkManager.class);
            authenticationContext = ComponentManager.getComponentInstanceOfType(JiraAuthenticationContext.class);
            userUtil = ComponentManager.getComponentInstanceOfType(UserUtil.class);
            timeZoneManager = ComponentManager.getComponentInstanceOfType(TimeZoneManager.class);
            fieldManager = ComponentManager.getComponentInstanceOfType(FieldManager.class);
            fieldLayoutManager = ComponentManager.getComponentInstanceOfType(FieldLayoutManager.class);
            workflowManager = ComponentManager.getComponentInstanceOfType(WorkflowManager.class);
            securityLevelManager = ComponentManager.getComponentInstanceOfType(IssueSecurityLevelManager.class);

                secondsPerDay = new Float(Float.valueOf(ap.getDefaultBackedString("jira.timetracking.hours.per.day")) * 3600).longValue();
		secondsPerWeek = new Float(Float.valueOf(ap.getDefaultBackedString("jira.timetracking.days.per.week")) * secondsPerDay).longValue();
		decimalFormat = NumberFormat.getInstance(i18n.getLocale());
		percentFormat = NumberFormat.getPercentInstance(i18n.getLocale());
		servletUrlPattern = Pattern.compile("^(.+?)://(.+?)/(.+)$");
                String formatDay1 = configurationService.getDayFormat1();
                if (formatDay1 == null) {
                    formatDay1 = "E";
                }
		String formatDay2 = configurationService.getDayFormat2();
		if (formatDay2 == null) {
		    formatDay2 = "d/MMM";
		}
		// FIXME: match the user's specified time zone in JIRA,
		// use com.atlassian.jira.datetime.DateTimeFormatter 
	        dateFormat1 = new SimpleDateFormat(formatDay1,i18n.getLocale());
	        dateFormat1.setTimeZone(timezone);
	        dateFormat2 = new SimpleDateFormat(formatDay2,i18n.getLocale());
                dateFormat2.setTimeZone(timezone);

                final String decimalSeparator = configurationService.getDecimalSeparator();
                if (decimalSeparator != null && decimalFormat instanceof DecimalFormat) {
                    DecimalFormatSymbols dfs = ((DecimalFormat)decimalFormat).getDecimalFormatSymbols();
                    dfs.setDecimalSeparator(decimalSeparator.charAt(0));
                    ((DecimalFormat)decimalFormat).setDecimalFormatSymbols(dfs);
                }

        final Integer maxFractionDigits = configurationService.getMaxFractionDigits();
        if (maxFractionDigits != null) {
            decimalFormat.setMaximumFractionDigits(maxFractionDigits);
        }

                prettyDuration = configurationService.isPrettyDuration();
                composeIssueLink = configurationService.getComposeIssueLink();

        CustomFieldManager customFieldManager = ComponentManager.getComponentInstanceOfType(CustomFieldManager.class);
        utilizationField = customFieldManager.getCustomFieldObjectByName("utilization");
        List<CustomField> customFields = customFieldManager.getCustomFieldObjects();
        CustomField epicLinkField = null;
        for (CustomField customField : customFields) {
            if (isEpicLinkField(customField)) {
                epicLinkField = customField;
                break;
            }
        }
        this.epicLinkField = epicLinkField;  // Issue#439: Epic fields for sub-tasks

        // Issue#483: Option for summing tasks by Epic
        String parentIssueFieldId = configurationService.getParentIssueField();
        if (epicLinkField != null && epicLinkField.getId().equals(parentIssueFieldId)) {
            this.parentIssueField = epicLinkField;
        } else {
            this.parentIssueField = null;
        }
        
        searchService = ComponentManager.getComponentInstanceOfType(SearchService.class);
	}

	public String formatDayHtml(Date date) {
	    return dateFormat1.format(date) + "<br/>" + dateFormat2.format(date);
	}
	
    public String formatWeek(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.WEEK_OF_MONTH, 1);
        c.add(Calendar.DAY_OF_MONTH, -1);
        return dateFormat2.format(date) + " - " + dateFormat2.format(c.getTime());
    }

    public String formatWeekDay(Date date) {
        return dateFormat2.format(date);
    }

    public String getHoursCss(long seconds) {
        Integer highlightHours = configurationService.getHighlightHours();
        if (highlightHours > 0) {
            long secondsThreshold = highlightHours * 60 * 60;
            if (seconds < secondsThreshold) {
                return WORK_UNDER_LIMIT;
            } else if (seconds > secondsThreshold) {
                return WORK_OVER_LIMIT;
            }
        }
        return "";
    }

    public String getHoursStyle(long seconds) {
        String css = getHoursCss(seconds);
        // see timesheet.css
        if (WORK_UNDER_LIMIT.equals(css)) {
            return "color: brown;";
        } else if (WORK_OVER_LIMIT.equals(css)) {
            return "color: red;";
        } else {
            return "";
        }
    }

        /**
	 * Format duration value
	 * @param value
	 * @return pretty formatted value, using Jira settings for hours in day, and days in week.
	 */
    public String getPrettyDuration(long value) {
        // short format, no localization
        return DateUtils.getDurationStringSeconds(value, secondsPerDay, secondsPerWeek);
    }
    
	/**
	 * Format duration value in hours
	 * @param value
	 * @return value
	 */
    public String getPrettyHours(long value) {
        return prettyDuration ? getPrettyDuration(value) : getHours(value) + "h";
    }

	/**
	 * Format duration value in hours
	 * @param value
	 * @return pretty formatted value
	 */
    public String getHours(long value)
    {
    	return decimalFormat.format(((float)value) / 60 / 60);
    }
    
    /**
     * Expand relative url to absolute path
     */
    public String expandUrl(HttpServletRequest req, String url) {
    	String path = req.getRequestURL().toString();
    	Matcher m = servletUrlPattern.matcher(path);
    	if (m.matches()) {
    		return m.group(1) + "://" + m.group(2) + req.getContextPath() + url;
    	} else {
    		return url;
    	}
    }

    /** 
     * Convert to percents.
     * 
     * @param value value
     * @param hundred hundreds of value
     * @return percetns
     */
    public String getPercents(long value, long hundred) {
        if (hundred == 0L) {
            return "&nbsp;";
        }
        float percents = ((float)value) * 100 / hundred;
        return percentFormat.format(percents);
    }

    /**
     * Get issue field value by field id for the issue.
     *
     * @param groupByFieldID
     * @param issue
     * @param dateTimeFormatter
     * @return String value concatenated for multi-select or null.
     */
    public String getFieldValue(String groupByFieldID, Issue issue,
            DateTimeFormatter  dateTimeFormatter, Worklog worklog) {
        if (groupByFieldID == null) {
            return "";
        } else if (groupByFieldID.equals(PROJECT_ROLE_PSEUDO_FIELD_ID)) {
            User workedUser = DirectoryUtil.getUser(userUtil, worklog.getAuthor());
            return getProjectRoles(workedUser, issue);
        } else if (groupByFieldID.equals(WORKED_USER_PSEUDO_FIELD_ID)) {
            User workedUser = DirectoryUtil.getUser(userUtil, worklog.getAuthor());
            return workedUser.getDisplayName();
        } else if (groupByFieldID.equals(GROUP_PSEUDO_FIELD_ID)) {
            return getUserGroups(worklog.getAuthor());
        } else if (groupByFieldID.equals(WORKLOG_CREATED_PSEUDO_FIELD_ID)){
            return dateTimeFormatter.format(worklog.getCreated());
        } else {
            return getFieldValue(groupByFieldID, issue, dateTimeFormatter, null, true);
        }
    }

    /**
     * Get issue field value by field id for the issue.
     *
     * @param groupByFieldID
     * @param issue
     * @param dateTimeFormatter
     * @param req if to render html for timetracking field
     * @return String value concatenated for multi-select or null.
     */
    public String getFieldValue(String groupByFieldID, Issue issue,
                                DateTimeFormatter  dateTimeFormatter, String contextPath, boolean sumSubTasks) {
        return getFieldTextValue(
                groupByFieldID,
                getFieldObjectValue(groupByFieldID, issue, contextPath, sumSubTasks));
    }

    public Object getFieldObjectValue(String groupByFieldID, Issue issue, String contextPath, boolean sumSubTasks) {
        if (groupByFieldID == null) {
            return "";
        } else if (groupByFieldID.equals(PROJECT_ROLE_PSEUDO_FIELD_ID)
                || groupByFieldID.equals(WORKED_USER_PSEUDO_FIELD_ID)
                || groupByFieldID.equals(GROUP_PSEUDO_FIELD_ID)
                || groupByFieldID.equals(WORKLOG_CREATED_PSEUDO_FIELD_ID)) {
            return NO_VALUE_FOR_FIELD;
        }

        Field groupByField = fieldManager.getField(groupByFieldID);
        if (groupByField == null) {
            log.error("Field '" + groupByFieldID + "' does not exist");
            return "";
        }

        // Set field value
        Object fieldValue = null;
        if (groupByField instanceof CustomField) {
            CustomField customField = (CustomField) groupByField;
            IssueType issueType = issue.getIssueTypeObject();
            // Issue#439: Epic fields for sub-tasks
            String customFieldType = customField.getCustomFieldType().getKey();
            if (customFieldType.startsWith(GH_PLUGIN_KEY) &&
                    // Issue#552: beside gh-sprint and gh-rank, TODO: more non-epic fields?
                    !customFieldType.equals(GH_SPRINT_FIELD_KEY) &&
                    !customFieldType.equals(GH_RANK_FIELD_KEY) &&
                    !customFieldType.equals(GH_RANK_FIELD_KEY2)) {
                issue = getEpic(issue, customField);
            }
            Object value = customField.getValue(issue);
            if (value != null
                    // Issue#542
                    && !customFieldType.equals(LABELS_FIELD_KEY)) {
                FieldLayoutItem fieldLayoutItem = fieldLayoutManager
                        .getFieldLayout(issue.getProjectObject(), issueType.getId())
                        .getFieldLayoutItem(groupByFieldID);
                if (fieldLayoutItem != null) {
                    fieldValue = customField.getViewHtml(fieldLayoutItem, null, issue);
                } else {
                    fieldValue = "";
                }
                
            /*
                if (groupByField instanceof CustomFieldStattable) {
                        StatisticsMapper sm = ((CustomFieldStattable)
                                groupByField).getStatisticsMapper((CustomField) groupByField);
                        fieldValue = sm.getValueFromLuceneField(value.toString()).toString();
                    }
                if (value instanceof List) {
                    fieldValue = getMultiValue((List) value);
                } else if (value instanceof Date ) {
                    fieldValue = dateTimeFormatter.format((Date) value);
                } else if (value instanceof User){
                    fieldValue = ((User) value).getDisplayName();
                } else if (value instanceof Map) {
                    fieldValue = getMultiValue((Map) value);
                } else {
                    fieldValue = value.toString();
                }
            */
            } else {
                fieldValue = value;
            }
        } else if (groupByField instanceof ComponentsSystemField) {
            /*
               * Implementation to handle GroupBy Component. Issue TIME-54.
               * Caveat: When there are multiple components assigned to one
               * issue, the component names are concatenated and the grouping
               * is done by the concatenated string. The issue isn't
               * counted/grouped for each component.
               */
            fieldValue = issue.getComponents();
        } else if (groupByField instanceof AffectedVersionsSystemField) {
            fieldValue = issue.getAffectedVersions();
        } else if (groupByField instanceof FixVersionsSystemField) {
            fieldValue = issue.getFixVersions();
        } else if (groupByField instanceof IssueTypeSystemField) {
            fieldValue = issue.getIssueTypeObject().getNameTranslation();
        } else if (groupByField instanceof LabelsSystemField) {
            fieldValue = issue.getLabels();
        } else if (groupByField instanceof StatusSystemField) {
            fieldValue = issue.getStatusObject().getName(); 
        } else if (groupByField instanceof IssueLinksSystemField) {
            fieldValue = issue;
        } else if (groupByField instanceof SecurityLevelSystemField) {
            Long securityLevelId = issue.getSecurityLevelId();
            if (securityLevelId != null) {
                IssueSecurityLevel securityLevel = securityLevelManager.getSecurityLevel(securityLevelId);
                fieldValue = securityLevel.getName();
            }
        } else if (groupByField instanceof TimeTrackingSystemField) {
            Long timeSpent = getIssueTimeSpent(issue, sumSubTasks);
            Long remaining = getIssueRemainingEstimate(issue, sumSubTasks);
            if (contextPath != null) {
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("timeSpent", getFieldName("timespent") + " - " + getPrettyHours(timeSpent));
                params.put("timeSpentRate", Math.round((float) timeSpent) * 100 / (timeSpent + remaining));
                params.put("remaining", getFieldName("timeestimate") + " - " + getPrettyHours(remaining));
                params.put("remainingRate", Math.round((float) remaining) * 100 / (timeSpent + remaining));
                params.put("contextPath", contextPath);
                try {
                    fieldValue = velocityManager.getBody("/templates/timesheetreport/", "timetracking.vm", params);
                } catch (VelocityException e) {
                    log.warn("Error while rendering timetracking field", e);
                }
            } else {
                fieldValue = getPrettyHours(timeSpent) +
                        "/" + getPrettyHours(remaining);
            }
        } else if (groupByField instanceof TimeSpentSystemField) {
            fieldValue = getIssueTimeSpent(issue, sumSubTasks);
        } else if (groupByField instanceof TimeEstimateSystemField) {
            fieldValue = getIssueRemainingEstimate(issue, sumSubTasks);
        } else if (groupByField instanceof OriginalEstimateSystemField) {
            fieldValue = getIssueOriginalEstimate(issue, sumSubTasks);
        } else if (groupByField instanceof ProjectSystemField) {
            fieldValue = issue.getProjectObject().getName();
        } else if (groupByField instanceof PrioritySystemField) {
            fieldValue = issue.getPriorityObject().getName();
        } else if (groupByField instanceof ResolutionSystemField && issue.getResolutionObject() != null) {
            fieldValue = issue.getResolutionObject().getName();
        } else if (groupByField instanceof AssigneeSystemField) {
            User assignee = issue.getAssignee();
            if (assignee != null) {
                fieldValue = assignee.getDisplayName();
            } // else NO_VALUE_FOR_FIELD;
        } else {
            // TODO Couldn't find an easy way to get each fields value as
            // string. Workaround.
            try {
                fieldValue = issue.getString(groupByFieldID);
            } catch (RuntimeException e) {
                fieldValue = "FieldTypeValueNotApplicableForGrouping";
            }
        }

        // need a string as reference element in map for grouping
        if (fieldValue == null
                || (fieldValue instanceof String && ((String) fieldValue).trim().length() == 0)
                || (fieldValue instanceof Collection && ((Collection) fieldValue).size() == 0)) {
            fieldValue = NO_VALUE_FOR_FIELD;
        }

        return fieldValue;        
    }

    public String getFieldTextValue(
            final String fieldId,
            final Object value) {

        if (value instanceof String) {
            return value.toString();
        } else if (value instanceof Collection) {
            return getMultiValue((Collection) value);
        } else if (value instanceof Issue) {
            return getIssueLinks((Issue) value);
        }

        final Field field = fieldManager.getField(fieldId);

        if (field instanceof TimeSpentSystemField
                || field instanceof TimeEstimateSystemField
                || field instanceof OriginalEstimateSystemField) {
            return getPrettyHours(Long.valueOf(value.toString()));
        }

        return value.toString();
    }

    private Issue getEpic(Issue issue, CustomField customField) {
        if (issue.isSubTask()) {
            return getEpic(issue.getParentObject(), customField);
        } else if (epicLinkField != null && !isEpicLinkField(customField) && !isEpic(issue)) {
            Issue epic = (Issue) issue.getCustomFieldValue(epicLinkField);
            if (epic != null) {
                return epic;
            }
        }
        return issue;
    }

    public CustomField getParentIssueField() {
        return parentIssueField;
    }

    public static boolean isEpicLinkField(CustomField customField) {
        // field value must be of type Issue for TimeBaseService.get getLinkedIssue
        return GH_EPIC_LINK_FIELD_KEY.equals(customField.getCustomFieldType().getKey());
    }

    private boolean isEpic(Issue issue) {
        // FIXME: support generic parentIssueField, check if field is applicable to issue?
        return "Epic".equals(issue.getIssueTypeObject().getName());
        
    }

    /**
     * Gets workplan time with utilization respect.
     *
     * @param issue issue
     * @param estimateConsidered used time
     * @return planned time
     */
    public long getPlannedTime(final Issue issue, final long estimateConsidered) {
        long workplanTime = 0L;
        long estimate = getIssueRemainingEstimate(issue, /*sumSubTasks*/ false);
        float utilization = getUtilizationValue(issue);
        workplanTime = Math.round(secondsPerDay * utilization);
        // remaining estimate < workplanTime
        if (estimate - estimateConsidered > 0 && estimate - estimateConsidered < workplanTime) {
            workplanTime = estimate - estimateConsidered;
        }

        return workplanTime;
    }

    /**
     * Gets utilization value for a specified issue.
     * <br/>
     * If "utilization" custom field is not defined or it's value, is not defined or is negative number - than assumes 1.
     *
     * @param issue issue
     * @return utilization value
     */
    private float getUtilizationValue(Issue issue) {
        float result = 1;
        if (utilizationField != null) {
            final Object valueObj = utilizationField.getValue(issue);
            String value = valueObj != null
                    ? StringUtils.trim(valueObj.toString())
                    : null;
            if (StringUtils.isNotBlank(value) && !StringUtils.startsWith(value, "-")) {
                boolean percents = false;
                if (StringUtils.endsWith(value, "%")) {
                    percents = true;
                    value = StringUtils.substringBeforeLast(value, "%");
                }
                if (NumberUtils.isNumber(value))
                {
                    result = NumberUtils.createFloat(value);
                    if (percents) {
                        result = result / 100;
                    }
                    if (result > 1) { // can't be more than 100% utilization
                        result = 1;
                    }
                }
            }
        }
        return result;
    }

    private long getIssueTime(final Issue issue, final boolean sumSubTasks,
            final Function<Issue, Long> timeFunction, final Set<String> previousIssues) {
        previousIssues.add(issue.getKey());
        long time = timeFunction.get(issue);
        if (sumSubTasks) {
            Collection<Issue> subTasks = issue.getSubTaskObjects();
            User remoteUser = authenticationContext.getLoggedInUser();
            if (subTasks != null && subTasks.size() > 0) {
                for (Issue subTask : subTasks) {
                    if (!previousIssues.contains(subTask.getKey())) {
                        time += getIssueTime(subTask, sumSubTasks, timeFunction, previousIssues);
                    }
                }
                
            } else if (composeIssueLink != null) {
                LinkCollection linkCollection = issueLinkManager.getLinkCollection(issue, remoteUser);
                List<Issue> linkedIssues = linkCollection.getInwardIssues(composeIssueLink);
                if (linkedIssues != null) {
                    for (Issue linkedIssue: linkedIssues) {
                        if (!previousIssues.contains(linkedIssue.getKey())) {
                            time += getIssueTime(linkedIssue, sumSubTasks, timeFunction, previousIssues);
                        }
                    }
                }
            } if (parentIssueField != null && isEpic(issue)) {
                final SearchService.ParseResult parseResult =
                        searchService.parseQuery(remoteUser, "\"" + parentIssueField.getNameKey() + "\" = " + issue.getKey());
                if (parseResult.isValid()) {
                    try {
                        SearchResults results = searchService.search(remoteUser,
                                    parseResult.getQuery(), PagerFilter.getUnlimitedFilter());
                        for (Issue childIssue : results.getIssues()) {
                            if (!previousIssues.contains(childIssue.getKey())) {
                                time += getIssueTime(childIssue, sumSubTasks, timeFunction, previousIssues);
                            }
                        }
                    } catch (SearchException e) {
                        log.warn("Error searching for epic issues: " + e.getMessage());
                    }
                } else {
                    log.warn("Error parsing epic issues query: " + parseResult.getErrors());
                }
            }
        } // else !sumSubTasks
        return time;
        
    }

    private long getIssueTimeSpent(Issue issue, boolean sumSubTasks) {
        return getIssueTime(issue, sumSubTasks, new Function<Issue, Long>() {
            public Long get(Issue issue) {
                Long time = issue.getTimeSpent();
                if (time == null) {
                    time = 0L;
                }
                return time;
                
            }
        }, new TreeSet<String>());
    }

    private long getIssueRemainingEstimate(Issue issue, boolean sumSubTasks) {
        return getIssueTime(issue, sumSubTasks, new Function<Issue, Long>() {
            public Long get(Issue issue) {
                Long time = issue.getEstimate();
                if (time == null) {
                    time = 0L;
                }
                return time;

            }
        }, new TreeSet<String>());
    }

    private long getIssueOriginalEstimate(Issue issue, boolean sumSubTasks) {
        return getIssueTime(issue, sumSubTasks, new Function<Issue, Long>() {
            public Long get(Issue issue) {
                Long time = issue.getOriginalEstimate();
                if (time == null) {
                    time = 0L;
                }
                return time;
                
            }
        }, new TreeSet<String>());
    }

    public static String getProjectRoles(Worklog worklog) {
        UserUtil userUtil = ComponentManager.getComponentInstanceOfType(UserUtil.class);
        User workedUser = DirectoryUtil.getUser(userUtil, worklog.getAuthor());
        return getProjectRoles(workedUser, worklog.getIssue());
    }

    public static String getProjectRoles(User workedUser, Issue issue) {
        ProjectRoleManager projectRoleManager = ComponentManager.getComponentInstanceOfType(
                ProjectRoleManager.class);
        Collection<ProjectRole> projectRoles = projectRoleManager.getProjectRoles(workedUser, issue.getProjectObject());
        if (projectRoles == null || projectRoles.size() == 0) {
            return "";
        } else {
            return TextUtils.plainTextToHtml(projectRoles.iterator().next().getName());
        }
    }

    public String getUserGroups(String userName) {
        final SortedSet<String> groups = userUtil.getGroupNamesForUser(userName);
        if (CollectionUtils.isNotEmpty(groups)) {
            return groups.iterator().next();
        }
        return "";
    }

    // https://developer.atlassian.com/display/JIRADEV/Retrieving+issue%27s+links
    public static String getIssueLinks(Issue issue) {
        StringBuffer result = new StringBuffer();
        IssueLinkManager issueLinkManager = ComponentManager.getComponentInstanceOfType(IssueLinkManager.class);
        JiraAuthenticationContext authenticationContext = ComponentManager.getComponentInstanceOfType(JiraAuthenticationContext.class);
        User remoteUser = authenticationContext.getLoggedInUser();
        LinkCollection linkCollection = issueLinkManager.getLinkCollection(issue, remoteUser);
        Set<IssueLinkType> linkTypes = linkCollection.getLinkTypes();
        for (IssueLinkType linkType : linkTypes) {
            appendLinkedIssues(linkCollection.getOutwardIssues(linkType.getName()), linkType.getOutward(), result);
            appendLinkedIssues(linkCollection.getInwardIssues(linkType.getName()), linkType.getInward(), result);
        }
        return result.toString();
    }

    private static void appendLinkedIssues(List<Issue> linkedIssues, String linkName, StringBuffer result) {
        if (linkedIssues != null) {
            result.append(TextUtils.plainTextToHtml(linkName));
            result.append(": ");
            for (int i = 0; i < linkedIssues.size(); i++) {
                Issue linkedIssue = linkedIssues.get(i);
                result.append(linkedIssue.getKey());
                if (i + 1 < linkedIssues.size()) {
                    result.append(", ");
                }
            }
            result.append("<br/>");
        }
    }

    @SuppressWarnings("unchecked")
    public static String getMultiValue(Collection values) {
        final List<String> fieldValues = new ArrayList<String>();
        for (Object o : values) {
            String value = null;
            if (o instanceof Map) {
                final Map<String, Object> map = (Map<String, Object>) o;
                // do not check if (map.containsKey("name")) intentionally
                // for better diagnosability
                value = (String) map.get("name");
            } else if (o instanceof OfBizValueWrapper) {
                final OfBizValueWrapper map = (OfBizValueWrapper) o;
                value = map.getString("name");
            } else if (o instanceof User){
                value = ((User) o).getDisplayName();
            } else if (o != null) {
                value = o.toString();
            }
            if (value != null) {
                fieldValues.add(value);
            }
        }
        return StringUtils.join(fieldValues, ", ");
    }

    public String getMultiValue(Map value) {
        return getMultiValue(value.values());
    }

    /**
     * @deprecated since JIRA 6 it's not needed
     */
    @Deprecated
    public static String getUnquotedString(String s) {
        if (isJira6()) {
            return s; // JRA-31905: no need to escape anything anymore
        }
        return TextUtils.plainTextToHtml(s, false);
    }

    public static boolean isJira6() {
        com.atlassian.sal.api.ApplicationProperties applicationProperties =
                ComponentManager.getOSGiComponentInstanceOfType(com.atlassian.sal.api.ApplicationProperties.class);
        return applicationProperties.getVersion().startsWith("6.");
    }

    public static String getFieldName(String fieldID) {
        if (fieldID.equals(PROJECT_ROLE_PSEUDO_FIELD_ID)) {
            return PROJECT_ROLE_PSEUDO_FIELD_NAME;
        } else if (fieldID.equals(WORKED_USER_PSEUDO_FIELD_ID)) {
            return WORKED_USER_PSEUDO_FIELD_NAME;
        } else if (fieldID.equals(GROUP_PSEUDO_FIELD_ID)) {
            return GROUP_PSEUDO_FIELD_NAME;
        } else if (fieldID.equals(WORKLOG_CREATED_PSEUDO_FIELD_ID)) {
            return WORKLOG_CREATED_PSEUDO_FIELD_NAME;
        } else {
            FieldManager fieldManager = 
                (FieldManager) ComponentManager.getComponentInstanceOfType(FieldManager.class);
            Field groupByField = fieldManager.getField(fieldID);
            return groupByField != null ? groupByField.getName() : "N/A";
        }
    }

    // https://bitbucket.org/azhdanov/jiratimesheet/issue/443
    public Boolean isIssueEditable(Issue issue) {
        // Could check Edit Issue Permission first
        JiraWorkflow workflow = workflowManager.getWorkflow(issue);
        StepDescriptor currentStep = workflow.getLinkedStep(issue.getStatusObject());
        Map<String, String> properties = currentStep.getMetaAttributes();
        String editAllowed = properties.get(JiraWorkflow.JIRA_META_ATTRIBUTE_EDIT_ALLOWED);
    	return editAllowed == null || Boolean.valueOf(editAllowed);
    }

    public static String urlencode(Object source) throws UnsupportedEncodingException {
        return URLEncoder.encode(source.toString(), "UTF-8");
    }
   
    public static String makeLinkedHtml(String s) {
        return JiraKeyUtils.linkBugKeys(TextUtils.plainTextToHtml(s));
    }

    // see pivot-report-excel.vm and timesheet-report-excel.vm
    public Date getWorklogStartDate(Worklog worklog) {
        User workedUser = DirectoryUtil.getUser(userUtil, worklog.getAuthor());
        TimeZone workedUserTimeZone = timeZoneManager.getTimeZoneforUser(workedUser); 
        Calendar otherDate = CalendarUtil.convertWorkedTimeDate(worklog.getStartDate(),
                workedUserTimeZone, loggedInUserTimeZone, /* truncate */ false);
        return otherDate.getTime();
    }

    // http://stackoverflow.com/questions/5902090/how-to-extract-parameters-from-a-given-url
    public static Map<String, List<String>> getQueryParams(String url) {
        // using TreeSet to check if already subscribed
        Map<String, List<String>> params = new TreeMap<String, List<String>>();
        String[] urlParts = url.split("\\?");
        if (urlParts.length > 1) {
            String query = urlParts[1];
            for (String param : query.split("&")) {
                try {
                    String[] pair = param.split("=");
                    String key = URLDecoder.decode(pair[0], "UTF-8");
                    if (pair.length > 1) {
                        String value = URLDecoder.decode(pair[1], "UTF-8");
                        List<String> values = params.get(key);
                        if (values == null) {
                            values = new LinkedList<String>();
                            params.put(key, values);
                        }
                        values.add(value);
                    }
                    
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
            }
        }

        return params;
    }

    public static String toQueryParams(Map<String, List<String>> queryParams) {
        StringBuilder sb = new StringBuilder();
        for (String param : queryParams.keySet()) {
            List<String> values = queryParams.get(param);
            for (int i = 0; i < values.size(); i++) {
                String value = values.get(i);
                try {
                    sb.append(param).append("=").append(urlencode(value));
                    if (i + 1 < values.size()) {
                        sb.append("&");
                    }
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
            }
            sb.append("&");
        }
        return sb.length() > 0 ? sb.substring(0, sb.length() - 1) : "";
    }

    public static String toComaSeparatedString(List<String> list) {
        final StringBuilder sb = new StringBuilder();
        if (list != null) {
            for (String string : list) {
                sb.append(string);
                sb.append(", ");
            }
        }
        return sb.length() > 0 ? sb.substring(0, sb.length() - 2) : "";
    }
}

