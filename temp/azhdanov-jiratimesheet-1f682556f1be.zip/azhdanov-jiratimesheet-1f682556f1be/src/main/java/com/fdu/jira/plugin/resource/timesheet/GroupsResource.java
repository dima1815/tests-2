package com.fdu.jira.plugin.resource.timesheet;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.fdu.jira.plugin.report.timesheet.AnyGroupValuesGenerator;
import com.fdu.jira.plugin.report.timesheet.GroupValuesGenerator;
import com.fdu.jira.plugin.resource.AbstractResource;

@Path("/groups")
public class GroupsResource extends AbstractResource {

    private final JiraAuthenticationContext authenticationContext;

    public GroupsResource(JiraAuthenticationContext authenticationContext) {
        this.authenticationContext = authenticationContext;
        
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response getValues(@QueryParam(value = "includeAny") boolean includeAny) {
        GroupValuesGenerator valuesGenerator =
                includeAny ? new AnyGroupValuesGenerator() : new GroupValuesGenerator();
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("User", authenticationContext.getLoggedInUser());
        Map<String, String> values = valuesGenerator.getValues(params);
        return getOkResponse(new MapRepresentation(values));
    }

}
