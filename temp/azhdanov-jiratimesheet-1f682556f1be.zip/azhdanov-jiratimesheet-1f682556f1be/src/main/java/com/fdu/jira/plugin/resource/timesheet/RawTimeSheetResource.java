package com.fdu.jira.plugin.resource.timesheet;

import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.fdu.jira.plugin.resource.AbstractResource;

import jira.plugin.report.timesheet.TimeBase;
import jira.plugin.report.timesheet.Timesheet;
import jira.plugin.report.timesheet.TimesheetService;
import jira.timesheet.plugin.configuration.IConfigurationService;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.fdu.jira.util.CalendarUtil;
import com.fdu.jira.util.ILicenseUtil;

/**
 * @PublicApi
 */
@Path("/raw-timesheet")
public class RawTimeSheetResource extends AbstractResource {

    // References to managers required for this portlet
    private JiraAuthenticationContext authenticationContext;
    private TimeZoneManager timeZoneManager;
    private final ILicenseUtil licenseUtil;
    private final TimesheetService timesheetService;
    private final IConfigurationService configurationService;

    public RawTimeSheetResource(JiraAuthenticationContext authenticationContext,
            TimeZoneManager timeZoneManager,
            ILicenseUtil licenseUtil,
            TimesheetService timesheetService,
            IConfigurationService configurationService) {

        this.authenticationContext = authenticationContext;
        this.timeZoneManager = timeZoneManager;
        this.licenseUtil = licenseUtil;
        this.timesheetService = timesheetService;
        this.configurationService = configurationService;
    }

    /**
     * Gets raw timetracking data in json fromat.
     * 
     * All parameters are optional, if nothing is specified it behaves like
     * report, displays data a week before current day for currently logged in
     * user.
     * 
     * Dates in response are UNIX time - milliseconds since 01/01/1970;
     * timesSpent is in seconds.
     * 
     * @param targetUser
     *            username
     * @param targetGroup
     *            group name, e.g. jira-users
     * @param startDate
     *            begin date in Jira date picker format, e.g. 01/Jun/2012, or in
     *            ISO date format, e.g. 2012-06-01
     * @param endDate
     *            end date, format is the same
     * @param projectid
     *            e.g. 10001 (not project key!)
     * @param filterId
     * 
     * @response.representation.200.doc Example response: <code>
     * { "worklog" :
     *   [ { "entries" : 
     *     [ { "author" : "admin",
     *       "authorFullName" : "admin",
     *       "comment" : "test",
     *       "created" : 1340870920388,
     *       "startDate" : 1340870880000,
     *       "timeSpent" : 3600,
     *       "updateAuthor" : "admin",
     *       "updateAuthorFullName" : "admin",
     *       "updated" : 1340870920388
     *     } ],
     *     "key" : "TP-1",
     *     "summary" : "Some Problem"
     *   } ]
     * }
     * </code>
     */
    @GET
    @AnonymousAllowed
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getTimesheet(@Context HttpServletRequest request) {
        User user = authenticationContext.getLoggedInUser();
        if (user == null) {
            return Response.noContent().build();
        }
        TimeZone timezone = timeZoneManager.getLoggedInUserTimeZone();
        I18nHelper i18n = authenticationContext.getI18nHelper();
        Timesheet timesheet = new Timesheet(user, timezone, i18n,
                request.getParameterMap(),
                EnumSet.of(TimeBase.Options.DATES, TimeBase.Options.ISO_DATES),
                EnumSet.noneOf(Timesheet.Options.class),
                configurationService);

        Map<String, Object> params = getVelocityParams(timesheet);
        Map<Issue, List<Worklog>> worklog = timesheet.allWorkLogs;
        String error = (String) params.get("error");
        return getOkResponse(new RawTimeSheetRepresentation(worklog, error,
                timesheet.startDate, timesheet.endDate));
    }

    private Map<String, Object> getVelocityParams(Timesheet timesheet) {
        Map<String, Object> params = timesheet.resultParams;
        params.put("loggedin", timesheet.remoteUser != null);
        params.put("license", licenseUtil.getLicenseStatus(true));

        final I18nHelper i18n = timesheet.i18n;

        if (!CalendarUtil.isValidTimeInterval(timesheet.startDate, timesheet.endDate, configurationService)) {
            params.put("error", i18n.getText("timesheet.timeIntervalTooLong", configurationService.getMaxDays() / 7));
            return params;
        }

        timesheet.excelView = true;
        try {
            timesheetService.getTimeSpents(timesheet);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return params;
    }
}
