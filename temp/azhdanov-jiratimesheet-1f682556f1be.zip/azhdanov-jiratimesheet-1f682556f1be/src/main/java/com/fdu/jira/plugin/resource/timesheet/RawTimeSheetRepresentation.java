package com.fdu.jira.plugin.resource.timesheet;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.worklog.Worklog;

/**
 * JAXB representation.
 */
@XmlRootElement
@SuppressWarnings("unused")
public class RawTimeSheetRepresentation {

    @XmlJavaTypeAdapter(WorklogAdapter.class)
    private Map<Issue, List<Worklog>> worklog;
    @XmlElement private String error;
    @XmlElement private Date startDate;
    @XmlElement private Date endDate;

    private RawTimeSheetRepresentation() {
        // for JAXB
    }

    public RawTimeSheetRepresentation(Map<Issue, List<Worklog>> worklog, String error, Date startDate, Date endDate) {
        this.worklog = worklog;
        this.error = error;
        this.startDate = startDate;
        this.endDate = endDate;
    }
}
