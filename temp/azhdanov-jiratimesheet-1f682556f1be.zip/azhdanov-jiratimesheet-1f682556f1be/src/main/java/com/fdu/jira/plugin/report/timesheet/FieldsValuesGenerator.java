package com.fdu.jira.plugin.report.timesheet;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jira.timesheet.plugin.configuration.IConfigurationService;

import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.issue.fields.Field;
import com.atlassian.jira.issue.fields.FieldManager;
import com.atlassian.jira.issue.fields.SearchableField;
import com.fdu.jira.util.TextUtil;

public class FieldsValuesGenerator {
    private final IConfigurationService configurationService;
    private final FieldManager fieldManager;

    public enum Type {
        GROUP_BY_FIELD_VALUES, ADDITIONAL_FIELDS_VALUES
    }

    public static final String ALL_GROUPS = "ALL_GROUPS";

    public FieldsValuesGenerator() {
        fieldManager = ComponentManager.getComponentInstanceOfType(FieldManager.class);
        // workaround ClassCastException with getOSGiComponentInstanceOfType(IConfigurationService) after plugin reload
        configurationService = ComponentManager.getOSGiComponentInstanceOfType(IConfigurationService.class);
    }

    public Map<String, String> getValues(Map<String, ?> params, Type type) {
        Map<String, String> values = new LinkedHashMap<String, String>();
        values.put("", TextUtil.NONE);

        
        Set<SearchableField> fields = fieldManager.getAllSearchableFields();

        List<Field> sortedFields = new ArrayList<Field>(fields.size());
        sortedFields.addAll(fields);
        sortedFields.add(fieldManager.getField("timeoriginalestimate"));
        sortedFields.add(fieldManager.getField("timeestimate"));
        sortedFields.add(fieldManager.getField("timespent"));

        Collections.sort(sortedFields, new Comparator<Field>() {
            public int compare(Field o, Field other) {
                return o.getName().compareTo(other.getName());
            }
        });

        Collection<String> groupByFields = null;
        if (!Boolean.TRUE.equals(params.get(ALL_GROUPS))) {
            groupByFields = configurationService.getGroupByFields();
        }

        for (Field field : sortedFields) {
            if (groupByFields == null ||
                    groupByFields.contains(field.getId()) ||
                    groupByFields.contains(field.getName())) {
                values.put(field.getId(), TextUtil.getUnquotedString(field.getName()));
            }
        }

        if (Type.GROUP_BY_FIELD_VALUES.equals(type)) {
            if (groupByFields == null || groupByFields.contains(TextUtil.PROJECT_ROLE_PSEUDO_FIELD_ID)) {
                values.put(TextUtil.PROJECT_ROLE_PSEUDO_FIELD_ID, TextUtil.PROJECT_ROLE_PSEUDO_FIELD_NAME);
            }

            if (groupByFields == null || groupByFields.contains(TextUtil.WORKED_USER_PSEUDO_FIELD_ID)) {
                values.put(TextUtil.WORKED_USER_PSEUDO_FIELD_ID, TextUtil.WORKED_USER_PSEUDO_FIELD_NAME);
            }

            if (groupByFields == null || groupByFields.contains(TextUtil.GROUP_PSEUDO_FIELD_ID)) {
                values.put(TextUtil.GROUP_PSEUDO_FIELD_ID, TextUtil.GROUP_PSEUDO_FIELD_NAME);
            }

            if (groupByFields == null || groupByFields.contains(TextUtil.WORKLOG_CREATED_PSEUDO_FIELD_ID)) {
                values.put(TextUtil.WORKLOG_CREATED_PSEUDO_FIELD_ID, TextUtil.WORKLOG_CREATED_PSEUDO_FIELD_NAME);
            }
        }

        return values;
    }
}
