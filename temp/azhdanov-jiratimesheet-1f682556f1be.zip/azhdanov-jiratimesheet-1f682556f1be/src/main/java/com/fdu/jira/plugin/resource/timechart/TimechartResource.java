package com.fdu.jira.plugin.resource.timechart;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.bc.filter.SearchRequestService;
import com.atlassian.jira.datetime.DateTimeFormatter;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.datetime.DateTimeStyle;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.issuetype.IssueType;
import com.atlassian.jira.issue.priority.Priority;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.security.Permissions;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.atlassian.velocity.VelocityManager;
import com.fdu.jira.plugin.resource.AbstractResource;
import com.fdu.jira.util.CalendarUtil;
import com.fdu.jira.util.ILicenseUtil;
import com.fdu.jira.util.ServletUtil;
import com.fdu.jira.util.TextUtil;
import com.opensymphony.util.TextUtils;

import jira.plugin.report.timesheet.TimeBase;
import jira.plugin.report.timesheet.Timesheet;
import jira.plugin.report.timesheet.TimesheetService;
import jira.timesheet.plugin.configuration.IConfigurationService;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.apache.velocity.exception.VelocityException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;

@Path("/timechart")
public class TimechartResource extends AbstractResource {
    private static final Logger log = Logger.getLogger(TimechartResource.class);

    // References to managers required for this portlet
    private JiraAuthenticationContext authenticationContext;
    private PermissionManager permissionManager;
    private final ProjectManager projectManager;
    private SearchRequestService searchRequestService;
    private TimeZoneManager timeZoneManager;
    private final ILicenseUtil licenseUtil;
    private final TimesheetService timesheetService;
    private final IConfigurationService configurationService;
    private ProjectRoleManager projectRoleManager;
    private final VelocityManager velocityManager;
    private DateTimeFormatterFactory dateTimeFormatterFactory;


    public TimechartResource(JiraAuthenticationContext authenticationContext,
                             PermissionManager permissionManager,
                             ProjectManager projectManager,
                             SearchRequestService searchRequestService,
                             TimeZoneManager timeZoneManager,
                             ILicenseUtil licenseUtil,
                             TimesheetService timesheetService,
                             IConfigurationService configurationService,
                             ProjectRoleManager projectRoleManager,
                             VelocityManager velocityManager,
                             DateTimeFormatterFactory dateTimeFormatterFactory) {

        this.authenticationContext = authenticationContext;
        this.permissionManager = permissionManager;
        this.projectManager = projectManager;
        this.searchRequestService = searchRequestService;
        this.timeZoneManager = timeZoneManager;
        this.licenseUtil = licenseUtil;
        this.timesheetService = timesheetService;
        this.configurationService = configurationService;
        this.projectRoleManager = projectRoleManager;
        this.velocityManager = velocityManager;
        this.dateTimeFormatterFactory = dateTimeFormatterFactory;
    }

    @GET
    @AnonymousAllowed
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getTimesheet(@Context HttpServletRequest request,
                                 @QueryParam("projectOrFilter") String projectOrFilter) {
        final User user = authenticationContext.getLoggedInUser();
        if (user == null) {
            return Response.noContent().build();
        }
        final TimeZone timezone = timeZoneManager.getLoggedInUserTimeZone();
        final I18nHelper i18n = authenticationContext.getI18nHelper();
        final Timesheet timesheet = new Timesheet(user, timezone, i18n,
                request.getParameterMap(),
                EnumSet.noneOf(TimeBase.Options.class),
                EnumSet.noneOf(Timesheet.Options.class),
                configurationService);

        final int numOfWeeks = ServletUtil.getIntParam(request, "numOfWeeks", 1);
        final int reportingDay = ServletUtil.getIntParam(
                request,
                "reportingDay",
                Calendar.getInstance(timeZoneManager.getLoggedInUserTimeZone(), authenticationContext.getLocale()).getFirstDayOfWeek());
        final int offset = ServletUtil.getIntParam(request, "offset", 0);
        final Date startDateParam = getDateParam(request.getParameter("startDate"));
        Long[] projectOrFilterIds = new Long[2];
        String projectOrFilterName = ServletUtil.getProjectOrFilter(projectOrFilter, projectOrFilterIds,
                projectManager, authenticationContext, searchRequestService);
        timesheet.projectId = projectOrFilterIds[0];
        timesheet.filterId = projectOrFilterIds[1];
        // pass parameters
        if (projectOrFilterName != null) {
            timesheet.resultParams.put("projectOrFilterName", projectOrFilterName);
            timesheet.resultParams.put("projectId", timesheet.projectId);
            timesheet.resultParams.put("filterId", timesheet.filterId);
        }

        timesheet.reportingDay = CalendarUtil.getReportingDay(startDateParam, reportingDay, timesheet.monthView, timezone);
        timesheet.resultParams.put("reportingDay", timesheet.reportingDay); // overwrite
        final Calendar[] dates = CalendarUtil.getDatesRange(timesheet.reportingDay, numOfWeeks, offset, timesheet.monthView, timesheet.timezone, startDateParam);
        final Calendar startDate = dates[0], endDate = dates[1];
        timesheet.startDate = startDate.getTime();
        timesheet.endDate = endDate.getTime();
        // endDate for report
        endDate.add(Calendar.DAY_OF_MONTH, -1);
        timesheet.resultParams.put("startDate", startDate.getTime());
        timesheet.resultParams.put("endDate", endDate.getTime());
        
        final TimechartRepresentation representation = new TimechartRepresentation(
                getChartName(timesheet, projectOrFilterName),
                getSliderHtml(offset, timesheet, startDateParam),
                projectOrFilterName,
                authenticationContext.getI18nHelper().getText(
                        licenseUtil.getLicenseStatus(false) + ".text",
                        licenseUtil.getLicenseMgmtUrl(request.getContextPath())));

        if (!licenseUtil.isLicenseValid()) {
            return getOkResponse(representation);
        }

        if (!CalendarUtil.isValidTimeInterval(timesheet.startDate, timesheet.endDate, configurationService)) {
            representation.licenseMsgHtml = i18n.getText("timesheet.timeIntervalTooLong", configurationService.getMaxDays() / 7);
            return getOkResponse(representation);
        }

        if (timesheetService.isForbiddenByTimesheetAuditorsGroup(timesheet)) {
            representation.licenseMsgHtml = i18n.getText("group.timesheet.userNotInTimesheetAuditorsGroup");
            return getOkResponse(representation);
        }

        if (timesheet.targetGroup != null && timesheet.projectId == null && timesheet.projectRoleId == null &&
                !permissionManager.hasPermission(Permissions.USER_PICKER, user)) {
            representation.licenseMsgHtml = i18n.getText("group.timesheet.noPermissions");
            return getOkResponse(representation);
        }

        try {
            timesheetService.getTimeSpents(timesheet);
        } catch (Exception e) {
            representation.licenseMsgHtml = e.getMessage();
            return getOkResponse(representation);
        }

        return getOkResponse(buildRepresentation(representation, timesheet));
    }

    protected TimechartRepresentation buildRepresentation(TimechartRepresentation representation,
            Timesheet timesheet) {

        final I18nHelper i18nHelper = authenticationContext.getI18nHelper();

        if (timesheet.groupByField != null) {
            Map<String, Long> groupedByFieldTime = new TreeMap<String, Long>();
            for (Map<String, Map<Date, List<Worklog>>> groupedByFieldTimeSpents : timesheet.projectGroupedByFieldTimeSpents.values()) {
                for (String fieldValue : groupedByFieldTimeSpents.keySet()) {
                    long timespent = 0; 
                    for (List<Worklog> worklogs : groupedByFieldTimeSpents.get(fieldValue).values()) {
                        timespent += sumTimespents(worklogs);
                    }
                    Long time = groupedByFieldTime.get(fieldValue);
                    if (time != null) {
                        timespent += time;
                    }
                    groupedByFieldTime.put(fieldValue, timespent);
                }                
            }
            for (String fieldValue : groupedByFieldTime.keySet()) {
                Long timespent = groupedByFieldTime.get(fieldValue);
                String fieldValueHtml;
                if (fieldValue == null || fieldValue.isEmpty() || TextUtil.NO_VALUE_FOR_FIELD.equals(fieldValue)) {
                    fieldValueHtml = i18nHelper.getText("report.timesheet.groupbyfield.novalue"); 
                } else if (/*TextUtil.*/"FieldTypeValueNotApplicableForGrouping".equals(fieldValue)) {
                    fieldValueHtml = i18nHelper.getText("report.timesheet.groupbyfield.couldnotreadvalue"); 
                } else {                
                    fieldValueHtml = isCustomField(timesheet.groupByField) ? fieldValue
                        : TextUtils.plainTextToHtml(fieldValue);
                }
                representation.addEntry(fieldValueHtml, timespent);
                
            }
        } else if (multipleUser(timesheet)) {
            // multiple users
            for (User user : timesheet.userWorkLogShort.keySet()) {
                final Map<Date, Long> timespents = timesheet.userWorkLogShort.get(user);
                String userName;
                try {
                    userName = TextUtil.urlencode(user.getName());
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
                representation.addEntry(
                        TextUtils.plainTextToHtml(user.getDisplayName()),
                        sumTimespents(timespents),
                        getAbsoluteUrl(timesheet, "/secure/ConfigureReport.jspa?weekends=true&showDetails=true&reportKey=jira-timesheet-plugin:report&targetUser=" + userName + "&reportingDay=" + timesheet.reportingDay));
            }
        }
        else {
            // single user
            for (Issue issue : timesheet.weekWorkLogShort.keySet()) {
                final Map<Date, Long> weekTimeSpents = timesheet.weekWorkLogShort.get(issue);
                final List<ImageRepresentation> icons = new ArrayList<ImageRepresentation>();
                final IssueType issueTypeObject = issue.getIssueTypeObject();
                if (issueTypeObject != null) {
                    final String url = getAbsoluteUrl(timesheet, issueTypeObject.getIconUrl());
                    final String title = composeNameWithDescription(issueTypeObject.getNameTranslation(), issueTypeObject.getDescTranslation());
                    icons.add(new ImageRepresentation(url, title));
                }
                final Priority priorityObject = issue.getPriorityObject();
                if (priorityObject != null) {
                    final String url = getAbsoluteUrl(timesheet, priorityObject.getIconUrl());
                    final String title = composeNameWithDescription(priorityObject.getNameTranslation(), priorityObject.getDescTranslation());
                    icons.add(new ImageRepresentation(url, title));
                }
                representation.addEntry(
                        issue.getKey(),
                        sumTimespents(weekTimeSpents),
                        getAbsoluteUrl(timesheet, "/browse/" + issue.getKey()),
                        TextUtils.plainTextToHtml(issue.getSummary()),
                        icons.toArray(new ImageRepresentation[icons.size()]));
            }
        }

        return representation;
    }

    private boolean isCustomField(String groupByField) {
        return groupByField.startsWith("customfield_")
                && !TextUtil.PROJECT_ROLE_PSEUDO_FIELD_ID.equals(groupByField)
                && !TextUtil.WORKED_USER_PSEUDO_FIELD_ID.equals(groupByField)
                && !TextUtil.GROUP_PSEUDO_FIELD_ID.equals(groupByField)
                && !TextUtil.WORKLOG_CREATED_PSEUDO_FIELD_ID.equals(groupByField);
    }

    protected boolean multipleUser(Timesheet timesheet) {
        return CollectionUtils.isNotEmpty(timesheet.targetGroup)
                || timesheet.projectRoleId != null
                || timesheet.projectId != null;
    }

    protected Long sumTimespents(Collection<Worklog> worklogs) {
        Long result = 0L;
        for (Worklog worklog : worklogs) {
            result += worklog.getTimeSpent();
        }
        return result;
    }

    protected Long sumTimespents(Map<Date, Long> timespents) {
        Long result = 0L;
        for (Long time : timespents.values()) {
            result += time;
        }
        return result;
    }

    protected String getAbsoluteUrl(Timesheet timesheet, String url) {
        String baseUrl = timesheet.resultParams.get("baseurl").toString();
        boolean isAbsoluteUrl = url.startsWith("http://") || url.startsWith("https://");
        return isAbsoluteUrl ? url : baseUrl + url;
    }

    protected String getChartName(Timesheet timesheet, String projectOrFilterName) {

        final I18nHelper i18nHelper = authenticationContext.getI18nHelper();

        String chartName = "";
        String url = getAbsoluteUrl(timesheet, "/secure/ConfigureReport.jspa?reportKey=jira-timesheet-plugin:report&weekends=true");

        DateTimeFormatter formatter = dateTimeFormatterFactory.formatter().forLoggedInUser().withZone(timesheet.timezone);
        DateTimeFormatter dpFormatter = formatter.withStyle(DateTimeStyle.DATE_PICKER);
        DateTimeFormatter outlookDateFormatter = formatter.withStyle(DateTimeStyle.DATE);
        Date endDate = (Date) timesheet.resultParams.get("endDate"); // -1 adjusted
        try {
            url += "&startDate=" + TextUtil.urlencode(dpFormatter.format(timesheet.startDate));
            url += "&endDate=" + TextUtil.urlencode(dpFormatter.format(endDate));
        } catch (UnsupportedEncodingException e) {
            log.error(e.getMessage());
        }

        if (CollectionUtils.isNotEmpty(timesheet.targetGroup)) {
            for (String targetGroup : timesheet.targetGroup) {
                try {
                    url += "&targetGroup=" + TextUtil.urlencode(targetGroup);
                } catch (UnsupportedEncodingException e) {
                    log.error(e.getMessage());
                }
            }
            chartName = i18nHelper.getText("group.timesheet.summary", TextUtil.toComaSeparatedString(timesheet.targetGroup));
            if (timesheet.projectRole != null) {
                chartName += " " + i18nHelper.getText("portlet.timesheet.andRole", TextUtils.plainTextToHtml(timesheet.projectRole.getName()));
            }
        }
        else if (timesheet.projectRoleId != null) {
            ProjectRole role = projectRoleManager.getProjectRole(timesheet.projectRoleId);
            chartName += i18nHelper.getText("role.timesheet.summary", TextUtils.plainTextToHtml(role.getName()));
        }
        else if (timesheet.projectId != null) {
            chartName += i18nHelper.getText("project.timesheet.summary", TextUtils.plainTextToHtml(projectOrFilterName));
        }
        else {
            chartName += i18nHelper.getText("portlet.timesheet.summary", TextUtils.plainTextToHtml(timesheet.targetUser.getDisplayName()));
            url += "&targetUser=" + timesheet.targetUser.getName();
        }

        if (CollectionUtils.isNotEmpty(timesheet.excludeTargetGroup)) {
            for (String group : timesheet.targetGroup) {
                url += "&excludeTargetGroup=" + group;
            }
            chartName += " " + i18nHelper.getText("portlet.timesheet.andNotGroup", TextUtil.toComaSeparatedString(timesheet.excludeTargetGroup));
        }

        if (timesheet.projectId != null) {
            url += "&projectid=" + timesheet.projectId;
            if (timesheet.targetGroup != null || timesheet.projectRoleId != null) {
                chartName += " " + i18nHelper.getText("portlet.timesheet.andproj", TextUtils.plainTextToHtml(projectOrFilterName));
            }
        }
        if (timesheet.filterId != null) {
            url += "&filterid=" + timesheet.filterId;
            chartName += " " + i18nHelper.getText("portlet.timesheet.andFilter", TextUtils.plainTextToHtml(projectOrFilterName));
        }

        if (timesheet.projectRole != null) {
            url += "&projectRoleId=" + timesheet.projectRoleId;
        }

        if (timesheet.groupByField != null) {
            chartName += " " + i18nHelper.getText("portlet.timesheet.andGroupedBy", TextUtils.plainTextToHtml(TextUtil.getFieldName(timesheet.groupByField)));
            url += "&groupByField=" + timesheet.groupByField;
        }
        url += "&reportingDay=" + timesheet.reportingDay;
        
        chartName += "&nbsp;" + i18nHelper.getText("project.pivot.from", outlookDateFormatter.format(timesheet.startDate));
        chartName += "&nbsp;" + i18nHelper.getText("project.pivot.to", outlookDateFormatter.format(endDate));

        return chartName + " " +
                String.format("(<a href='%s'>%s</a>)", url, i18nHelper.getText("portlet.timesheet.details"));
    }

    //TODO replace with existing method or move this method to some Utils class
    protected String composeNameWithDescription(String name, String description) {
        return TextUtils.plainTextToHtml(String.format("%s - %s", name, description));
    }

    private String getSliderHtml(int offset, Timesheet timesheet, Date startDateParam) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("i18n", authenticationContext.getI18nHelper());
        params.put("offset", offset);
        params.put("monthView", timesheet.monthView);
        DateTimeFormatter formatter = dateTimeFormatterFactory.formatter().forLoggedInUser().withZone(timeZoneManager.getLoggedInUserTimeZone());
        DateTimeFormatter outlookDateFormatter = formatter.withStyle(DateTimeStyle.DATE);
        params.put("startDate", timesheet.startDate);
        params.put("outlookDate", outlookDateFormatter);
        params.put("lockDate", startDateParam);
        params.put("isoDate", formatter.withStyle(DateTimeStyle.ISO_8601_DATE));
        String sliderHtml = null;
        try {
            sliderHtml = velocityManager.getBody("/templates/common/", "timesheet-slider.vm", params);
        } catch (VelocityException e) {
            log.warn("Error while rendering timesheet slider", e);
        }
        return sliderHtml;
    }
}
