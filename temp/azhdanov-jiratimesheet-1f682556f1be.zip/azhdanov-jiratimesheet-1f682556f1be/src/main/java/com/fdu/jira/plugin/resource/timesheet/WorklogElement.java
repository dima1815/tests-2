package com.fdu.jira.plugin.resource.timesheet;

import javax.xml.bind.annotation.XmlElement;

public class WorklogElement {
    @XmlElement public String key;
    @XmlElement public String summary;
    @XmlElement public WorklogEntryElement[] entries;

    // Required by JAXB
    @SuppressWarnings("unused")
    private WorklogElement() {
    } 

    public WorklogElement(String key, String summary)
    {
      this.key   = key;
      this.summary = summary;
    }
}
