package com.fdu.jira.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.user.util.UserUtil;

/*
 * Temporary class, while combined support for JIRA 5 and 6
 */
public abstract class DirectoryUtil {
    private static Class<?> applicationUsersClass;
    private static Method getKeyForMethod;
    private static Class<?> applicationUserClass;
    private static Method getUserByKeyMethod;
    private static Method toDirectoryUserMethod;

    static {
        try {
            applicationUsersClass = Class.forName("com.atlassian.jira.user.ApplicationUsers");
            getKeyForMethod = applicationUsersClass.getDeclaredMethod("getKeyFor", User.class);
            applicationUserClass = Class.forName("com.atlassian.jira.user.ApplicationUser");
            getUserByKeyMethod = UserUtil.class.getDeclaredMethod("getUserByKey", String.class);
            toDirectoryUserMethod = applicationUsersClass.getDeclaredMethod("toDirectoryUser", applicationUserClass);
        } catch (ClassNotFoundException e) {
        } catch (SecurityException e) {
        } catch (NoSuchMethodException e) {
        }

    }

    /*
     *  Returns userKey if it is available (since JIRA 5.1.1), otherwise usernName.
     *  See also: Issue #376: No data for renamed user
     *  See also: for user compatibility for different versions use https://bitbucket.org/atlassian/user-compatibility-jira/overview
     *  TODO: get rid of reflection, drop support for JIRA below 5.1.1, use ApplicaitonUsers.getKeyFor
     */
    public static String getUserName(User user) {
        // issue #396 support non lower case usernames, see also Issue #347 and JRA-24558
        if (TextUtil.isJira6() && getKeyForMethod != null) {
            try {
                return (String) getKeyForMethod.invoke(null, user);
            } catch (IllegalArgumentException e) {
            } catch (IllegalAccessException e) {
            } catch (InvocationTargetException e) {
            }
        }
        return user.getName();
    }

    /*
     *  Looks up user by userKey if it is available (since JIRA 5.1.1), otherwise by usernName.
     *  See also: Issue #376: No data for renamed user
     *  TODO: get rid of reflection, drop support for JIRA below 5.1.1, use userUtil.getUserByKey
     */
    public static User getUser(UserUtil userUtil, String username) {
        if (toDirectoryUserMethod != null && getUserByKeyMethod != null) {
            try {
                return (User) toDirectoryUserMethod.invoke(null, getUserByKeyMethod.invoke(userUtil, username));
            } catch (InvocationTargetException e) {
            } catch (IllegalArgumentException e) {
            } catch (IllegalAccessException e) {
            }
        }
        return userUtil.getUser(username);        
    }
}
