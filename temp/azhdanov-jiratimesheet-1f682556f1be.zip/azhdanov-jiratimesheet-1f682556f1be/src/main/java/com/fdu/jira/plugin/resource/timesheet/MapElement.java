package com.fdu.jira.plugin.resource.timesheet;

import javax.xml.bind.annotation.XmlElement;

public class MapElement {
    @XmlElement public String label;
    @XmlElement public String value;

    public MapElement(String label, String value) {
        this.label = label;
        this.value = value;
    }

}
