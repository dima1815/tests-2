package com.fdu.jira.plugin.resource.timesheet;

import java.util.Map;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class MapAdapter extends XmlAdapter<MapElement[], Map<String, String>> {
    @Override
    public Map<String, String> unmarshal(MapElement[] v) throws Exception {
        return null;
    }

    @Override
    public MapElement[] marshal(Map<String, String> v) throws Exception {
        MapElement[] mapElements = new MapElement[v.size()];
        int i = 0;
        for (Map.Entry<String, String> entry : v.entrySet()) {
            MapElement mapElement = new MapElement(entry.getValue(), entry.getKey());
            mapElements[i++] = mapElement;
        }

        return mapElements;
    }

}
