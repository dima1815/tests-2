package com.fdu.jira.util;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.component.ComponentAccessor;
import jira.timesheet.plugin.configuration.IConfigurationService;
import org.apache.commons.collections.CollectionUtils;

import java.util.List;

/**
 * @author Roman Boris
 * @since 17-Sep-14
 */
public final class ForbiddenUtil {

    public static boolean isForbiddenByAuditorsGroup(final String userName) {

        final List<String> timesheetAuditorsGroups = ComponentManager.getOSGiComponentInstanceOfType(IConfigurationService.class).getTimesheetAuditorsGroups();
        return CollectionUtils.isNotEmpty(timesheetAuditorsGroups)
                && !CollectionUtils.containsAny(ComponentAccessor.getUserUtil().getGroupNamesForUser(userName), timesheetAuditorsGroups);
    }

    public static boolean isOthersTimesheet(
            final User remoteUser,
            final String targetUserName,
            final List<String> targetGroup,
            final Long projectId,
            final Long projectRoleId) {

        return (remoteUser != null && targetUserName != null && !remoteUser.getName().equals(targetUserName)) ||
                // group timesheet
                CollectionUtils.isNotEmpty(targetGroup) ||
                // group timesheet (project or role with no target user)
                (targetUserName == null 
                        && (projectId != null || projectRoleId != null));
    }
}
