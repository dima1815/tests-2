package com.fdu.jira.util;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Properties;

import jira.plugin.report.timesheet.LicenseException;
import jira.timesheet.plugin.configuration.IConfigurationService;
import jira.timesheet.plugin.license.LicenseEncoder;
import jira.timesheet.plugin.license.TimesheetLicense;

import org.apache.log4j.Logger;

import com.atlassian.jira.config.CoreFeatures;
import com.atlassian.jira.config.FeatureManager;
import com.atlassian.upm.api.license.entity.PluginLicense;
import com.atlassian.upm.api.util.Option;
import com.atlassian.upm.license.storage.lib.PluginLicenseStoragePluginUnresolvedException;
import com.atlassian.upm.license.storage.lib.ThirdPartyPluginLicenseStorageManager;

public final class LicenseUtil implements ILicenseUtil {
    private final ThirdPartyPluginLicenseStorageManager licenseManager;
    private final IConfigurationService configurationService;
    private Option<TimesheetLicense> cachedLicense;
    private FeatureManager featureManager;

    public LicenseUtil(ThirdPartyPluginLicenseStorageManager licenseManager,
            IConfigurationService configurationService,
            FeatureManager featureManager) {
        this.licenseManager = licenseManager;
        this.configurationService = configurationService;
        this.featureManager = featureManager;
    }

    @Override
    public boolean isLicenseValid() {
        return "license.valid".equals(getLicenseStatus(false));
    }

    public void checkLicense() {
        String status = getLicenseStatus(false);
        if (!"license.valid".equals(status)) {
            throw new LicenseException(status);
        }
    }

    @Override
    public boolean isJiraOnDemand() {
        return featureManager.isEnabled(CoreFeatures.ON_DEMAND);
    }

    @Override
    public String getLicenseStatus(boolean isFreeForJiraOnDemand) {
        try {
            // Check and see if a license is currently stored.
            // This accessor method can be used whether or not a licensing-aware
            // UPM is present.
            Option<PluginLicense> pluginLicenseOption = licenseManager.getLicense();
            if (pluginLicenseOption.isDefined()) {
                PluginLicense pluginLicense = pluginLicenseOption.get();
                // Check and see if the stored license has an error. If not, it
                // is currently valid.
                if (pluginLicense.getError().isDefined()) {
                    return "license." + pluginLicense.getError().get().name();
                } else {
                    return "license.valid";
                }
                // temporary, until AMKT supports JIRA onDemand
            } else if (isFreeForJiraOnDemand && isJiraOnDemand()) {
                return "license.valid";
            } else if (isJiraOnDemand()) {
                Option<TimesheetLicense> timesheetLicenseOption = getTimesheetLicense();
                if (timesheetLicenseOption.isDefined()) {
                    TimesheetLicense timesheetLicense = timesheetLicenseOption.get();
                    if (timesheetLicense.getError().isDefined()) {
                        return "license." + timesheetLicense.getError().get();
                    } else {
                        return "license.valid";
                    }
                }
            }
            return "license.nolicense";
        } catch (PluginLicenseStoragePluginUnresolvedException e) {
            log.error("Required licensing support not found: " + e.getMessage());
            return "license.error";
        }
    }

    // UPM > 2.0 "jira/plugins/servlet/upm#manage/com.fdu.jira.plugin.jira-timesheet-plugin"
    // otherwise "/plugins/servlet/com.fdu.jira.plugin.jira-timesheet-plugin/license";
    @Override
    public String getLicenseMgmtUrl(String contextPath) {
        if (isJiraOnDemand()) {
            return contextPath + "/secure/LicenseConfiguration!default.jspa";
        } else if (licenseManager.isUpmLicensingAware()) {
            try {
                return licenseManager.getPluginManagementUri().toASCIIString();
            } catch (PluginLicenseStoragePluginUnresolvedException e) {
                log.error("Required licensing support not found: " + e.getMessage());
            }
        }
        // fall back
        return contextPath + "/plugins/servlet/com.fdu.jira.plugin.jira-timesheet-plugin/license";
    }

    @Override
    public Option<TimesheetLicense> getTimesheetLicense() {
        String rawLicense = configurationService.getLicense();
        // TODO: use CachedReference from atlasscom.atlassian.cache:atlassian-cache-api:2.0?
        // but it does not have invalidate()
        // see https://developer.atlassian.com/display/JIRADEV/Plugin+Guide+to+JIRA+High+Availability+and+Clustering
        if (cachedLicense == null
                || !cachedLicense.isDefined()
                || !cachedLicense.get().getRawLicense().equals(rawLicense)) {
            cachedLicense = createTimesheetLicense(rawLicense);
        }
        return cachedLicense;
    }

    @Override
    public Option<TimesheetLicense> setTimesheetLicense(String rawLicense) {
        Option<TimesheetLicense> license = createTimesheetLicense(rawLicense);
        if (license.isDefined() && license.get().isValid()) {
            configurationService.setLicense(rawLicense);
            cachedLicense = license;
        }
        return license;
    }

    private Option<TimesheetLicense> createTimesheetLicense(String rawLicense) {
        if (rawLicense == null || rawLicense.isEmpty()) { 
            return Option.none();
        }
        byte[] decodedBytes;
        try {
            decodedBytes = LicenseEncoder.decode(rawLicense);
        } catch (Exception e) {
            log.warn("Can't decode license: " + e.toString());
            return Option.none();
        }
        Properties properties = new Properties();
        try {
            Reader input = new StringReader(new String(decodedBytes, "UTF8"));
            properties.load(input);
        } catch (IOException e) {
            log.warn("Can't load license properties", e);
            return Option.none();
        }
        try {
            TimesheetLicense pluginLicense = new TimesheetLicense(properties, rawLicense);
            return Option.some(pluginLicense);
        } catch (Throwable e) {
            log.warn("Can't init license: " + e.toString());
            return Option.none();            
        }
    }

    private static final Logger log = Logger.getLogger(LicenseUtil.class);

}
