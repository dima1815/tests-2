package com.fdu.jira.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.bc.JiraServiceContext;
import com.atlassian.jira.bc.JiraServiceContextImpl;
import com.atlassian.jira.bc.filter.SearchRequestService;
import com.atlassian.jira.issue.search.SearchRequest;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.JiraAuthenticationContext;

public final class ServletUtil
{
    private static final Logger log = Logger.getLogger(ServletUtil.class);

    private ServletUtil() {}

    public static int getIntParam(HttpServletRequest request, String name, int defaultValue) {
        String param = request.getParameter(name);
        if (param == null || param.length() == 0) {
            return defaultValue;
        }

        try {
            return Integer.parseInt(param);
        } catch(NumberFormatException e) {
            return defaultValue;
        }
    }

    /*
     * Returns true if the request parameter is not null and is equal, ignoring case, to the string "true".
     */
    public static boolean getBooleanParam(HttpServletRequest request, String name, boolean defaultValue) {
        String param = request.getParameter(name);
        if (param == null) {
            return defaultValue;
        }
        return Boolean.valueOf(param);
    }

    public static String getProjectOrFilter(String projectOrFilter,
            Long[] projectOrFilterIds,
            ProjectManager projectManager,
            JiraAuthenticationContext authenticationContext,
            SearchRequestService searchRequestService) {
        String projectOrFilterName = null;
        if (projectOrFilter != null && projectOrFilter.indexOf("-")  != -1) {
            int i = projectOrFilter.indexOf("-");
            String type = projectOrFilter.substring(0, i);
            Long id = Long.parseLong(projectOrFilter.substring(i + 1));
            if ("project".equals(type)) {
                projectOrFilterIds[0] = id;
                Project project = projectManager.getProjectObj(id); 
                projectOrFilterName = project.getName();
            } else if ("filter".equals(type)) {
                User user = authenticationContext.getLoggedInUser();
                JiraServiceContext jiraServiceContext = new JiraServiceContextImpl(user);
                SearchRequest filter = searchRequestService.getFilter(jiraServiceContext, id);
                if (filter != null) { // don't  have permission
                    projectOrFilterName = filter.getName();
                    projectOrFilterIds[1] = id;
                }
            } else {
                log.error("Unsupported type of projectOrFilter argument: " + type);
            }
        }
        return projectOrFilterName;
    }
}
