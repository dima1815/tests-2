package com.fdu.jira.util;

import java.util.Arrays;
import java.util.Date;
import java.util.Calendar;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.user.util.UserUtil;
import com.opensymphony.util.TextUtils;
import org.apache.commons.lang.StringUtils;

public class WeekPortletHeader {

    private TimeZoneManager timeZoneManager;
    private UserUtil userUtil;

    private Calendar weekDayDate;
    private String weekDayCSS;
    private String holidayName;
    private boolean monthView;
    private Set<Integer> weekends;
    private int reportingDay;
    private int highlightHours;

    public WeekPortletHeader(Calendar date, boolean monthView, Set<Integer> weekends, String holidayName, int reportingDay, int highlightHours) {
        weekDayDate = date;
        this.monthView = monthView;
        this.weekends = weekends;
        this.holidayName = holidayName;
        this.reportingDay = reportingDay;
        this.highlightHours = highlightHours;
    }

    public Date getWeekDayDate() {
        return weekDayDate.getTime();
    }

    public Date getWeekDayTime() {
        Calendar weekDayTime = CalendarUtil.copyCalendar(weekDayDate, weekDayDate.getTimeZone());
        return weekDayTime.getTime();
    }

    public String getWeekDayCSS() {
        return weekDayCSS;
    }

    public void setWeekDayCSS(String aWeekDayCSS) {
        this.weekDayCSS = aWeekDayCSS;
    }

    public List<String> getWeekDayCSSList() {
        return Arrays.asList(StringUtils.split(weekDayCSS));
    }

    // see timesheet.css
    public String getWeekDayStyle() {
        final List<String> weekDayCSSList = getWeekDayCSSList();
        if (weekDayCSSList.contains("nonBusinessDay")) {
            return "background-color: #ffeedd;";
        } else if (weekDayCSSList.contains("nonWorkedDay")) {
            return "color: #bbb;";
        } else if (weekDayCSSList.contains("toDay")) {
            return "background-color: #e3feeb;";
        } else { // businessDay, workedDay
            return "";
        }
    }

    public String getHolidayStyle() {
        if (getWeekDayCSSList().contains("holidayDayOfWeek")) {
            return "color: #D04437;";
        }
        return "";
    }

    public boolean isBusinessDay() {
        return !isNonBusinessDay();
    }

    public boolean isNonBusinessDay() {
        int dayOfWeek = weekDayDate.get(Calendar.DAY_OF_WEEK);
        return weekends.contains(dayOfWeek);
    }

    public boolean isHoliday() {
        return holidayName != null;
    }

    public String getHolidayNameHtml() {
        return "\n" + TextUtils.plainTextToHtml(holidayName);
    }

    public boolean hasIncompleteHours(int total) {
        return !isHoliday() && isBusinessDay() && (total == 0 || total < highlightHours);
    }

    public int getWeek() {
        return weekDayDate.get(Calendar.WEEK_OF_YEAR);
    }

    public boolean equalsToWorklogDate(Worklog worklog) {
        final User workedUser = DirectoryUtil.getUser(getUserUtil(), worklog.getAuthor());
        final TimeZone workedUserTimeZone = getTimeZoneManager().getTimeZoneforUser(workedUser);
        final Calendar otherDate = CalendarUtil.convertWorkedTimeDate(worklog.getStartDate(),
                workedUserTimeZone, weekDayDate.getTimeZone());
        if (monthView) {
            CalendarUtil.roundByWeekDay(otherDate, reportingDay);
        }
        return weekDayDate.equals(otherDate);
    }

    protected TimeZoneManager getTimeZoneManager() {
        if (timeZoneManager == null){
            timeZoneManager = ComponentAccessor.getComponent(TimeZoneManager.class);
        }
        return timeZoneManager;
    }

    protected UserUtil getUserUtil() {
        if (userUtil == null){
            userUtil = ComponentAccessor.getUserUtil();
        }
        return userUtil;
    }
}
