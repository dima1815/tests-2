package com.fdu.jira.plugin.report.timesheet;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import jira.timesheet.plugin.configuration.IConfigurationService;

import webwork.action.ActionContext;

import com.atlassian.configurable.ValuesGenerator;
import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.security.Permissions;
import com.fdu.jira.util.TextUtil;

public class ProjectValuesGenerator implements ValuesGenerator {
    public static final String ALL_PROJECTS = "ALL_PROJECTS";
    private ProjectManager projectManager;
    private PermissionManager permissionManager;
    private IConfigurationService configurationService;

    public ProjectValuesGenerator() {
        projectManager = ComponentManager.getComponentInstanceOfType(ProjectManager.class);
        permissionManager = ComponentManager.getComponentInstanceOfType(PermissionManager.class);
        // workaround ClassCastException with getOSGiComponentInstanceOfType(IConfigurationService) after plugin reload
        configurationService = ComponentManager.getOSGiComponentInstanceOfType(IConfigurationService.class);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public Map<String, String> getValues(Map userParams) {
        Collection<Project> projects = projectManager.getProjectObjects();
        User remoteUser = (User) userParams.get("User");

        Collection<String> excludeProjects = null;
        if (!Boolean.TRUE.equals(userParams.get(ALL_PROJECTS))) {
            excludeProjects = configurationService.getExcludeProjects();;
        }

        Map<String, String> result = new LinkedHashMap<String, String>();
        result.put("", TextUtil.NONE);
        for (Project project : projects) {
            if (permissionManager.hasPermission(Permissions.BROWSE, project, remoteUser)
                    && (excludeProjects == null || !excludeProjects.contains(project.getId().toString()))) {
                result.put(project.getId().toString(),  TextUtil.getUnquotedString(project.getName()));
            }
        }
        if (ActionContext.getRequest().getParameter("projectid") == null
                && ActionContext.getRequest().getParameter("selectedProjectId") != null) {
            Map actionParameters = new HashMap(ActionContext.getParameters());
            actionParameters.put("projectid",
                    new String[] {ActionContext.getRequest().getParameter("selectedProjectId")});
            ActionContext.setParameters(actionParameters);
        }
        return result;
    }
}

