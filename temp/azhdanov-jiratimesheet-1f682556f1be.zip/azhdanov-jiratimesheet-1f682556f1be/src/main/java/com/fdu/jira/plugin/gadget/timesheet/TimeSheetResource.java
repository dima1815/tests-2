package com.fdu.jira.plugin.gadget.timesheet;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.bc.filter.SearchRequestService;
import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.jira.datetime.DateTimeFormatter;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.datetime.DateTimeStyle;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.search.SearchResults;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.security.Permissions;
import com.atlassian.jira.security.xsrf.XsrfTokenGenerator;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.util.velocity.DefaultVelocityRequestContextFactory;
import com.atlassian.jira.util.velocity.VelocityRequestContext;
import com.atlassian.jira.web.FieldVisibilityManager;
import com.atlassian.jira.web.bean.PagerFilter;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.atlassian.velocity.VelocityManager;
import com.fdu.jira.plugin.resource.AbstractResource;
import com.fdu.jira.util.CalendarUtil;
import com.fdu.jira.util.ILicenseUtil;
import com.fdu.jira.util.ServletUtil;
import com.opensymphony.util.TextUtils;

import jira.plugin.report.timesheet.TimeBase;
import jira.plugin.report.timesheet.Timesheet;
import jira.plugin.report.timesheet.TimesheetService;
import jira.timesheet.plugin.configuration.IConfigurationService;

import org.apache.log4j.Logger;
import org.apache.velocity.exception.VelocityException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.EnumSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.TimeZone;

@Path("/timesheet")
public class TimeSheetResource extends AbstractResource {
    private static final Logger log = Logger.getLogger(TimeSheetResource.class);

    // References to managers required for this portlet
    private JiraAuthenticationContext authenticationContext;
    private PermissionManager permissionManager;
    private ApplicationProperties applicationProperties;
    private FieldVisibilityManager fieldVisibilityManager;
    private SearchRequestService searchRequestService;
    private DateTimeFormatterFactory dateTimeFormatterFactory;
    private TimeZoneManager timeZoneManager;
    private final ILicenseUtil licenseUtil;
    private final ProjectManager projectManager;
    private final TimesheetService timesheetService;
    private final XsrfTokenGenerator xsrfTokenGenerator;
    private final SearchService searchService;
    private final VelocityManager velocityManager;
    private final IConfigurationService configurationService;


    public TimeSheetResource(JiraAuthenticationContext authenticationContext,
            PermissionManager permissionManager,
            ApplicationProperties applicationProperties,
            DateTimeFormatterFactory dateTimeFormatterFactory,
            ProjectManager projectManager,
            FieldVisibilityManager fieldVisibilityManager,
            SearchRequestService searchRequestService,
            TimeZoneManager timeZoneManager,
            ILicenseUtil licenseUtil,
            TimesheetService timesheetService,
            XsrfTokenGenerator xsrfTokenGenerator,
            SearchService searchService,
            VelocityManager velocityManager,
            IConfigurationService configurationService) {
        this.authenticationContext = authenticationContext;
        this.permissionManager = permissionManager;
        this.applicationProperties = applicationProperties;
        this.dateTimeFormatterFactory = dateTimeFormatterFactory;
        this.projectManager = projectManager;
        this.fieldVisibilityManager = fieldVisibilityManager;
        this.searchRequestService = searchRequestService;
        this.timeZoneManager = timeZoneManager;
        this.licenseUtil = licenseUtil;
        this.timesheetService = timesheetService;
        this.xsrfTokenGenerator = xsrfTokenGenerator;
        this.searchService = searchService;
        this.velocityManager = velocityManager;
        this.configurationService = configurationService;
    }

    @GET
    @AnonymousAllowed
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getTimesheet(@Context HttpServletRequest request,
            @QueryParam ("projectOrFilter") String projectOrFilter)
    {
        User targetUser = authenticationContext.getLoggedInUser();
        TimeZone timezone = timeZoneManager.getLoggedInUserTimeZone();
        I18nHelper i18n = authenticationContext.getI18nHelper();
        Timesheet timesheet = new Timesheet(targetUser, timezone, i18n,
                request.getParameterMap(),
                EnumSet.noneOf(TimeBase.Options.class),
                EnumSet.of(Timesheet.Options.SHOW_WEEKENDS),
                configurationService);
        
        Long[] projectOrFilterIds = new Long[2];
        String projectOrFilterName = ServletUtil.getProjectOrFilter(projectOrFilter, projectOrFilterIds,
                projectManager, authenticationContext, searchRequestService);
        timesheet.projectId = projectOrFilterIds[0];
        timesheet.filterId = projectOrFilterIds[1];
        // pass parameters
        if (projectOrFilterName != null) {
            timesheet.resultParams.put("projectOrFilterName", projectOrFilterName);
            timesheet.resultParams.put("projectId", timesheet.projectId);
            timesheet.resultParams.put("filterId", timesheet.filterId);
        }

        try
        {
            return Response
                    .ok(new TimeSheetRepresentation(velocityManager.getBody(
                            "templates/timesheetgadget/",
                            "timesheet-gadget.vm",
                            getVelocityParams(request, timesheet,
                                    projectOrFilterName)), projectOrFilterName))
                    .cacheControl(getNoCacheControl()).expires(new Date())
                    .header("Pragma", "no-cache").build();
        }
        catch (VelocityException e)
        {
            e.printStackTrace();
            return Response.serverError().build();
        }
    }

    private Map<String, Object> getVelocityParams(HttpServletRequest request, Timesheet timesheet,
            String projectOrFilterName) {
        // Retrieve the number of minute to add for a Low Worklog
        int numOfWeeks = ServletUtil.getIntParam(request, "numOfWeeks", 1);
        // Retrieve the week day that is to be a first day
        int reportingDay = ServletUtil.getIntParam(
                request,
                "reportingDay",
                Calendar.getInstance(timeZoneManager.getLoggedInUserTimeZone(), authenticationContext.getLocale()).getFirstDayOfWeek());
        int offset = ServletUtil.getIntParam(request, "offset", 0);

        final String startDateParam = request.getParameter("startDate");
        final Date startDate = getDateParam(startDateParam);

        Map<String, Object> params = getVelocityParams(numOfWeeks, reportingDay, offset,
                timesheet, projectOrFilterName, startDate);
        params.put("textutils", new TextUtils());
        params.put("req", request);
        final VelocityRequestContext velocityRequestContext = new DefaultVelocityRequestContextFactory(applicationProperties).getJiraVelocityRequestContext();
        params.put("requestContext", velocityRequestContext);
        params.put("atl_token", xsrfTokenGenerator.generateToken(request));
        params.put("license", licenseUtil.getLicenseStatus(true));
        params.put("licenseMgmt", licenseUtil.getLicenseMgmtUrl(request.getContextPath()));
        return params;
    }

    // Pass the data required for the portlet display to the view template
    private Map<String, Object> getVelocityParams(int numOfWeeks, int reportingDay, int offset,
            Timesheet timesheet, String projectOrFilterName, Date startDateParam) {
        Map<String, Object> params = timesheet.resultParams;
        final User user = authenticationContext.getLoggedInUser();
        TimeZone timezone = timesheet.timezone;

        params.put("loggedin", user != null);

        if (user == null) /* anonymous access */ {
            return params;
        }

        final I18nHelper i18n = timesheet.i18n;

        timesheet.reportingDay = CalendarUtil.getReportingDay(startDateParam, reportingDay, timesheet.monthView, timezone);
        params.put("reportingDay", timesheet.reportingDay); // overwrite
        final Calendar[] dates = CalendarUtil.getDatesRange(timesheet.reportingDay, numOfWeeks, offset, timesheet.monthView, timezone, startDateParam);
        final Calendar startDate = dates[0], endDate = dates[1];
        timesheet.startDate = startDate.getTime();
        timesheet.endDate = endDate.getTime();

        params.put("startDate", timesheet.startDate);
        // endDate for report
        endDate.add(Calendar.DAY_OF_MONTH, -1);
        params.put("endDate", endDate.getTime());
        params.put("offset", offset);
        DateTimeFormatter formatter = dateTimeFormatterFactory.formatter().forLoggedInUser().withZone(timezone);
        params.put("outlookDate", formatter.withStyle(DateTimeStyle.DATE));
        params.put("dpDate", formatter.withStyle(DateTimeStyle.DATE_PICKER));
        params.put("dpDateTime", formatter.withStyle(DateTimeStyle.DATE_TIME_PICKER));
        params.put("isoDate", formatter.withStyle(DateTimeStyle.ISO_8601_DATE));
        params.put("jsDateTimeFormat", applicationProperties.getDefaultBackedString("jira.date.time.picker.javascript.format"));
        params.put("lockDate", startDateParam);

        if (!CalendarUtil.isValidTimeInterval(startDate.getTime(), endDate.getTime(), configurationService)) {
            params.put("error", i18n.getText("timesheet.timeIntervalTooLong", configurationService.getMaxDays() / 7));
            return params;
        }

        try {
            if (timesheetService.isForbiddenByTimesheetAuditorsGroup(timesheet)) {
                params.put("users", Collections.EMPTY_LIST);
                params.put("error", i18n.getText("group.timesheet.userNotInTimesheetAuditorsGroup"));
                return params;
            }

            if (timesheet.targetGroup != null && timesheet.projectId == null && timesheet.projectRoleId == null &&
                    !permissionManager.hasPermission(Permissions.USER_PICKER, user)) {
                params.put("users", Collections.EMPTY_LIST);
                return params;
            }

            timesheetService.getTimeSpents(timesheet);
            params.put("users", timesheet.users); // initialized by group or project
            if (timesheet.users == null) {
                params.put("targetUser", timesheet.targetUser); // it's not set by default
            }

            params.put("projectRole", timesheet.projectRole);
            params.put("userWorkLog", timesheet.userWorkLogShort);

            // issue #317: show issues in progress
            if (timesheet.showDetails && timesheet.targetGroup == null
                    && timesheet.projectRoleId == null
                    && timesheet.remoteUser.equals(timesheet.targetUser)) { // classic user view
                String inProgressQuery = configurationService.getInProgressQuery();
                if (inProgressQuery != null) {
                    final SearchService.ParseResult parseResult =
                            searchService.parseQuery(timesheet.remoteUser, inProgressQuery);
                    if (parseResult.isValid()) {
                        SearchResults results = searchService.search(timesheet.remoteUser,
                                    parseResult.getQuery(), PagerFilter.getUnlimitedFilter());
                        for (Issue issue : results.getIssues()) {
                            if (!timesheet.weekWorkLogShort.containsKey(issue)) {
                                Map<Date, Long> weekTimeSpents = new Hashtable<Date, Long>();
                                timesheet.weekWorkLogShort.put(issue, weekTimeSpents);
                            }
                        }
                    } else {
                        log.warn("Error parsing in-progress query: " + parseResult.getErrors());
                    }
                }
                
            }
            params.put("weekWorkLog", timesheet.showDetails ? timesheet.weekWorkLogShort : timesheet.projectTimeSpents);
            params.put("projectGroupedTimeSpents", timesheet.projectGroupedByFieldTimeSpents);
            params.put("detailedWeekWorkLog", timesheet.weekWorkLog);
            params.put("weekTotalTimeSpents", timesheet.weekTotalTimeSpents);
            params.put("additionalFieldSumByProjectMap", timesheet.additionalFieldSumByProjectMap);
            params.put("fieldVisibility", fieldVisibilityManager);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return params;
    }
}
