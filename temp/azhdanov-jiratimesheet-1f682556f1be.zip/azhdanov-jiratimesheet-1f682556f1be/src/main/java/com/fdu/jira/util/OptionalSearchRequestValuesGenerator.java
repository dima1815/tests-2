package com.fdu.jira.util;

import com.atlassian.configurable.ValuesGenerator;
import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.bc.JiraServiceContext;
import com.atlassian.jira.bc.JiraServiceContextImpl;
import com.atlassian.jira.bc.filter.SearchRequestService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.search.SearchRequest;
import com.atlassian.jira.sharing.SharedEntityColumn;
import com.atlassian.jira.sharing.search.SharedEntitySearchContext;
import com.atlassian.jira.sharing.search.SharedEntitySearchParameters;
import com.atlassian.jira.sharing.search.SharedEntitySearchParametersBuilder;
import com.atlassian.jira.sharing.search.SharedEntitySearchResult;
import com.atlassian.jira.util.Consumer;
import com.atlassian.jira.util.NotNull;
import com.opensymphony.util.TextUtils;

import java.util.Map;

import org.apache.commons.collections.map.ListOrderedMap;

public class OptionalSearchRequestValuesGenerator implements ValuesGenerator {
		// extends SearchRequestValuesGenerator {

	public Map<String, String> getValues(Map params) {
	        final Map<String, String> savedFilters = new ListOrderedMap();
	        savedFilters.put("", "None");

	        SearchRequestService src = ComponentAccessor.getComponent(SearchRequestService.class);

	        User u = (User) params.get("User");
	        JiraServiceContext jsc = new JiraServiceContextImpl(u);

	        // Issue#382 show all shared filters
                // https://answers.atlassian.com/questions/24794/jira-how-to-get-a-list-of-all-accessible-filters-through-api
	        SharedEntitySearchParameters searchParams = new SharedEntitySearchParametersBuilder().
	                setEntitySearchContext(SharedEntitySearchContext.USE).
	                setName(null).
	                setDescription(null).
	                setFavourite(null).
	                setSortColumn(SharedEntityColumn.NAME, true).
	                setUserName(null).
	                setShareTypeParameter(null).
	                setTextSearchMode(null).
	                toSearchParameters();
	        SharedEntitySearchResult<SearchRequest> result = src.search(jsc, searchParams, 0, Integer.MAX_VALUE);
	        result.foreach(new Consumer<SearchRequest>() {
                    public void consume(@NotNull SearchRequest element) {
                        savedFilters.put(element.getId().toString(), TextUtils.htmlEncode(element.getName()));
                    }
	        });
	        
		return savedFilters;
	}

}
