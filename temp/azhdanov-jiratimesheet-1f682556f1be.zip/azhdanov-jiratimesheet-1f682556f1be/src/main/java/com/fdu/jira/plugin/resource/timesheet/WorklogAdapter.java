package com.fdu.jira.plugin.resource.timesheet;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.worklog.Worklog;

public class WorklogAdapter extends XmlAdapter<WorklogElement[], Map<Issue, List<Worklog>>>{

    @Override
    public Map<Issue, List<Worklog>> unmarshal(WorklogElement[] v) throws Exception {
        return null;
    }

    @Override
    public WorklogElement[] marshal(Map<Issue, List<Worklog>> v) throws Exception {
        WorklogElement[] worklogElements = new WorklogElement[v.size()];
        int i = 0;
        for (Map.Entry<Issue, List<Worklog>> entry : v.entrySet()) {
            Issue issue = entry.getKey();
            WorklogElement worklogElement = new WorklogElement(issue.getKey(), issue.getSummary());
            worklogElements[i++] = worklogElement;
            List<Worklog> worklogs = entry.getValue();
            worklogElement.entries = new WorklogEntryElement[worklogs.size()];
            int j = 0;
            for (Worklog worklog : worklogs) {
                worklogElement.entries[j++] = new WorklogEntryElement(worklog);
            }
        }

        return worklogElements;
    }

}
