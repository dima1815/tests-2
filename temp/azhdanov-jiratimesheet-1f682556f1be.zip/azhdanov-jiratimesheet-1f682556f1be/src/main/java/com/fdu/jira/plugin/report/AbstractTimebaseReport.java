package com.fdu.jira.plugin.report;

import com.atlassian.jira.datetime.DateTimeFormatter;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.datetime.DateTimeStyle;
import com.atlassian.jira.plugin.report.impl.AbstractReport;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.util.ParameterUtils;
import com.atlassian.jira.web.FieldVisibilityManager;
import com.atlassian.jira.web.action.ProjectActionSupport;
import com.fdu.jira.util.CalendarUtil;
import com.fdu.jira.util.ILicenseUtil;

import jira.plugin.report.timesheet.TimeBase;
import jira.timesheet.plugin.configuration.IConfigurationService;

import org.apache.commons.lang.time.DateUtils;

import org.apache.velocity.tools.generic.MathTool;
import webwork.action.ActionContext;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

public abstract class AbstractTimebaseReport<T extends TimeBase> extends AbstractReport {

    protected final JiraAuthenticationContext authenticationContext;

    protected DateTimeFormatterFactory dateTimeFormatterFactory;

    protected FieldVisibilityManager fieldVisibilityManager;

    protected TimeZoneManager timeZoneManager;

    protected final ILicenseUtil licenseUtil;

    protected final IConfigurationService configurationService;


    protected AbstractTimebaseReport(
            JiraAuthenticationContext authenticationContext,
            DateTimeFormatterFactory dateTimeFormatterFactory,
            FieldVisibilityManager fieldVisibilityManager,
            TimeZoneManager timeZoneManager,
            ILicenseUtil licenseUtil,
            IConfigurationService configurationService) {
        this.authenticationContext = authenticationContext;
        this.dateTimeFormatterFactory = dateTimeFormatterFactory;
        this.fieldVisibilityManager = fieldVisibilityManager;
        this.timeZoneManager = timeZoneManager;
        this.licenseUtil = licenseUtil;
        this.configurationService = configurationService;
    }

    public boolean isExcelViewSupported() {
        return true;
    }

    // Generate html report
    public String generateReportHtml(ProjectActionSupport action, Map params) throws Exception {
        return generateReport(action, params, false);
    }

    // Generate excel, report
    public String generateReportExcel(ProjectActionSupport action, Map params) throws Exception {
        if (getReportObject() == null) { // ConfigureReport!excelView.jspa does not call validate
            init(params);
        }

        StringBuilder contentDispositionValue = new StringBuilder(50);
        
        //Appending xls file extension with the report name
        // Thanks to Dipti Ranjan Behera[Guavus]:
        // https://answers.atlassian.com/questions/273734/excel-file-in-jira-timesheet-plugin-is-not-getting-downloaded-in-right-way/273806
        contentDispositionValue.append("attachment;filename=\"");
        contentDispositionValue.append(getDescriptor().getName()).append(".xls\";");
        
        HttpServletResponse response = ActionContext.getResponse();
        response.addHeader("content-disposition", contentDispositionValue.toString());

        return generateReport(action, params, true);
    }

    public void validate(ProjectActionSupport action, Map params) {
        init(params);

        final I18nHelper i18n = authenticationContext.getI18nHelper();

        // validate start & end dates

        Date startDate = ParameterUtils.getDateParam(params, "startDate",
                i18n.getLocale());
        Date endDate = ParameterUtils.getDateParam(params, "endDate",
                i18n.getLocale());

        // use current date if endDate is not specified. See TimeBase#getEndDate()
        if (endDate == null) {
            endDate = DateUtils.truncate(
                    DateUtils.addDays(new Date(), 1),
                    Calendar.DAY_OF_MONTH);
        }

        // Use one week before end date if startDate is not specified. See TimeBase#getStartDate()
        if (startDate == null) {
            startDate = DateUtils.truncate(
                    DateUtils.addWeeks(endDate, -1),
                    Calendar.DAY_OF_MONTH);
        }

        // The end date must be after the start date
        if (endDate.before(startDate)) {
            action.addError("endDate", action
                    .getText(getValidationErrorMessages().get("beforeStartDate")));
        }

        //  maxPeriod
        if (!CalendarUtil.isValidTimeInterval(startDate, endDate, configurationService)) {
            action.addError("endDate", action
                    .getText("timesheet.endDateTooLate", configurationService.getMaxDays() / 29));
        }
    }

    protected void prepareVelocityParams(Map<String, Object> velocityParams, TimeBase timebase) {
        final DateTimeFormatter formatter = dateTimeFormatterFactory.formatter().forLoggedInUser().withZone(timebase.timezone);
        velocityParams.put("outlookDate", formatter.withStyle(DateTimeStyle.DATE));
        velocityParams.put("outlookTime", formatter.withStyle(DateTimeStyle.COMPLETE));
        velocityParams.put("dpDate", formatter.withStyle(DateTimeStyle.DATE_PICKER));
        velocityParams.put("fieldVisibility", fieldVisibilityManager);
        velocityParams.put("license", licenseUtil.getLicenseStatus(true));
        String decimalSeparator = configurationService.getDecimalSeparator();
        if (decimalSeparator == null) {
            DecimalFormat decimalFormat = (DecimalFormat) DecimalFormat.getInstance(authenticationContext.getLocale());
            DecimalFormatSymbols decimalFormatSymbols = decimalFormat.getDecimalFormatSymbols();
            decimalSeparator = new String(new char[]{decimalFormatSymbols.getDecimalSeparator()});
        }
        velocityParams.put("decimalSymbol", decimalSeparator);
        velocityParams.put("math", new MathTool());
    }

    protected abstract String generateReport(ProjectActionSupport action, Map params, boolean excelView) throws Exception;
    protected abstract T getReportObject();
    protected abstract void init(Map params);
    protected abstract Map<String, String> getValidationErrorMessages();
}
