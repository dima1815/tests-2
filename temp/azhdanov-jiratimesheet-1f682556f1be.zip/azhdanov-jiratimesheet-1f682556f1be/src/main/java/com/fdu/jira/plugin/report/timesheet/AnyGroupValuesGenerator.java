package com.fdu.jira.plugin.report.timesheet;

import java.util.Map;

public class AnyGroupValuesGenerator extends GroupValuesGenerator {

    public static final String ANY_GROUP = "@any";
    private static final String ANY_GROUP_NAME = "Any group";

    public Map<String, String> getValues(Map params) {
        Map<String, String> values = super.getValues(params);
        values.put(ANY_GROUP, ANY_GROUP_NAME);
        return values;
    }

}
