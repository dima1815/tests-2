package com.fdu.jira.plugin.gadget.pivot;

import java.util.Calendar;
import java.util.Date;
import java.util.EnumSet;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.fdu.jira.plugin.resource.AbstractResource;

import jira.plugin.report.pivot.PivotService;
import jira.plugin.report.pivot.TimePivot;
import jira.plugin.report.timesheet.TimeBase.Options;
import jira.timesheet.plugin.configuration.IConfigurationService;

import org.apache.velocity.exception.VelocityException;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.bc.filter.SearchRequestService;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.jira.datetime.DateTimeFormatter;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.datetime.DateTimeStyle;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.util.velocity.DefaultVelocityRequestContextFactory;
import com.atlassian.jira.util.velocity.VelocityRequestContext;
import com.atlassian.jira.web.FieldVisibilityManager;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.atlassian.velocity.VelocityManager;
import com.fdu.jira.plugin.gadget.timesheet.TimeSheetRepresentation;
import com.fdu.jira.util.CalendarUtil;
import com.fdu.jira.util.ILicenseUtil;
import com.fdu.jira.util.ServletUtil;
import com.opensymphony.util.TextUtils;

/**
 * Generate a summary of worked hours for all or specified project.
 */
@Path ("/project-pivot-summary")
public class ProjectPivotSummaryResource extends AbstractResource {
    // References to managers required for this gadget
    private JiraAuthenticationContext authenticationContext;
    private FieldVisibilityManager fieldVisibilityManager;
    private ApplicationProperties applicationProperties;
    private ProjectManager projectManager;
    private SearchRequestService searchRequestService;
    private DateTimeFormatterFactory dateTimeFormatterFactory;
    private TimeZoneManager timeZoneManager;
    private final ILicenseUtil licenseUtil;
    private final PivotService pivotService;
    private final IConfigurationService configurationService;

    public ProjectPivotSummaryResource(JiraAuthenticationContext authenticationContext,
            ApplicationProperties applicationProperties,
            DateTimeFormatterFactory dateTimeFormatterFactory,
            FieldVisibilityManager fieldVisibilityManager,
            ProjectManager projectManager,
            SearchRequestService searchRequestService,
            TimeZoneManager timeZoneManager,
            ILicenseUtil licenseUtil,
            PivotService pivotService,
            IConfigurationService configurationService) {
        this.authenticationContext = authenticationContext;
        this.applicationProperties = applicationProperties;
        this.dateTimeFormatterFactory = dateTimeFormatterFactory;
        this.fieldVisibilityManager = fieldVisibilityManager;
        this.projectManager = projectManager;
        this.searchRequestService = searchRequestService;
        this.timeZoneManager = timeZoneManager;
        this.licenseUtil = licenseUtil;
        this.pivotService = pivotService;
        this.configurationService = configurationService;
    }

    @GET
    @AnonymousAllowed
    @Produces ({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getSummary(@Context HttpServletRequest request,
            @QueryParam ("projectOrFilter") String projectOrFilter)
    {
        User user = authenticationContext.getLoggedInUser();
        TimeZone timezone = timeZoneManager.getLoggedInUserTimeZone();
        I18nHelper i18n = authenticationContext.getI18nHelper();
        TimePivot pivot = new TimePivot(user, timezone, i18n,
                request.getParameterMap(),
                EnumSet.noneOf(Options.class),
                configurationService);
        VelocityManager vm = ComponentManager.getInstance().getVelocityManager();
        Long[] projectOrFilterIds = new Long[2];
        String projectOrFilterName = ServletUtil.getProjectOrFilter(projectOrFilter, projectOrFilterIds,
                projectManager, authenticationContext, searchRequestService);
        pivot.projectId = projectOrFilterIds[0];
        pivot.filterId = projectOrFilterIds[1];
        try
        {
            return Response
                    .ok(new TimeSheetRepresentation(vm.getBody(
                            "templates/pivotgadget/",
                            "project-pivot-summary.vm",
                            getVelocityParams(request, pivot,
                                    projectOrFilterName)), projectOrFilterName))
                    .cacheControl(getNoCacheControl()).expires(new Date())
                    .header("Pragma", "no-cache").build();
        }
        catch (VelocityException e)
        {
            e.printStackTrace();
            return Response.serverError().build();
        }
    }

    // Pass the data required for the portlet display to the view template
    protected Map<String,Object> getVelocityParams(HttpServletRequest request, TimePivot pivot, String projectOrFilterName) {
        // Retrieve the number of minute to add for a Low Worklog
        int numOfWeeks = ServletUtil.getIntParam(request, "numOfWeeks", 1);
        // Retrieve the week day that is to be a first day
        int reportingDay = ServletUtil.getIntParam(
                request,
                "reportingDay",
                Calendar.getInstance(timeZoneManager.getLoggedInUserTimeZone(), authenticationContext.getLocale()).getFirstDayOfWeek());
        int offset = ServletUtil.getIntParam(request, "offset", 0);

        final String startDateParam = request.getParameter("startDate");
        final Date startDate = getDateParam(startDateParam);

        Map<String, Object> params = getVelocityParams(numOfWeeks, offset, reportingDay, pivot, projectOrFilterName, startDate);
        params.put("textutils", new TextUtils());
        params.put("req", request);
        final VelocityRequestContext velocityRequestContext =
            new DefaultVelocityRequestContextFactory(applicationProperties).getJiraVelocityRequestContext();
        params.put("requestContext", velocityRequestContext);
        params.put("license", licenseUtil.getLicenseStatus(true));
        params.put("licenseMgmt", licenseUtil.getLicenseMgmtUrl(request.getContextPath()));
        return params;
    }

    protected Map<String, Object> getVelocityParams(
            int numOfWeeks, int offset, int reportingDay, TimePivot pivot, String projectOrFilterName, Date startDateParam) {
        Map<String, Object> params = pivot.resultParams;
        final User user = pivot.remoteUser;
        TimeZone timezone = pivot.timezone;

        params.put("loggedin", user != null);

        final I18nHelper i18n = pivot.i18n;

        pivot.reportingDay = CalendarUtil.getReportingDay(startDateParam, reportingDay, pivot.monthView, timezone);
        params.put("reportingDay", pivot.reportingDay); // overwrite
        final Calendar[] dates = CalendarUtil.getDatesRange(pivot.reportingDay, numOfWeeks, offset, pivot.monthView, timezone, startDateParam);
        final Calendar startDate = dates[0], endDate = dates[1];
        pivot.startDate = startDate.getTime();
        pivot.endDate = endDate.getTime();

        params.put("startDate", pivot.startDate);
        params.put("offset", offset);
        // endDate for report
        endDate.add(Calendar.DAY_OF_MONTH, -1);
        params.put("endDate", endDate.getTime());
        DateTimeFormatter formatter = dateTimeFormatterFactory.formatter().forLoggedInUser().withZone(timezone);
        params.put("outlookDate", formatter.withStyle(DateTimeStyle.DATE));
        params.put("dpDate", formatter.withStyle(DateTimeStyle.DATE_PICKER));
        params.put("isoDate", formatter.withStyle(DateTimeStyle.ISO_8601_DATE));
        params.put("lockDate", startDateParam);

        if (user == null) /* anonymous access */ {
            return params;
        }

        if (pivotService.isForbiddenByTimesheetAuditorsGroup(pivot)) {
            params.put("error", i18n.getText("project.pivot.userNotInTimesheetAuditorsGroup"));
            return params;
        }

        if (!CalendarUtil.isValidTimeInterval(startDate.getTime(), endDate.getTime(), configurationService)) {
            params.put("error", i18n.getText("timesheet.timeIntervalTooLong", configurationService.getMaxDays() / 7));
            return params;
        }

        try {
            pivotService.getTimeSpents(pivot);

            // Pass the issues to the velocity template
            if (projectOrFilterName != null) {
                params.put("projectOrFilterName", projectOrFilterName);
                params.put("filterId", pivot.filterId);
                params.put("projectId", pivot.projectId);
            }
            params.put("fieldVisibility", fieldVisibilityManager);
            params.put("workedIssues", pivot.showDetails ? pivot.workedIssues : pivot.workedProjects);
            params.put("workedUsers", pivot.workedUsers);
            params.put("targetGroup", pivot.targetGroup);
            params.put("excludeTargetGroup", pivot.excludeTargetGroup);
            params.put("projectRole", pivot.projectRole);
            params.put("additionalFieldSumByProjectMap", pivot.additionalFieldSumByProjectMap);
            params.put("projectGroupedTimeSpents", pivot.projectGroupedByFieldTimeSpents);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return params;
    }
}
