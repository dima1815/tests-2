package com.fdu.jira.plugin.resource.timechart;

import javax.xml.bind.annotation.XmlElement;

public class ImageRepresentation {

    @XmlElement
    public String url;

    @XmlElement
    public String title;

    public ImageRepresentation() {
        // for JAXB
    }

    public ImageRepresentation(String url, String title) {
        this.url = url;
        this.title = title;
    }
}
