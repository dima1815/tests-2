package jira.plugin.report.timesheet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.apache.commons.lang.StringEscapeUtils;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.worklog.Worklog;

import jira.timesheet.plugin.configuration.IConfigurationService;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.util.ParameterUtils;
import com.fdu.jira.util.CalendarUtil;
import com.fdu.jira.util.ServletUtil;
import com.fdu.jira.util.TextUtil;

public class TimeBase {
    @SuppressWarnings("rawtypes")
    public TimeBase(User remoteUser, TimeZone timezone,
            I18nHelper i18n,
            Map params, EnumSet<Options> options,
            IConfigurationService configurationService) {
        this.remoteUser = remoteUser;
        this.timezone = timezone;
        this.i18n = i18n;
        resultParams.put("i18n", i18n);
        textUtil = new TextUtil(i18n, timezone, configurationService);
        resultParams.put("textUtil", textUtil);

        if (params.containsKey("baseUrl")) {
            resultParams.put("baseurl", ParameterUtils.getStringParam(params, "baseUrl"));
        }

        if (options.contains(Options.DATES) || options.contains(Options.ISO_DATES)) {
          // local reportingDay for default end date only
          int reportingDay = ParameterUtils.getIntParam(params, "reportingDay", 0);
          endDate = getEndDate(params, i18n, timezone, options, reportingDay);
          Calendar endDateC = Calendar.getInstance(timezone);
          endDateC.setTime(endDate);
          endDateC.add(Calendar.DAY_OF_MONTH, -1); // adjust back to display and change
          resultParams.put("endDate", endDateC.getTime());
          startDate = getStartDate(params, i18n, endDate, timezone, options);
          resultParams.put("startDate", startDate);
        }

        if (!"".equals(ParameterUtils.getStringParam(params, "targetGroup"))) {
            targetGroup = getListParam(params, "targetGroup");
            resultParams.put("targetGroup", targetGroup);
        }

        if (!"".equals(ParameterUtils.getStringParam(params, "excludeTargetGroup"))) {
            excludeTargetGroup = getListParam(params, "excludeTargetGroup");
            resultParams.put("excludeTargetGroup", excludeTargetGroup);
        }

        if(!"".equals(ParameterUtils.getStringParam(params, "projectid"))) {
            projectId = ParameterUtils.getLongParam(params, "projectid");
            resultParams.put("projectId", projectId);
        }

        if(!"".equals(ParameterUtils.getStringParam(params, "filterid"))) {
            filterId = ParameterUtils.getLongParam(params, "filterid");
            resultParams.put("filterId", filterId);
        }
        
        if(!"".equals(ParameterUtils.getStringParam(params, "projectRoleId"))) {
            projectRoleId = ParameterUtils.getLongParam(params, "projectRoleId");
            resultParams.put("projectRoleId", projectRoleId);
        }

        if (negativeParam(params, "showDetails") ) {
            showDetails = false;
        }
        resultParams.put("showDetails", showDetails);

        if("true".equals(ParameterUtils.getStringParam(params, "sumSubTasks"))) {
            sumSubTasks = true;
        }
        resultParams.put("sumSubTasks", sumSubTasks);

        final String groupByFieldParam = ParameterUtils.getStringParam(params, "groupByField");
        if(groupByFieldParam != null && !"".equals(groupByFieldParam) && !"false".equals(groupByFieldParam)) {
            groupByField = groupByFieldParam;
            resultParams.put("groupByField", groupByField);
        }

        resultParams.put("moreFields", getListParam(params, "moreFields"));

        composeIssueLink = configurationService.getComposeIssueLink();

        if("true".equals(ParameterUtils.getStringParam(params, "monthView"))) {
            monthView = true;
        }
        resultParams.put("monthView", monthView);

        reportingDay = ParameterUtils.getIntParam(params, "reportingDay",
                monthView ? Calendar.getInstance(timezone, i18n.getLocale()).getFirstDayOfWeek() : 0);
        resultParams.put("reportingDay", reportingDay);

    }

    public User remoteUser;
    public Date startDate;
    public Date endDate;
    public boolean monthView = false;
    public boolean excelView = false;
    public List<String> targetGroup;
    public List<String> excludeTargetGroup;
    public Long projectId;
    public Long filterId;
    public Long projectRoleId;
    public ProjectRole projectRole;
    public String groupByField;
    public boolean showDetails = true;
    public boolean sumSubTasks = false;
    public Map<String, Object> resultParams = new HashMap<String, Object>();
    public TimeZone timezone;
    public I18nHelper i18n;
    public TextUtil textUtil;
    public String composeIssueLink;

    // for projectRole in timesheet
    public Set<User> users = null;
    // for group or project resources in timesheet
    public Set<String> authors = null;
    // number of worklogs of a report
    public int worklogCount;

    public int reportingDay;

    public Map<String, Map<String, Number>> additionalFieldSumByProjectMap =
            new HashMap<String, Map<String, Number>>();

    public Map<Issue, List<Worklog>> allWorkLogs = new Hashtable<Issue, List<Worklog>>();

    // configuraiton otpions
    public enum Options {
        DATES, ISO_DATES
    }

    public static Date getDateParam(String name, Map params, I18nHelper i18n, TimeZone timezone,
            EnumSet<Options> options) {
        Date date = null;
        if (options.contains(Options.DATES)) {
            // FIXME: use DateTimeFormatter
            date = ParameterUtils.getDateParam(params, name,
                    i18n.getLocale());
        }
        if (date == null && options.contains(Options.ISO_DATES)) {
            date = CalendarUtil.getIsoDateParam(params, name, timezone); 
        }
        return date;
    }

    @SuppressWarnings("unchecked")
    public static List<String> getListParam(Map params, String field) {
        List<String> result = ParameterUtils.getListParam(params, field);
        if (result == null) {
            result = new ArrayList<String>();
            String moreField = ParameterUtils.getStringParam(params, field);
            if (moreField != null && !moreField.isEmpty()) {
                result.add(moreField);
            }
        } else if (result.size() == 1) { // for gadgets
            result = Arrays.asList(result.get(0).split("\\|"));
        }
        // issue#528: group names come html encoded from reports
        // caution: erroneous for gadget instead 
        for (int i = 0; i < result.size(); i++) {
            result.set(i, StringEscapeUtils.unescapeHtml(result.get(i)));
        }
        return result;
    }

    public static Date getEndDate(Map params, I18nHelper i18n, TimeZone timezone,
            EnumSet<Options> options, int reportingDay) {
        Date endDate = getDateParam("endDate", params, i18n, timezone, options);
        // set endDate right after the date user has specified
        Calendar calendarDate = Calendar.getInstance(timezone);
        if (endDate != null) {
            calendarDate.setTime(endDate);
        } else if (reportingDay != 0) {
            CalendarUtil.roundByWeekDay(calendarDate, reportingDay);
        }
        // include the specified date or today
        calendarDate.add(Calendar.DAY_OF_YEAR, 1);
        CalendarUtil.roundDate(calendarDate);
        return calendarDate.getTime();
    }

    public static Date getStartDate(Map params, I18nHelper i18n,
        Date endDate, TimeZone timezone, EnumSet<Options> options) {
        Date startDate = getDateParam("startDate", params, i18n, timezone, options);
        Calendar calendarDate = Calendar.getInstance(timezone);
        // set startDate a week before
        if (startDate == null) {
            calendarDate.setTime(endDate);
            calendarDate.add(Calendar.WEEK_OF_YEAR, -1);
        } else {
            calendarDate.setTime(startDate);
        }
        CalendarUtil.roundDate(calendarDate);
        return calendarDate.getTime();
    }

    protected boolean negativeParam(Map params, String name) {
        String value = ParameterUtils.getStringParam(params, name);
        return value == null || "".equals(value) || "false".equals(value);
    }
}
