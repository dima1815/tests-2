package jira.plugin.report.timesheet;

public class LicenseException extends RuntimeException {
    private static final long serialVersionUID = 7802732300292437127L;

    public LicenseException(String licenseStatus) {
        super("Lisense is not valid: " + licenseStatus);
    }
}
