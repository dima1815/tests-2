package jira.plugin.report.timesheet;


import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

import com.atlassian.configurable.ValuesGenerator;
import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.fdu.jira.util.TextUtil;

public class ProjectRoleValuesGenerator  implements ValuesGenerator {

    public Map<String, String> getValues(Map arg0) {
        ProjectRoleManager projectManager = 
            ComponentManager.getComponentInstanceOfType(ProjectRoleManager.class);
        Collection<ProjectRole> projectRoles = projectManager.getProjectRoles();
        JiraAuthenticationContext authenticationContext =
            ComponentManager.getComponentInstanceOfType(JiraAuthenticationContext.class);
        User remoteUser = authenticationContext.getLoggedInUser();
        Map<String, String> result = new LinkedHashMap<String, String>();
        result.put("", TextUtil.NONE);
        if (remoteUser != null) {
            for (ProjectRole projectRole : projectRoles) {
                // TODO: permissions?
                result.put(projectRole.getId().toString(),  TextUtil.getUnquotedString(projectRole.getName()));
            }
        }
        return result;
    }
}

