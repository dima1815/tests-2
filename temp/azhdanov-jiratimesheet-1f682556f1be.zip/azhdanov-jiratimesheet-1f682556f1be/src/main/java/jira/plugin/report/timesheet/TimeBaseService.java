package jira.plugin.report.timesheet;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.bc.JiraServiceContext;
import com.atlassian.jira.bc.JiraServiceContextImpl;
import com.atlassian.jira.bc.filter.SearchRequestService;
import com.atlassian.jira.bc.issue.util.VisibilityValidator;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.comparator.UserComparator;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.link.IssueLinkManager;
import com.atlassian.jira.issue.link.LinkCollection;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.issue.search.SearchProvider;
import com.atlassian.jira.issue.search.SearchRequest;
import com.atlassian.jira.issue.search.SearchResults;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.issue.worklog.WorklogManager;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.security.Permissions;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.user.util.UserUtil;
import com.atlassian.jira.web.bean.PagerFilter;
import com.fdu.jira.plugin.report.timesheet.AnyGroupValuesGenerator;
import com.fdu.jira.util.CalendarUtil;
import com.fdu.jira.util.DirectoryUtil;
import com.fdu.jira.util.ForbiddenUtil;
import com.fdu.jira.util.MathUtils;
import com.fdu.jira.util.MyUser;
import com.fdu.jira.util.WeekendUtil;
import com.fdu.jira.util.WorklogUtil;
import com.google.common.base.Function;
import com.google.common.collect.Ordering;

import edu.emory.mathcs.backport.java.util.Collections;
import jira.timesheet.plugin.configuration.IConfigurationService;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.ofbiz.core.entity.DelegatorInterface;
import org.ofbiz.core.entity.EntityCondition;
import org.ofbiz.core.entity.EntityConditionList;
import org.ofbiz.core.entity.EntityExpr;
import org.ofbiz.core.entity.EntityListIterator;
import org.ofbiz.core.entity.EntityOperator;
import org.ofbiz.core.entity.GenericEntityException;
import org.ofbiz.core.entity.GenericValue;
import org.ofbiz.core.util.UtilMisc;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TimeZone;
import java.util.TreeSet;

public class TimeBaseService<T extends TimeBase> {
    private static final Logger log = Logger.getLogger(TimeBaseService.class);

    protected final DateTimeFormatterFactory dateTimeFormatterFactory;
    private final PermissionManager permissionManager;
    private final WorklogManager worklogManager;
    protected final IssueManager issueManager;
    private final SearchProvider searchProvider;
    private final VisibilityValidator visibilityValidator;
    private final UserUtil userUtil;
    private final SearchRequestService searchRequestService;
    private final TimeZoneManager timeZoneManager;
    private final ProjectRoleManager projectRoleManager;
    private final IssueLinkManager issueLinkManager;

    private final IConfigurationService configurationService;

    public TimeBaseService(ApplicationProperties applicationProperties,
            PermissionManager permissionManager,
            WorklogManager worklogManager,
            IssueManager issueManager,
            SearchProvider searchProvider,
            VisibilityValidator visibilityValidator,
            UserUtil userUtil,
            SearchRequestService searchRequestService,
            TimeZoneManager timeZoneManager,
            ProjectRoleManager projectRoleManager,
            IssueLinkManager issueLinkManager,
            IConfigurationService configurationService,
            DateTimeFormatterFactory dateTimeFormatterFactory) {
        this.permissionManager = permissionManager;
        this.worklogManager = worklogManager;
        this.issueManager = issueManager;
        this.searchProvider = searchProvider;
        this.visibilityValidator = visibilityValidator;
        this.userUtil = userUtil;
        this.searchRequestService = searchRequestService;
        this.timeZoneManager = timeZoneManager;
        this.projectRoleManager = projectRoleManager;
        this.issueLinkManager = issueLinkManager;
        this.configurationService = configurationService;
        this.dateTimeFormatterFactory = dateTimeFormatterFactory;
    }

    protected Issue getParentIssue(final Issue issue, final TimeBase timebase) {
        if (timebase.sumSubTasks) {
            return getLinkedIssue(issue, timebase, new TreeSet<String>());
        }
        return issue;
    }

    // returns original if no unique linked issue or no parent task
    private Issue getLinkedIssue(final Issue issue, final TimeBase timebase, final Set<String> previousIssues) {
        previousIssues.add(issue.getKey());
        String composeIssueLink = timebase.composeIssueLink;
        CustomField parentIssueField = timebase.textUtil.getParentIssueField();
        if (issue.isSubTask()) {
            Issue parent = issue.getParentObject();
            if (!previousIssues.contains(parent.getKey())) {
                return getLinkedIssue(parent, timebase, previousIssues);
            }
        } else if (composeIssueLink != null) {
            LinkCollection linkCollection = issueLinkManager.getLinkCollection(issue, timebase.remoteUser);
            List<Issue> linkedIssues = linkCollection.getOutwardIssues(composeIssueLink);
            if (linkedIssues != null && linkedIssues.size() == 1) {
                Issue linkedIssue = linkedIssues.iterator().next();
                if (!previousIssues.contains(linkedIssue.getKey())) {
                    return getLinkedIssue(linkedIssue, timebase, previousIssues);
                }
            } else if (linkedIssues != null) {
                log.info("No unique outward issue link of name "
                        + composeIssueLink + " for issue " + issue.getKey());
            } else {
                log.debug("No outward issue links of name "
                        + composeIssueLink + " for issue " + issue.getKey());
            }
        } else if (parentIssueField != null) {
            Issue linkedIssue = (Issue) issue.getCustomFieldValue(parentIssueField);
            if (linkedIssue != null) {
                if (!previousIssues.contains(linkedIssue.getKey())) {
                    return getLinkedIssue(linkedIssue, timebase, previousIssues);
                }
            }
            
        }
        return issue;
    }

    public void getTimeSpents(T timebase) throws SearchException, GenericEntityException {
        JiraServiceContext jiraServiceContext = new JiraServiceContextImpl(timebase.remoteUser);
        TimeZone timezone = timeZoneManager.getLoggedInUserTimeZone();

        Set<Long> filteredIssues = new TreeSet<Long>();
        if (timebase.filterId != null) {
            SearchRequest filter = searchRequestService.getFilter(jiraServiceContext, timebase.filterId);
            if (filter != null) { // not logged in
                PagerFilter pager = new PagerFilter(1000);
                List<Issue> issues;
                do {
                    SearchResults results = searchProvider.search(filter.getQuery(), timebase.remoteUser, pager);
                    issues = results.getIssues();
                    for (Issue issue : issues) {
                        filteredIssues.add(issue.getId());
                    }

                    pager = PagerFilter.newPageAlignedFilter(pager.getEnd(), pager.getMax());
                    
                } while (issues.size() == pager.getMax());
                log.info("Using filter: " + timebase.filterId
                        + ", with query: " + filter.getQuery()
                        + ", having " + filteredIssues.size() + " issues");
            }
        }

        // TIME-281: expand interval for worklogs in all time zones
        Calendar startDate = Calendar.getInstance();
        startDate.setTime(timebase.startDate);
        startDate.add(Calendar.DAY_OF_MONTH, -1);
        Calendar endDate = Calendar.getInstance();
        endDate.setTime(timebase.endDate);
        endDate.add(Calendar.DAY_OF_MONTH, 1);

        EntityExpr startExpr = new EntityExpr("startdate",
                EntityOperator.GREATER_THAN_EQUAL_TO, new Timestamp(
                        startDate.getTime().getTime()));
        EntityExpr endExpr = new EntityExpr("startdate",
                EntityOperator.LESS_THAN, new Timestamp(endDate.getTime().getTime()));
        List<EntityExpr> entityExprs = UtilMisc.toList(startExpr, endExpr);
        Set<User> excludeUsers;
        if (CollectionUtils.isNotEmpty(timebase.excludeTargetGroup)) {
            excludeUsers = userUtil.getAllUsersInGroupNames(timebase.excludeTargetGroup);
        } else {
            excludeUsers = Collections.emptySet();
        }
        if (CollectionUtils.isNotEmpty(timebase.targetGroup)) {
            
            timebase.users = new TreeSet<User>(new UserComparator()); // Issue#444: worked or active users
        
            if (!timebase.targetGroup.contains(AnyGroupValuesGenerator.ANY_GROUP)) {
                Set<User> users = userUtil.getAllUsersInGroupNames(timebase.targetGroup);
                timebase.authors = new TreeSet<String>();
                for (User user : users) {
                    if (excludeUsers.contains(user)) {
                        continue;
                    }
                    // TIME-156 and JRA-31902, support for mixed case, JIRA stores lower case
                    timebase.authors.add(DirectoryUtil.getUserName(user));
                    if (user.isActive()) {
                        timebase.users.add(user);
                     }
                }
                log.info("Searching worklogs created since '" + timebase.startDate
                    + "', till '" + timebase.endDate + "', by group '" + timebase.targetGroup + "'");
            } else {
                log.info("Searching worklogs created since '" + timebase.startDate
                        + "', till '" + timebase.endDate + "', by any user");
            }
        }

        addEntityExpressions(timebase, entityExprs);

        if (timebase.projectRoleId != null) {
            timebase.projectRole = projectRoleManager.getProjectRole(timebase.projectRoleId);
            timebase.users = new TreeSet<User>(new UserComparator());
        }

        final List<ProjectRole> timesheetAuditorsRoles = new ArrayList<ProjectRole>();
        Map<String, Boolean> isInTimesheetAuditorsRoleCache = null;
        final List<String> timesheetAuditorsRolesConfig = configurationService.getTimesheetAuditorsRoles();
        if (CollectionUtils.isNotEmpty(timesheetAuditorsRolesConfig)) {
            for (String role : timesheetAuditorsRolesConfig) {
                final ProjectRole projectRole = projectRoleManager.getProjectRole(role);
                if (projectRole != null) {
                    timesheetAuditorsRoles.add(projectRole);
                }
            }
            isInTimesheetAuditorsRoleCache = new HashMap<String, Boolean>();
        }

        final EntityCondition entityCondition = new EntityConditionList(entityExprs, EntityOperator.AND);

        final EntityListIterator worklogIterator =
                ComponentManager.getComponent(DelegatorInterface.class).findListIteratorByCondition(
                        "Worklog", entityCondition, null, null);

        try {

        timebase.worklogCount = 0;
        
        List<String> excludeProjects = configurationService.getExcludeProjects();

        for (GenericValue genericWorklog = worklogIterator.next(); genericWorklog != null; genericWorklog = worklogIterator.next()) {
            timebase.worklogCount++;

            Worklog worklog = WorklogUtil.convertToWorklog(genericWorklog, worklogManager, issueManager);

            Issue workedIssue = worklog.getIssue();

            if (!visibilityValidator.isValidVisibilityData(jiraServiceContext,
                    "worklog", workedIssue, worklog.getGroupLevel(),
                    worklog.getRoleLevelId() != null ? worklog.getRoleLevelId().toString() : null)) {
                log.debug("Worklog " + worklog.getId() + " is not visible for currently logged in user, skipping.");
                continue;
            }

            Issue issue = getParentIssue(workedIssue, timebase);

            if (timebase.filterId != null && !filteredIssues.contains(issue.getId())) {
                log.debug("Issue " + issue.getKey() + " did not match filter, skipping.");
                continue;
            }

            User workedUser;
            String author = worklog.getAuthor();
            if (author != null) {
                workedUser = DirectoryUtil.getUser(userUtil, author);
                if (workedUser == null) {
                    // TIME-221: user may have been deleted
                    workedUser = new MyUser(author, worklog.getAuthorFullName());
                }
            } else {
                author = "anonymous";
                // causes NPE by TimeZoneManagerImpl.getTimeZoneforUser - DefaultUserPreferencesManager.getPreferences - cache.get
                workedUser = new MyUser(author, author);
            }

            if (timebase.authors != null && !timebase.authors.contains(author)) {
                log.debug("Author " + author + " did not match group condition, skipping.");
                continue;
            }

            Project project = issue.getProjectObject();

            // isInTimesheetAuditorsRole?
            // do this before project and role checks not to reveal users
            if (CollectionUtils.isNotEmpty(timesheetAuditorsRoles) && !timebase.remoteUser.equals(workedUser)) {
                Boolean isInTimesheetAuditorsRole = isInTimesheetAuditorsRoleCache.get(project.getKey());
                if (isInTimesheetAuditorsRole == null) {
                    isInTimesheetAuditorsRole = false;
                    for (ProjectRole timesheetAuditorsRole : timesheetAuditorsRoles) {
                        isInTimesheetAuditorsRole |=
                                projectRoleManager.isUserInProjectRole(timebase.remoteUser, timesheetAuditorsRole, project);
                    }
                    isInTimesheetAuditorsRoleCache.put(project.getKey(), isInTimesheetAuditorsRole);
                }
                if (!isInTimesheetAuditorsRole) {
                    log.debug("Issue " + issue.getKey() + " does not match timesheetAuditorsRole, skipping.");
                    continue; // exclude issues that users can't (shouldn't be
                                // allowed to) see
                }
            }

            if (skipByRestrictedGroup(timebase.remoteUser, workedUser)) {
                log.debug(String.format("Worklog of user '%s' skipped because of restriction groups", workedUser.getDisplayName()));
                continue;
            }

            if (excludeUsers.contains(workedUser)) {
                log.debug("User " + workedUser.getName() + " excluded by excludeTargetGroup.");
                continue;
            }

            if (timebase.projectId != null && !project.getId().equals(timebase.projectId)){
                log.debug("Issue " + issue.getKey() + " did not match project condition, skipping.");
                continue; // exclude issues from other projects than (if) selected
            } else if (excludeProjects != null && excludeProjects.contains(project.getId().toString())) {
                log.info("Issue " + issue.getKey() + "  matched excludeProjects plugin configuration, skipping");
                continue; // exclude issues from excludeProjects
            } else if (timebase.users != null && timebase.projectRole == null) {
                timebase.users.add(workedUser);
            }

            if (timebase.projectRole != null) {
               if (!projectRoleManager.isUserInProjectRole(workedUser, timebase.projectRole, project)) {
                   log.debug("Issue " + issue.getKey() + " did not match role condition, skipping.");
                   continue; // TIME-271
               } else {
                   timebase.users.add(workedUser);
               }
            }

            if (!permissionManager.hasPermission(Permissions.BROWSE, issue,
                    timebase.remoteUser)) {
                log.debug("Issue " + issue.getKey() + " is out of permission, skipping.");
                continue; // exclude issues that users can't (shouldn't be
                            // allowed to) see
            }

            Date dateCreated = worklog.getStartDate(); // server time zone

            // TIME-281: convert to remote user time zone
            TimeZone workedUserTimeZone;
            if (workedUser instanceof MyUser && workedUser.getName().equals("anonymous")) {
                // FIXME: causes NPE, may be just exclude anonymous records?
                workedUserTimeZone = timeZoneManager.getTimeZoneforUser(timebase.remoteUser);
            } else {
                workedUserTimeZone = timeZoneManager.getTimeZoneforUser(workedUser);
            }
            Calendar cal = CalendarUtil.convertWorkedTimeDate(dateCreated, workedUserTimeZone, timezone);

            Date dateOfTheDay = cal.getTime();
            // TIME-281: exclude workogs by date in target timezone
            if (dateOfTheDay.before(timebase.startDate) || !dateOfTheDay.before(timebase.endDate)) {
                log.debug("Worklog with date " + dateCreated + " did not match date interval, skipping.");
                continue;
            }

            processSingle(timebase, worklog, issue, project, workedUser, cal);

        }
        
        } finally {
            worklogIterator.close();
        }

        log.info("Processed " + timebase.worklogCount + " worklogs");

        postProcess(timebase, timezone);
    }

    protected boolean skipByRestrictedGroup(User loggedUser, User workedUser) {
        final List<String> restrictedGroups = configurationService.getRestrictedGroups();
        final SortedSet<String> loggedUserGroups;
        if (loggedUser != null) {
            loggedUserGroups = userUtil.getGroupNamesForUser(loggedUser.getName());
        } else {
            loggedUserGroups = new TreeSet<String>(); // no groups for anonymous, let fall back
        }
        final SortedSet<String> worklogGroups = userUtil.getGroupNamesForUser(workedUser.getName());
        if (CollectionUtils.isNotEmpty(restrictedGroups)) {
            if (CollectionUtils.isNotEmpty(loggedUserGroups) && CollectionUtils.isNotEmpty(worklogGroups)) {
                for (String restrictedGroup : restrictedGroups) {
                    if (loggedUserGroups.contains(restrictedGroup) && worklogGroups.contains(restrictedGroup)) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }

    protected void addEntityExpressions(T timebase, List<EntityExpr> entityExprs) throws GenericEntityException {
        // see overrides
    }

    protected void processSingle(T timebase, Worklog worklog,
            Issue issue, Project project, User workedUser, Calendar workedDate) {
        // see overrides
    }

    protected void postProcess(T timebase, TimeZone timezone) {
        if (timebase.excelView && timebase.allWorkLogs != null) {
            for (List<Worklog> worklogs : timebase.allWorkLogs.values()) {
                java.util.Collections.sort(worklogs, getWorklogByDateOrder());
            }
        }
        // see overrides
    }

    public boolean isForbiddenByTimesheetAuditorsGroup(T timebase) {
        return ForbiddenUtil.isForbiddenByAuditorsGroup(timebase.remoteUser.getName());
    }

    protected Set<Integer> getWeekends() {
        return WeekendUtil.getWeekendsAsDays(configurationService.getWeekendType());
    }

    protected void prepareAdditionalFieldSumByProject(T timebase) {
        for (Object moreField : (List) timebase.resultParams.get("moreFields")) {
            final String field = (String) moreField;
            final Map<String, Number> projectMap = new HashMap<String, Number>();
            timebase.additionalFieldSumByProjectMap.put(field, projectMap);

            final Set<Issue> issues = getGroupedIssues(timebase);
            if (CollectionUtils.isNotEmpty(issues)) {
                for (Issue issue : issues) {
                    final String projectKey = issue.getProjectObject().getKey();
                    final Number valueFromMap = projectMap.get(projectKey);
                    final Object value = timebase.textUtil.getFieldObjectValue(field, issue, null, true);
                    if (NumberUtils.isNumber(value.toString())) {
                        final Number numberValue = NumberUtils.createNumber(value.toString());
                        if (valueFromMap != null || numberValue != null) {
                            projectMap.put(projectKey,
                                    MathUtils.add(
                                            normalizeNumberValue(valueFromMap),
                                            normalizeNumberValue(numberValue)));
                        }
                    }
                }
            }
        }
    }

    protected Ordering<Worklog> getWorklogByDateOrder() {
        return Ordering.natural()
                .onResultOf(new Function<Worklog, Long>() {
                    public Long apply(Worklog w) {
                        return w.getStartDate().getTime();
                    }
                })
                .nullsLast();
    }

    protected Number normalizeNumberValue(Number value) {
        return (value == null) ? NumberUtils.createNumber("0") : value;
    }

    protected Set<Issue> getGroupedIssues(T timebase) {
        return new HashSet<Issue>();
    }
}
