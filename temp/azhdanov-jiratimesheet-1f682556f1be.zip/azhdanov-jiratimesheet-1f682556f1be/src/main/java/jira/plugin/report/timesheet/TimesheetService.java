package jira.plugin.report.timesheet;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.TreeSet;

import com.fdu.jira.util.CalendarUtil;
import com.fdu.jira.util.ForbiddenUtil;
import jira.timesheet.plugin.holidays.HolidayService;
import jira.timesheet.plugin.configuration.IConfigurationService;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.ofbiz.core.entity.EntityExpr;
import org.ofbiz.core.entity.EntityOperator;
import org.ofbiz.core.entity.GenericEntityException;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.bc.filter.SearchRequestService;
import com.atlassian.jira.bc.issue.util.VisibilityValidator;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.comparator.UserComparator;
import com.atlassian.jira.issue.link.IssueLinkManager;
import com.atlassian.jira.issue.search.SearchProvider;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.issue.worklog.WorklogManager;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.security.roles.ProjectRoleActors;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.security.roles.RoleActor;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.user.util.UserUtil;
import com.fdu.jira.plugin.report.timesheet.IssueProjectComparator;
import com.fdu.jira.util.WeekPortletHeader;

public class TimesheetService extends TimeBaseService<Timesheet> {
    private static final Logger log = Logger.getLogger(TimesheetService.class);

    protected static final int WORKLOG_LIMIT = 2300;

    private final ProjectRoleManager projectRoleManager;
    private final ProjectManager projectManager;
    private final HolidayService holidayService;
    private final IConfigurationService configurationService;

    public TimesheetService(DateTimeFormatterFactory dateTimeFormatterFactory,
            PermissionManager permissionManager, WorklogManager worklogManager,
            IssueManager issueManager, SearchProvider searchProvider,
            VisibilityValidator visibilityValidator, UserUtil userUtil,
            SearchRequestService searchRequestService,
            TimeZoneManager timeZoneManager,
            ProjectRoleManager projectRoleManager,
            IssueLinkManager issueLinkManager,
            ApplicationProperties applicationProperties,
            ProjectManager projectManager,
            HolidayService holidayService,
            IConfigurationService configurationService) {
        super(applicationProperties, permissionManager, worklogManager,
                issueManager, searchProvider, visibilityValidator, userUtil,
                searchRequestService, timeZoneManager, projectRoleManager,
                issueLinkManager, configurationService, dateTimeFormatterFactory);
        this.projectRoleManager = projectRoleManager;
        this.projectManager = projectManager;
        this.holidayService = holidayService;
        this.configurationService = configurationService;
    }

    @Override
    protected void addEntityExpressions(Timesheet timesheet,
            List<EntityExpr> entityExprs) throws GenericEntityException {
        if (CollectionUtils.isNotEmpty(timesheet.targetGroup)) {
            // see TimeBase.getTimeSpents
        } else if (timesheet.targetUserName != null
                || (timesheet.projectId == null && timesheet.projectRoleId == null)) {
            // JRA-31902 support for mixed case, JIRA stores lower case
            // issue #347 support non lower case usernames, see also JRA-24558
            // issue #376 No data for renamed user
            String username = timesheet.getTargetUserName();
            EntityExpr userExpr = new EntityExpr("author",
                    EntityOperator.EQUALS, username);
            entityExprs.add(userExpr);

            log.info("Searching worklogs created since '" + timesheet.startDate
                    + "', till '" + timesheet.endDate + "', by '" + username
                    + "'");
        } else { // timesheet.projectRoleId != null || timesheet.projectId !=
                 // null
            log.info("Searching worklogs created since '" + timesheet.startDate
                    + "', till '" + timesheet.endDate + "'");
        }

        if (timesheet.projectId != null && timesheet.targetUserName == null
                && timesheet.projectRoleId == null
                && timesheet.targetGroup == null) {
            // show timesheet for all project members
            timesheet.users = new TreeSet<User>(new UserComparator());
            // users are collected on the way
        }
    }

    @Override
    protected void processSingle(Timesheet timesheet, Worklog worklog,
            Issue issue, Project project, User workedUser, Calendar workedDate) {

        if (timesheet.showDetails && timesheet.worklogCount > WORKLOG_LIMIT) {
            timesheet.showDetails = false;
        }

        if (timesheet.priority != null
                && !issue.getPriorityObject().getId()
                        .equals(timesheet.priority)) {
            log.debug("Issue " + issue.getKey()
                    + " did not match priority condition, skipping.");
            return; // filter out issue by priority
        }

        Date dateOfTheDay = workedDate.getTime();

        WeekPortletHeader weekDay = new WeekPortletHeader(workedDate,
                timesheet.monthView, getWeekends(), holidayService.getHolidayName(workedDate), timesheet.reportingDay, configurationService.getHighlightHours());
        if (!timesheet.showWeekends && weekDay.isNonBusinessDay()) {
            log.debug("Worklog " + worklog.getId()
                    + " is on weekend, skipping.");
            return; // exclude worklogs and issues that were started on weekends
                    // if no weekends desired to show
        }

        if (timesheet.monthView) {
            CalendarUtil.roundByWeekDay(workedDate, timesheet.reportingDay);
            dateOfTheDay = workedDate.getTime();
        }
        Long dateCreatedLong = workedDate.getTimeInMillis();

        long spent;

        if (timesheet.excelView) {
            // excel view shows complete work log
            List<Worklog> issueWorklogs = timesheet.allWorkLogs.get(issue);
            if (issueWorklogs == null) {
                issueWorklogs = new ArrayList<Worklog>();
                timesheet.allWorkLogs.put(issue, issueWorklogs);
            }
            issueWorklogs.add(worklog);
        } else {
            // html view shows summary hours per issue for each user
            // per entry (report)

            // per issue (portlet)
            Map<Date, Long> weekTimeSpents = timesheet.weekWorkLogShort
                    .get(issue);
            if (weekTimeSpents == null) {
                weekTimeSpents = new Hashtable<Date, Long>();
                timesheet.weekWorkLogShort.put(issue, weekTimeSpents); // portlet
            }

            spent = worklog.getTimeSpent();
            Long dateSpent = weekTimeSpents.get(dateOfTheDay);

            if (dateSpent != null) {
                spent += dateSpent;
            }

            weekTimeSpents.put(dateOfTheDay, spent);

            // per user (group portlet)
            updateUserWorkLog(timesheet, worklog, workedUser, dateOfTheDay);

            // per project per day
            Map<Date, Long> projectWorkLog = timesheet.projectTimeSpents
                    .get(project);
            if (projectWorkLog == null) {
                projectWorkLog = new Hashtable<Date, Long>();
                timesheet.projectTimeSpents.put(project, projectWorkLog);
            }

            spent = worklog.getTimeSpent();

            Long projectSpent = projectWorkLog.get(dateOfTheDay);

            if (projectSpent != null) {
                spent += projectSpent;
            }

            projectWorkLog.put(dateOfTheDay, spent);

            // per project and field
            calculateTimesForProjectGroupedByField(timesheet, worklog, issue,
                    project, dateOfTheDay);

            // total per day
            spent = worklog.getTimeSpent();
            dateSpent = timesheet.weekTotalTimeSpents.get(dateCreatedLong);
            if (dateSpent != null) {
                spent += dateSpent;
            }
            timesheet.weekTotalTimeSpents.put(dateCreatedLong, spent);

            spent = worklog.getTimeSpent();
            // always collect details, but show only if (timesheet.showDetails)
                Map<Issue, List<Worklog>> userWorkLog = timesheet.weekWorkLog
                        .get(workedUser);
                if (userWorkLog == null) {
                    userWorkLog = new TreeMap<Issue, List<Worklog>>(
                            new IssueProjectComparator<Issue>());
                    timesheet.weekWorkLog.put(workedUser, userWorkLog);
                }
                List<Worklog> issueWorkLog = userWorkLog.get(issue);
                if (issueWorkLog == null) {
                    issueWorkLog = new ArrayList<Worklog>();
                    userWorkLog.put(issue, issueWorkLog);
                }
                issueWorkLog.add(worklog);

                // totals per user/week
                Map<Long, Long> userTotalTimeSpents = timesheet.userWeekTotalTimeSpents
                        .get(workedUser);
                if (userTotalTimeSpents == null) {
                    userTotalTimeSpents = new HashMap<Long, Long>();
                    timesheet.userWeekTotalTimeSpents.put(workedUser,
                            userTotalTimeSpents);
                }
                Long weekDaySpent = userTotalTimeSpents.get(dateCreatedLong);
                if (weekDaySpent != null) {
                    spent += weekDaySpent;
                }
                userTotalTimeSpents.put(dateCreatedLong, spent);

                // totals per user/issue
                spent = worklog.getTimeSpent();
                Map<Issue, Long> issueTotalTimeSpents = timesheet.userIssueTotalTimeSpents
                        .get(workedUser);
                if (issueTotalTimeSpents == null) {
                    issueTotalTimeSpents = new HashMap<Issue, Long>();
                    timesheet.userIssueTotalTimeSpents.put(workedUser,
                            issueTotalTimeSpents);
                }
                Long issueSpent = issueTotalTimeSpents.get(issue);
                if (issueSpent != null) {
                    spent += issueSpent;
                }
                issueTotalTimeSpents.put(issue, spent);
        }
    }

    @Override
    protected void postProcess(Timesheet timesheet, TimeZone timezone) {

        super.postProcess(timesheet, timezone);

        // fill dates (ordered list) and week days (corresponding to each date)
        Calendar calendarDate = Calendar.getInstance(timezone);
        calendarDate.setTime(timesheet.startDate);
        if (timesheet.monthView) {
            CalendarUtil.roundByWeekDay(calendarDate, timesheet.reportingDay);
        }
        Calendar today = Calendar.getInstance(timezone);

        while (timesheet.endDate.after(calendarDate.getTime())) {
            final Calendar workingDate = (Calendar) calendarDate.clone();
            WeekPortletHeader wph = new WeekPortletHeader(
                    (Calendar) calendarDate.clone(), timesheet.monthView, getWeekends(), holidayService.getHolidayName(workingDate), timesheet.reportingDay, configurationService.getHighlightHours());
            String businessDay = "";
            if (!timesheet.monthView) {
                if (calendarDate.get(Calendar.DATE) == today.get(Calendar.DATE)
                        && calendarDate.get(Calendar.MONTH) == today
                                .get(Calendar.MONTH)
                        && calendarDate.get(Calendar.YEAR) == today
                                .get(Calendar.YEAR)) {
                    businessDay = "toDay";
                } else if (wph.isNonBusinessDay() || wph.isHoliday()) {
                    businessDay = "nonBusinessDay";
                }
                if (wph.isHoliday()) {
                    businessDay += " holidayDayOfWeek";
                }

            } else {
                if (CalendarUtil.isSameWeek(calendarDate, today, timesheet.reportingDay)) {
                    businessDay = "toDay";
                }
            }
            wph.setWeekDayCSS(businessDay); // rowHeaderDark redText
                                            // red-highlight
            if (timesheet.monthView || timesheet.showWeekends
                    || wph.isBusinessDay()) { // check if allowed to show
                                              // weekends and if this it is a
                                              // weekend
                timesheet.weekDays.add(wph);
            }
            int field = Calendar.DAY_OF_YEAR;
            if (timesheet.monthView) {
                field = Calendar.WEEK_OF_YEAR;
            }
            calendarDate.add(field, 1);
            // TIME-294: in Brazil DST starts on midnight, so hour gets changed
            // when iterating through clock change week
            calendarDate.set(Calendar.HOUR_OF_DAY, 0);
        }

        prepareAdditionalFieldSumByProject(timesheet);
    }

    @Override
    protected Set<Issue> getGroupedIssues(Timesheet pivot)
    {
        return pivot.weekWorkLogShort.keySet();
    }

    // not used by commit#8dac261: project timesheet shows worked users,
    // similarly to role view
    private Set<User> projectUsers(Long projectId, Set<User> filter)
            throws GenericEntityException {
        Set<User> users = new TreeSet<User>();

        Project resourceProject = projectManager.getProjectObj(projectId);
        Collection<ProjectRole> projectRoles = projectRoleManager
                .getProjectRoles();
        for (ProjectRole projectRole : projectRoles) {
            if ("Users".equals(projectRole.getName())) {
                continue;
            }

            ProjectRoleActors allProjectRoleActors = projectRoleManager
                    .getProjectRoleActors(projectRole, resourceProject);
            if (allProjectRoleActors != null) {
                addRoleActors(allProjectRoleActors,
                        "atlassian-user-role-actor", users, filter);
                addRoleActors(allProjectRoleActors,
                        "atlassian-group-role-actor", users, filter);
            }
        }

        return users;
    }

    private void addRoleActors(final ProjectRoleActors allProjectRoleActors,
            final String roleActorsType, final Set<User> users, Set<User> filter) {
        Set<RoleActor> actorsObjects = allProjectRoleActors
                .getRoleActorsByType(roleActorsType);
        if (actorsObjects != null) {
            for (RoleActor actor : actorsObjects) {
                for (User roleUser : actor.getUsers()) {
                    if (filter == null || filter.contains(roleUser)) {
                        if (roleUser.isActive()) {
                            users.add(roleUser);
                        }
                    }
                }
            }
        }
    }

    private void updateUserWorkLog(Timesheet timesheet, Worklog worklog,
            User workedUser, Date dateOfTheDay) {
        long spent;
        Map<Date, Long> dateToWorkMap = timesheet.userWorkLogShort
                .get(workedUser);
        if (dateToWorkMap == null) {
            dateToWorkMap = new HashMap<Date, Long>();
            timesheet.userWorkLogShort.put(workedUser, dateToWorkMap); // portlet
        }

        spent = worklog.getTimeSpent();
        Long dateSpent = dateToWorkMap.get(dateOfTheDay);

        if (dateSpent != null) {
            spent += dateSpent;
        }
        dateToWorkMap.put(dateOfTheDay, spent);
    }

    /**
     * Calculates the times spend per project, grouped by a field.
     * <p/>
     * Stores results in {@link Timesheet#projectGroupedByFieldTimeSpents}.
     * 
     * @param timesheet
     *            - timesheet
     * @param worklog
     *            - reference to for-loop variable from @see #getTimeSpents
     * @param issue
     *            - reference to for-loop variable from @see #getTimeSpents
     * @param project
     *            - reference to for-loop variable from @see #getTimeSpents
     * @param dateOfTheDay
     *            - reference to for-loop variable from @see #getTimeSpents
     */
    private void calculateTimesForProjectGroupedByField(Timesheet timesheet,
            Worklog worklog, Issue issue, Project project, Date dateOfTheDay) {

        String fieldValue = timesheet.textUtil.getFieldValue(
                timesheet.groupByField, issue, dateTimeFormatterFactory
                        .formatter().forLoggedInUser(), worklog);

        if (fieldValue != null && !fieldValue.isEmpty()) {

            // dimension Project to field
            Map<String, Map<Date, List<Worklog>>> projectToFieldWorkLog = timesheet.projectGroupedByFieldTimeSpents
                    .get(project);
            if (projectToFieldWorkLog == null) {
                projectToFieldWorkLog = new TreeMap<String, Map<Date, List<Worklog>>>();
                timesheet.projectGroupedByFieldTimeSpents.put(project,
                        projectToFieldWorkLog);
            }

            // dimension Field to Time
            Map<Date, List<Worklog>> fieldToTimeWorkLog = projectToFieldWorkLog
                    .get(fieldValue);
            if (fieldToTimeWorkLog == null) {
                fieldToTimeWorkLog = new TreeMap<Date, List<Worklog>>();
                projectToFieldWorkLog.put(fieldValue, fieldToTimeWorkLog);
            }

            List<Worklog> projectGroupedWorklog = fieldToTimeWorkLog
                    .get(dateOfTheDay);
            if (projectGroupedWorklog == null) {
                projectGroupedWorklog = new ArrayList<Worklog>();
                fieldToTimeWorkLog.put(dateOfTheDay, projectGroupedWorklog);
            }
            projectGroupedWorklog.add(worklog);
        }
    }

    @Override
    public boolean isForbiddenByTimesheetAuditorsGroup(Timesheet timesheet) {
        boolean othersTimesheet = ForbiddenUtil.isOthersTimesheet(
                timesheet.remoteUser,
                timesheet.targetUserName,
                timesheet.targetGroup,
                timesheet.projectId,
                timesheet.projectRoleId);
        return othersTimesheet && super.isForbiddenByTimesheetAuditorsGroup(timesheet);
    }
}
