package jira.plugin.report.pivot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeMap;

import com.atlassian.jira.datetime.DateTimeFormatterFactory;

import jira.plugin.report.timesheet.TimeBaseService;
import jira.timesheet.plugin.configuration.IConfigurationService;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.ofbiz.core.entity.EntityExpr;
import org.ofbiz.core.entity.GenericEntityException;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.crowd.embedded.api.UserComparator;
import com.atlassian.jira.bc.filter.SearchRequestService;
import com.atlassian.jira.bc.issue.util.VisibilityValidator;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.link.IssueLinkManager;
import com.atlassian.jira.issue.search.SearchProvider;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.issue.worklog.WorklogManager;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.user.util.UserUtil;

public class PivotService extends TimeBaseService<TimePivot> {
    private static final Logger log = Logger.getLogger(PivotService.class);

    public PivotService(PermissionManager permissionManager,
            WorklogManager worklogManager,
            IssueManager issueManager,
            SearchProvider searchProvider,
            VisibilityValidator visibilityValidator,
            UserUtil userUtil,
            SearchRequestService searchRequestService,
            ProjectRoleManager projectRoleManager,
            IssueLinkManager issueLinkManager,
            ApplicationProperties applicationProperties,
            TimeZoneManager timeZoneManager,
            IConfigurationService configurationService,
            DateTimeFormatterFactory dateTimeFormatterFactory) {
        super(applicationProperties, permissionManager, worklogManager,
                issueManager, searchProvider, visibilityValidator, userUtil,
                searchRequestService, timeZoneManager, projectRoleManager,
                issueLinkManager, configurationService, dateTimeFormatterFactory);
    }

    @Override
    protected void addEntityExpressions(TimePivot pivot, List<EntityExpr> entityExprs) throws GenericEntityException {
        if (CollectionUtils.isEmpty(pivot.targetGroup)) {
            log.info("Searching worklogs created since '" + pivot.startDate
                    + "', till '" + pivot.endDate + "'");
        }
    }

    @Override
    protected void processSingle(TimePivot pivot, Worklog worklog, Issue issue, Project project, User workedUser, Calendar workedDate) {
        
                    if (pivot.excelView && pivot.showDetails) {
                        // excel view shows complete work log
                        List<Worklog> issueWorklogs = pivot.allWorkLogs.get(issue);
                        if (issueWorklogs == null) {
                            issueWorklogs = new ArrayList<Worklog>();
                            pivot.allWorkLogs.put(issue, issueWorklogs);
                        }
                        issueWorklogs.add(worklog);
                    } else {
                        Map<User, Long> userWorkLog;

                        if (pivot.showDetails) {
                            // shows summary hours per issue for each user
                            userWorkLog = pivot.workedIssues.get(issue);
                            if (userWorkLog == null) {
                                userWorkLog = new Hashtable<User, Long>();
                                pivot.workedIssues.put(issue, userWorkLog);
                            }
                        } else {
                            if (StringUtils.isNotBlank(pivot.groupByField)) {
                                pivot.workedIssues.put(issue, null); //for grouping
                            }
                            // shows summary hours per project for each user
                            userWorkLog = pivot.workedProjects.get(project);
                            if (userWorkLog == null) {
                                userWorkLog = new Hashtable<User, Long>();
                                pivot.workedProjects.put(project, userWorkLog);
                            }
                        }

                        // user per issue
                        long timespent = worklog.getTimeSpent();
                        
                        Long worked = userWorkLog.get(workedUser);
                        if (worked != null) {
                            timespent += worked;
                        }

                        userWorkLog.put(workedUser, timespent);

                        calculateTimesForProjectGroupedByField(
                                pivot, worklog, issue, project, workedUser);

                        // user total
                        timespent = worklog.getTimeSpent();
                        worked = pivot.workedUsers.get(workedUser);
                        if (worked != null) {
                            timespent += worked;
                        }
                        pivot.workedUsers.put(workedUser, timespent);
                    }
    }

    /**
     * Calculates the times spend per project, grouped by a field.
     * <p/>
     * Stores results in {@link TimePivot#projectGroupedByFieldTimeSpents}.
     *
     * @param pivot
     *            - pivot
     * @param worklog
     *            - reference to for-loop variable from @see #getTimeSpents
     * @param issue
     *            - reference to for-loop variable from @see #getTimeSpents
     * @param project
     *            - reference to for-loop variable from @see #getTimeSpents
     * @param user
     *            - reference to for-loop variable from @see #getTimeSpents
     */
    private void calculateTimesForProjectGroupedByField(TimePivot pivot, Worklog worklog, Issue issue, Project project, User user) {

        final String fieldValue = pivot.textUtil.getFieldValue(
                pivot.groupByField,
                issue,
                dateTimeFormatterFactory.formatter().forLoggedInUser(),
                worklog);

        if (fieldValue != null && !fieldValue.isEmpty()) {

            // dimension Project to field
            Map<String, Map<User, List<Worklog>>> projectToFieldWorkLog = pivot.projectGroupedByFieldTimeSpents.get(project);
            if (projectToFieldWorkLog == null) {
                projectToFieldWorkLog = new TreeMap<String, Map<User, List<Worklog>>>();
                pivot.projectGroupedByFieldTimeSpents.put(project, projectToFieldWorkLog);
            }

            // dimension Field to Time
            Map<User, List<Worklog>> fieldToTimeWorkLog = projectToFieldWorkLog.get(fieldValue);
            if (fieldToTimeWorkLog == null) {
                fieldToTimeWorkLog = new TreeMap<User, List<Worklog>>(UserComparator.USER_COMPARATOR);
                projectToFieldWorkLog.put(fieldValue, fieldToTimeWorkLog);
            }

            List<Worklog> projectGroupedWorklog = fieldToTimeWorkLog.get(user);
            if (projectGroupedWorklog == null) {
                projectGroupedWorklog = new ArrayList<Worklog>();
                fieldToTimeWorkLog.put(user, projectGroupedWorklog);
            }
            projectGroupedWorklog.add(worklog);
        }
    }

    @Override
    protected void postProcess(TimePivot pivot, TimeZone timezone) {
        prepareAdditionalFieldSumByProject(pivot);
    }

    @Override
    protected Set<Issue> getGroupedIssues(TimePivot pivot)
    {
        return pivot.workedIssues.keySet();
    }
}
