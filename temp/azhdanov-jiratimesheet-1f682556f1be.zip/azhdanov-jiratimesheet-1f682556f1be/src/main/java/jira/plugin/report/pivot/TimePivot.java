package jira.plugin.report.pivot;

import java.util.EnumSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.crowd.embedded.api.UserComparator;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.comparator.IssueKeyComparator;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.util.I18nHelper;

import com.google.common.collect.Ordering;
import jira.plugin.report.timesheet.TimeBase;
import jira.timesheet.plugin.configuration.IConfigurationService;

public class TimePivot extends TimeBase {

    @SuppressWarnings("rawtypes")
    public TimePivot(User remoteUser, TimeZone timezone,
            I18nHelper i18n,
            Map params, EnumSet<Options> options,
            IConfigurationService configurationService) {
        super(remoteUser, timezone, i18n, params, options, configurationService);

    }

    public Map<Issue, List<Worklog>> allWorkLogs = new Hashtable<Issue, List<Worklog>>();

    public Map<Project, Map<User, Long>> workedProjects = new TreeMap<Project, Map<User, Long>>(new ProjectComparator());

    public Map<Issue, Map<User, Long>> workedIssues = new TreeMap<Issue, Map<User, Long>>(
            IssueKeyComparator.COMPARATOR);

    public Map<User, Long> workedUsers = new TreeMap<User, Long>(UserComparator.USER_COMPARATOR);

    /**
     * <p>Variable that contains the project times grouped by a specific field.</p>
     * <p>This Variable represents/contains three nested maps [project to [fieldname to [user to worklogs]]]</p>
     */
    public Map<Project, Map<String, Map<User, List<Worklog>>>> projectGroupedByFieldTimeSpents =
            new TreeMap<Project, Map<String, Map<User, List<Worklog>>>>(new ProjectComparator());

    protected static class ProjectComparator extends Ordering<Project> {
        @Override
        public int compare(Project p1, Project p2) {
            return p1.getKey().compareTo(p2.getKey());
        }
    }
}
