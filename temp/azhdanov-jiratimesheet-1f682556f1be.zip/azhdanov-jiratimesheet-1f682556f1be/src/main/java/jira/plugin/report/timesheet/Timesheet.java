package jira.plugin.report.timesheet;

import java.util.ArrayList;
import java.util.Date;
import java.util.EnumSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;

import jira.timesheet.plugin.configuration.IConfigurationService;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.comparator.IssueKeyComparator;
import com.atlassian.jira.issue.comparator.UserComparator;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.util.ParameterUtils;
import com.fdu.jira.util.DirectoryUtil;
import com.fdu.jira.util.WeekPortletHeader;

public class Timesheet extends TimeBase {
    @SuppressWarnings("rawtypes")
    public Timesheet(User remoteUser, TimeZone timezone, I18nHelper i18n,
            Map params,
            EnumSet<TimeBase.Options> baseOptions, EnumSet<Options> options,
            IConfigurationService configurationService) {
        super(remoteUser, timezone, i18n, params, baseOptions, configurationService);

        resultParams.put("weekDays", weekDays);

        targetUser = ParameterUtils.getUserParam(params, "targetUser");
        if (targetUser == null) {
            targetUser = remoteUser;
            // leave targetUserName uninitialized, see TimesheetService 
        } else { // do not set implicit value for report
            targetUserName = DirectoryUtil.getUserName(targetUser);
            resultParams.put("targetUser", targetUser);
        }

        if(!"".equals(ParameterUtils.getStringParam(params, "priority"))) {
            priority = ParameterUtils.getStringParam(params, "priority");
            resultParams.put("priority", priority);
        }

        // must be true for timechart and pivot gadget
        if(options.contains(Options.SHOW_WEEKENDS) && negativeParam(params, "weekends")) {
            showWeekends = false;
        }
        resultParams.put("showWeekends", showWeekends);
    }

    public User targetUser;
    public String targetUserName;
    public String priority;
    public boolean showWeekends = true;

    public enum Options {
        SHOW_WEEKENDS
    }

    // A collection of interval start dates - correlating with the timeSpents
    // collection.    
    public List<WeekPortletHeader> weekDays = new ArrayList<WeekPortletHeader>();

    public Map<User, Map<Issue, List<Worklog>>> weekWorkLog =
        new TreeMap<User, Map<Issue, List<Worklog>>>(new UserComparator());

    public Map<Issue, Map<Date, Long>> weekWorkLogShort =
        new TreeMap<Issue, Map<Date, Long>>(new IssueKeyComparator());
    public Map<User, Map<Date, Long>> userWorkLogShort =
        new TreeMap<User, Map<Date, Long>>(new UserComparator());
    public Map<Long, Long> weekTotalTimeSpents = new Hashtable<Long, Long>();
    public Map<User, Map<Long, Long>> userWeekTotalTimeSpents =
        new Hashtable<User, Map<Long, Long>>();
    public Map<User, Map<Issue, Long>> userIssueTotalTimeSpents =
        new Hashtable<User, Map<Issue, Long>>();
    public Map<Project, Map<Date, Long>> projectTimeSpents =
        new Hashtable<Project, Map<Date, Long>>();

    /**
    * <p>Variable that contains the project times grouped by a specific field.</p>
    * <p>This Variable represents/contains three nested maps [project to [fieldname to [date to worklogs]]]</p>
    */
    public Map<Project, Map<String, Map<Date, List<Worklog>>>> projectGroupedByFieldTimeSpents =
        new Hashtable<Project, Map<String, Map<Date, List<Worklog>>>>();

    public String getTargetUserName() {
        if (targetUserName == null) {
            targetUserName = DirectoryUtil.getUserName(targetUser);
        }
        return targetUserName;
    }
    
}
