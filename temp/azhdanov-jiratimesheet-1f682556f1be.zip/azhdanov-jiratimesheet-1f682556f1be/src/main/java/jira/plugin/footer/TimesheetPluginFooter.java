package jira.plugin.footer;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import com.atlassian.jira.config.CoreFeatures;
import com.atlassian.jira.config.FeatureManager;
import com.atlassian.jira.plugin.navigation.FooterModuleDescriptor;
import com.atlassian.jira.plugin.navigation.PluggableFooter;
import com.atlassian.jira.web.ExecutingHttpRequest;

public class TimesheetPluginFooter implements PluggableFooter {

    private FooterModuleDescriptor descriptor;
    private FeatureManager featureManager;

    public TimesheetPluginFooter(FeatureManager featureManager) {
        this.featureManager = featureManager;
    }

    public String getFullFooterHtml(HttpServletRequest request) {
        return descriptor.getFooterHtml(request, buildParameters(false));
    }

    public String getSmallFooterHtml(HttpServletRequest request) {
        return descriptor.getFooterHtml(request, buildParameters(true));
    }

    public void init(FooterModuleDescriptor descriptor) {
        this.descriptor = descriptor;
    }

    private Map<String, Object> buildParameters(boolean smallFooter) {
        Map<String, Object> parameters = new HashMap<String, Object>();
        boolean showFooter = showFooter();
        parameters.put("showFooter", showFooter);
        parameters.put("useDiv", !featureManager.isEnabled(CoreFeatures.ON_DEMAND));
        if (showFooter) {
            parameters.put("jiraTimesheetPluginVersion", getClass().getPackage().getImplementationVersion());
        }
        return parameters;
    }

    private final Pattern configureReport = Pattern.compile(".*/secure/ConfigureReport(!.+)?.jspa"); 
    private final Pattern timesheetPlugin = Pattern.compile(".*(^|&)reportKey=jira-timesheet-plugin\\W.+?");
    private final Pattern timesheetAction = Pattern.compile(".*/secure/(TimesheetSubscriptions|TimesheetConfiguration|HolidaysConfiguration|LicenseConfiguration|SubscriptionsConfiguration)(!.+)?.jspa");

    private boolean showFooter() {
        HttpServletRequest request = ExecutingHttpRequest.get();
        return (configureReport.matcher(request.getRequestURI()).matches() && timesheetPlugin.matcher(request.getQueryString()).matches())
                || timesheetAction.matcher(request.getRequestURI()).matches();
    }
}
