package jira.timesheet.plugin.jql;

import com.atlassian.crowd.embedded.api.Group;
import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.JiraDataType;
import com.atlassian.jira.JiraDataTypes;
import com.atlassian.jira.datetime.DateTimeFormatter;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.datetime.DateTimeStyle;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.jql.operand.QueryLiteral;
import com.atlassian.jira.jql.query.QueryCreationContext;
import com.atlassian.jira.jql.util.JqlDateSupport;
import com.atlassian.jira.plugin.jql.function.AbstractJqlFunction;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.user.util.UserUtil;
import com.atlassian.jira.util.MessageSet;
import com.atlassian.jira.util.NotNull;
import com.atlassian.query.clause.TerminalClause;
import com.atlassian.query.operand.FunctionOperand;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.ofbiz.core.entity.GenericEntityException;

import jira.plugin.report.timesheet.Timesheet;
import jira.plugin.report.timesheet.TimesheetService;
import jira.plugin.report.timesheet.TimeBase;
import jira.timesheet.plugin.configuration.ConfigurationService;

/**
 * A handler for the <code>workedIssues(fromDate, toDate, byUserOrGroup)</code>
 * JQL function to return issues, that have worklogs matching function arguments.
 * <p>
 * This function returns all issues that have a worklog with
 * <code>startDate</code> between specified <code>fromDate</code> and
 * <code>toDate</code> including, and <code>author</code> that is equal to
 * specified user or is member of the specified group.
 * </p>
 * <p>
 * E.g. JQL query: key in workedIssues("2013/09/23", "2013/09/29",
 * "jira-developers")
 * </p>
 * <p>
 * Valid date formats include: <code>yyyy/MM/dd HH:mm</code>,
 * <code>yyyy-MM-dd HH:mm</code>, <code>yyyy/MM/dd</code>,
 * <code>yyyy-MM-dd</code>, or relative format e.g. <code>-5d</code>,
 * <code>4w 2d</code>. Note, only date part is used, specifically
 * <code>fromDate</code> is understood as 'yyyy/MM/dd 00:00' and
 * <code>toDate</code> is understood as 'yyyy/MM/dd 23:59:59.999'
 * </p>
 */
// https://developer.atlassian.com/display/JIRADEV/Adding+a+JQL+Function+to+JIRA
public class WorkedIssuesFunction extends AbstractJqlFunction {

    private DateTimeFormatterFactory dateTimeFormatterFactory;
    private JiraAuthenticationContext authenticationContext;
    private TimeZoneManager timeZoneManager;
    private ConfigurationService configurationService;
    private final JqlDateSupport jqlDateSupport;
    private final UserUtil userUtil;
    private TimesheetService timesheetService;

    public WorkedIssuesFunction(
            DateTimeFormatterFactory dateTimeFormatterFactory,
            JiraAuthenticationContext authenticationContext,
            TimeZoneManager timeZoneManager,
            ConfigurationService configurationService,
            JqlDateSupport jqlDateSupport,
            UserUtil userUtil,
            TimesheetService timesheetService) {
        this.dateTimeFormatterFactory = dateTimeFormatterFactory;
        this.authenticationContext = authenticationContext;
        this.timeZoneManager = timeZoneManager;
        this.configurationService = configurationService;
        this.jqlDateSupport = jqlDateSupport;
        this.userUtil = userUtil;
        this.timesheetService = timesheetService;
    }

    public List<QueryLiteral> getValues(
            @NotNull final QueryCreationContext queryCreationContext,
            @NotNull final FunctionOperand operand,
            @NotNull final TerminalClause terminalClause) {
        final List<QueryLiteral> literals = new LinkedList<QueryLiteral>();

        User remoteUser = authenticationContext.getLoggedInUser();
        TimeZone timeZone = timeZoneManager.getLoggedInUserTimeZone();
        Map<String, String> params = new HashMap<String, String>();
        List<String> args = operand.getArgs();
        DateTimeFormatter formatter = dateTimeFormatterFactory.formatter().forLoggedInUser().withZone(timeZone).withStyle((DateTimeStyle.DATE_PICKER));
        String startDate = formatter.format(jqlDateSupport.convertToDate(args.get(0)));
        params.put("startDate", startDate);
        String endDate = formatter.format(jqlDateSupport.convertToDate(args.get(1)));
        params.put("endDate", endDate);
        String byUserOrGroup = args.get(2);
        User user = userUtil.getUser(byUserOrGroup);
        if (user != null) {
            params.put("targetUser", byUserOrGroup);
        } else { // guaranteed by validate
            params.put("targetGroup", byUserOrGroup);
        }
        final Timesheet timesheet = new Timesheet(remoteUser, timeZone, getI18n(),
                params, EnumSet.of(TimeBase.Options.DATES),
                EnumSet.noneOf(Timesheet.Options.class),
                configurationService);
        timesheet.excelView = true;
        try {
            timesheetService.getTimeSpents(timesheet);

            for (Issue issue : timesheet.allWorkLogs.keySet()) {
                literals.add(new QueryLiteral(operand, issue.getKey()));
            }
        } catch (SearchException e) {
            e.printStackTrace();
        } catch (GenericEntityException e) {
            e.printStackTrace();
        }

        return literals;
    }

    /**
     * Validate there are 2 date arguments and 3rd is user or group argument.
     */
    public MessageSet validate(User searcher, @NotNull FunctionOperand operand,
            @NotNull TerminalClause terminalClause) {
        MessageSet messageSet = validateNumberOfArgs(operand, 3);
        if (!messageSet.hasAnyErrors()) {
            List<String> args = operand.getArgs();
            String from = args.get(0);
            // See https://confluence.atlassian.com/display/JIRA/Advanced+Searching#AdvancedSearching-Created
            if (!jqlDateSupport.validate(from)) {
                messageSet.addErrorMessage(getI18n().getText("jira.timesheet.plugin.jql.date.invalid", from, "fromDate"));
            }
            String to = args.get(1);
            if (!jqlDateSupport.validate(to)) {
                messageSet.addErrorMessage(getI18n().getText("jira.timesheet.plugin.jql.date.invalid", to, "toDate"));
            }
            String byUserOrGroup = args.get(2);
            User user = userUtil.getUser(byUserOrGroup);
            Group group = userUtil.getGroupObject(byUserOrGroup);
            if (user == null && group == null) {
                messageSet.addErrorMessage(getI18n().getText("jira.timesheet.plugin.jql.userOrGroup.invalid", byUserOrGroup));
            }// else if (group != null) {
            //    permissionManager.hasPermission(Permissions.USER_PICKER, loggedInUser);
            // TODO? P3: searcher has BROWSE_USERS permission if 3rd argument is group
            // TODO: P3: searcher is in TimesheetAuditorsGroup if it is defined and 3rd argument is group 
            // TODO: P3: searcher is in TimesheetAuditorsRole if it is defined and 3rd argument is group            
        }
        return messageSet;
    }

    /**
     * This function requires 3 arguments.
     */
    public int getMinimumNumberOfExpectedArguments() {
        return 3;
    }

    /**
     * This function deals with issues.
     */
    public JiraDataType getDataType() {
        return JiraDataTypes.ISSUE;
    }

}