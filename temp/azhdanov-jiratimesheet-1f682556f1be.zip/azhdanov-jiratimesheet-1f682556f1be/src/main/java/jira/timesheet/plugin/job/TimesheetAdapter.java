package jira.timesheet.plugin.job;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.datetime.DateTimeFormatter;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.datetime.DateTimeStyle;
import com.atlassian.jira.plugin.report.ReportModuleDescriptor;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.util.ParameterUtils;
import com.atlassian.plugin.PluginAccessor;
import com.fdu.jira.plugin.report.timesheet.TimeSheet;
import com.fdu.jira.util.CalendarUtil;
import com.fdu.jira.util.TextUtil;

public class TimesheetAdapter {
    public static final String REPORT_KEY = "jira-timesheet-plugin:report";
    public static final String EMAIL_JOB_CONFIGURATION_ID_PARAM = "emailJobConfigurationId";
    private final TimeZoneManager timeZoneManager;
    private final DateTimeFormatterFactory dateTimeFormatterFactory;
    private PluginAccessor pluginAccessor;
    private ReportModuleDescriptor descriptor;

    public TimesheetAdapter(TimeZoneManager timeZoneManager,
            DateTimeFormatterFactory dateTimeFormatterFactory) {
        this.timeZoneManager = timeZoneManager;
        this.dateTimeFormatterFactory = dateTimeFormatterFactory;
    }

    public String getGeneratedReport(TimesheetJobConfiguration config) throws Exception {
        return getGeneratedReport(config, false, false);
    }

    public String getGeneratedReport(TimesheetJobConfiguration config, boolean individual, boolean hideUnsubscribeLink) throws Exception {
        Map<String, List<String>> params = TextUtil.getQueryParams("?" + config.getParams());
        int reportingDay = ParameterUtils.getIntParam(params, "reportingDay", 0); // everyday?
        int numOfWeeks = ParameterUtils.getIntParam(params, "numOfWeeks", 1);
        boolean monthView = ParameterUtils.getBooleanParam(params, "monthView");
        TimeZone timezone = timeZoneManager.getLoggedInUserTimeZone();
        int offset = 0;
        if (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == reportingDay && !monthView) {
            offset = -1; // email week before, opposite to gadget
        }
        Calendar[] dates = CalendarUtil.getDatesRange(reportingDay, numOfWeeks, offset, monthView, timezone);
        DateTimeFormatter formatter = dateTimeFormatterFactory.formatter().forLoggedInUser().withZone(timezone).withStyle(DateTimeStyle.DATE_PICKER);
        final Calendar startDate = dates[0], endDate = dates[1];
        addDateParam(params, "startDate", startDate, formatter);
        endDate.add(Calendar.DAY_OF_MONTH, -1);
        addDateParam(params, "endDate", endDate, formatter);
        addParam(params, EMAIL_JOB_CONFIGURATION_ID_PARAM, Integer.toString(config.getID()));
        params.remove(TimesheetSubscriptions.PARAM_CC_USER_GROUP);
        params.remove(TimesheetSubscriptions.PARAM_REMIND_GROUP);
        if (individual) {
            params.remove("targetGroup");
            params.remove("projectid");
            params.remove("projectRoleId");
            addParam(params, TimeSheet.PARAM_SHOW_INCOMPLETE_MSG, "true");
        }
        if (hideUnsubscribeLink) {
            addParam(params, TimeSheet.PARAM_HIDE_UNSUBSCRIBE_LINK, "true");
        }

        return getReport().getModule().generateReportHtml(/* action */ null, params);
    }

    private void addDateParam(Map<String, List<String>> params, String param, Calendar date, DateTimeFormatter formatter) {
        addParam(params, param, formatter.format(date.getTime()));
    }

    private void addParam(Map<String, List<String>> params, String name, String... values) {
        List<String> param = Arrays.asList(values);
        params.put(name, param);
    }

    private ReportModuleDescriptor getReport() {
        if (descriptor == null) {
            descriptor = (ReportModuleDescriptor) getPluginAccessor()
                    .getEnabledPluginModule(REPORT_KEY);
        }
        return descriptor;
    }


    private PluginAccessor getPluginAccessor() {
        if (pluginAccessor == null) {
            pluginAccessor = ComponentAccessor.getPluginAccessor();
        }
        return pluginAccessor;
    }

}
