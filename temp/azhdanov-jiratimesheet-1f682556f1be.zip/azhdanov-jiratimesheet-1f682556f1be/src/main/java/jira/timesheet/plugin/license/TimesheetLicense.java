package jira.timesheet.plugin.license;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import com.atlassian.extras.api.LicenseType;
import com.atlassian.upm.api.util.Option;
import com.google.common.base.Throwables;

/**
 * Mimics com.atlassian.extras.api.PluginLicense.
 * 
 */
public class TimesheetLicense {
    // ACADEMIC, COMMERCIAL, COMMUNITY, DEMONSTRATION, DEVELOPER, NON_PROFIT,
    // OPEN_SOURCE, PERSONAL, STARTER, HOSTED, TESTING
    private static final String LICENSE_TYPE_PROPERTY = "licenseType";
    private static final String CREATEION_DATE_PROPERTY = "creationDate";
    private static final String EXPIRY_DATE_PROPERTY = "expiryDate";
    private static final String SUPPORT_ENTITLEMENT_NUMBER_PROPERTY = "supportEntitlementNumber";
    private static final DateFormat ISO_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private static final String ORGANIZATION_PROPERTY = "organization";

    private LicenseType licenseType;
    private Date creationDate;
    private Option<Date> expiryDate;
    private String organization;
    private String rawLicense;
    private Option<String> supportEntitlementNumber;

    public TimesheetLicense(Properties licenseProperties, String rawLicense) {
        licenseType = LicenseType.valueOf(licenseProperties.getProperty(LICENSE_TYPE_PROPERTY));
        String creationDateString = licenseProperties.getProperty(CREATEION_DATE_PROPERTY);
        if (creationDateString == null) {
            throw new RuntimeException("creationDate not set");
        }
        try {
            creationDate = ISO_DATE_FORMAT.parse(creationDateString);
        } catch (ParseException e) {
            Throwables.propagate(e);
        }
        String expiryDateString = licenseProperties.getProperty(EXPIRY_DATE_PROPERTY);
        if (expiryDateString != null) {
            try {
                expiryDate = Option.some(ISO_DATE_FORMAT.parse(expiryDateString));
            } catch (ParseException e) {
                Throwables.propagate(e);
            }
        } else {
            expiryDate = Option.none();
        }
        organization = licenseProperties.getProperty(ORGANIZATION_PROPERTY, "");
        String supportEntitlementNumber = licenseProperties.getProperty(SUPPORT_ENTITLEMENT_NUMBER_PROPERTY);
        if (supportEntitlementNumber == null) {
            this.supportEntitlementNumber = Option.none();
        } else {
            this.supportEntitlementNumber = Option.some(supportEntitlementNumber);
        }
        this.rawLicense = rawLicense;
    }

    public boolean isValid() {
        return !expiryDate.isDefined() || expiryDate.get().after(Calendar.getInstance().getTime());
    }

    public LicenseType getLicenseType() {
        return licenseType;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public Option<Date> getExpiryDate() {
        return expiryDate;
    }

    public String getOrganization() {
        return organization;
    }

    public Option<String> getSupportEntitlementNumber() {
        return supportEntitlementNumber;
    }

    public String getRawLicense() {
        return rawLicense;
    }

    public Option<String> getError() {
        if (expiryDate.isDefined() && !expiryDate.get().after(Calendar.getInstance().getTime())) {
            return Option.some("EXPIRED");
        } else {
            return Option.none();
        }
    }
}
