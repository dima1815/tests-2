package jira.timesheet.plugin.job;

public interface ITimesheetJobScheduler {
    TimesheetJobConfiguration getJobConfigurationFromTriggerName(final String triggerName);
}
