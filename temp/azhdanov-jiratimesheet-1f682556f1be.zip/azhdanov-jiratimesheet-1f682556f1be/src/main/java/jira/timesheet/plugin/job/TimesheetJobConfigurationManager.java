package jira.timesheet.plugin.job;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.crowd.embedded.api.User;

public interface TimesheetJobConfigurationManager {
    // http://www.j-tricks.com/1/post/2012/07/active-objects-injection.html
    ActiveObjects getActiveObjects();

    TimesheetJobConfiguration addJobConfiguration(User user, String reportKey, String queryString, String cronExpression);

    TimesheetJobConfiguration getJobConfiguration(Integer id);

    TimesheetJobConfiguration getJobConfiguration(User user, String key);

    TimesheetJobConfiguration[] getJobConfigurations(User user, String reportKey);
    
    TimesheetJobConfiguration[] getJobConfigurations(User user, String reportKey, String queryString);

    TimesheetJobConfiguration[] getAllJobConfigurations();

    TimesheetJobConfiguration updateJobConfiguration(User user, String key, String cronExpression, String queryString);

    void removeJobConfiguration(User user, String reportKey, String queryString);

    void removeJobConfiguration(User user, String key);

}

    
