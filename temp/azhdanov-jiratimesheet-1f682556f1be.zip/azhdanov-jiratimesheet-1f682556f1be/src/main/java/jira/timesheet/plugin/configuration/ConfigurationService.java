package jira.timesheet.plugin.configuration;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;

import javax.annotation.Nullable;

import com.fdu.jira.util.WeekendUtil;

import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.sal.api.pluginsettings.PluginSettings;
import com.atlassian.sal.api.pluginsettings.PluginSettingsFactory;

public class ConfigurationService implements IConfigurationService {
    private static final Logger log = Logger.getLogger(ConfigurationService.class);
    private static final String PLUGIN_KEY = "jira.timesheet.plugin";
    private static final String TIMESHEET_AUDITORS_GROUP = "timesheetAuditorsGroup";
    private static final String TIMESHEET_AUDITORS_ROLE = "timesheetAuditorsRole";
    private static final String WEEKEND_TYPE = "weekendType";
    private static final String DECIMAL_SEPARATOR = "decimalSeparator";
    private static final String DAY_FORMAT_1 = "dayFormat1";
    private static final String DAY_FORMAT_2 = "dayFormat2";
    private static final String COMPOSE_ISSUE_LINK = "composeIssueLink";
    private static final String PARENT_ISSUE_FIELD = "parentIssueField";
    private static final String IN_PROGRESS_CLAUSE = "inProgressClause";
    private static final String IN_PROGRESS_QUERY = "inProgressQuery";
    private static final String MAX_DAYS = "maxDays";
    private static final String MAX_FRACTION_DIGITS = "maxFractionDigits";
    private static final String PRETTY_DURATION = "prettyDuration";
    // keep low case for backed jira-config property
    private static final String GROUP_BY_FIELDS = "groupbyfields";
    private static final String EXCLUDE_PROJECTS = "excludeProjects";
    private static final String RESTRICTED_GROUPS = "restrictedGroups";
    private static final String THRESHOLD_HOURS = "highlightHours";
    private static final String LICENSE = "license";

    private static final Integer MAX_DAYS_DEFAULT = 62; // 2 months
    private final PluginSettings pluginSettings;
    private final ApplicationProperties applicationProperties;

    public ConfigurationService(PluginSettingsFactory pluginSettingFactory,
            ApplicationProperties applicationProperties) {
        this.applicationProperties = applicationProperties;
        pluginSettings = pluginSettingFactory.createGlobalSettings();
    }

    @Override
    @Nullable
    public List<String> getTimesheetAuditorsGroups() {
        final String value = getBacked(TIMESHEET_AUDITORS_GROUP) ;
        return value == null ? null : Arrays.asList(value.split(","));
    }

    @Override
    public void setTimesheetAuditorsGroups(@Nullable List<String> timesheetAuditorsGroups) {
        String value = timesheetAuditorsGroups == null ? null : StringUtils.collectionToCommaDelimitedString(timesheetAuditorsGroups);
        set(TIMESHEET_AUDITORS_GROUP, value);
    }

    @Override
    @Nullable
    public List<String> getTimesheetAuditorsRoles() {
        final String value = getBacked(TIMESHEET_AUDITORS_ROLE) ;
        return value == null ? null : Arrays.asList(value.split(","));
    }

    @Override
    public void setTimesheetAuditorsRoles(@Nullable List<String> timesheetAuditorsRoles) {
        String value = timesheetAuditorsRoles == null ? null : StringUtils.collectionToCommaDelimitedString(timesheetAuditorsRoles);
        set(TIMESHEET_AUDITORS_ROLE, value);
    }

    @Override
    // backed
    @Nullable
    public String getComposeIssueLink() {
        return getBacked(COMPOSE_ISSUE_LINK);
    }

    @Override
    public void setComposeIssueLink(String composeIssueLink) {
        setBacked(COMPOSE_ISSUE_LINK, composeIssueLink);
    }

    @Override
    @Nullable
    public String getParentIssueField() {
        return get(PARENT_ISSUE_FIELD);
    }

    @Override
    public void setParentIssueField(String parentIssueField) {
        set(PARENT_ISSUE_FIELD, parentIssueField);
    }

    @Override
    @Nullable
    public String getInProgressQuery() {
        String inProgressQuery = get(IN_PROGRESS_QUERY);
        if (inProgressQuery == null) {
            String inProgressClause = getInProgressClause();
            if (inProgressClause != null && !inProgressClause.isEmpty()) {
                inProgressQuery = "assignee = currentUser() and " + inProgressClause;
            }
        } else if (inProgressQuery.isEmpty()) {
            return null;
        }
        return inProgressQuery;
    }

    @Override
    public void setInProgressQuery(@Nullable String inProgressQuery) {
        set(IN_PROGRESS_QUERY, inProgressQuery);
        setInProgressClause(null); // clear
    }

    // backed
    @Nullable
    String getInProgressClause() {
        return getBacked(IN_PROGRESS_CLAUSE);
    }

    void setInProgressClause(@Nullable String inProgressClause) {
        setBacked(IN_PROGRESS_CLAUSE, inProgressClause);
    }

    @Override
    // backed, default 2 months
    public Integer getMaxDays() {
        String maxDays = getBacked(MAX_DAYS);
        if (maxDays == null) {
            return MAX_DAYS_DEFAULT;
        } else {
            Integer maxDaysInteger = Integer.valueOf(maxDays);
            return maxDaysInteger;
        }
    }

    @Override
    public void setMaxDays(@Nullable Integer maxDays) {
        setBacked(MAX_DAYS, maxDays != null ? maxDays.toString() : null);       
    }

    @Override
    public Integer getMaxFractionDigits() {
        final String savedValue = getBacked(MAX_FRACTION_DIGITS);
        return savedValue != null
                ? Integer.valueOf(savedValue)
                : null;
    }

    @Override
    public void setMaxFractionDigits(Integer maxFractionDigits) {
        setBacked(MAX_FRACTION_DIGITS, maxFractionDigits != null ? maxFractionDigits.toString() : null);
    }

    @Override
    // backed, default false
    public Boolean isPrettyDuration() {
        return Boolean.valueOf(getBacked(PRETTY_DURATION));
    }

    @Override
    public void setPrettyDuration(Boolean prettyDuration) {
        setBacked(PRETTY_DURATION, prettyDuration != null ? prettyDuration.toString() : null);
    }

    @Override
    // default 0/no
    public Integer getHighlightHours() {
        String highlightHours = get(THRESHOLD_HOURS);
        if (highlightHours == null) {
            highlightHours = "0";
        }
        try {
            return Integer.valueOf(highlightHours);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @Override
    public void setHighlightHours(Integer highlightHours) {
        set(THRESHOLD_HOURS, highlightHours != null ? highlightHours.toString() : null);
    }

    @Override
    // backed
    @Nullable
    public List<String> getGroupByFields() {
        String value = getBacked(GROUP_BY_FIELDS) ;
        return value == null ? null : Arrays.asList(value.split(","));
    }

    @Override
    public void setGroupByFields(@Nullable List<String> groupByFields) {
        String value = groupByFields == null ? null : StringUtils.collectionToCommaDelimitedString(groupByFields);
        setBacked(GROUP_BY_FIELDS, value);
    }

    @Override
    @Nullable
    public List<String> getExcludeProjects() {
        String value = get(EXCLUDE_PROJECTS) ;
        return value == null ? null : Arrays.asList(value.split(","));
    }

    @Override
    public void setExcludeProjects(@Nullable List<String> excludeProjects) {
        String value = excludeProjects == null ? null : StringUtils.collectionToCommaDelimitedString(excludeProjects);
        set(EXCLUDE_PROJECTS, value);
    }

    @Override
    public List<String> getRestrictedGroups() {
        String value = get(RESTRICTED_GROUPS) ;
        return value == null ? null : Arrays.asList(StringUtils.delimitedListToStringArray(value, ","));
    }

    @Override
    public void setRestrictedGroups(List<String> groups) {
        String value = groups == null ? null : StringUtils.collectionToCommaDelimitedString(groups);
        set(RESTRICTED_GROUPS, value);
    }

    @Override
    public String getWeekendType() {
        final String weekend = getBacked(WEEKEND_TYPE);
        return org.apache.commons.lang.StringUtils.isNotBlank(weekend)
                ? weekend
                : WeekendUtil.getDefaultWeekend();
    }

    @Override
    public void setWeekendType(String weekendType) {
        setBacked(WEEKEND_TYPE, weekendType);
    }


    @Override
    public String getDecimalSeparator() {
        return getBacked(DECIMAL_SEPARATOR);
    }

    @Override
    public void setDecimalSeparator(String decimalSeparator) {
        setBacked(DECIMAL_SEPARATOR, decimalSeparator);
    }

    @Override
    public String getDayFormat1() {
        return getBacked(DAY_FORMAT_1);
    }

    @Override
    public void setDayFormat1(String format) {
        setBacked(DAY_FORMAT_1, format);
    }

    @Override
    public String getDayFormat2() {
        return getBacked(DAY_FORMAT_2);
    }

    @Override
    public void setDayFormat2(String format) {
        setBacked(DAY_FORMAT_2, format);
    }

    @Override
    public String getLicense() {
        return get(LICENSE);
    }

    @Override
    public void setLicense(String license) {
        set(LICENSE, license);
    }

    private String getBacked(String name) {
        String value = get(name);
        if (value == null) {
            String key = getKeyForProperty(name);
            value = applicationProperties.getDefaultBackedString(key);
        }
        if (value != null && value.isEmpty()) {
            return null;
        }
        return value;
    }

    private void setBacked(String name, String value) {
        if (value != null) {
            set(name, value);
        } else if (getBacked(name) != null) {
            // empty string to override jira-config.properties
            set(name, EMPTY_STRING);
        }
    }

    private String get(String name) {
        String key = getKeyForProperty(name);
        
        try {
            return (String) pluginSettings.get(key);
        } catch (IllegalArgumentException exception) {
            log.error(MessageFormat.format("Error retrieving the {0} setting from PluginSettings.", name)
                    , exception);
            return null;
        }
    }

    private void set(String name, String value) {
        String key = getKeyForProperty(name);
        pluginSettings.put(key, value); 
    }

    private String getKeyForProperty(String propertyName) {
        return PLUGIN_KEY + "." + propertyName;
    }

}
