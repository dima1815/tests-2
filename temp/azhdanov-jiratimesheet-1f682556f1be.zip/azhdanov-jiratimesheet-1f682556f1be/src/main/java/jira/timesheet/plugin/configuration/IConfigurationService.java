package jira.timesheet.plugin.configuration;

import java.util.List;

public interface IConfigurationService {

    String EMPTY_STRING = "";

    List<String> getTimesheetAuditorsGroups();

    void setTimesheetAuditorsGroups(List<String> timesheetAuditorsGroups);

    List<String> getTimesheetAuditorsRoles();

    void setTimesheetAuditorsRoles(List<String> timesheetAuditorsRoles);

    String getComposeIssueLink();

    void setComposeIssueLink(String composeIssueLink);

    String getParentIssueField();

    void setParentIssueField(String parentIssueField);

    String getInProgressQuery();

    void setInProgressQuery(String inProgressQuery);

    Integer getMaxDays();

    void setMaxDays(Integer maxDays);

    Integer getMaxFractionDigits();

    void setMaxFractionDigits(Integer maxFractionDigits);

    Boolean isPrettyDuration();

    void setPrettyDuration(Boolean prettyDuration);

    Integer getHighlightHours();

    void setHighlightHours(Integer highlightHours);

    List<String> getGroupByFields();

    void setGroupByFields(List<String> groupByFields);

    List<String> getExcludeProjects();

    void setExcludeProjects(List<String> excludeProjects);

    String getWeekendType();

    void setWeekendType(String weekendType);

    String getDecimalSeparator();

    void setDecimalSeparator(String decimalSeparator);

    String getDayFormat1();

    void setDayFormat1(String format);

    String getDayFormat2();

    void setDayFormat2(String format);

    List<String> getRestrictedGroups();

    void setRestrictedGroups(List<String> groups);

    String getLicense();

    void setLicense(String license);
}
