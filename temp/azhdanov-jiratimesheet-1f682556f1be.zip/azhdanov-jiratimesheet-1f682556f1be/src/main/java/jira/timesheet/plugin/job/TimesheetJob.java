package jira.timesheet.plugin.job;


import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.user.util.UserUtil;
import com.atlassian.mail.Email;
import com.atlassian.mail.queue.MailQueue;
import com.atlassian.mail.queue.MailQueueItem;
import com.atlassian.mail.queue.SingleMailQueueItem;
import com.fdu.jira.util.ForbiddenUtil;
import com.fdu.jira.util.TextUtil;
import com.google.common.collect.ImmutableList;
import jira.plugin.report.timesheet.LicenseException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.atlassian.jira.util.ParameterUtils.getLongParam;
import static com.atlassian.jira.util.ParameterUtils.getStringParam;

public class TimesheetJob implements Job {
    private static final Logger log = Logger.getLogger(TimesheetJob.class);

    private TimesheetAdapter timesheetAction;
    private ITimesheetJobScheduler tsJobScheduler;
    private UserUtil userUtil;
    private JiraAuthenticationContext authenticationContext;
    private MailQueue mailQueue;

    public void execute(JobExecutionContext context) throws JobExecutionException {
        final TimesheetJobConfiguration config = getTimesheetJobScheduler().getJobConfigurationFromTriggerName(context.getTrigger().getName());
        if (config != null) {
            final String configUsername = config.getUsername();
            final User configUser = getUserUtil().getUser(configUsername);
            if (configUser == null) {
                log.warn("User not found: " + configUsername);
                return;
            }
            queueEmail(configUser, config, false, false);

            final Map<String, List<String>> params = TextUtil.getQueryParams("?" + config.getParams());

            final String ccGroup = getStringParam(params, TimesheetSubscriptions.PARAM_CC_USER_GROUP);
            if (StringUtils.isNotBlank(ccGroup)) {
                final Set<User> ccUsers = getUserUtil().getAllUsersInGroupNames(ImmutableList.of(ccGroup));
                if (CollectionUtils.isNotEmpty(ccUsers)) {
                    for (User user : ccUsers) {
                        final String targetUserName = getStringParam(params, TimesheetSubscriptions.PARAM_TARGET_USER);
                        if (ForbiddenUtil.isOthersTimesheet(
                                    user,
                                    targetUserName,
                                    params.get(TimesheetSubscriptions.PARAM_TARGET_GROUP),
                                    getLongParam(params, TimesheetSubscriptions.PARAM_PROJECT_ID),
                                    getLongParam(params, TimesheetSubscriptions.PARAM_PROJECT_ROLE_ID))
                                && ForbiddenUtil.isForbiddenByAuditorsGroup(user.getName())) {
                            log.warn(String.format("Not sending timesheet to user '%s' -  forbidden by auditors group", user.getName()));
                        } else {
                            if (!StringUtils.equals(configUsername, user.getName())) { // do not send once again to config.getUsername() user
                                queueEmail(user, config, false, true);
                            }
                        }
                    }
                }
            }

            final String remindGroup = getStringParam(params, TimesheetSubscriptions.PARAM_REMIND_GROUP);
            if (StringUtils.isNotBlank(remindGroup)) {
                final Set<User> remindUsers = getUserUtil().getAllUsersInGroupNames(ImmutableList.of(remindGroup));
                if (CollectionUtils.isNotEmpty(remindUsers)) {
                    for (User user : remindUsers) {
                        queueEmail(user, config, true, true);
                    }
                }
            }
        }
    }

    private void queueEmail(
            final User user,
            final TimesheetJobConfiguration config,
            final boolean individual,
            final boolean hideUnsubscribeLink) {
        log.info(String.format("Executing timesheet job: %s, for %s with params: %s", config.getKey(), user.getDisplayName(), config.getParams()));
        getJiraAuthenticationContext().setLoggedInUser(user);
        String generatedReport = null;
        try {
            generatedReport = getTimesheetAdapter().getGeneratedReport(config, individual, hideUnsubscribeLink);
        } catch (LicenseException e) {
            log.error(String.format("Can't render timesheet email: %s", e.getMessage()));
        } catch (Exception e) {
            log.error(String.format("Can't render timesheet email: %s", e.getMessage()), e);
        }
        if (generatedReport != null) {
            final String emailAddress = user.getEmailAddress();
            log.info(String.format("Sending timesheet email to %s", emailAddress));
            final Email email = new Email(emailAddress);
            email.setSubject("Timesheet Report"); // TODO: title similar to gadget
            email.setBody(generatedReport);
            email.setMimeType("text/html; charset=UTF-8");
            final MailQueueItem item = new SingleMailQueueItem(email);
            getMailQueue().addItem(item);
        }
        getJiraAuthenticationContext().setLoggedInUser((User) null);
    }

    private UserUtil getUserUtil() {
        if (userUtil == null) {
            userUtil = ComponentAccessor.getUserUtil();
        }
        return userUtil;
    }

    private MailQueue getMailQueue() {
        if (mailQueue == null) {
            mailQueue = ComponentAccessor.getMailQueue();
        }
        return mailQueue;
    }

    private JiraAuthenticationContext getJiraAuthenticationContext() {
        if (authenticationContext == null) {
            authenticationContext = ComponentAccessor.getJiraAuthenticationContext();
        }
        return authenticationContext;
    }

    private TimesheetAdapter getTimesheetAdapter() {
        if (timesheetAction == null) {
            final TimeZoneManager timeZoneManager = ComponentAccessor.getComponent(TimeZoneManager.class);
            final DateTimeFormatterFactory dateTimeFormatterFactory = ComponentManager.getComponent(DateTimeFormatterFactory.class);
            timesheetAction = new TimesheetAdapter(timeZoneManager, dateTimeFormatterFactory);
        }
        return timesheetAction;
    }

    private ITimesheetJobScheduler getTimesheetJobScheduler() {
        if (tsJobScheduler == null) {
            tsJobScheduler = ComponentManager.getOSGiComponentInstanceOfType(ITimesheetJobScheduler.class);
        }
        return tsJobScheduler;
    }
}
