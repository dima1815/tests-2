package jira.timesheet.plugin.job;

public final class FakeRequest {
    private final String contextPath;

    public FakeRequest(String contextPath) {
        this.contextPath = contextPath;
        
    }

    public String getContextPath() {
        return contextPath;
    }

}
