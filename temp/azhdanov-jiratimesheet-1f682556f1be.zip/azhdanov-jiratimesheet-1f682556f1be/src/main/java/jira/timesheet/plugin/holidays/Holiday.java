package jira.timesheet.plugin.holidays;

import net.java.ao.Entity;
import net.java.ao.schema.Table;

@Table("Holiday")
public interface Holiday extends Entity {

    String getName();
    void setName(String name);

    Integer getYear();
    void setYear(Integer year);

    Integer getMonth();
    void setMonth(Integer month);

    Integer getDay();
    void setDay(Integer day);

    String getLocale();
    void setLocale(String locale);
}
