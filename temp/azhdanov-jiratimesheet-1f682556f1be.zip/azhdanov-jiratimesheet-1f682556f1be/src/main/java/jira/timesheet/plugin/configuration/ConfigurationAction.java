package jira.timesheet.plugin.configuration;

import com.atlassian.crowd.embedded.api.Group;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.link.IssueLinkType;
import com.atlassian.jira.issue.link.IssueLinkTypeManager;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.util.MessageSet;
import com.fdu.jira.plugin.report.timesheet.FieldsValuesGenerator;
import com.fdu.jira.plugin.report.timesheet.GroupByFieldValuesGenerator;
import com.fdu.jira.plugin.report.timesheet.ProjectValuesGenerator;
import com.fdu.jira.util.ILicenseUtil;
import com.fdu.jira.util.TextUtil;
import com.fdu.jira.util.WeekendUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.TreeMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

public class ConfigurationAction extends ConfigurationActionBase {
    private static final long serialVersionUID = 8927665679520718828L;

    public static final String BLANK = "blank";
    private final IConfigurationService configurationService;
    private final GroupManager groupManager;
    private final ProjectRoleManager projectRoleManager;
    private final IssueLinkTypeManager issueLinkTypeManager;
    private final SearchService searchService;
    private final GroupByFieldValuesGenerator fieldsValuesGenerator;
    private final ProjectValuesGenerator projectValuesGenerator;

    private String statusMessage = "";
    private String[] timesheetAuditorsGroups = new String[]{};
    private String[] timesheetAuditorsRoles = new String[]{};
    private String composeIssueLink;
    private String parentIssueField;
    private Integer maxDays;
    private String inProgressQuery;
    private Boolean prettyDuration;
    private Integer highlightHours;
    private String[] groupByFields = new String[] {};
    private String[] excludeProjects = new String[] {};
    private String[] restrictedGroups = new String[] {};
    private String weekendType;
    private String decimalSeparator;
    private String dayFormat1;
    private String dayFormat2;
    private Integer maxFractionDigits;

    private CustomFieldManager customFieldManager;

    // issue#395, issue#391, issue#370: workaround for automatic wiring broken with some plugins installed, e.g. com.plugenta.jiraauditor
    public ConfigurationAction() {
        this(ComponentManager.getOSGiComponentInstanceOfType(IConfigurationService.class),
                ComponentManager.getOSGiComponentInstanceOfType(ILicenseUtil.class),
                ComponentManager.getComponent(GroupManager.class),
                ComponentManager.getComponent(ProjectRoleManager.class),
                ComponentManager.getComponent(IssueLinkTypeManager.class),
                ComponentManager.getComponent(SearchService.class),
                ComponentManager.getComponent(CustomFieldManager.class));
        
    }
    public ConfigurationAction(IConfigurationService configurationService,
            ILicenseUtil licenseUtil,
            GroupManager groupManager,
            ProjectRoleManager projectRoleManager,
            IssueLinkTypeManager issueLinkTypeManager,
            SearchService searchService,
            CustomFieldManager customFieldManager) {
        super(licenseUtil);
        this.configurationService = configurationService;
        this.groupManager = groupManager;
        this.projectRoleManager = projectRoleManager;
        this.issueLinkTypeManager = issueLinkTypeManager;
        this.searchService = searchService;
        this.customFieldManager = customFieldManager;
        fieldsValuesGenerator = new GroupByFieldValuesGenerator();
        projectValuesGenerator = new ProjectValuesGenerator();
    }

    @Override
    public String doDefault() {
        final List<String> auditorsGroupsList = configurationService.getTimesheetAuditorsGroups();
        if (auditorsGroupsList != null) {
            timesheetAuditorsGroups = auditorsGroupsList.toArray(timesheetAuditorsGroups);
        }
        final List<String> auditorsRolesList = configurationService.getTimesheetAuditorsRoles();
        if (auditorsRolesList != null) {
            timesheetAuditorsRoles = auditorsRolesList.toArray(timesheetAuditorsRoles);
        }
        composeIssueLink = configurationService.getComposeIssueLink();
        parentIssueField = configurationService.getParentIssueField();
        inProgressQuery = configurationService.getInProgressQuery();
        maxDays = configurationService.getMaxDays();
        prettyDuration = configurationService.isPrettyDuration();
        highlightHours = configurationService.getHighlightHours();
        List<String> groupByFieldsList = configurationService.getGroupByFields();
        if (groupByFieldsList != null) {
            groupByFields = groupByFieldsList.toArray(groupByFields);
        }
        List<String> excludeProjectsList = configurationService.getExcludeProjects();
        if (excludeProjectsList != null) {
            excludeProjects = excludeProjectsList.toArray(excludeProjects);
        }
        final List<String> restrictedGroupsList = configurationService.getRestrictedGroups();
        if (restrictedGroupsList != null) {
            restrictedGroups = restrictedGroupsList.toArray(restrictedGroups);
        }
        weekendType = configurationService.getWeekendType();
        decimalSeparator = configurationService.getDecimalSeparator();
        dayFormat1 = configurationService.getDayFormat1();
        dayFormat2 = configurationService.getDayFormat2();
        maxFractionDigits = configurationService.getMaxFractionDigits();
        // let see configuration with no license
        return INPUT; 
    }

    @Override
    public String doExecute() throws Exception {
        String action = validateAdminAction(SUCCESS);
        if (SUCCESS.equals(action)) {
            saveChanges();
            statusMessage = "timesheet.configuration.success";
            maxDays = configurationService.getMaxDays();
        }
        return action;
    }

    private void saveChanges() {
        configurationService.setTimesheetAuditorsGroups(Arrays.asList(timesheetAuditorsGroups));
        configurationService.setTimesheetAuditorsRoles(Arrays.asList(timesheetAuditorsRoles));
        configurationService.setComposeIssueLink(composeIssueLink);
        configurationService.setParentIssueField(parentIssueField);
        configurationService.setInProgressQuery(inProgressQuery);
        configurationService.setMaxDays(maxDays); // set or remove
        configurationService.setPrettyDuration(prettyDuration); // set or remove
        configurationService.setHighlightHours(highlightHours);
        configurationService.setGroupByFields(Arrays.asList(groupByFields));
        configurationService.setExcludeProjects(Arrays.asList(excludeProjects));
        configurationService.setRestrictedGroups(Arrays.asList(restrictedGroups));
        configurationService.setWeekendType(weekendType);
        configurationService.setDecimalSeparator(decimalSeparator);
        configurationService.setDayFormat1(dayFormat1);
        configurationService.setDayFormat2(dayFormat2);
        configurationService.setMaxFractionDigits(maxFractionDigits);
    }

    @Override
    protected void doValidation() {
        if (!ArrayUtils.isEmpty(timesheetAuditorsGroups)) {
            for (String timesheetAuditorsGroup : timesheetAuditorsGroups) {
                if (!groupManager.groupExists(timesheetAuditorsGroup)) {
                    addError(
                            "timesheetAuditorsGroups",
                            getText("timesheet.configuration.error.timesheetAuditorsGroups.invalid",
                                    timesheetAuditorsGroup));
                }
            }
        }

        if (!ArrayUtils.isEmpty(timesheetAuditorsRoles)) {
            for (String timesheetAuditorsRole : timesheetAuditorsRoles) {
                if (projectRoleManager.getProjectRole(timesheetAuditorsRole) == null) {
                    addError(
                            "timesheetAuditorsRoles",
                            getText("timesheet.configuration.error.timesheetAuditorsRoles.invalid",
                                    timesheetAuditorsRole));
                }
            }
        }

        if (composeIssueLink != null && !composeIssueLink.isEmpty()) {
            Collection<IssueLinkType> issueLinkTypesByName = issueLinkTypeManager.getIssueLinkTypesByName(composeIssueLink);
            if (issueLinkTypesByName == null || issueLinkTypesByName.isEmpty()) {
                addError(
                        "composeIssueLink",
                        getText("timesheet.configuration.error.composeIssueLink.invalid",
                                composeIssueLink));
            }
       }

        if (parentIssueField != null && !parentIssueField.isEmpty()) {
            CustomField customField = customFieldManager.getCustomFieldObject(parentIssueField);
            if (parentIssueField == null || parentIssueField.isEmpty() || !isIssueLinkField(customField)) {
                addError(
                        "parentIssueField",
                        getText("timesheet.configuration.error.parentIssueField.invalid",
                                parentIssueField));
            }
       }

        if (inProgressQuery != null && !inProgressQuery.isEmpty()) {
           final SearchService.ParseResult parseResult =
                   searchService.parseQuery(getLoggedInUser(), inProgressQuery);
           if (!parseResult.isValid()) {
               MessageSet errors = parseResult.getErrors();
               addError(
                        "inProgressQuery",
                        getText("timesheet.configuration.error.inProgressQuery.invalid",
                            inProgressQuery,
                            errors.hasAnyErrors() ?
                                StringUtils.join(
                                    errors.getErrorMessages(), ",") : ""));
           }
       }
       
       if (StringUtils.length(decimalSeparator) > 1) {
           addError("decimalSeparator",
               getText("timesheet.configuration.error.decimalSeparator.invalid"));
       }

        try {
            new SimpleDateFormat(dayFormat1, getLocale());
        } catch (Exception e) {
            addError("dayFormat1",
                getText("timesheet.configuration.error.dayFormat.invalid"));
        }
        try {
            new SimpleDateFormat(dayFormat2, getLocale());
        } catch (Exception e) {
            addError("dayFormat2",
                    getText("timesheet.configuration.error.dayFormat.invalid"));
        }
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public List<String> getTimesheetAuditorsGroupsList() {
        return Arrays.asList(timesheetAuditorsGroups);
    }

    public String[] getTimesheetAuditorsGroups() {
        return timesheetAuditorsGroups;
    }

    public void setTimesheetAuditorsGroups(String[] timesheetAuditorsGroups) {
        this.timesheetAuditorsGroups = timesheetAuditorsGroups;
    }

    public List<String> getGroups() {
        return getGroups(true);
    }

    public List<String> getGroupsNoEmpty() {
        return getGroups(false);
    }

    private List<String> getGroups(boolean addEmpty) {
        Collection<Group> allGroups = groupManager.getAllGroups();
        List<String> groups = new ArrayList<String>(allGroups.size());
        if (addEmpty) {
            groups.add(""); //todo need to do this in UI (.vm) and remove #getGroupsNoEmpty
        }
        for (Group group : allGroups) {
            groups.add(group.getName());
        }
        return groups;
    }

    public LinkedHashMap<String, String> getWeekendTypeList() {
        final LinkedHashMap<String, String> result = new LinkedHashMap<String, String>();
        result.put("Sat-Sun", WeekendUtil.getDefaultWeekend());
        result.put("Fri-Sat", WeekendUtil.getIslamicWeekend());
        result.put("Sun", WeekendUtil.getIndiaWeekend());
        return result;
    }

    public List<String> getTimesheetAuditorsRolesList() {
        return Arrays.asList(timesheetAuditorsRoles);
    }

    public String[] getTimesheetAuditorsRoles() {
        return timesheetAuditorsRoles;
    }

    public void setTimesheetAuditorsRoles(String[] timesheetAuditorsRoles) {
        this.timesheetAuditorsRoles = timesheetAuditorsRoles;
    }

    public List<String> getRoles() {
        return getRoles(true);
    }

    public List<String> getRolesNoEmpty() {
        return getRoles(false);
    }

    public List<String> getRoles(final boolean addEmpty) {
        Collection<ProjectRole> projectRoles = projectRoleManager.getProjectRoles();
        List<String> roles = new ArrayList<String>(projectRoles.size());
        if (addEmpty) {
            roles.add(""); //todo need to do this in UI (.vm) and remove #getRolesNoEmpty
        }
        for (ProjectRole role : projectRoles) {
            roles.add(role.getName());
        }
        return roles;
    }

    public String getComposeIssueLink() {
        return composeIssueLink == null ? ConfigurationService.EMPTY_STRING : composeIssueLink;
    }

    public void setComposeIssueLink(String composeIssueLink) {
        this.composeIssueLink = composeIssueLink;
    }

    public String getParentIssueField() {
        return parentIssueField == null ? ConfigurationService.EMPTY_STRING : parentIssueField;
    }

    public void setParentIssueField(String parentIssueField) {
        this.parentIssueField = parentIssueField;
    }

    public Map<String, String> getIssueFields() {
        List<CustomField> customFields = customFieldManager.getCustomFieldObjects();
        Map<String, String> result = new TreeMap<String, String>();
        result.put("", "");
        for (CustomField field : customFields) {
            if (isIssueLinkField(field)) {
                result.put(field.getId(), field.getName());
                break;
            }
        }
        return result;
    }

    private boolean isIssueLinkField(CustomField field) {
        // field value must be of type Issue for TimeBaseService.getLinkedIssue()
        return TextUtil.isEpicLinkField(field);        
    }


    public String getWeekendType() {
        return weekendType;
    }

    public void setWeekendType(String weekendType) {
        this.weekendType = weekendType;
    }

    public String getDecimalSeparator() {
        return decimalSeparator;
    }

    public void setDecimalSeparator(String decimalSeparator) {
        this.decimalSeparator = decimalSeparator;
    }

    public String getDayFormat1() {
        return dayFormat1;
    }

    public void setDayFormat1(String dayFormat1) {
        this.dayFormat1 = dayFormat1;
    }

    public String getDayFormat2() {
        return dayFormat2;
    }

    public void setDayFormat2(String dayFormat2) {
        this.dayFormat2 = dayFormat2;
    }

    public List<String> getIssueLinks() {
        Collection<IssueLinkType> issueLinkTypes = issueLinkTypeManager.getIssueLinkTypes();
        List<String> issueLinks = new ArrayList<String>(issueLinkTypes.size());
        issueLinks.add("");
        for (IssueLinkType issueLinkType : issueLinkTypes) {
            issueLinks.add(issueLinkType.getName());
        }
        return issueLinks;
    }

    public String getInProgressQuery() {
        return inProgressQuery == null ? ConfigurationService.EMPTY_STRING : inProgressQuery;
    }

    public void setInProgressQuery(String inProgressQuery) {
        this.inProgressQuery = inProgressQuery;
    }

    public Integer getMaxDays() {
        return maxDays;
    }

    public void setMaxDays(Integer maxDays) {
        this.maxDays = maxDays;
    }

    public Integer getMaxFractionDigits() {
        return maxFractionDigits;
    }

    public void setMaxFractionDigits(Integer maxFractionDigits) {
        this.maxFractionDigits = maxFractionDigits;
    }

    public Boolean getPrettyDuration() {
        return prettyDuration;
    }

    public void setPrettyDuration(Boolean prettyDuration) {
        this.prettyDuration = prettyDuration;
    }

    public Integer getHighlightHours() {
        return highlightHours;
    }

    public void setHighlightHours(Integer highlightHours) {
        this.highlightHours = highlightHours;
    }

    public List<String> getGroupByFieldsList() {
        return Arrays.asList(groupByFields);
    }

    public String[] getGroupByFields() {
        return groupByFields;
    }

    public void setGroupByFields(String[] groupByFields) {
        this.groupByFields = groupByFields;
    }

    public Map<String, String> getAllGroupByFields() {
        Map<String, Object>  params = new TreeMap<String, Object>();
        params.put("User", getLoggedInUser());
        params.put(FieldsValuesGenerator.ALL_GROUPS, Boolean.TRUE);
        Map<String, String> allGroupByFields = fieldsValuesGenerator.getValues(params);
        allGroupByFields.remove(ConfigurationService.EMPTY_STRING);
        return allGroupByFields;
    }

    public List<String> getExcludeProjectsList() {
        return Arrays.asList(excludeProjects);
    }

    public List<String> getRestrictedGroupsList() {
        return Arrays.asList(restrictedGroups);
    }

    public String[] getExcludeProjects() {
        return excludeProjects;
    }

    public void setExcludeProjects(String[] excludeProjects) {
        this.excludeProjects = excludeProjects;
    }

    public String[] getRestrictedGroups() {
        return restrictedGroups;
    }

    public void setRestrictedGroups(String[] restrictedGroups) {
        this.restrictedGroups = restrictedGroups;
    }

    public Map<String, String> getAllProjects() {
        Map<String, Object>  params = new TreeMap<String, Object>();
        params.put("User", getLoggedInUser());
        params.put(ProjectValuesGenerator.ALL_PROJECTS, Boolean.TRUE);
        Map<String, String> allProjects = projectValuesGenerator.getValues(params);
        allProjects.remove(ConfigurationService.EMPTY_STRING);
        return allProjects;
    }
}
