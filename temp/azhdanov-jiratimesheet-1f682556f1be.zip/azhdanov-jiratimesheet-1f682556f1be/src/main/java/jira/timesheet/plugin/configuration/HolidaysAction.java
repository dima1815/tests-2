package jira.timesheet.plugin.configuration;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.fdu.jira.util.ILicenseUtil;

import jira.timesheet.plugin.holidays.HolidayImportException;
import jira.timesheet.plugin.holidays.HolidayService;
import org.apache.commons.lang.StringUtils;
import webwork.action.ServletActionContext;

import java.io.File;

public class HolidaysAction extends ConfigurationActionBase {

    protected HolidayService holidayService;

    private static final long serialVersionUID = 1L;

    public static final String BLANK = "blank";

    public String statusMessage = "";

    private String importUrl;

    private final JiraAuthenticationContext authenticationContext;

    public String doDefault() {
        return validateAdminAction(SUCCESS);
    }

    public HolidaysAction(HolidayService holidayService,
            JiraAuthenticationContext authenticationContext,
            ILicenseUtil licenseUtil) {
        super(licenseUtil);
        this.holidayService = holidayService;
        this.authenticationContext = authenticationContext;
    }

    public String doImportHolidaysFromUrl() {
        try {
            holidayService.importHolidays(importUrl);
        } catch (HolidayImportException e) {
            parseStatusMessage(e);
        }
        return BLANK;
    }

    public String doImportHolidaysFromFile() {
        final File importFile = ServletActionContext.getMultiPartRequest().getFile("importFile");
        try {
            holidayService.importHolidays(importFile);
        } catch (HolidayImportException e) {
            parseStatusMessage(e);
        }
        return BLANK;
    }

    public String getImportUrl() {
        return importUrl;
    }

    public void setImportUrl(String importUrl) {
        this.importUrl = importUrl;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    protected void parseStatusMessage(HolidayImportException e) {
        statusMessage = StringUtils.isBlank(e.getMessageParam())
                ? getText(e.getMessage())
                : getText(e.getMessage(), e.getMessageParam());
    }

    public JiraAuthenticationContext getAuthenticationContext() {
        return authenticationContext;
    }

}
