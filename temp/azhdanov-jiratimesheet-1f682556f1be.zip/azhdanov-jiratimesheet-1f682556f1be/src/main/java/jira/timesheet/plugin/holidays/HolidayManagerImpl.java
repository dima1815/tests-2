package jira.timesheet.plugin.holidays;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.sal.api.transaction.TransactionCallback;
import org.apache.commons.lang.ArrayUtils;

public class HolidayManagerImpl implements HolidayManager {

    private final ActiveObjects ao;
    private final ApplicationProperties applicationProperties;

    public HolidayManagerImpl(ActiveObjects ao,
                              ApplicationProperties applicationProperties) {
        this.ao = ao;
        this.applicationProperties = applicationProperties;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Holiday addHoliday(final HolidayDate date, final String name) {
        final Holiday holiday = getHoliday(date);
        if (holiday != null) {
            return holiday;
        }
        return ao.executeInTransaction(new TransactionCallback<Holiday>() {
            public Holiday doInTransaction() {
                final Holiday holiday = ao.create(Holiday.class);
                holiday.setYear(date.getYear());
                holiday.setMonth(date.getMonth());
                holiday.setDay(date.getDay());
                holiday.setName(name);
                holiday.setLocale(applicationProperties.getDefaultLocale().getCountry());
                holiday.save();
                return holiday;
            }
        });
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Holiday updateHoliday(final Integer id, final HolidayDate date, final String name) {
        final Holiday holiday = ao.get(Holiday.class, id);
        if (holiday == null) {
            return holiday;
        }
        return ao.executeInTransaction(new TransactionCallback<Holiday>() {
            public Holiday doInTransaction() {
                holiday.setYear(date.getYear());
                holiday.setMonth(date.getMonth());
                holiday.setDay(date.getDay());
                holiday.setName(name);
                holiday.setLocale(applicationProperties.getDefaultLocale().getCountry());
                holiday.save();
                return holiday;
            }
        });
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void deleteHoliday(Integer id) {
        final Holiday holiday = ao.get(Holiday.class, id);
        if (holiday != null) {
            ao.delete(holiday);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Holiday getHoliday(HolidayDate date) {
        final Holiday[] holidays = ao.find(Holiday.class, "MONTH = ? and DAY = ? and (YEAR is null or YEAR = ?)",
                date.getMonth(), date.getDay(), date.getYear());
        return ArrayUtils.isEmpty(holidays) ? null : holidays[0];
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Holiday[] findHolidays(Integer year) {
        return ao.find(Holiday.class, "YEAR is null or YEAR = ?", year);
    }
}
