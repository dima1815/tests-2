package jira.timesheet.plugin.job;

import org.apache.log4j.Logger;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.crowd.embedded.api.User;
import com.atlassian.sal.api.transaction.TransactionCallback;
import com.fdu.jira.util.DirectoryUtil;

public class TimesheetJobConfigurationManagerImpl implements TimesheetJobConfigurationManager {
    private static final Logger log = Logger.getLogger(TimesheetJobConfigurationManagerImpl.class);
    private final ActiveObjects ao;

    public TimesheetJobConfigurationManagerImpl(ActiveObjects ao) {
        this.ao = ao;
    }
    
    public ActiveObjects getActiveObjects() {
        return ao;
    }

    public TimesheetJobConfiguration addJobConfiguration(final User user, final String reportKey,
            final String queryString, final String cronExpression) {
        final String username = DirectoryUtil.getUserName(user);
        final String key = getKey(reportKey, queryString);
        final TimesheetJobConfiguration[] existingConfigs = findExisting(username, key);
        if (existingConfigs.length == 0) {
            log.info("Adding timesheet job: " + key + " for user: " + username);
            return ao.executeInTransaction(new TransactionCallback<TimesheetJobConfiguration>() {
                public TimesheetJobConfiguration doInTransaction() {
                    final TimesheetJobConfiguration config = ao.create(TimesheetJobConfiguration.class);
                    config.setUsername(username);
                    config.setKey(key);
                    config.setParams(queryString);
                    config.setCronExpression(cronExpression);
                    config.save();
                    return config;
                }
            });
        } else {
            log.warn("Found existing timesheet job: " + existingConfigs[0].getKey());
            return existingConfigs[0];
        }
    }

    public TimesheetJobConfiguration updateJobConfiguration(final User user, final String key, final String cronExpression, final String queryString) {
        final String username = DirectoryUtil.getUserName(user);
        final TimesheetJobConfiguration[] existingConfigs = findExisting(username, key);
        if (existingConfigs.length == 1) {
            log.info("Updating timesheet job: " + key);
            return ao.executeInTransaction(new TransactionCallback<TimesheetJobConfiguration>() {
                public TimesheetJobConfiguration doInTransaction() {
                    final TimesheetJobConfiguration config = existingConfigs[0];
                    config.setCronExpression(cronExpression);
                    config.setParams(queryString);
                    config.save();
                    return config;
                }
            });
        } else {
            log.error("Have not found unique timesheet job for key: " + key);
            return null;
        }
    }

    public TimesheetJobConfiguration getJobConfiguration(Integer id) {
        return ao.get(TimesheetJobConfiguration.class, id);
    }

    public TimesheetJobConfiguration getJobConfiguration(User user, String key) {
        if (user != null) {
            final String username = DirectoryUtil.getUserName(user);
            TimesheetJobConfiguration[] existing = findExisting(username, key);
            if (existing.length == 1) {
                return existing[0];
            }
        }
        return null;
    }

    public TimesheetJobConfiguration[] getJobConfigurations(User user, String reportKey,
            String queryString) {
        if (user == null) {
            return new TimesheetJobConfiguration[] {};
        }
        final String username = DirectoryUtil.getUserName(user);
        final String key = getKey(reportKey, queryString);
        return findExisting(username, key);
    }

    public TimesheetJobConfiguration[] getJobConfigurations(User user,
            String reportKey) {
        if (user == null) {
            return new TimesheetJobConfiguration[] {};
        }
        final String username = DirectoryUtil.getUserName(user);
        return ao.find(TimesheetJobConfiguration.class, "USERNAME = ? and KEY like ?", 
                username, reportKey + "#%");
    }

    // TODO: consider using stream: http://blogs.atlassian.com/2011/09/activeobjects_streaming_api/
    // see also https://developer.atlassian.com/display/DOCS/Best+practices+for+developing+with+Active+Objects
    public TimesheetJobConfiguration[] getAllJobConfigurations() {
        return ao.find(TimesheetJobConfiguration.class);
    }

    public void removeJobConfiguration(User user, String reportKey,
            String queryString) {
        final String key = getKey(reportKey, queryString);
        removeJobConfiguration(user, key);
    }

    public void removeJobConfiguration(User user, String key) {
        final String username = DirectoryUtil.getUserName(user);
        final TimesheetJobConfiguration[] existingConfigs = findExisting(username, key);
        ao.delete(existingConfigs);
    }

    private String getKey(String reportKey, String queryString) {
        return reportKey + "#" + Integer.toHexString(queryString.hashCode());
    }

    private TimesheetJobConfiguration[] findExisting(final String username, final String key) {
        return ao.find(TimesheetJobConfiguration.class, "USERNAME = ? and KEY = ?",
                username, key);
    }
}
