package jira.timesheet.plugin.configuration;

import com.atlassian.gzipfilter.org.apache.commons.lang.StringUtils;
import com.atlassian.jira.user.util.UserUtil;
import com.fdu.jira.util.ILicenseUtil;
import edu.emory.mathcs.backport.java.util.Arrays;
import jira.timesheet.plugin.job.TimesheetJobConfiguration;
import jira.timesheet.plugin.job.TimesheetJobConfigurationManager;

import java.util.List;

@SuppressWarnings("unchecked")
public class SubscriptionsConfigurationAction extends ConfigurationActionBase {
    private static final long serialVersionUID = 1L;

    private String statusMessage = "";
    private String subscriptionKey;
    private String subscriptionUser;
    private List<TimesheetJobConfiguration> subscriptions;
    private TimesheetJobConfigurationManager timesheetJobConfigurationManager;
    private UserUtil userUtil;

    public SubscriptionsConfigurationAction(ILicenseUtil licenseUtil,
                                            TimesheetJobConfigurationManager timesheetJobConfigurationManager,
                                            UserUtil userUtil) {
        super(licenseUtil);
        this.timesheetJobConfigurationManager = timesheetJobConfigurationManager;
        this.userUtil = userUtil;
    }

    @Override
    public String doDefault() {
        this.subscriptions = Arrays.asList(
                timesheetJobConfigurationManager.getAllJobConfigurations());
        return INPUT;
    }

    public String doDelete() {
        String action = validateAdminAction(SUCCESS);
        if (SUCCESS.equals(action)) {
            if (StringUtils.isNotBlank(subscriptionUser)
                    && StringUtils.isNotBlank(subscriptionKey)) {
                timesheetJobConfigurationManager.removeJobConfiguration(
                        userUtil.getUser(subscriptionUser),
                        subscriptionKey);
            }
            return getRedirect("/secure/SubscriptionsConfiguration!default.jspa");
        }
        return action;
    }

    public String getSubscriptionKey() {
        return subscriptionKey;
    }

    public void setSubscriptionKey(String subscriptionKey) {
        this.subscriptionKey = subscriptionKey;
    }

    public String getSubscriptionUser() {
        return subscriptionUser;
    }

    public void setSubscriptionUser(String subscriptionUser) {
        this.subscriptionUser = subscriptionUser;
    }

    public List<TimesheetJobConfiguration> getSubscriptions() {
        return subscriptions;
    }

    public String getStatusMessage() {
        return statusMessage;
    }
}
