package jira.timesheet.plugin.job;

import net.java.ao.Entity;
import net.java.ao.Preload;
import net.java.ao.schema.Table;

/*
 * Timesheet plugin job configuration active object.  
 */
@Preload
@Table("TimesheetJobCfg")
public interface TimesheetJobConfiguration extends Entity {
    String getUsername();
    void setUsername(String username);

    /*
     * report-key:params-hash
     */
    String getKey();
    void setKey(String key);

    String getParams();
    void setParams(String params);

    String getCronExpression();
    void setCronExpression(String cronExpression);
}
