package jira.timesheet.plugin.license;

import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.upm.api.util.Option;
import com.fdu.jira.util.ILicenseUtil;

public class LicenseConfigurationAction extends JiraWebActionSupport {
    private static final long serialVersionUID = 1L;

    private static final String LICENSE_URL = "http://www.jiratimesheet.com/license.html";

    private String statusMessage = "";
    private Option<TimesheetLicense> license;
    private String rawLicense;

    private ILicenseUtil licenseUtil;

    private boolean eligibleButtons;
    private String buyPluginUri;
    private String renewPluginUri;
    private String tryPluginUri;

    public LicenseConfigurationAction(ILicenseUtil licenseUtil) {
        this.licenseUtil = licenseUtil;
        license = licenseUtil.getTimesheetLicense();
    }

    @Override
    public String doDefault() {
        doValidation();
        return SUCCESS;
    }

    @Override
    protected void doValidation() {
        if (!licenseUtil.isJiraOnDemand()) {
            this.addErrorMessage(getText("license.configuration.error.jiraOnDemandOnly",
                    licenseUtil.getLicenseMgmtUrl(request.getContextPath())));
        } else {
            if (license.isDefined()) {
                if (license.get().getError().isDefined()) {
                    eligibleButtons = true;
                    renewPluginUri = LICENSE_URL;
                }
            } else {
                eligibleButtons = true;
                buyPluginUri = LICENSE_URL;
                tryPluginUri = LICENSE_URL;
            }
        }
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public Option<TimesheetLicense> getLicense() {
        return license;
    }

    public String getRawLicense() {
        return rawLicense;
    }
    public void setRawLicense(String rawLicense) {
        if (licenseUtil.isJiraOnDemand()) {
            this.rawLicense = rawLicense;
            Option<TimesheetLicense> newLicense = licenseUtil.setTimesheetLicense(rawLicense);
            if (newLicense.isDefined() && newLicense.get().isValid()) {
                license = newLicense;
                statusMessage = "timesheet.configuration.success";
            } else {
                String error = "";
                if (newLicense.isDefined() && newLicense.get().getError().isDefined()) {
                    error = getText("plugin.license.storage.admin.license.error." + newLicense.get().getError().get());
                }
                addError("rawLicense", getText("license.configuration.error.rawLicense.invalid", error));
            }
        }
        // TODO: clear license
    }

    public boolean isEligibleButtons() {
        return eligibleButtons;
    }

    public String getBuyPluginUri() {
        return buyPluginUri;
    }

    public String getRenewPluginUri() {
        return renewPluginUri;
    }

    public String getTryPluginUri() {
        return tryPluginUri;
    }
}
