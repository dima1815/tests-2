package jira.timesheet.plugin.servlet;

import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.atlassian.sal.api.ApplicationProperties;
import com.atlassian.templaterenderer.TemplateRenderer;

public class IssuesTimesheetServlet extends HttpServlet {

    private static final long serialVersionUID = 1979386553751625310L;
    private static final String TEMPLATE = "templates/issuestimesheet/issues-timesheet.vm";
    private final ApplicationProperties applicationProperties;
    private final TemplateRenderer renderer;

    public IssuesTimesheetServlet(ApplicationProperties applicationProperties,
                              TemplateRenderer renderer) {
        this.applicationProperties = applicationProperties;
        this.renderer = renderer;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        final Map<String, Object> context = initVelocityContext(resp);
        renderer.render(TEMPLATE, context, resp.getWriter());
    }

    private Map<String, Object> initVelocityContext(HttpServletResponse resp) {
        resp.setContentType("text/html;charset=utf-8");
        URI servletUri = URI.create(applicationProperties.getBaseUrl()
                + "/plugins/servlet/issues-timesheet");

        final Map<String, Object> context = new HashMap<String, Object>();
        context.put("servletUri", servletUri);
        return context;
    }

}
