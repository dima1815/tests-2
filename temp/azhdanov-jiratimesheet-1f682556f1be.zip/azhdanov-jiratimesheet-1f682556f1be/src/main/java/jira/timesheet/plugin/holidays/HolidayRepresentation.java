package jira.timesheet.plugin.holidays;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.StringUtils;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class HolidayRepresentation {

    protected int id;

    protected String date;

    protected String name;

    protected String locale;

    @SuppressWarnings("unused")
    private HolidayRepresentation() {
        // for JAXB
    }

    public HolidayRepresentation(Holiday holiday) {
        this.id = holiday.getID();
        this.date = composeDate(holiday);
        this.name = holiday.getName();
        this.locale = holiday.getLocale();
    }

    private String composeDate(Holiday holiday) {
        final StringBuilder sb = new StringBuilder();
        String year = holiday.getYear() != null ? holiday.getYear().toString() : "*";
        sb.append(year)
                .append("-")
                .append(pad(holiday.getMonth()))
                .append("-")
                .append(pad(holiday.getDay()));
        return sb.toString();
    }

    private String pad(Integer i) {
        return (i < 10 ? "0" : "") + i;
    }

    public HolidayDate getHolidayDate() {
        final String[] parts = StringUtils.split(date, "-");
        return new HolidayDate("*".equals(parts[0]) ? null : Integer.valueOf(parts[0]),
                Integer.valueOf(parts[1]),
                Integer.valueOf(parts[2]));
    }


}
