package jira.timesheet.plugin.job;

import java.text.ParseException;
import java.util.Timer;
import java.util.TimerTask;

import javax.annotation.PreDestroy;

import org.apache.log4j.Logger;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.springframework.beans.factory.DisposableBean;

import com.atlassian.jira.ComponentManager;
import com.atlassian.sal.api.lifecycle.LifecycleAware;

// https://answers.atlassian.com/questions/14469/quartz-job-class-inside-a-plugin-not-loaded-when-jira-restarted
public class TimesheetJobScheduler implements LifecycleAware, ITimesheetJobScheduler, DisposableBean {

    public static final String SUBSCRIPTION_PREFIX = "SUBSCRIPTION_";
    public static final String SUBSCRIPTION_IDENTIFIER = "TIMESHEET_SUBSCRIPTION";

    private static final Logger log = Logger.getLogger(TimesheetJobScheduler.class);
    private final TimesheetJobConfigurationManager timesheetJobConfigurationManager;

    public TimesheetJobScheduler(TimesheetJobConfigurationManager timesheetJobConfigurationManager) {
        this.timesheetJobConfigurationManager = timesheetJobConfigurationManager;
    }

    @PreDestroy
    protected void unschedule() {
        Scheduler scheduler = getScheduler();
        try {
            for (String triggerName : scheduler.getTriggerNames(SUBSCRIPTION_IDENTIFIER)) {
                    scheduler.unscheduleJob(triggerName, SUBSCRIPTION_IDENTIFIER);
            }
        } catch (SchedulerException e) {
            log.warn("Can't unschedule timesheet job: " + e.getMessage());
        }
        try {
            scheduler.deleteJob(SUBSCRIPTION_IDENTIFIER, SUBSCRIPTION_IDENTIFIER);
        } catch (SchedulerException e) {
            log.warn("Can't delete timesheet job: " + e.getMessage());
        }
    }

    public void onStart() {
        unschedule();
        // https://answers.atlassian.com/questions/14922/active-object-service-fails-to-load-when-a-component-is-marked-public-true
        new Timer("Timesheet Delayed Subscriptions Initialization").schedule(new TimerTask() {

            @Override
            public void run() {
                schedule();
            }
            
        }, 15 * 1000); // in 15 seconds
    }

    private void schedule() {
        for (TimesheetJobConfiguration config : timesheetJobConfigurationManager.getAllJobConfigurations()) {
            try {
                doSchedule(config, new CronTrigger("temp", "temp", config.getCronExpression()));
            } catch (ParseException e) {
                log.error("Can't schedule timesheet job: " + e.getMessage());
            }
        }
    }

    public void unschedule(final TimesheetJobConfiguration jobConfiguration) {
        try {
            log.info("Unscheduling " + jobConfiguration.getKey() + " on " + jobConfiguration.getCronExpression());
            getScheduler().unscheduleJob(SUBSCRIPTION_PREFIX + jobConfiguration.getID(), SUBSCRIPTION_IDENTIFIER);
        } catch (final SchedulerException e) {
            // ignore
        }
    }

    public void schedule(final TimesheetJobConfiguration jobConfiguration, final CronTrigger trigger) {
        unschedule(jobConfiguration);
        doSchedule(jobConfiguration, trigger);
    }

    private void doSchedule(final TimesheetJobConfiguration jobConfiguration, final CronTrigger trigger) {
        try {
            if (!getScheduler().isInStandbyMode() && !getScheduler().isShutdown()) {
                populateTriggerFields(trigger, jobConfiguration.getID());
                getScheduler().scheduleJob(trigger);
            } else {
                throw new IllegalStateException("The scheduler is paused or shutdown so the subscription was not created.");
            }
        } catch (final SchedulerException e) {
            log.warn("Can't schedule " + jobConfiguration.getKey() + " on " + trigger.getCronExpression() + ": " + e.getMessage());
        }
    }

    private void populateTriggerFields(final Trigger trigger, final Integer subscriptionId) throws SchedulerException     {
        final JobDetail jd = new JobDetail(SUBSCRIPTION_IDENTIFIER, SUBSCRIPTION_IDENTIFIER, TimesheetJob.class, false, true, false);

        trigger.setName(SUBSCRIPTION_PREFIX + subscriptionId);
        trigger.setGroup(SUBSCRIPTION_IDENTIFIER);
        trigger.setJobName(SUBSCRIPTION_IDENTIFIER);
        trigger.setJobGroup(SUBSCRIPTION_IDENTIFIER);

        getScheduler().addJob(jd, true);
    }

    public TimesheetJobConfiguration getJobConfigurationFromTriggerName(final String triggerName) {
        return timesheetJobConfigurationManager.getJobConfiguration(new Integer(triggerName.substring(SUBSCRIPTION_PREFIX.length(), triggerName.length())));
    }

    public Trigger getTriggerFromJobConfiguration(final TimesheetJobConfiguration jobConfiguration) throws SchedulerException {
        return getScheduler().getTrigger(SUBSCRIPTION_PREFIX + jobConfiguration.getID(), SUBSCRIPTION_IDENTIFIER);
    }

    // We need to get the scheduler every time since it's reference can change when we do an import.
    private Scheduler getScheduler() {
        return ComponentManager.getComponentInstanceOfType(Scheduler.class);
    }

    @Override
    public void destroy() throws Exception {
        unschedule();
    }
}
