package jira.timesheet.plugin.holidays;

public class HolidayImportException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    protected String messageParam;

    public HolidayImportException(String messageKey) {
        super(messageKey);
    }

    public HolidayImportException(String message, String messageParam) {
        this(message);
        this.messageParam = messageParam;
    }

    public String getMessageParam() {
        return messageParam;
    }
}
