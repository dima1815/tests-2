package jira.timesheet.plugin.holidays;

public interface HolidayManager {

    Holiday addHoliday(HolidayDate day, String name);

    Holiday updateHoliday(Integer id, HolidayDate date, String name);

    void deleteHoliday(Integer id);

    Holiday getHoliday(HolidayDate date);

    Holiday[] findHolidays(Integer year);
}
