package jira.timesheet.plugin.holidays;

import com.fdu.jira.plugin.resource.AbstractResource;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;

@Path("/holidays")
public class HolidaysResource extends AbstractResource {

    protected HolidayManager holidayManager;

    public HolidaysResource(HolidayManager timesheetHolidayManager) {
        this.holidayManager = timesheetHolidayManager;
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response getHolidays(@QueryParam(value = "year") final Integer year) {

        final ArrayList<HolidayRepresentation> list = new ArrayList<HolidayRepresentation>();

        for (Holiday holiday : holidayManager.findHolidays(year)) {
            list.add(new HolidayRepresentation(holiday));
        }

        return getOkResponse(list);
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    public Response addHoliday(HolidayRepresentation data) {
        Holiday holiday = holidayManager.addHoliday(data.getHolidayDate(), data.name);
        return getOkResponse(new HolidayRepresentation(holiday));
    }

    @PUT
    @Path("{id}")
    @Produces({MediaType.APPLICATION_JSON})
    public Response updateHoliday(@PathParam("id") Integer id, HolidayRepresentation data) {
        Holiday holiday = holidayManager.updateHoliday(id, data.getHolidayDate(), data.name);
        return getOkResponse(new HolidayRepresentation(holiday));
    }

    @DELETE
    @Path("{id}")
    @Produces({MediaType.APPLICATION_JSON})
    public Response deleteHoliday(@PathParam("id") Integer id) {
        holidayManager.deleteHoliday(id);
        return getVoidOkResponse();
    }
}
