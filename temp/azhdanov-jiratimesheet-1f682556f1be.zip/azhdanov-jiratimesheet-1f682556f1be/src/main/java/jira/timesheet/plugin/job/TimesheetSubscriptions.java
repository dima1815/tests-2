package jira.timesheet.plugin.job;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.bc.JiraServiceContext;
import com.atlassian.jira.bc.filter.SearchRequestService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.issue.search.SearchRequest;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.util.FilterCronValidationErrorMappingUtil;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.jira.web.component.cron.CronEditorBean;
import com.atlassian.jira.web.component.cron.CronEditorWebComponent;
import com.atlassian.jira.web.component.cron.parser.CronExpressionParser;
import com.fdu.jira.plugin.report.timesheet.GroupValuesGenerator;
import com.fdu.jira.util.CalendarUtil;
import com.fdu.jira.util.ILicenseUtil;
import com.fdu.jira.util.TextUtil;
import com.google.common.collect.ImmutableMap;
import jira.plugin.report.timesheet.TimeBase;
import jira.plugin.report.timesheet.TimeBase.Options;
import org.apache.commons.lang.StringUtils;
import org.quartz.CronTrigger;
import webwork.action.ActionContext;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import static com.atlassian.jira.util.ParameterUtils.getBooleanParam;
import static com.atlassian.jira.util.ParameterUtils.getIntParam;
import static com.atlassian.jira.util.ParameterUtils.getStringParam;

public class TimesheetSubscriptions extends JiraWebActionSupport {
    private static final long serialVersionUID = 3313014666217606423L;

    public static final String PARAM_REMIND_GROUP = "remind";
    public static final String PARAM_CC_USER_GROUP = "cc-group";
    public static final String PARAM_TARGET_USER = "targetUser";
    public static final String PARAM_TARGET_GROUP = "targetGroup";
    public static final String PARAM_PROJECT_ID = "projectid";
    public static final String PARAM_PROJECT_ROLE_ID = "projectRoleId";

    private static final String TIMESHEET_SUBSCRIPTION_PREFIX = "timesheet.subscription";
    private static final String BLANK = "blank";
    private static final String OK = "ok";

    private final TimesheetJobScheduler timesheetJobScheduler;
    private final TimesheetJobConfigurationManager timesheetJobConfigurationManager;
    private final TimeZoneManager timeZoneManager;
    private final DateTimeFormatterFactory dateTimeFormatterFactory;
    private final ILicenseUtil licenseUtil;
    private SearchRequestService searchRequestService;
    private ProjectRoleManager projectManager;
    private String statusMessage = "";
    private String configureUrl;
    private Map<String, List<String>> queryParams;
    private String generatedReportHtml;
    private String key;
    private TimesheetAdapter timesheetAdapter;
    private CronEditorBean cronEditorBean;
    private final FilterCronValidationErrorMappingUtil errorMapper;
    private Timestamp nextRun;
    private CronTrigger cronTrigger;
    private String cronExpression;
    private String cronEditorHtml;
    private String ccUserGroup;
    private String remindGroup;
    private Map<String, String> groups;

    public TimesheetSubscriptions(TimesheetJobScheduler timesheetJobScheduler,
            TimesheetJobConfigurationManager timesheetJobConfigurationManager,
            TimeZoneManager timeZoneManager,
            DateTimeFormatterFactory dateTimeFormatterFactory,
            ILicenseUtil licenseUtil,
            JiraAuthenticationContext jiraAuthenticationContext) {
        this.timesheetJobScheduler = timesheetJobScheduler;
        this.timesheetJobConfigurationManager = timesheetJobConfigurationManager;
        this.timeZoneManager = timeZoneManager;
        this.dateTimeFormatterFactory = dateTimeFormatterFactory;
        this.licenseUtil = licenseUtil;
        this.errorMapper = new FilterCronValidationErrorMappingUtil(jiraAuthenticationContext);
    }

    @Override
    public String doDefault() throws Exception {
        
        if (!licenseUtil.isLicenseValid()) {
            statusMessage = getText(licenseUtil.getLicenseStatus(false) + ".text",
                    licenseUtil.getLicenseMgmtUrl(request.getContextPath()));
            addErrorMessage(statusMessage);
        } 
        return INPUT;
    }

    @Override
    protected void doValidation() {
        if (getLoggedInUser() == null) {
            statusMessage = "Error, not logged in"; // may not happen
            addErrorMessage(statusMessage);
            return;
        }
        if (StringUtils.isBlank(configureUrl)) {
            statusMessage = getText("timesheet.subscriptions.error.noConfigUrl");
            addError("configureUrl", statusMessage);
            return;
        } else {
            queryParams = TextUtil.getQueryParams(configureUrl);
        }
        final List<String> reportKey = queryParams.remove("reportKey");
        if (reportKey.size() != 1 || !TimesheetAdapter.REPORT_KEY.equals(reportKey.get(0))) {
            statusMessage = "Error, not a timesheet report configuration url";
            addError("configureUrl", statusMessage);
            return;
        }

    }

    public String doPreview() {
        if (!licenseUtil.isLicenseValid()) {
            statusMessage = getText(licenseUtil.getLicenseStatus(false) + ".text",
                    licenseUtil.getLicenseMgmtUrl(request.getContextPath()));
            addErrorMessage(statusMessage);
            return INPUT;
        } else if (key == null || key.isEmpty()) {
            statusMessage = getText("timesheet.subscriptions.error.noReportKey");
            addError("reportKey", statusMessage);
            return INPUT;
        } else if (!key.startsWith(TimesheetAdapter.REPORT_KEY)) {
            statusMessage = getText("timesheet.subscriptions.error.notTimesheetReportKey");
            addError("reportKey", statusMessage);
            return INPUT;
        } else {
            TimesheetJobConfiguration config = timesheetJobConfigurationManager.getJobConfiguration(getLoggedInUser(), key);
            if (config != null) {
                try {
                    generatedReportHtml = getTimeshetAdapter().getGeneratedReport(config);
                } catch (Exception e) {
                    log.error("Can't render timesheet report:" + e.getMessage(), e);
                    statusMessage = "Can't render timesheet report";
                    return ERROR;
                }
            }
            return SUCCESS;
        }
    }

    public String doSchedule() throws Exception {
        if (!licenseUtil.isLicenseValid()) {
            statusMessage = getText(licenseUtil.getLicenseStatus(false) + ".text",
                    licenseUtil.getLicenseMgmtUrl(request.getContextPath()));
            addErrorMessage(statusMessage);
            return INPUT;
        } else if (key == null && configureUrl == null) {
            statusMessage = getText("timesheet.subscriptions.error.noSubscriptionKey");
            return INPUT;
        } else if (key != null) {
            TimesheetJobConfiguration jobConfiguration = timesheetJobConfigurationManager.getJobConfiguration(getLoggedInUser(), key);
            if (jobConfiguration == null) {
                statusMessage = getText("timesheet.subscriptions.error.jobNotFound");
                return INPUT;
            } else {
                // reminder
                final Map<String, List<String>> queryParams = TextUtil.getQueryParams("?" + jobConfiguration.getParams());
                this.ccUserGroup = getStringParam(queryParams, PARAM_CC_USER_GROUP);
                this.remindGroup = getStringParam(queryParams, PARAM_REMIND_GROUP);
                // Get from the trigger
                final CronTrigger cronTrigger = (CronTrigger) timesheetJobScheduler.getTriggerFromJobConfiguration(jobConfiguration);
                if (cronTrigger != null) { // FIXME: remove
                    String cronExpression = cronTrigger.getCronExpression();
                    CronExpressionParser cronExpresionParser = new CronExpressionParser(cronExpression);
                    cronEditorBean = cronExpresionParser.getCronEditorBean();

                    nextRun = new Timestamp(cronTrigger.getNextFireTime()
                            .getTime());
                }
            }
        }
        final CronEditorWebComponent cronEditorWebComponent = new CronEditorWebComponent();
        this.cronEditorHtml = cronEditorWebComponent.getHtml(getCronEditorBean(), TIMESHEET_SUBSCRIPTION_PREFIX);
        this.groups = new GroupValuesGenerator().getValues(ImmutableMap.of("User", getLoggedInUser()));
        return SUCCESS;
    }

    private CronEditorBean getCronEditorBean() {
        if (cronEditorBean == null) {
            cronEditorBean = new CronExpressionParser().getCronEditorBean();
        }
        return cronEditorBean;
    }

    private void doScheduleValidation() {
        cronEditorBean = new CronEditorBean(TIMESHEET_SUBSCRIPTION_PREFIX, ActionContext.getParameters());
        final CronEditorWebComponent component = new CronEditorWebComponent();
        addErrorCollection(component.validateInput(cronEditorBean, "cron.editor.name"));
        if (!hasAnyErrors()) {
            JiraServiceContext serviceContext = getJiraServiceContext();
            cronExpression = component.getCronExpressionFromInput(cronEditorBean);
            cronTrigger = validateAndCreateCronTrigger(serviceContext, cronExpression);
        }
    }

    /**
     * Validate and create {@link CronTrigger} using expr. Errors are passed
     * back via the context
     * 
     * @param context
     *            jira service context
     * @param expr
     *            the Cron Expression to validate and turn into trigger
     * @return null if error occurs during creation
     */
    private CronTrigger validateAndCreateCronTrigger(
            JiraServiceContext context, String expr) {
        CronTrigger trigger = null;
        try {
            trigger = new CronTrigger("temp", "temp", expr);
            // Test the trigger by calculating next fire time. This will catch
            // some extra errors
            final Date nextFireTime = trigger.getFireTimeAfter(null);
            if (nextFireTime == null) {
                String str = getText("filter.subsription.cron.errormessage.filter.never.run", expr);
                context.getErrorCollection().addErrorMessage(str);
            }
        } catch (ParseException e) { // Generally known validations problems
            errorMapper.mapError(context, e);
        } catch (IllegalArgumentException e) { // Null expression
            log.info("Cron expression was null. Probably the 'dailyWeeklyMonthly' request param was invalid", e);
            context.getErrorCollection().addErrorMessage(getText("filter.subsription.cron.errormessage.mode.error"));
        } catch (Exception e) {// Unknown validation problems.
            log.info("Unknown error when validating cron expression", e);
            context.getErrorCollection().addErrorMessage(getText("filter.subsription.cron.errormessage.general.error", expr));
        }

        return trigger;

    }

    public String doUpdate() throws Exception {
        doScheduleValidation();
        if (hasAnyErrors()) {
            return INPUT;
        } else if (!licenseUtil.isLicenseValid()) {
            statusMessage = getText(licenseUtil.getLicenseStatus(false) + ".text",
                    licenseUtil.getLicenseMgmtUrl(request.getContextPath()));
            addErrorMessage(statusMessage);
            return INPUT;
        } 
        TimesheetJobConfiguration jobConfiguration;
        if (key != null) {
            // we have a subscription id so we are editing it
            jobConfiguration = timesheetJobConfigurationManager.getJobConfiguration(getLoggedInUser(), key);
            final Map<String, List<String>> queryParams = TextUtil.getQueryParams("?" + jobConfiguration.getParams());
            addParam(queryParams, PARAM_CC_USER_GROUP, this.ccUserGroup);
            addParam(queryParams, PARAM_REMIND_GROUP, this.remindGroup);
            jobConfiguration = timesheetJobConfigurationManager.updateJobConfiguration(
                    getLoggedInUser(), key, cronExpression, getReportQueryString(queryParams, getI18nHelper()));
            if (jobConfiguration == null) {
                statusMessage = getText("timesheet.subscriptions.error.jobNotFound");
                return INPUT;
            }

        } else {
            // no subscription id so we are creating a new one
            jobConfiguration = timesheetJobConfigurationManager.addJobConfiguration(getLoggedInUser(),
                    TimesheetAdapter.REPORT_KEY,
                    getReportQueryString(queryParams, getI18nHelper()),
                    cronExpression);
            if (jobConfiguration == null) {
                statusMessage = getText("timesheet.subscriptions.error.jobNotFound");
                return INPUT;
            }
        }
        timesheetJobScheduler.schedule(jobConfiguration, cronTrigger);
        return forceRedirect("TimesheetSubscriptions!default.jspa?key="
                + TextUtil.urlencode(jobConfiguration.getKey()));
    }

    private TimesheetAdapter getTimeshetAdapter() {
        if (timesheetAdapter == null) {
            timesheetAdapter = new TimesheetAdapter(timeZoneManager,
                    dateTimeFormatterFactory);
        }
        return timesheetAdapter;
    }

    public String doDelete() {
        if (!licenseUtil.isLicenseValid()) {
            statusMessage = getText(licenseUtil.getLicenseStatus(false) + ".text",
                    licenseUtil.getLicenseMgmtUrl(request.getContextPath()));
            addErrorMessage(statusMessage);
            return INPUT;
        } else if (key == null || key.isEmpty()) {
            statusMessage = getText("timesheet.subscriptions.error.noReportKey");
            addError("reportKey", statusMessage);
            return ERROR;
        } else if (!key.startsWith(TimesheetAdapter.REPORT_KEY)) {
            statusMessage = getText("timesheet.subscriptions.error.notTimesheetReportKey");
            addError("reportKey", statusMessage);
            return ERROR;
        } else {
            timesheetJobConfigurationManager.removeJobConfiguration(getLoggedInUser(), key);
            return forceRedirect("TimesheetSubscriptions!default.jspa");
        }
    }

    private CronTrigger getDefaultTrigger() {
        String reportingDay = getStringParam(queryParams, "reportingDay");
        if (reportingDay.equals("0")) {
            reportingDay = "*"; // every day
        }
        final String expr = "0 0 8 ? * " + reportingDay; // 8am at reportingDay
        try {
            return new CronTrigger("temp", "temp", expr);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    public String doSubscribe() throws Exception {
        doValidation();
        if (hasAnyErrors()) {
            return BLANK;
        } else if (!licenseUtil.isLicenseValid()) {
            statusMessage = getText(licenseUtil.getLicenseStatus(false) + ".text",
                    licenseUtil.getLicenseMgmtUrl(request.getContextPath()));
            addErrorMessage(statusMessage);
            return BLANK;
        } 
        final String queryString = getReportQueryString(queryParams, getI18nHelper());
        final CronTrigger defaultTrigger = getDefaultTrigger();
        final TimesheetJobConfiguration jobConfiguration = timesheetJobConfigurationManager
                .addJobConfiguration(getLoggedInUser(),
                        TimesheetAdapter.REPORT_KEY, queryString, defaultTrigger.getCronExpression());
        timesheetJobScheduler.schedule(jobConfiguration, defaultTrigger);
        statusMessage = OK;
        return BLANK;
    }

    public String doUnsubscribe() throws Exception {
        doValidation();
        if (hasAnyErrors()) {
            return BLANK;
        } else if (!licenseUtil.isLicenseValid()) {
            statusMessage = getText(licenseUtil.getLicenseStatus(false) + ".text",
                    licenseUtil.getLicenseMgmtUrl(request.getContextPath()));
            addErrorMessage(statusMessage);
            return BLANK;
        } 
        final String queryString = getReportQueryString(queryParams, getI18nHelper());
        timesheetJobConfigurationManager.removeJobConfiguration(
                getLoggedInUser(), TimesheetAdapter.REPORT_KEY, queryString);
        statusMessage = OK;
        return BLANK;
    }

    public static String getReportQueryString(
            final Map<String, List<String>> queryParams, final I18nHelper i18n) {
        queryParams.remove("Next"); // cleanup
        queryParams.remove("selectedProjectId"); // cleanup
        queryParams.remove("reportKey"); // cleanup

        final boolean monthView = getBooleanParam(queryParams, "monthView");
        final TimeZone timezone = TimeZone.getDefault(); // FIXME: user timezone
        int reportingDay = getIntParam(queryParams, "reportingDay", monthView ? Calendar.getInstance(timezone, i18n.getLocale()).getFirstDayOfWeek() : 0 /* today */);
        final EnumSet<Options> options = EnumSet.noneOf(TimeBase.Options.class);
        final Date endDate = TimeBase.getEndDate(queryParams, i18n, timezone, options, reportingDay);
        final Date startDate = TimeBase.getStartDate(queryParams, i18n, endDate, timezone, options);
        queryParams.remove("startDate");
        queryParams.remove("endDate");

        final long numOfWeeks = CalendarUtil.getNumOfWeeks(startDate, endDate, monthView);
        addParam(queryParams, "numOfWeeks", "" + numOfWeeks);

        if (reportingDay == 0) {
            Calendar today = Calendar.getInstance();
            CalendarUtil.roundDate(today);
            today.add(Calendar.DAY_OF_WEEK, 1); // TimeBase.getEndDate adds 1 day
            Calendar endDateC = Calendar.getInstance();
            endDateC.setTime(endDate);
            if (!today.equals(endDateC)) {
                reportingDay = endDateC.get(Calendar.DAY_OF_WEEK);
            }
        }
        addParam(queryParams, "reportingDay", "" + reportingDay);
        return TextUtil.toQueryParams(queryParams);
    }

    public String getStatusMessageHtml() {
        return statusMessage;
    }

    public void setConfigureUrl(String configureUrl) {
        this.configureUrl = configureUrl;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public List<Map<String, Object>> getTimesheetJobConfigurations() {
        TimesheetJobConfiguration[] jobConfigurations = timesheetJobConfigurationManager
                .getJobConfigurations(getLoggedInUser(), TimesheetAdapter.REPORT_KEY);
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>(jobConfigurations.length);
        for (TimesheetJobConfiguration jobConfiguration : jobConfigurations) {
            Map<String, Object> map = new HashMap<String, Object>();
            String params = jobConfiguration.getParams();
            Map<String, List<String>> queryParams = TextUtil.getQueryParams("?" + params);
            for (String name : queryParams.keySet()) {
                List<String> param = queryParams.get(name);
                if (name.equals("reportingDay")) {
                    map.put(getText("portlet.timesheet.reportingDay.label"),
                            getText("report.timesheet.weekdays." + param.get(0)));
                } else if (name.equals(PARAM_TARGET_USER)) {
                    map.put(getText("report.timesheet.targetuser"), getUserDisplayName(param.get(0)));
                } else if (name.equals(PARAM_TARGET_GROUP)) {
                    map.put(getText("report.timesheet.targetgroup"), TextUtil.toComaSeparatedString(param));
                } else if (name.equals("excludeTargetGroup")) {
                    map.put(getText("report.timesheet.excludetargetgroup"), TextUtil.toComaSeparatedString(param));
                } else if (name.equals("priority")) {
                    map.put(getText("report.timesheet.priority.label"),
                            getConstantsManager().getPriorityName(param.get(0)));
                } else if (name.equals(PARAM_PROJECT_ID)) {
                    map.put(getText("report.timesheet.project.label"), getProjectName(param.get(0)));
                } else if (name.equals("filterid")) {
                    map.put(getText("report.timesheet.filterid.name"), getFilterName(param.get(0)));
                } else if (name.equals(PARAM_PROJECT_ROLE_ID)) {
                    map.put(getText("report.timesheet.projectroleid.name"), getRoleName(param.get(0)));
                } else if (name.equals("weekends") && Boolean.valueOf(param.get(0))) {
                    map.put(getText("report.timesheet.weekends.label"), getText("gadget.timesheet.yes"));
                } else if (name.equals("showDetails") && Boolean.valueOf(param.get(0))) {
                    map.put(getText("report.timesheet.showdetails.label"), getText("gadget.timesheet.yes"));
                } else if (name.equals("monthView") && Boolean.valueOf(param.get(0))) {
                    map.put(getText("report.timesheet.monthView.label"), getText("gadget.timesheet.yes"));
                } else if (name.equals("sumSubTasks") && Boolean.valueOf(param.get(0))) {
                    map.put(getText("report.pivot.sumsubtasks"), getText("gadget.timesheet.yes"));
                } else if (name.equals("groupByField")) {
                    map.put(getText("report.timesheet.groupbyfield.label"), getFieldName(param.get(0)));
                } else if (name.equals("moreFields")) {
                    map.put(getText("report.timesheet.morefields.label"), getFieldNames(param));
                }
            }
            map.put("key", jobConfiguration.getKey());
            map.put("raw", params);
            list.add(map);
        }
        return list;
    }

    private String getFieldNames(List<String> fieldIds) {
        List<String> result = new ArrayList<String>(fieldIds.size());
        for (String fieldId : fieldIds) {
            result.add(TextUtil.getFieldName(fieldId));
        }
        return TextUtil.toComaSeparatedString(result);
    }

    private String getFieldName(String fieldId) {
        return TextUtil.getFieldName(fieldId);
    }

    private String getRoleName(String roleId) {
        Long id = new Long(roleId);
        ProjectRole projectRole = getProjectRoleManager().getProjectRole(id);
        return projectRole != null ? projectRole.getName() : roleId;
    }

    private ProjectRoleManager getProjectRoleManager() {
        if (projectManager == null) {
            projectManager = ComponentManager.getComponentInstanceOfType(ProjectRoleManager.class);
        }
        return projectManager;
    }

    private String getFilterName(String filterId) {
        final Long id = new Long(filterId);
        final SearchRequest filter = getSearchRequestService().getFilter(getJiraServiceContext(), id);
        return filter != null ? filter.getName() : filterId;
    }

    private SearchRequestService getSearchRequestService() {
        if (searchRequestService == null) {
            searchRequestService = ComponentAccessor.getComponent(SearchRequestService.class);
        }
        return searchRequestService;
    }

    private String getProjectName(String projectId) {
        final Long id = new Long(projectId);
        final Project project = getProjectManager().getProjectObj(id);
        // TODO Auto-generated method stub
        return project != null ? project.getName() : projectId;
    }

    private String getUserDisplayName(String username) {
        final User user = getUserManager().getUser(username);
        return user != null ? user.getDisplayName() : username;
    }

    public String getGeneratedReportHtml() {
        return generatedReportHtml;
    }

    public String getCronEditorHtml() {
        return cronEditorHtml;
    }

    public String getCcUserGroup() {
        return ccUserGroup;
    }

    public void setCcUserGroup(String ccUserGroup) {
        this.ccUserGroup = ccUserGroup;
    }

    public String getRemindGroup() {
        return remindGroup;
    }

    public void setRemindGroup(String remindGroup) {
        this.remindGroup = remindGroup;
    }

    public Map<String, String> getGroups() {
        return groups;
    }

    public static void addParam(Map<String, List<String>> queryParams, String name, String value) {
        final List<String> paramValue = new ArrayList<String>(1);
        paramValue.add(value);
        queryParams.put(name, paramValue);
    }
}
