package jira.timesheet.plugin.configuration;

import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.fdu.jira.util.ILicenseUtil;

public abstract class ConfigurationActionBase extends JiraWebActionSupport {

    private static final long serialVersionUID = 3904641388973681649L;
    private final ILicenseUtil licenseUtil;

    public ConfigurationActionBase(ILicenseUtil licenseUtil) {
        this.licenseUtil = licenseUtil;
    }

    protected String validateAdminAction(String predictedAction) {
        if (!licenseUtil.isLicenseValid()) {
            return redirectToLicense();
        } else {
            return predictedAction;
        }
    }

    private String redirectToLicense() {
        return getRedirect(licenseUtil.getLicenseMgmtUrl(""));
    }
}
