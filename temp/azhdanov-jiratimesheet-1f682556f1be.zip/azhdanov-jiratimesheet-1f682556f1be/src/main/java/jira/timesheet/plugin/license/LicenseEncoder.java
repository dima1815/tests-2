package jira.timesheet.plugin.license;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * LicenseEncoder allows to encode and decode license in following format:
 * <pre>| secret key encrypted with rsa private key | data encrypted with the secret key |</pre>
 * 
 * To encode license, use:
 * 
 * <pre>java -cp target/classes/ jira.timesheet.plugin.license.LicenseEncoder private.der license</pre>
 * 
 * Alternatively:
 * <pre>
 * Gen random key:
 *   openssl rand -out key 16
 * 
 * Encrypt key:
 *   openssl rsautl -sign -inkey private.pem -in key -out key.rsa
 * 
 * Encrypt license:
 *   openssl enc -aes-128-ecb -K `hexdump -e '16/1 "%02x""\n"' key` -in license -out data.aes
 * 
 * Encode in base64:
 *   cat key.rsa data.aes | openssl enc -base64
 * </pre>
 * 
 * Based on
 * <ul>
 * <li>http://sigpipe.macromates.com/2004/09/05/using-openssl-for-license-keys/</li>
 * <li>http://docs.oracle.com/javase/tutorial/security/apisign/index.html</li>
 * <li>http://stackoverflow.com/questions/1391692/encrypting-with-rsa-private-key-in-java</li>
 * <li>http://stackoverflow.com/questions/7143514/how-to-encrypt-a-large-file-in-openssl-using-public-key</li>
 * </ul>
 * 
 */
public class LicenseEncoder {

    /*
     * To generate RSA private key and extract public key in java format in base64 encoding:
     *  
     *   openssl genrsa -out private.pem 512
     *   openssl rsa -in private.pem -outform DER -pubout | openssl enc -base64
     */
    static class Key {
        private final static String base64Key =
                "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANRmWbFmZ6gi+tsThP/kNez7WdN5WxQg"
                + "Gb0VpevO/0jXWksiEB21cxHZz5muocOTfH5UJXvvdZQYZTCHD35Pm9cCAwEAAQ==";

        public static String get() {
            return base64Key;
        }
    }

    private static final int PRIVATE_KEY_LENGTH = 64; // 512 bit
    private static final int KEY_LENGTH = 16; // 128 bit

    /*
     * To encrypt with RSA private key in java format:
     * 
     *   openssl pkcs8 -topk8 -nocrypt -in private.pem -outform der -out private.der
     *   java -cp target/classes/ jira.timesheet.plugin.license.LicenseEncoder private.der license
     */
    public static void main(String[] args) {

        if (args.length != 2) {
            System.out.println("Usage: LicenseEncoder privateKey licenseFile\n"
                    + "    Where privateKey must be in DER format and may be generated as follows:\n"
                    + "\topenssl genrsa -out private.pem 512\n"
                    + "\topenssl pkcs8 -topk8 -nocrypt -in private.pem -outform der -out private.der\n"
                    + "    Then update public key in base64Key field, which can be obtained with:\n"
                    + "\topenssl rsa -in private.pem -outform DER -pubout | openssl enc -base64");
        } else try{
            /* read private key for asymmetric cipher */
            FileInputStream keyfis = new FileInputStream(args[0]);
            byte[] encKey = new byte[keyfis.available()];  
            keyfis.read(encKey);
            keyfis.close();

            KeySpec privKeySpec = new PKCS8EncodedKeySpec(encKey);

            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PrivateKey privKey = keyFactory.generatePrivate(privKeySpec);

            Cipher asymmetricCipher = Cipher.getInstance("RSA");
            asymmetricCipher.init(Cipher.ENCRYPT_MODE, privKey);

            /* generate secret key for symmetric cipher */
            SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
            byte[] key = new byte[KEY_LENGTH];
            random.nextBytes(key);

            /* encrypt secret key with private key */
            byte[] encryptedKey = asymmetricCipher.doFinal(key);

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            outputStream.write(encryptedKey);

            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");        
            Cipher symmetricCipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            symmetricCipher.init(Cipher.ENCRYPT_MODE, keySpec);

            /* encrypt data */
            FileInputStream datafis = new FileInputStream(args[1]);
            BufferedInputStream bufin = new BufferedInputStream(datafis);
            byte[] buffer = new byte[1024];
            int len;

            CipherOutputStream cipherOutputStream = new CipherOutputStream(outputStream, symmetricCipher);
            while (bufin.available() != 0) {
                len = bufin.read(buffer);
                cipherOutputStream.write(buffer, 0, len);
            };

            cipherOutputStream.close();
            outputStream.close();
            bufin.close();

            byte[] encryptedData = outputStream.toByteArray();
            
            BASE64Encoder base64Encoder = new BASE64Encoder();
            System.out.println(base64Encoder.encode(encryptedData));

        } catch (Exception e) {
            System.err.println("Error: " + e.toString());
        }
    }

    /**
     * Decodes base64 encoded data in the following format:
     * <pre>| secret key encrypted with rsa private key | data encrypted with the secret key |</pre>
     * 
     * @throws IOException 
     */
    public static byte[] decode(String base64Data) throws Exception {

        BASE64Decoder base64Decoder = new BASE64Decoder();
        byte[] encKey = base64Decoder.decodeBuffer(Key.get());

        KeySpec pubKeySpec = new X509EncodedKeySpec(encKey);

        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey pubKey = keyFactory.generatePublic(pubKeySpec);

        Cipher asymmetricCipher = Cipher.getInstance("RSA");
        asymmetricCipher.init(Cipher.DECRYPT_MODE, pubKey);

        byte[] decodedData = base64Decoder.decodeBuffer(base64Data);

        byte[] key = asymmetricCipher.doFinal(decodedData, 0, PRIVATE_KEY_LENGTH);

        SecretKeySpec keySpec = new SecretKeySpec(key, "AES");        
        Cipher symmetricCipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        symmetricCipher.init(Cipher.DECRYPT_MODE, keySpec);

        return symmetricCipher.doFinal(decodedData, PRIVATE_KEY_LENGTH, decodedData.length - PRIVATE_KEY_LENGTH);
    }

}
