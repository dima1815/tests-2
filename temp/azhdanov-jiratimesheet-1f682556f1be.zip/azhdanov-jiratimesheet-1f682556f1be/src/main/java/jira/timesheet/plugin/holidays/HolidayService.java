package jira.timesheet.plugin.holidays;

import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.fdu.jira.util.IcalUtils;
import com.google.common.base.Throwables;
import net.fortuna.ical4j.data.CalendarBuilder;
import net.fortuna.ical4j.data.ParserException;
import net.fortuna.ical4j.model.Component;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * Holiday service allows to retrieve holiday by name and import holidays in ics
 * format by URL or InputStrem.
 * <p>
 * It also loads earlier saved holidays for backward compatibility. If holiday name is
 * not defined {@link #BANK_HOLIDAY} will be used as holiday name.
 * </p>
 * Things to consider: 0) Holidays for user viewing the report or holidays for
 * user reported worked log? 1) No holidays calendar in java -
 * http://www.javaworld.com/javaworld/javatips/jw-javatip44.html 2)
 * holidaywebservice.com - for .net, or www.bank-holidays.com - no service api?
 * 3) http://www.codeproject.com/Articles/18261/Working-with-date-time-patterns
 * 4) http://static.springsource.org/spring/docs/3.0.x/javadoc-api/org/
 * springframework/scheduling/support/CronSequenceGenerator.html
 * 
 * @since 2.6
 */
public class HolidayService {

    public static final String BANK_HOLIDAY = "Bank holiday";

    protected HolidayManager holidayManager;

    public HolidayService(HolidayManager holidayManager) {
        this.holidayManager = holidayManager;
    }

    public String getHolidayName(Calendar calendar) {

        String holidayName = null;

        final Holiday holiday = holidayManager.getHoliday(new HolidayDate(calendar));
        if (holiday != null) {
            holidayName = StringUtils.isNotBlank(holiday.getName())
                    ? holiday.getName()
                    : BANK_HOLIDAY;
        } else {
            holidayName = getHolidays().get(calendar.getTime());
        }
        return holidayName;
    }

    /**
     * Imports holidays from the specified URL.
     */
    public void importHolidays(final String urlString) throws HolidayImportException {
        try {
            if (StringUtils.isBlank(urlString)) {
                throw new HolidayImportException("error.timesheet.holidays.blankUrl");
            }

            // webcal is just an unofficial synonym for http 
            String httpUrl;
            if (urlString.startsWith("webcal:")) {
                httpUrl = urlString.replaceFirst("^.+?:", "http:");
            } else {
                httpUrl = urlString;
            }

            final URL url = new URL(httpUrl);

            final URLConnection conn = url.openConnection();

            importHolidays(conn.getInputStream());
        }
        catch (MalformedURLException mue) {
            throw new HolidayImportException("error.timesheet.holidays.badlyFormedUrl", urlString);
        }
        catch (UnknownHostException uhe) {
            throw new HolidayImportException("error.timesheet.holidays.unknownHost", uhe.getMessage());
        }
        catch (FileNotFoundException fnfe) {
            throw new HolidayImportException("error.timesheet.holidays.fileNotFound", fnfe.getMessage());
        }
        catch (HolidayImportException e) {
            throw e;
        } catch (Throwable e) {
            throw new HolidayImportException("error.timesheet.holidays.unexpected", e.getMessage());
        }
    }

    /**
     * Imports holidays from the specified file.
     */
    public void importHolidays(final File file) throws HolidayImportException {
        try {
            importHolidays(new FileInputStream(file));
        }
        catch (FileNotFoundException e) {
            throw new HolidayImportException("error.timesheet.holidays.fileNotExists", file.getName());
        }
        catch (Exception e) {
            Throwables.propagateIfInstanceOf(e, HolidayImportException.class);
        }
    }

    protected void importHolidays(InputStream stream) throws HolidayImportException {
        try {
            final CalendarBuilder builder = new CalendarBuilder();

            final net.fortuna.ical4j.model.Calendar calendar = builder.build(stream);

            for (Object o : calendar.getComponents()) {
                final Component component = (Component) o;
                final String holidayName = IcalUtils.readValue(component, "SUMMARY");
                final String fromString = IcalUtils.readValue(component, "DTSTART");
                final String toString = IcalUtils.readValue(component, "DTEND");
                final String rRule = IcalUtils.readValue(component, "RRULE");

                final SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
                Date from = format.parse(fromString);
                Date to = format.parse(toString);

                HolidayDate holidayDate = getHolidayDateFromString(fromString);

                final boolean repeatedHoliday = IcalUtils.isYearlyRRule(rRule);

                // loop is for more than 1 day holidays
                while (!DateUtils.isSameDay(from, to)) {
                    if (repeatedHoliday) {
                        holidayDate.setYear(null);
                    }
                    holidayManager.addHoliday(holidayDate, holidayName);
                    from = DateUtils.addDays(from, 1);
                    holidayDate = getHolidayDate(from);
                }
            }
        }
        catch (IOException ioe) {
            throw new HolidayImportException("error.timesheet.holidays.readError", ioe.getMessage());
        }
        catch (ParserException pe) {
            throw new HolidayImportException("error.timesheet.holidays.parseError", pe.getMessage());
        }
        catch (Exception e) {
            Throwables.propagateIfInstanceOf(e, HolidayImportException.class);
        }
    }

    protected HolidayDate getHolidayDate(Date date) {
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return new HolidayDate(calendar);
    }

    protected HolidayDate getHolidayDateFromString(String value) {
        final Integer year = Integer.valueOf(StringUtils.substring(value, 0, 4));
        final Integer month = Integer.valueOf(StringUtils.substring(value, 4, 6));
        final Integer day = Integer.valueOf(StringUtils.substring(value, 6, 8));
        return new HolidayDate(year, month, day);
    }

    private static Map<Date, String> holidays;
    private static final Logger log = Logger.getLogger(HolidayService.class);
    /*
     * @deprecated backward compatibility, since 2.6
     */
    @Deprecated
    private static Map<Date, String> getHolidays() {
        if (holidays == null) {
            synchronized (HolidayService.class) {
                if (holidays == null) {
                    holidays = new TreeMap<Date, String>();
                    ApplicationProperties ap = ComponentManager.getComponentInstanceOfType(ApplicationProperties.class);
                    String p = ap.getDefaultBackedString("jira.timesheet.plugin.holidays");
                    if (p == null) {
                        log.debug("There is no 'jira.timesheet.plugin.holidays' application property set");
                        return holidays;
                    }

                    Locale locale;
                    String localeStr = ap.getDefaultBackedString("jira.i18n.default.locale");
                    if (localeStr != null) {
                        locale = new Locale(localeStr);
                    } else {
                        locale = Locale.getDefault();
                    }
                    log.debug("Using " + locale.getDisplayName() + " locale for parsing holidays");
                    
                    String formatStr = ap.getDefaultBackedString("jira.lf.date.dmy");
                    log.debug("Using " + formatStr + " holidays date format");
                    DateFormat df = new SimpleDateFormat(formatStr, locale);
                    

                    String[] s = p.split(",");
                    for (int i = 0; i < s.length; i++) {
                        String[] t = s[i].split("-");
                        try {
                            Date date = df.parse(t[0].trim());
                            String name = t.length == 2 ? t[1].trim() : "Bank holiday";
                            holidays.put(date, name);
                        } catch (Exception e) {
                            log.warn("Can't parse holiday: " + s[i], e);
                            continue;
                        }
                    }
                }
            }
        }
        return holidays;
    }
}
