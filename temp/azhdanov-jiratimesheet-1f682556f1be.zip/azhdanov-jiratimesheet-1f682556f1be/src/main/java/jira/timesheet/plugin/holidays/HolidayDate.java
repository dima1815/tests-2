package jira.timesheet.plugin.holidays;

import java.util.Calendar;

public class HolidayDate {

    protected Integer year;
    protected Integer month;
    protected Integer day;

    public HolidayDate(Integer year, Integer month, Integer day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public HolidayDate(Calendar date) {
        this.year = date.get(Calendar.YEAR);
        this.month = date.get(Calendar.MONTH) + 1;
        this.day = date.get(Calendar.DAY_OF_MONTH);
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }
}
