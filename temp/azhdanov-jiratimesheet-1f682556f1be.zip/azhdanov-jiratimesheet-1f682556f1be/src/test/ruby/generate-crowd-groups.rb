require 'rubygems'
require 'httparty'
require 'json'

class Crowd
  include HTTParty
  base_uri "http://localhost:8095/crowd/rest/usermanagement/1"
  format :json
  headers({'Content-Type' => 'application/json', 'Accept' => 'application/json'})
  basic_auth('demo', 'demo')
  #debug_output($stderr)

  def self.auth(username, password)
    post("/authentication?username=#{username}", :body => {:value => password}.to_json)
  end

  def self.create_group(groupname)
    post("/group", :body => {:name => groupname, :type => :GROUP, :active => true}.to_json)
  end

end

#puts Crowd.auth("admin", "admin")
for i in 1..10000
  Crowd.create_group("test#{i}")
end
