gem 'json', '=1.7.6'
require 'rubygems'
require 'pp'
require 'jira'

# Generates a lot of issues.

# Install:
# gem install jira-ruby
#
# Prerequisites:
# atlas-run 
# 
# Make 'Story Points' custom field be available on 'Default Screen'
# see Administration - Custom Fields - Story Points - Screens
#
# Usage:
# ruby src/test/ruby/generate-issues.rb
#
# or
#
# for i in {1..1000}; do ruby src/test/ruby/generate-issues.rb; done

# TODO: set status to resolved to use with worklogs
# see jira-ruby support for transitions, https://github.com/trineo/jira-ruby/issues/24 

username = "admin"
password = "admin"

options = {
            :username => username,
            :password => password,
            :site     => 'http://localhost:2990/',
            :context_path => '/jira',
            :auth_type => :basic,
            :use_ssl => false, #running locally 
            :debug_output => false # $stderr #, see https://github.com/trineo/jira-ruby/issues/32
          }

client = JIRA::Client.new(options)

PROJECT_KEY = 'TIME' 

begin
  project = client.Project.find(PROJECT_KEY)
rescue
  puts "Project #{PROJECT_KEY} not found"
  exit
end

# Can't create project :(
# https://answers.atlassian.com/questions/24718/how-to-create-a-new-project-in-jira-using-the-rest-api
if (!project)
  project = client.Project.build
  fields = {:name => 'Time', :key => PROJECT_KEY}
  project.save!({:fields => fields})
end

puts "Project -> key: #{project.key}, name: #{project.name}"
create = [
  'Hocus Focus Problem',
  'Loch Ness Monster Bug',
  'Hindenbug',
  'Mega problem']

create.each { |c| 
  issue = client.Issue.build
  fields = {:summary => c, :project => {:id => project.id}, :issuetype => {:name => "Bug"}
  }
  issue.save!({:fields => fields})
  print '.'; $stdout.flush
}
puts
