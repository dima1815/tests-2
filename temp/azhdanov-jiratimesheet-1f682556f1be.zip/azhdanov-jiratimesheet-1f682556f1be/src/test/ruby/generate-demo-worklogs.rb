gem 'json', '>=1.7.6'
require 'rubygems'
require 'pp'
require 'jira'

# Generates random worklogs for all projects and issues.

# Install:
# gem install jira-ruby
#
# Prerequisites:
# atlas-run 
#
# Usage:
# ruby src/test/ruby/generate-worklogs.rb

username = "demo"
password = "demo123"

options = {
            :username => username,
            :password => password,
            :site     => 'https://timesheet-report-dev.jira-dev.com',
            :context_path => '',
            :auth_type => :basic,
            :use_ssl => true, #running locally 
            :debug_output => false # $stderr #, see https://github.com/sumoheavy/jira-ruby/issues/32
          }

client = JIRA::Client.new(options)

projects = client.Project.all

if projects.size == 0
  puts "No projects!"
end

projects.each do |project|
  puts "Project -> key: #{project.key}, name: #{project.name}"
  issues = project.issues
  if issues.size == 0
    puts "No issues, creating..."

    create = [
      'Hocus Focus Problem',
      'Loch Ness Monster Bug',
      'Hindenbug',
      'Mega problem']

    create.each { |c| 
      issue = client.Issue.build
      fields = {:summary => c, :project => {:id => project.id}, :issuetype => {:id => "3"}}
      issue.save!({:fields => fields})
    }
  end
  project.issues.each do |issue|
    timespent = issue.timespent || 0
    if issue.status.name != 'Closed'
      puts "Issue -> key: #{issue.key}, status: #{issue.status.name}"
      2.times {
        worklog = issue.worklogs.build
        started = (Date.today - 7 + rand(14)).to_time.strftime('%FT%T.000%z') #2012-09-29T00:00:00.000+0000
        timeSpentSeconds = ((rand 8) + 1) * 60 * 60
        puts "Worklog new -> started: #{started}, timeSpentSeconds: #{timeSpentSeconds}"
        worklog.save!(:started => started, :timeSpentSeconds => timeSpentSeconds, :comment => "test")
      }
    else
      puts "Issue -> key: #{issue.key}, timespent: #{timespent}, status: #{issue.status.name}"
    end
  end
end
