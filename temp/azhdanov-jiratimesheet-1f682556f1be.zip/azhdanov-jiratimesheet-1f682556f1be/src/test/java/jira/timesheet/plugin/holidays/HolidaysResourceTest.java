package jira.timesheet.plugin.holidays;

import jira.plugin.report.timesheet.AbstractTestCase;
import org.junit.Test;

import javax.ws.rs.core.Response;

import java.util.List;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class HolidaysResourceTest extends AbstractTestCase {

    protected HolidayManager holidayManager = mock(HolidayManager.class);

    protected HolidaysResource holidaysResource = new HolidaysResource(holidayManager);

    @Test
    public void test_getHolidays() {

        final Holiday holiday = mock(Holiday.class);
        when(holiday.getID()).thenReturn(7);
        when(holiday.getLocale()).thenReturn("ES");
        when(holiday.getName()).thenReturn("Holiday Name");
        when(holiday.getMonth()).thenReturn(3);
        when(holiday.getDay()).thenReturn(23);
        when(holiday.getYear()).thenReturn(null);

        final Integer year = 2013;
        when(holidayManager.findHolidays(year)).thenReturn(new Holiday[]{holiday});
        final Response response = holidaysResource.getHolidays(year);

        assertThat(response.getStatus(),
                is(Response.Status.OK.getStatusCode()));
        final Object entity = response.getEntity();
        assertNotNull(entity);
        assertThat(entity, instanceOf(List.class));
        @SuppressWarnings("unchecked")
        final List<HolidayRepresentation> list = (List<HolidayRepresentation>) entity;
        assertThat(list.size(), is(1));
        HolidayRepresentation representation = list.iterator().next();
        assertThat(representation.id, is(7));
        assertThat(representation.name, is("Holiday Name"));
        assertThat(representation.date, is("*-03-23"));
        assertThat(representation.locale, is("ES"));
    }
}