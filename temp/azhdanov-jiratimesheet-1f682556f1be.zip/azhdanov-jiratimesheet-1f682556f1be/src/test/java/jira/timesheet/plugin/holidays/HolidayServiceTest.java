package jira.timesheet.plugin.holidays;

import jira.plugin.report.timesheet.AbstractTestCase;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.internal.verification.VerificationModeFactory.times;

public class HolidayServiceTest extends AbstractTestCase {

    protected HolidayManager holidayManager = mock(HolidayManager.class);

    protected HolidayService holidayService = new HolidayService(holidayManager);

    @Test
    public void test_importHolidays_string_negative() {
        try {
            holidayService.importHolidays((String) null);
            fail();
        } catch (Exception e) {
            assertThat(e, instanceOf(HolidayImportException.class));
            assertThat(e.getMessage(), is("error.timesheet.holidays.blankUrl"));
        }

        try {
            holidayService.importHolidays("wrongProtocol://myUrl.com");
            fail();
        } catch (Exception e) {
            assertThat(e, instanceOf(HolidayImportException.class));
            assertThat(e.getMessage(), is("error.timesheet.holidays.badlyFormedUrl"));
        }

        try {
            holidayService.importHolidays("webcal://myWrongUrl.xxx.yyy/test");
            fail();
        } catch (Exception e) {
            assertThat(e, instanceOf(HolidayImportException.class));
            assertThat(e.getMessage(), is("error.timesheet.holidays.unknownHost"));
        }
    }

    @Test
    public void test_importHolidays_stream_negative() {
        try {
            holidayService.importHolidays(
                    IOUtils.toInputStream("something wrong"));
            fail();
        } catch (Exception e) {
            assertThat(e, instanceOf(HolidayImportException.class));
            assertThat(e.getMessage(), is("error.timesheet.holidays.parseError"));
        }

    }

    @Test
    public void test_importHolidays_stream_positive() {
        holidayService.importHolidays(
                IOUtils.toInputStream(
                        getCalendarContent()));

        verify(holidayManager, times(3))
                .addHoliday(any(HolidayDate.class), anyString());
    }

    @SuppressWarnings("StringBufferReplaceableByString")
    protected String getCalendarContent() {
        return new StringBuilder()
                .append("BEGIN:VCALENDAR\n")
                .append("PRODID:-//Calendar Labs//Calendar 1.0//EN\n")
                .append("VERSION:2.0\n")
                .append("CALSCALE:GREGORIAN\n")
                .append("METHOD:PUBLISH\n")
                .append("X-WR-CALNAME:USA Holidays\n")
                .append("X-WR-TIMEZONE:America/New_York\n")

                .append("BEGIN:VEVENT\n")
                .append("DTSTART;VALUE=DATE:20120101\n")
                .append("RRULE:FREQ=YEARLY;INTERVAL=1\n")
                .append("DTEND;VALUE=DATE:20120103\n")
                .append("DTSTAMP:20111213T124028Z\n")
                .append("UID:72a768f20220b156b9132b5d1@calendarlabs.com\n")
                .append("CREATED:20111213T123901Z\n")
                .append("DESCRIPTION:Visit http://www.calendarlabs.com/holidays/ to know more about New Year's Day and for any other calendar needs.\n")
                .append("LAST-MODIFIED:20111213T123901Z\n")
                .append("LOCATION:\n")
                .append("SEQUENCE:0\n")
                .append("STATUS:CONFIRMED\n")
                .append("SUMMARY:New Year's Day\n")
                .append("TRANSP:TRANSPARENT\n")
                .append("END:VEVENT\n")

                .append("BEGIN:VEVENT\n")
                .append("DTSTART;VALUE=DATE:20120116\n")
                .append("DTEND;VALUE=DATE:20120117\n")
                .append("DTSTAMP:20111213T124028Z\n")
                .append("UID:782d4b0140efaefcbf3dc99e5@calendarlabs.com\n")
                .append("CREATED:20111213T123901Z\n")
                .append("DESCRIPTION:Visit http://www.calendarlabs.com/holidays/ to know more about M L King Day and for any other calendar needs.\n")
                .append("LAST-MODIFIED:20111213T123901Z\n")
                .append("LOCATION:\n")
                .append("SEQUENCE:0\n")
                .append("STATUS:CONFIRMED\n")
                .append("SUMMARY:M L King Day\n")
                .append("TRANSP:TRANSPARENT\n")
                .append("END:VEVENT\n")

                .append("END:VCALENDAR\n")
                .toString();
    }
}
