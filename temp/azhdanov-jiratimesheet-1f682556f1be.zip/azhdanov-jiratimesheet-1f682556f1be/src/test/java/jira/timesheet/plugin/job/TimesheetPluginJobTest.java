package jira.timesheet.plugin.job;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.bc.filter.SearchRequestService;
import com.atlassian.jira.bc.issue.util.VisibilityValidator;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.jira.datetime.DateTimeFormatter;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.datetime.DateTimeStyle;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.link.IssueLinkManager;
import com.atlassian.jira.issue.search.SearchProvider;
import com.atlassian.jira.issue.worklog.WorklogManager;
import com.atlassian.jira.mock.component.MockComponentWorker;
import com.atlassian.jira.plugin.report.ReportModuleDescriptor;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.user.util.UserUtil;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.web.FieldVisibilityManager;
import com.atlassian.jira.web.action.ProjectActionSupport;
import com.atlassian.mail.queue.MailQueue;
import com.atlassian.mail.queue.MailQueueItem;
import com.atlassian.plugin.ModuleDescriptor;
import com.atlassian.plugin.PluginAccessor;
import com.atlassian.upm.license.storage.lib.ThirdPartyPluginLicenseStorageManager;
import com.fdu.jira.plugin.report.timesheet.TimeSheet;
import jira.plugin.report.timesheet.TimesheetService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Trigger;

import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest(ComponentManager.class)
public class TimesheetPluginJobTest {
    User remoteUser;
    TimeZone timezone;
    I18nHelper i18n;
    UserManager userManager;
    TimeZoneManager timeZoneManager;
    IssueLinkManager issueLinkManager;
    ApplicationProperties applicationProperties;
    JiraAuthenticationContext authenticationContext;
    DateTimeFormatterFactory dateTimeFormatterFactory;
    FieldVisibilityManager fieldVisibilityManager;
    ThirdPartyPluginLicenseStorageManager licenseManager;
    PermissionManager permissionManager;
    WorklogManager worklogManager;
    IssueManager issueManager;
    SearchProvider searchProvider;
    VisibilityValidator visibilityValidator;
    UserUtil userUtil;
    SearchRequestService searchRequestService;
    ProjectRoleManager projectRoleManager;
    TimesheetService timesheetService;
    ProjectManager projectManager;
    ActiveObjects ao;
    MailQueue mailQueue;

    TimeSheet timeSheetReport;

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Before
    public void setup() throws Exception {

        userManager = mock(UserManager.class);
        timeZoneManager = mock(TimeZoneManager.class);
        issueLinkManager = mock(IssueLinkManager.class);
        applicationProperties = mock(ApplicationProperties.class);
        authenticationContext = mock(JiraAuthenticationContext.class);
        mailQueue = mock(MailQueue.class);
        dateTimeFormatterFactory = mock(DateTimeFormatterFactory.class);
        userUtil = mock(UserUtil.class);

        PluginAccessor pluginAccessor = mock(PluginAccessor.class);
        ComponentAccessor.initialiseWorker(new MockComponentWorker()
                .addMock(PluginAccessor.class, pluginAccessor)
                .addMock(UserManager.class, userManager)
                .addMock(JiraAuthenticationContext.class, authenticationContext)
                .addMock(MailQueue.class, mailQueue)
                .addMock(TimeZoneManager.class, timeZoneManager)
                .addMock(UserUtil.class, userUtil));

        // for test
        remoteUser = mock(User.class);
        when(remoteUser.getEmailAddress()).thenReturn("admin@example.com");
        when(userManager.getUser(anyString())).thenReturn(remoteUser);
        when(userUtil.getUser(anyString())).thenReturn(remoteUser);
        timezone = TimeZone.getDefault();
        i18n = mock(I18nHelper.class);
        ao = mock(ActiveObjects.class);

        when(authenticationContext.getI18nHelper()).thenReturn(i18n);
        when(timeZoneManager.getLoggedInUserTimeZone()).thenReturn(timezone);
        
        when(applicationProperties.getDefaultBackedString("jira.timesheet.plugin.composeIssueLink")).thenReturn("Compose");
        when(applicationProperties.getDefaultBackedString("jira.timesheet.plugin.isComposeIssueLinkTransitive")).thenReturn("true");
        
        timesheetService = mock(TimesheetService.class);
        timeSheetReport = mock(TimeSheet.class);
        when(timeSheetReport.generateReportHtml(Matchers.<ProjectActionSupport>anyObject(), Matchers.<Map>anyObject())).thenReturn("Hello world");
        ReportModuleDescriptor reportModuleDescriptor = mock(ReportModuleDescriptor.class);
        when(reportModuleDescriptor.getModule()).thenReturn(timeSheetReport);
        when(pluginAccessor.getEnabledPluginModule(anyString())).thenReturn((ModuleDescriptor) reportModuleDescriptor);
        
        DateTimeFormatter formatter = mock(DateTimeFormatter.class);
        when(dateTimeFormatterFactory.formatter()).thenReturn(formatter);
        when(formatter.forLoggedInUser()).thenReturn(formatter);
        when(formatter.withZone(Matchers.<TimeZone>anyObject())).thenReturn(formatter);
        when(formatter.withStyle(DateTimeStyle.DATE_PICKER)).thenReturn(formatter);
        
        // for TextUtil
        PowerMockito.mockStatic(ComponentManager.class);
        when(ComponentManager.getComponentInstanceOfType(ApplicationProperties.class)).thenReturn(applicationProperties);
        when(ComponentManager.getComponentInstanceOfType(JiraAuthenticationContext.class)).thenReturn(authenticationContext);
        when(applicationProperties.getDefaultBackedString("jira.timetracking.hours.per.day")).thenReturn("8");
        when(applicationProperties.getDefaultBackedString("jira.timetracking.days.per.week")).thenReturn("5");

        TimesheetJobConfigurationManager tjcm = new TimesheetJobConfigurationManagerImpl(ao);
        when(ComponentManager.getOSGiComponentInstanceOfType(TimesheetJobConfigurationManager.class)).thenReturn(tjcm);
        when(ComponentManager.getComponent(DateTimeFormatterFactory.class)).thenReturn(dateTimeFormatterFactory);
        when(ComponentManager.getOSGiComponentInstanceOfType(ITimesheetJobScheduler.class)).thenReturn(new TimesheetJobScheduler(tjcm));

        when(i18n.getLocale()).thenReturn(Locale.getDefault());
    }

    private TimesheetJobConfiguration getMockConfig(String username) {
        TimesheetJobConfiguration mock = mock(TimesheetJobConfiguration.class);
        when(mock.getUsername()).thenReturn(username);
        when(mock.getKey()).thenReturn("test");
        when(mock.getParams()).thenReturn("reportinDay=0");
        return mock;
    }

    @Test
    public void testQueueEmail() throws JobExecutionException {
        TimesheetJob pluginJob = new TimesheetJob();
        JobExecutionContext context = mock(JobExecutionContext.class);
        Trigger trigger = mock(Trigger.class);
        when(trigger.getName()).thenReturn(TimesheetJobScheduler.SUBSCRIPTION_PREFIX + "1");
        when(context.getTrigger()).thenReturn(trigger);
        TimesheetJobConfiguration config = getMockConfig("admin");
        when(ao.get(TimesheetJobConfiguration.class, 1)).thenReturn(config);
        pluginJob.execute(context);
        verify(mailQueue).addItem(any(MailQueueItem.class));
    }
}
