package jira.timesheet.plugin.license;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import jira.timesheet.plugin.configuration.ConfigurationService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.atlassian.jira.config.FeatureManager;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.sal.api.pluginsettings.PluginSettings;
import com.atlassian.sal.api.pluginsettings.PluginSettingsFactory;
import com.atlassian.upm.api.util.Option;
import com.atlassian.upm.license.storage.lib.ThirdPartyPluginLicenseStorageManager;
import com.fdu.jira.util.LicenseUtil;

@RunWith(PowerMockRunner.class)
@PrepareForTest({LicenseEncoder.Key.class})
@PowerMockIgnore({"javax.crypto.*"})
public class LicenseUtilTest {
    PluginSettings pluginSettings;
    ConfigurationService configurationService;
    LicenseUtil licenseUtil;

    private final static String base64Key = 
            "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBALEIImThzi67lNGAKExYYkSFITjo+roE" +
            "3VfW0WbAht8Oxwa1xBKj27wU20CIfijR9RCCbbF/ymE5rYSw+8Jw33sCAwEAAQ==";

    @Before
    public void setup() {
        PluginSettingsFactory pluginSettingFactory = mock(PluginSettingsFactory.class);
        pluginSettings = mock(PluginSettings.class);
        when(pluginSettingFactory.createGlobalSettings()).thenReturn(pluginSettings);
        ApplicationProperties applicationProperties = mock(ApplicationProperties.class);
        configurationService = new ConfigurationService(pluginSettingFactory, applicationProperties);
        ThirdPartyPluginLicenseStorageManager licenseManager = mock(ThirdPartyPluginLicenseStorageManager.class);
        FeatureManager featureManager = mock(FeatureManager.class);
        
        licenseUtil = new LicenseUtil(licenseManager, configurationService, featureManager);
        
        PowerMockito.mockStatic(LicenseEncoder.Key.class);
        when(LicenseEncoder.Key.get()).thenReturn(base64Key);
    }

    @Test
    public void testCachedLicense() {
        assertFalse(licenseUtil.getTimesheetLicense().isDefined());
        /*
         * licenseType=COMMERCIAL
         * creationDate=2013-12-26
         */
        String rawLicense = "Rlw0unHZ4lZ1yzpn1bBFLWVXs9PFTx2h09ENJ1TWpa7D46v7kP1HILte7bIVzlPF7MucVyNhPojb"
                + "dte++MYnQ4mNrRQXcIq1Q9BdyeSzDCJXhVLfDR3wy/sAsKNlbF7VJ+JRa78lglwgNiI/pMQCTA==";
        final String key = "jira.timesheet.plugin.license";
        when(pluginSettings.get(key)).thenReturn(rawLicense);
        Option<TimesheetLicense> timesheetLicense = licenseUtil.getTimesheetLicense();
        assertTrue(timesheetLicense.isDefined());
        assertTrue("cached license", licenseUtil.getTimesheetLicense() == timesheetLicense); 
        rawLicense = "rKNG1VqZW7SwWWSg9hnQ5ADdWWPdKGEwg/8O5VYEu8iZ+1fRwOXNqC9EHBoilZ/spqGZGg5jSCRk"
                + "QoHVZFCv/wmJvKD+B1OXAjoOLYH3kTU1L1WaiWTMYRAwFrBAhCxTTXPE3SHKWzYKUgUMJxnGjg==";
        when(pluginSettings.get(key)).thenReturn(rawLicense);
        assertFalse("new license", licenseUtil.getTimesheetLicense() == timesheetLicense);
        Option<TimesheetLicense> newTimesheetLicense = licenseUtil.setTimesheetLicense(rawLicense);
        verify(pluginSettings).put(key, rawLicense);
        assertFalse("cache reset", newTimesheetLicense == timesheetLicense); 
        assertTrue("new cached license", licenseUtil.getTimesheetLicense() == newTimesheetLicense); 
        when(pluginSettings.get(key)).thenReturn(null);
        assertFalse("removed license", licenseUtil.getTimesheetLicense().isDefined()); 
    }

    @Test
    public void testNoLicense() {
        assertFalse(licenseUtil.getTimesheetLicense().isDefined());
    }

    @Test
    public void testNotALicense() {
        assertFalse(licenseUtil.setTimesheetLicense("hababuba").isDefined());
    }

    @Test
    public void testEmptyLicense() {
        String rawLicense = "G4vDW+urdwoMXPHyV1P5i5MHWceD5WaWexoL6jLNZ0y4rDDE1l1+FXgkKvh3z7HqAeAt8LuUdMvn"
                + "G0GalPqx7Z0AxWZb7v98xR3Rk3puBXk=";
        assertFalse(licenseUtil.setTimesheetLicense(rawLicense).isDefined());
    }

    @Test
    public void testNoCreationDate() {
        /*
         * licenseType=COMMERCIAL
         */
        String rawLicense = "pq6LPxS+vzk4qPFuix0mKoj/165vde/4sEQmlr13wvHxb/jP6Pm794aSxMWWoVbnMqiRo6G2Ousj"
                + "7oEMks6zLuTrKLBI8ggpfUIc/6hFali32etOXS0bkMjVJODTufIw";
        assertFalse(licenseUtil.setTimesheetLicense(rawLicense).isDefined());
    }
    
    @Test
    public void testNoExpiryDateSet() {
        /*
         * licenseType=COMMERCIAL
         * creationDate=2013-12-26
         * expiryDate=
         */
        String rawLicense = "BcYZmpyONO5wtY3kKcqKllBMdwqfzNKiyFlMfQaWLHH9Nb+zXAtsNHXae4eXwkVD0e5DVp/izb3z"
                + "+HmcvQqckoFMv2L8Tt4DZ0OfK1XOfLyNHiJa0E9N1j4pxOLaJfkdUaAQe8Egg6DruTa7qIKy6hGw"
                + "N+DbpkQcNyOvM6JaS9U=";
        assertFalse(licenseUtil.setTimesheetLicense(rawLicense).isDefined());
    }

    @Test
    public void testNoSEN() {
        /*
         * licenseType=COMMERCIAL
         * creationDate=2013-12-26
         */
        String rawLicense = "Rlw0unHZ4lZ1yzpn1bBFLWVXs9PFTx2h09ENJ1TWpa7D46v7kP1HILte7bIVzlPF7MucVyNhPojb"
                + "dte++MYnQ4mNrRQXcIq1Q9BdyeSzDCJXhVLfDR3wy/sAsKNlbF7VJ+JRa78lglwgNiI/pMQCTA==";
        Option<TimesheetLicense> timesheetLicense = licenseUtil.setTimesheetLicense(rawLicense);
        assertTrue(timesheetLicense.isDefined());
        assertFalse(timesheetLicense.get().getSupportEntitlementNumber().isDefined());
    }

    @Test
    public void testEndlessLicense() {
        assertFalse(licenseUtil.getTimesheetLicense().isDefined());
        /*
         * licenseType=COMMERCIAL
         * creationDate=2013-12-26
         * supportEntitlementNumber=L-1
         */
        String rawLicense = "T7Lr/b356ptvElUX+Viw7ZCNd/kC/Xunxvpep6oSFSypc/mDLwBqjfjZA8Sz2kzUz0JLOBU3ied0"
                + "2hRp9ZId8wpGEaiya7Gfg+Nj9fGIneRuqoeFT84fIRfXheRaORxbfLZVFzOMT34yQov6+UUkWneg"
                + "oTkiPkLq+b/YaSLvWp+VlxFHMFDlSuO0CuQ+Shfe";
        Option<TimesheetLicense> timesheetLicense = licenseUtil.setTimesheetLicense(rawLicense);
        assertTrue(timesheetLicense.isDefined());
        assertTrue(timesheetLicense.get().isValid());
        assertFalse(timesheetLicense.get().getExpiryDate().isDefined());
    }

    @Test
    public void testExpiredLicense() {
        assertFalse(licenseUtil.getTimesheetLicense().isDefined());
        /*
         * licenseType=COMMERCIAL
         * creationDate=2013-12-26
         * expiryDate=2013-12-26
         * supportEntitlementNumber=L-1
         */
        String rawLicense = "NgnC+7NJ79bmDLqIuWtb2kS6WNLMJS5+1GaADDYNxxxy0pNztX8oVIfhgJeeeMdu22tLUxO+TK6e"
                + "v1THWbhyGy2xfEtrqu14BvEv6SIXG+R7j9zB9uRdj2oBb32dc8FsX8cB7ZOyR+8d0HFxc91/tdBl"
                + "FCki1pPbd3zG/XskhCFK4QnIRC7xdTsniWign1SNoffIKqW1ONqo+DTCeF8WXvs9ylczRcki72hQ"
                + "2WDKJVo=";
        Option<TimesheetLicense> timesheetLicense = licenseUtil.setTimesheetLicense(rawLicense);
        assertTrue(timesheetLicense.isDefined());
        assertTrue(timesheetLicense.get().getExpiryDate().isDefined());
        assertFalse(timesheetLicense.get().isValid());
    }

    @Test
    public void testValidLicense() {
        assertFalse(licenseUtil.getTimesheetLicense().isDefined());
        /*
         * licenseType=COMMERCIAL
         * creationDate=2013-12-26
         * expiryDate=2099-12-26
         * organization=Acme Inc.
         * supportEntitlementNumber=L-1
         */
        String rawLicense = "VJVbQTfzbjfJHaC/Ew8ciDMjySMC5WzCMwTNfttoJmMhNwRswp8SiP19RWwoaL2SX50tmtKKgGxo"
                + "VccCyR7fg98fMqTbUQABCJsb7i92rOp0oKxmxaf+4yMS/1hFnzm9XzIiBbJnbScZVKY9bmhCx/+C"
                + "CLhHu2f1nzEWoL2GeuVFY8s1ReOAQTn+LRSOuAUMlq8zy10nsyhaaxpn9QlGWwrLyOyt5S0REAa7"
                + "luXGUIi5YriCfIX+1Dy/N0agtMiF";
        Option<TimesheetLicense> timesheetLicense = licenseUtil.setTimesheetLicense(rawLicense);
        assertTrue(timesheetLicense.isDefined());
        TimesheetLicense license = timesheetLicense.get();
        assertTrue("ExpiryDate", license.getExpiryDate().isDefined());
        assertTrue("Valid", license.isValid());
        assertEquals("Organization", "Acme Inc.", license.getOrganization());
        assertEquals("SupportEntitlementNumber", "L-1", license.getSupportEntitlementNumber().get());
    }
}
