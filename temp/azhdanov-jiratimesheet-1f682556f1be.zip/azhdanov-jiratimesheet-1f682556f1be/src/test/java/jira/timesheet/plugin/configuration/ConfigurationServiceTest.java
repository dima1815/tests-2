package jira.timesheet.plugin.configuration;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.fdu.jira.util.WeekendUtil;
import com.google.common.collect.ImmutableList;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.util.StringUtils;

import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.sal.api.pluginsettings.PluginSettings;
import com.atlassian.sal.api.pluginsettings.PluginSettingsFactory;

public class ConfigurationServiceTest {

    ApplicationProperties applicationProperties;
    PluginSettings pluginSettings;
    ConfigurationService configurationService;

    @Before
    public void setup() {
        PluginSettingsFactory pluginSettingFactory = mock(PluginSettingsFactory.class);
        pluginSettings = mock(PluginSettings.class);
        when(pluginSettingFactory.createGlobalSettings()).thenReturn(pluginSettings);
        applicationProperties = mock(ApplicationProperties.class);
        configurationService = new ConfigurationService(pluginSettingFactory, applicationProperties);
    }

    @Test
    public void testTimesheetAuditorsGroup() {
        String key = "jira.timesheet.plugin.timesheetAuditorsGroup";
        String value = "Timesheet Auditors";
        when(pluginSettings.get(key)).thenReturn(value);
        final List<String> timesheetAuditorsGroups = configurationService.getTimesheetAuditorsGroups();
        assertNotNull(timesheetAuditorsGroups);
        assertThat(timesheetAuditorsGroups.size(), is(1));
        assertTrue(timesheetAuditorsGroups.contains(value));
        configurationService.setTimesheetAuditorsGroups(ImmutableList.of(value));
        verify(pluginSettings).put(key, value);

        configurationService.setTimesheetAuditorsGroups(null);
        verify(pluginSettings).put(key, null);
    }

    @Test
    public void testTimesheetAuditorsRole() {
        String key = "jira.timesheet.plugin.timesheetAuditorsRole";
        String value = "Timesheet Auditors";
        when(pluginSettings.get(key)).thenReturn(value);
        final List<String> timesheetAuditorsRoles = configurationService.getTimesheetAuditorsRoles();
        assertNotNull(timesheetAuditorsRoles);
        assertThat(timesheetAuditorsRoles.size(), is(1));
        assertTrue(timesheetAuditorsRoles.contains(value));
        configurationService.setTimesheetAuditorsRoles(ImmutableList.of(value));
        verify(pluginSettings).put(key, value);

        configurationService.setTimesheetAuditorsRoles(null);
        verify(pluginSettings).put(key, null);
    }

    @Test
    public void testComposeIssueLink() {
        String key = "jira.timesheet.plugin.composeIssueLink";
        String value = "Compose";
        // backed property
        when(applicationProperties.getDefaultBackedString(key)).thenReturn(value);
        assertEquals("get", value, configurationService.getComposeIssueLink());
        configurationService.setComposeIssueLink(value);
        verify(pluginSettings).put(key, value);

        configurationService.setComposeIssueLink(null);
        verify(pluginSettings).put(key, ConfigurationService.EMPTY_STRING);
    }

    @Test
    public void testInProgressClause() {
        String key = "jira.timesheet.plugin.inProgressClause";
        String value = "status = \"In Progress\"";
        // backed property
        when(applicationProperties.getDefaultBackedString(key)).thenReturn(value);
        assertEquals("get", value, configurationService.getInProgressClause());
        configurationService.setInProgressClause(value);
        verify(pluginSettings).put(key, value);

        configurationService.setInProgressClause(null);
        verify(pluginSettings).put(key, ConfigurationService.EMPTY_STRING);
    }

    @Test
    public void testInProgressQuery() {
        String key = "jira.timesheet.plugin.inProgressQuery";
        String inProgressClauseKey = "jira.timesheet.plugin.inProgressClause";
        String inProgressClause = "status = \"In Progress\"";
        String assigneeClause = "assignee = currentUser() and ";
        String value = assigneeClause + inProgressClause;
        // backed property
        when(applicationProperties.getDefaultBackedString(inProgressClauseKey)).thenReturn(null);
        assertEquals("get", null, configurationService.getInProgressQuery());
        when(applicationProperties.getDefaultBackedString(inProgressClauseKey)).thenReturn(ConfigurationService.EMPTY_STRING);
        assertEquals("get", null, configurationService.getInProgressQuery());
        when(applicationProperties.getDefaultBackedString(inProgressClauseKey)).thenReturn(inProgressClause);
        assertEquals("get", value, configurationService.getInProgressQuery());
        configurationService.setInProgressQuery(value);
        verify(pluginSettings).put(key, value);
        verify(pluginSettings).put(inProgressClauseKey, ConfigurationService.EMPTY_STRING);

        reset(pluginSettings);
        configurationService.setInProgressQuery(null);
        verify(pluginSettings).put(inProgressClauseKey, ConfigurationService.EMPTY_STRING);
        verify(pluginSettings).put(key, null);

        when(pluginSettings.get(key)).thenReturn(ConfigurationService.EMPTY_STRING);
        assertNull("get empty", configurationService.getInProgressQuery());
    }

    @Test
    public void testMaxDays() {
        String key = "jira.timesheet.plugin.maxDays";
        Integer value = 30;
        // backed property
        when(applicationProperties.getDefaultBackedString(key)).thenReturn(value.toString());
        assertEquals("get", value, configurationService.getMaxDays());
        configurationService.setMaxDays(value);
        verify(pluginSettings).put(key, value.toString());

        configurationService.setMaxDays(null);
        verify(pluginSettings).put(key, ConfigurationService.EMPTY_STRING);

        // default
        when(pluginSettings.get(key)).thenReturn(ConfigurationService.EMPTY_STRING);
        assertEquals("get", new Integer(62), configurationService.getMaxDays());
    }

    @Test
    public void testPrettyDuration() {
        String key = "jira.timesheet.plugin.prettyDuration";
        Boolean value = Boolean.TRUE;
        // backed property
        when(applicationProperties.getDefaultBackedString(key)).thenReturn(value.toString());
        assertEquals("get", value, configurationService.isPrettyDuration());
        configurationService.setPrettyDuration(value);
        verify(pluginSettings).put(key, value.toString());

        configurationService.setPrettyDuration(null);
        verify(pluginSettings).put(key, ConfigurationService.EMPTY_STRING);

        when(pluginSettings.get(key)).thenReturn(ConfigurationService.EMPTY_STRING);
        assertEquals("get", Boolean.FALSE, configurationService.isPrettyDuration());
    }

    @Test
    public void testGroupByFields() {
        String key = "jira.timesheet.plugin.groupbyfields";
        List<String> value = new ArrayList<String>();
        value.add("assigne");
        value.add("environment");
        String stringValue = StringUtils.collectionToCommaDelimitedString(value);
        // backed property
        when(applicationProperties.getDefaultBackedString(key)).thenReturn(stringValue);
        assertEquals("get", value, configurationService.getGroupByFields());
        configurationService.setGroupByFields(value);
        verify(pluginSettings).put(key, stringValue);

        configurationService.setGroupByFields(null);
        verify(pluginSettings).put(key, ConfigurationService.EMPTY_STRING);

        when(pluginSettings.get(key)).thenReturn(ConfigurationService.EMPTY_STRING);
        assertNull("get", configurationService.getGroupByFields());
    }

    @Test
    public void test_weekendType() {
        final String key = "jira.timesheet.plugin.weekendType";

        String weekendType = configurationService.getWeekendType();
        assertThat(weekendType, is(WeekendUtil.getDefaultWeekend()));

        when(applicationProperties.getDefaultBackedString(key)).thenReturn(WeekendUtil.getIslamicWeekend());

        weekendType = configurationService.getWeekendType();
        assertThat(weekendType, is(WeekendUtil.getIslamicWeekend()));

        configurationService.setWeekendType(WeekendUtil.getIndiaWeekend());
        verify(pluginSettings).put(key, WeekendUtil.getIndiaWeekend());
    }

    @Test
    public void test_restrictedGroups() {
        final String key = "jira.timesheet.plugin.restrictedGroups";

        List<String> restrictedGroups = configurationService.getRestrictedGroups();
        assertTrue("Empty null", CollectionUtils.isEmpty(restrictedGroups));

        when(pluginSettings.get(key)).thenReturn("");
        restrictedGroups = configurationService.getRestrictedGroups();
        assertTrue("Empty", CollectionUtils.isEmpty(restrictedGroups));

        configurationService.setRestrictedGroups(Collections.<String>emptyList());
        verify(pluginSettings).put(key, "");

        configurationService.setRestrictedGroups(ImmutableList.of("jira-users", "jira-developers"));
        verify(pluginSettings).put(key, "jira-users,jira-developers");
    }
}
