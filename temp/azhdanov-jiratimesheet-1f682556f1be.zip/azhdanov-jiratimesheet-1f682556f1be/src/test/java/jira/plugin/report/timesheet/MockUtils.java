package jira.plugin.report.timesheet;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.ofbiz.core.entity.GenericValue;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.issue.issuetype.IssueType;
import com.atlassian.jira.issue.issuetype.MockIssueType;
import com.atlassian.jira.issue.status.MockStatus;
import com.atlassian.jira.issue.status.Status;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.issue.worklog.WorklogImpl;
import com.atlassian.jira.issue.worklog.WorklogManager;
import com.atlassian.jira.project.MockProject;
import com.atlassian.jira.project.Project;

public class MockUtils {
    public static final Status STATUS_OPEN = new MockStatus("1", "Open");
    public static final Status STATUS_RESOLVED = new MockStatus("5", "Resolved");
    public static final List<String> doneStatuses = Arrays
            .asList(new String[] { "5" });
    public static final IssueType TYPE_BUG = new MockIssueType("1", "Bug");
    public static final Project TIME = new MockProject(1, "TIME", "Timeship");

    public static MutableIssue createIssue(long id, String key, String summary,
            Long timeSpent, Status status) {
        MutableIssue issue = mock(MutableIssue.class);

        when(issue.getId()).thenReturn(id);
        when(issue.getKey()).thenReturn(key);
        when(issue.getSummary()).thenReturn(summary);
        when(issue.getTimeSpent()).thenReturn(timeSpent);
        when(issue.getStatusObject()).thenReturn(status);
        when(issue.getIssueTypeObject()).thenReturn(TYPE_BUG);
        when(issue.getProjectObject()).thenReturn(TIME);
        return issue;
    }

    public static void subTasks(Issue parent, Issue[] subTasks) {
        List<Issue> issues = new ArrayList<Issue>(subTasks.length);
        for (Issue subTask : subTasks) {
            when(subTask.isSubTask()).thenReturn(true);
            when(subTask.getParentObject()).thenReturn(parent);
            issues.add(subTask);
        }
        when(parent.getSubTaskObjects()).thenReturn(issues);
    }

    public static GenericValue createGenericWorklog(Long startDate, Issue issue, String author, Long timeSpent) {
        GenericValue gv = mock(GenericValue.class);
        Timestamp startTimestamp = new Timestamp(startDate);
        when(gv.getTimestamp("startdate")).thenReturn(startTimestamp);
        Timestamp zeroTimestamp = new Timestamp(0);
        when(gv.getTimestamp("created")).thenReturn(zeroTimestamp);
        when(gv.getTimestamp("updated")).thenReturn(zeroTimestamp);
        Long issueId = issue.getId();
        when(gv.getLong("issue")).thenReturn(issueId);
        when(gv.getString("author")).thenReturn(author);
        when(gv.getString("body")).thenReturn("test");
        when(gv.getString("grouplevel")).thenReturn("test");
        when(gv.getString("rolelevel")).thenReturn("test");
        when(gv.getLong("timeworked")).thenReturn(timeSpent);
        when(gv.getString("updateauthor")).thenReturn("test");
        return gv;
    }
}
