package jira.plugin.report.timesheet;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.bc.filter.SearchRequestService;
import com.atlassian.jira.bc.issue.util.VisibilityValidator;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.link.IssueLinkManager;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.issue.search.SearchProvider;
import com.atlassian.jira.issue.worklog.WorklogManager;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.web.FieldVisibilityManager;
import com.atlassian.upm.license.storage.lib.ThirdPartyPluginLicenseStorageManager;
import com.google.common.collect.ImmutableList;
import jira.timesheet.plugin.holidays.HolidayService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.ofbiz.core.entity.DelegatorInterface;
import org.ofbiz.core.entity.EntityCondition;
import org.ofbiz.core.entity.EntityListIterator;
import org.ofbiz.core.entity.GenericEntityException;

import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TimesheetServiceTest extends AbstractTestCase {
    TimeZone timezone;
    I18nHelper i18n;
    TimeZoneManager timeZoneManager;
    IssueLinkManager issueLinkManager;
    DateTimeFormatterFactory dateTimeFormatterFactory;
    FieldVisibilityManager fieldVisibilityManager;
    ThirdPartyPluginLicenseStorageManager licenseManager;
    PermissionManager permissionManager;
    WorklogManager worklogManager;
    IssueManager issueManager;
    SearchProvider searchProvider;
    VisibilityValidator visibilityValidator;
    SearchRequestService searchRequestService;
    ProjectRoleManager projectRoleManager;
    TimesheetService timesheetService;
    ProjectManager projectManager;
    DelegatorInterface delegatorInterface;
    private HolidayService holidayService;

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Before
    public void setup() throws GenericEntityException {
        //ComponentAccessor.initialiseWorker(new MockComponentWorker());
        //MultiTenantContext.defaultInit();
        //MultiTenantContextTestUtils.setupMultiTenantSystem();

        timeZoneManager = mock(TimeZoneManager.class);
        issueLinkManager = mock(IssueLinkManager.class);
        authenticationContext = mock(JiraAuthenticationContext.class);
        holidayService = mock(HolidayService.class);
        
        // for test
        timezone = TimeZone.getDefault();
        i18n = mock(I18nHelper.class);

        when(authenticationContext.getI18nHelper()).thenReturn(i18n);
        when(authenticationContext.getLoggedInUser()).thenReturn(remoteUser);
        when(timeZoneManager.getLoggedInUserTimeZone()).thenReturn(timezone);
        
        dateTimeFormatterFactory = mock(DateTimeFormatterFactory.class);
        timesheetService = new TimesheetService(dateTimeFormatterFactory, permissionManager, worklogManager, issueManager, searchProvider, visibilityValidator, userUtil, searchRequestService, timeZoneManager, projectRoleManager, issueLinkManager, applicationProperties, projectManager, holidayService, configurationService);

        delegatorInterface = mock(DelegatorInterface.class);
        when(ComponentManager.getComponent(DelegatorInterface.class)).thenReturn(delegatorInterface);
        // TODO: return issues in test
        EntityListIterator worklogIterator = mock(EntityListIterator.class);
        when(delegatorInterface.findListIteratorByCondition(anyString(), Matchers.<EntityCondition>anyObject(),
                Matchers.<Collection>anyObject(), Matchers.<List>anyObject())).thenReturn(worklogIterator);

        when(i18n.getLocale()).thenReturn(Locale.getDefault());

        // must have been used from AbstractTestCase
        when(ComponentManager.getComponentInstanceOfType(ApplicationProperties.class)).thenReturn(applicationProperties);
        when(ComponentManager.getComponentInstanceOfType(CustomFieldManager.class)).thenReturn(customFieldManager);
    }

    @Test
    public void testTimesheetService() throws SearchException, GenericEntityException {
        Map<String, Object> params = new HashMap<String, Object>();
        Timesheet timesheet = new Timesheet(remoteUser, timezone, i18n, params,
                EnumSet.of(TimeBase.Options.DATES),
                EnumSet.noneOf(Timesheet.Options.class), configurationService);
        timesheetService.getTimeSpents(timesheet);
        // TODO: test something
    }

    @Test
    public void testNotForbiddenByTimesheetAuditorsGroup() {
        Map<String, Object> params = new HashMap<String, Object>();
        Timesheet timesheet = new Timesheet(remoteUser, timezone, i18n, params,
                EnumSet.of(TimeBase.Options.DATES),
                EnumSet.noneOf(Timesheet.Options.class), configurationService);
        when(configurationService.getTimesheetAuditorsGroups()).thenReturn(ImmutableList.of("jira-administrators"));
        assertFalse(timesheetService.isForbiddenByTimesheetAuditorsGroup(timesheet));
    }

    @Test
    public void testOtherTimesheetForbiddenByTimesheetAuditorsGroup() {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("targetUser", "test");
        User testUser = mock(User.class);
        when(testUser.getName()).thenReturn("test");
        when(userManager.getUserObject("test")).thenReturn(testUser);
        Timesheet timesheet = new Timesheet(remoteUser, timezone, i18n, params,
                EnumSet.of(TimeBase.Options.DATES),
                EnumSet.noneOf(Timesheet.Options.class), configurationService);
        assertFalse(timesheetService.isForbiddenByTimesheetAuditorsGroup(timesheet));
        when(configurationService.getTimesheetAuditorsGroups()).thenReturn(ImmutableList.of("jira-administrators"));
        assertTrue(timesheetService.isForbiddenByTimesheetAuditorsGroup(timesheet));
    }

    @Test
    public void testGroupTimesheetForbiddenByTimesheetAuditorsGroup() {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("targetUser", "admin"); // Issue#544
        params.put("targetGroup", "jira-usres");
        Timesheet timesheet = new Timesheet(remoteUser, timezone, i18n, params,
                EnumSet.of(TimeBase.Options.DATES),
                EnumSet.noneOf(Timesheet.Options.class), configurationService);
        assertFalse(timesheetService.isForbiddenByTimesheetAuditorsGroup(timesheet));
        when(configurationService.getTimesheetAuditorsGroups()).thenReturn(ImmutableList.of("jira-administrators"));
        // admin is not in auditors group (jira-administrators)
        assertTrue(timesheetService.isForbiddenByTimesheetAuditorsGroup(timesheet));
    }

    @Test
    public void testProjectTimesheetForbiddenByTimesheetAuditorsGroup() {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("projectid", "10000");
        Timesheet timesheet = new Timesheet(remoteUser, timezone, i18n, params,
                EnumSet.of(TimeBase.Options.DATES),
                EnumSet.noneOf(Timesheet.Options.class), configurationService);
        assertFalse(timesheetService.isForbiddenByTimesheetAuditorsGroup(timesheet));
        when(configurationService.getTimesheetAuditorsGroups()).thenReturn(ImmutableList.of("jira-administrators"));
        assertTrue(timesheetService.isForbiddenByTimesheetAuditorsGroup(timesheet));
    }
}
