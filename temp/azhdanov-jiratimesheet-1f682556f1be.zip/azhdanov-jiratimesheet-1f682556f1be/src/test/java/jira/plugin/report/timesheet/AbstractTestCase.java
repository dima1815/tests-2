package jira.plugin.report.timesheet;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.properties.ApplicationProperties;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.fields.FieldManager;
import com.atlassian.jira.issue.link.IssueLinkManager;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.user.util.UserUtil;
import com.atlassian.jira.util.I18nHelper;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import webwork.action.ActionContext;

import javax.servlet.http.HttpServletRequest;

import jira.timesheet.plugin.configuration.ConfigurationService;
import jira.timesheet.plugin.configuration.IConfigurationService;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ComponentManager.class, ActionContext.class, ComponentAccessor.class})
@PowerMockIgnore({"org.apache.log4j.*"})
public class AbstractTestCase {

    protected User remoteUser;
    protected ComponentManager componentManager = mock(ComponentManager.class);
    protected HttpServletRequest httpRequest = mock(HttpServletRequest.class);
    protected ApplicationProperties applicationProperties = mock(ApplicationProperties.class);
    protected ProjectManager projectManager = mock(ProjectManager.class);
    protected JiraAuthenticationContext authenticationContext = mock(JiraAuthenticationContext.class);
    protected User loginUser = mock(User.class);
    protected PermissionManager permissionManager = mock(PermissionManager.class);
    protected FieldManager fieldManager = mock(FieldManager.class);
    protected IssueLinkManager issueLinkManager = mock(IssueLinkManager.class);
    protected I18nHelper i18nHelper = mock(I18nHelper.class);
    protected com.atlassian.sal.api.ApplicationProperties salApplicationProperties = mock(com.atlassian.sal.api.ApplicationProperties.class);
    protected ConfigurationService configurationService = mock(ConfigurationService.class);
    protected CustomFieldManager customFieldManager = mock(CustomFieldManager.class);
    protected UserManager userManager = mock(UserManager.class);
    protected UserUtil userUtil = mock(UserUtil.class);

    @SuppressWarnings("deprecation")
    @Before
    public void baseSetUp() {
        remoteUser = mock(User.class);
        when(remoteUser.getName()).thenReturn("admin");
        when(userManager.getUserObject("admin")).thenReturn(remoteUser);

        PowerMockito.mockStatic(ComponentManager.class);
        PowerMockito.mockStatic(ActionContext.class);
        PowerMockito.mockStatic(ComponentAccessor.class);
        when(ComponentManager.getInstance()).thenReturn(componentManager);
        when(ComponentManager.getComponentInstanceOfType(ApplicationProperties.class)).thenReturn(applicationProperties);
        when(ComponentManager.getComponentInstanceOfType(ProjectManager.class)).thenReturn(projectManager);
        when(ComponentManager.getComponentInstanceOfType(JiraAuthenticationContext.class)).thenReturn(authenticationContext);
        when(ComponentManager.getComponentInstanceOfType(PermissionManager.class)).thenReturn(permissionManager);
        when(ComponentManager.getComponentInstanceOfType(FieldManager.class)).thenReturn(fieldManager);
        when(ComponentManager.getComponentInstanceOfType(IssueLinkManager.class)).thenReturn(issueLinkManager);
        when(ComponentManager.getOSGiComponentInstanceOfType(com.atlassian.sal.api.ApplicationProperties.class)).thenReturn(salApplicationProperties);
        when(salApplicationProperties.getVersion()).thenReturn("5.0");

        when(ActionContext.getRequest()).thenReturn(httpRequest);
        when(componentManager.getApplicationProperties()).thenReturn(applicationProperties);
        when(authenticationContext.getLoggedInUser()).thenReturn(loginUser);
        when(authenticationContext.getI18nHelper()).thenReturn(i18nHelper);
        when(ComponentManager.getOSGiComponentInstanceOfType(IConfigurationService.class)).thenReturn(configurationService);
        when(ComponentAccessor.getUserManager()).thenReturn(userManager);
        when(ComponentAccessor.getUserUtil()).thenReturn(userUtil);
        // for TextUtil
        when(applicationProperties.getDefaultBackedString("jira.timetracking.hours.per.day")).thenReturn("8");
        when(applicationProperties.getDefaultBackedString("jira.timetracking.days.per.week")).thenReturn("5");
        when(ComponentManager.getComponentInstanceOfType(ApplicationProperties.class)).thenReturn(applicationProperties);
        when(ComponentManager.getComponentInstanceOfType(JiraAuthenticationContext.class)).thenReturn(authenticationContext);
        when(ComponentManager.getComponentInstanceOfType(CustomFieldManager.class)).thenReturn(customFieldManager);

        when(userUtil.getUser("admin")).thenReturn(remoteUser);
    }

}
