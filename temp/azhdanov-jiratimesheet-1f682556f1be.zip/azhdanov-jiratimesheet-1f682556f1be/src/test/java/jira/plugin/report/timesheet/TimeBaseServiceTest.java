package jira.plugin.report.timesheet;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.bc.JiraServiceContext;
import com.atlassian.jira.bc.issue.util.VisibilityValidator;
import com.atlassian.jira.datetime.DateTimeFormatterFactory;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.fields.Field;
import com.atlassian.jira.issue.fields.TimeSpentSystemField;
import com.atlassian.jira.issue.link.LinkCollection;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.issue.worklog.WorklogImpl;
import com.atlassian.jira.issue.worklog.WorklogManager;
import com.atlassian.jira.mock.issue.MockIssue;
import com.atlassian.jira.mock.ofbiz.MockGenericValue;
import com.atlassian.jira.project.MockProject;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.security.Permissions;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.util.I18nHelper;
import com.fdu.jira.util.DirectoryUtil;
import com.fdu.jira.util.TextUtil;
import com.fdu.jira.util.WorklogUtil;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSortedSet;
import jira.plugin.report.timesheet.TimeBase.Options;
import jira.timesheet.plugin.configuration.ConfigurationService;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.internal.matchers.EqualsWithDelta;
import org.ofbiz.core.entity.DelegatorInterface;
import org.ofbiz.core.entity.EntityCondition;
import org.ofbiz.core.entity.EntityListIterator;
import org.ofbiz.core.entity.GenericValue;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeSet;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyCollectionOf;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@PrepareForTest({WorklogUtil.class, DirectoryUtil.class})
public class TimeBaseServiceTest extends AbstractTestCase {

    protected TimeZone timezone;
    protected I18nHelper i18n;
    protected VisibilityValidator visibilityValidator;
    protected ConfigurationService configurationService;
    protected TimeBaseService<TimeBase> timeBaseService;
    protected DateTimeFormatterFactory dateTimeFormatterFactory;
    protected TimeZoneManager timezoneManager;
    protected DelegatorInterface delegatorInterface;
    protected Set<Issue> groupedIssues;

    protected int processSingleCall;

    @Before
    public void setup() {
        visibilityValidator = mock(VisibilityValidator.class);
        configurationService = mock(ConfigurationService.class);
        delegatorInterface = mock(DelegatorInterface.class);
        when(ComponentManager.getComponent(DelegatorInterface.class)).thenReturn(delegatorInterface);

        processSingleCall = 0;

        // for test
        timezone = TimeZone.getDefault();
        i18n = mock(I18nHelper.class);
        timezoneManager = mock(TimeZoneManager.class);

        when(configurationService.getComposeIssueLink()).thenReturn("Compose");
        when(timezoneManager.getLoggedInUserTimeZone()).thenReturn(timezone);

        timeBaseService = new TimeBaseService<TimeBase>(applicationProperties, permissionManager, null, null, null, visibilityValidator, userUtil, null, timezoneManager, null, issueLinkManager, configurationService, dateTimeFormatterFactory) {
            @Override
            protected void processSingle(TimeBase timebase, Worklog worklog, Issue issue, Project project, User workedUser, Calendar workedDate) {
                processSingleCall++;
            }
            @Override
            protected Set<Issue> getGroupedIssues(TimeBase timebase) {
                return groupedIssues;
            }
        };

        when(i18n.getLocale()).thenReturn(Locale.getDefault());
        
        Field timeSpentSystemField = mock(TimeSpentSystemField.class);
        when(fieldManager.getField(eq("timespent"))).thenReturn(timeSpentSystemField);
    }

    @Test
    public void testParentIssue() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("sumSubTasks", "true");
        EnumSet<Options> options = EnumSet.noneOf(TimeBase.Options.class); 
        TimeBase timebase = new TimeBase(remoteUser, timezone, i18n, params, options, configurationService);

        Issue i1 = MockUtils.createIssue(1, "TIME-1", "Hocus Focus Problem", 3600L, MockUtils.STATUS_RESOLVED); 
        Issue i11 = MockUtils.createIssue(11, "TIME-11", "Hindenbug", 3600L, MockUtils.STATUS_RESOLVED);
        Issue i2 = MockUtils.createIssue(2, "TIME-2", "Loch Ness Monster Bug", 3600L, MockUtils.STATUS_RESOLVED);
        Issue i21 = MockUtils.createIssue(21, "TIME-21", "Mega problem", 3600L, MockUtils.STATUS_RESOLVED);
        // i1 <-- sub task -- i11
        MockUtils.subTasks(i1, new Issue[] {i11});
        // i2 <-- sub task -- i21
        MockUtils.subTasks(i2, new Issue[] {i21});

        LinkCollection i1LinkCollection = mock(LinkCollection.class);
        when(issueLinkManager.getLinkCollection(eq(i2), Matchers.<User>anyObject())).thenReturn(i1LinkCollection);
        // i1 -- composes --> i21
        when(i1LinkCollection.getOutwardIssues(anyString())).thenReturn(Arrays.asList(i21));
        LinkCollection i2LinkCollection = mock(LinkCollection.class);
        when(issueLinkManager.getLinkCollection(eq(i1), Matchers.<User>anyObject())).thenReturn(i1LinkCollection);
        // i2 -- composes --> i1
        when(i2LinkCollection.getOutwardIssues(anyString())).thenReturn(Arrays.asList(i1)); // cycle

        // [i1 (cycle) <-- is composed by --] i2 <-- sub task -- i21 <-- is composed by -- i1 <-- sub task -- i11

        Issue parent = timeBaseService.getParentIssue(i11, timebase);
        assertEquals("Parent issue", i2.getKey(), parent.getKey());
    }

    @Test
    public void testTextUtilIssueTime() {

        Issue i1 = MockUtils.createIssue(1, "TIME-1", "Hocus Focus Problem", 3600L, MockUtils.STATUS_RESOLVED); 
        Issue i11 = MockUtils.createIssue(11, "TIME-11", "Hindenbug", 3600L, MockUtils.STATUS_RESOLVED);
        Issue i2 = MockUtils.createIssue(2, "TIME-2", "Loch Ness Monster Bug", 3600L, MockUtils.STATUS_RESOLVED);
        Issue i21 = MockUtils.createIssue(21, "TIME-21", "Mega problem", 3600L, MockUtils.STATUS_RESOLVED);
        MockUtils.subTasks(i1, new Issue[] {i11});
        MockUtils.subTasks(i2, new Issue[] {i21});

        LinkCollection i11LinkCollection = mock(LinkCollection.class);
        when(i11LinkCollection.getInwardIssues(anyString())).thenReturn(Arrays.asList(i2));
        when(issueLinkManager.getLinkCollection(eq(i11), Matchers.<User>anyObject())).thenReturn(i11LinkCollection);
        LinkCollection i21LinkCollection = mock(LinkCollection.class);
        when(i21LinkCollection.getInwardIssues(anyString())).thenReturn(Arrays.asList(i2));
        when(issueLinkManager.getLinkCollection(eq(i21), Matchers.<User>anyObject())).thenReturn(i21LinkCollection);
        
        // i1 <-- sub task -- i11 <-- is composed by -- i2 <-- sub task -- i21 <-- is composed by i1 (cycle)

        TextUtil textUtil = new TextUtil(i18n, timezone, configurationService);
        assertEquals("timeSpent", "4h", textUtil.getFieldValue("timespent", i1, null, null, true));
    }

    @Test
    public void testSkipByRestrictedGroup() {
        when(configurationService.getRestrictedGroups()).thenReturn(Arrays.asList("g2", "g3"));

        when(remoteUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(6));
        when(userUtil.getGroupNamesForUser(remoteUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g1", "g2")));

        final User worklogUser = mock(User.class);
        when(worklogUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(5));
        when(userUtil.getGroupNamesForUser(worklogUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g2", "g3", "g4")));

        assertFalse(timeBaseService.skipByRestrictedGroup(remoteUser, worklogUser));
    }

    @Test
    public void testSkipByRestrictedGroup_restricted() {
        when(configurationService.getRestrictedGroups()).thenReturn(Arrays.asList("g2"));

        when(remoteUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(6));
        when(userUtil.getGroupNamesForUser(remoteUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g1", "g2", "g3")));

        final User worklogUser = mock(User.class);
        when(worklogUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(5));
        when(userUtil.getGroupNamesForUser(worklogUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g1")));

        assertTrue(timeBaseService.skipByRestrictedGroup(remoteUser, worklogUser));
    }

    @Test
    public void testSkipByRestrictedGroup_noRestriction() {
        when(configurationService.getRestrictedGroups()).thenReturn(new ArrayList<String>());

        when(remoteUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(6));
        when(userUtil.getGroupNamesForUser(remoteUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g1")));

        final User worklogUser = mock(User.class);
        when(worklogUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(5));
        when(userUtil.getGroupNamesForUser(worklogUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g1", "g2", "g3")));

        assertFalse(timeBaseService.skipByRestrictedGroup(remoteUser, worklogUser));
    }

    @Test
    public void testSkipByRestrictedGroup_noRemoteGroups() {
        when(configurationService.getRestrictedGroups()).thenReturn(Arrays.asList("g2", "g9"));

        when(remoteUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(6));
        when(userUtil.getGroupNamesForUser(remoteUser.getName())).thenReturn(
                new TreeSet<String>(new ArrayList<String>()));

        final User worklogUser = mock(User.class);
        when(worklogUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(5));
        when(userUtil.getGroupNamesForUser(worklogUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g1", "g2", "g3")));

        assertTrue(timeBaseService.skipByRestrictedGroup(remoteUser, worklogUser));
    }

    @Test
    public void testSkipByRestrictedGroup_notContains() {
        when(configurationService.getRestrictedGroups()).thenReturn(Arrays.asList("g2"));

        when(remoteUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(6));
        when(userUtil.getGroupNamesForUser(remoteUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g1")));

        final User worklogUser = mock(User.class);
        when(worklogUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(5));
        when(userUtil.getGroupNamesForUser(worklogUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g2")));

        assertTrue(timeBaseService.skipByRestrictedGroup(remoteUser, worklogUser));
    }

    @Test
    public void testSkipByRestrictedGroup_noWorklogGroups() {
        when(configurationService.getRestrictedGroups()).thenReturn(Arrays.asList("g2"));

        when(remoteUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(6));
        when(userUtil.getGroupNamesForUser(remoteUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g2")));

        final User worklogUser = mock(User.class);
        when(worklogUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(5));
        when(userUtil.getGroupNamesForUser(worklogUser.getName())).thenReturn(
                new TreeSet<String>());

        assertTrue(timeBaseService.skipByRestrictedGroup(remoteUser, worklogUser));
    }

    @Test
    public void testSkipByRestrictedGroup_wrongGroup() {
        when(configurationService.getRestrictedGroups()).thenReturn(Arrays.asList("g7"));

        when(remoteUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(6));
        when(userUtil.getGroupNamesForUser(remoteUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g9")));

        final User worklogUser = mock(User.class);
        when(worklogUser.getName()).thenReturn(RandomStringUtils.randomAlphanumeric(5));
        when(userUtil.getGroupNamesForUser(worklogUser.getName())).thenReturn(
                new TreeSet<String>(Arrays.asList("g1", "g2", "g3")));

        assertTrue(timeBaseService.skipByRestrictedGroup(remoteUser, worklogUser));
    }

    @Test
    public void testSkipByExcludeGroup_1() throws Exception {
        timeBaseService.getTimeSpents(prepareForExcludeGroup());
        assertThat(processSingleCall, is(1));
    }

    @Test
    public void testSkipByExcludeGroup_2() throws Exception {
        final TimeBase timebase = prepareForExcludeGroup();
        timebase.excludeTargetGroup = Arrays.asList("test");
        when(userUtil.getGroupNamesForUser(anyString())).thenReturn(ImmutableSortedSet.of("excluded", "notExcluded"));
        timeBaseService.getTimeSpents(timebase);
        assertThat(processSingleCall, is(1));
    }

    @Test
    public void testSkipByExcludeGroup_3() throws Exception {
        final TimeBase timebase = prepareForExcludeGroup();
        timebase.excludeTargetGroup = Arrays.asList("excluded");
        when(userUtil.getAllUsersInGroupNames(timebase.excludeTargetGroup)).thenReturn(ImmutableSortedSet.of(remoteUser));
        timeBaseService.getTimeSpents(timebase);
        assertThat(processSingleCall, is(0));
    }

    @Test
    public void testPrepareAdditionalFieldSumByProject() {
        final Map<String, Object> params = new HashMap<String, Object>();
        final TimeBase timebase = new TimeBase(remoteUser, timezone, i18n, params,
                EnumSet.of(TimeBase.Options.DATES), configurationService);
        timebase.resultParams.put("moreFields", Arrays.asList("field_double", "field_long", "field_hours", "field_string"));
        this.groupedIssues = ImmutableSet.of(
                prepareIssue("pr_1", "field_double", "10.1"),
                prepareIssue("pr_1", "field_double", "5.0"),
                prepareIssue("pr_2", "field_long", "11"),
                prepareIssue("pr_2", "field_long", "7"),
                prepareIssue("pr_2", "field_hours", "11h"),
                prepareIssue("pr_2", "field_hours", "2h"),
                prepareIssue("pr_1", "field_string", "invoice"),
                prepareIssue("pr_1", "field_string", "description"));

        timeBaseService.prepareAdditionalFieldSumByProject(timebase);
        final Map<String, Map<String, Number>> result = timebase.additionalFieldSumByProjectMap;
        assertNotNull(result);
        assertThat(result.get("field_double").size(), is(1));
        assertThat(result.get("field_double").get("pr_1").doubleValue(), new EqualsWithDelta(15.1, 0.001));
        assertThat(result.get("field_long").size(), is(1));
        assertThat(result.get("field_long").get("pr_2").intValue(), is(18));
        assertThat(result.get("field_hours").size(), is(0));
        assertThat(result.get("field_string").size(), is(0));
    }

    protected Issue prepareIssue(final String projectKey, final String fieldName, final String value) {
        final Issue issue = new MockIssue(new Random().nextInt()) {

            @Override
            public String getString(String name) {
                return name.equals(fieldName) ? value : null;
            }

            @Override
            public Long getProjectId() {
                return new Random().nextLong();
            }

            @Override
            public Project getProjectObject() {
                return new MockProject(getProjectId(), projectKey);
            }

            @Override
            public String getKey() {
                return String.valueOf(getId() | getProjectId() | getProjectId()); //TODO this value influence timesheet.weekWorkLogShort.put()
            }
        };
        final Field field = mock(Field.class);
        when(fieldManager.getField(fieldName)).thenReturn(field);
        return issue;
    }

    @Test
    public void testNormalizeNumberValue() throws Exception {

        assertThat(timeBaseService.normalizeNumberValue(null).intValue(), is(0));
        assertThat(timeBaseService.normalizeNumberValue(10.2).doubleValue(), is(10.2));
    }

    protected TimeBase prepareForExcludeGroup() throws Exception {
        final Map<String, String> params = new HashMap<String, String>();
        params.put("sumSubTasks", "true");
        final EnumSet<Options> options = EnumSet.noneOf(TimeBase.Options.class);
        final TimeBase timebase = new TimeBase(remoteUser, timezone, i18n, params, options, configurationService);
        timebase.startDate = DateUtils.addDays(new Date(), -1);
        timebase.endDate = DateUtils.addDays(new Date(), 1);
        timebase.sumSubTasks = false;

        final EntityListIterator worklogIterator = mock(EntityListIterator.class);
        final MockGenericValue genericValue = new MockGenericValue("test");
        when(worklogIterator.next()).thenReturn(genericValue, (GenericValue[]) null);

        PowerMockito.mockStatic(WorklogUtil.class);
        when(WorklogUtil.convertToWorklog(any(GenericValue.class), any(WorklogManager.class), any(IssueManager.class)))
                .thenReturn(prepareWorklog());

        PowerMockito.mockStatic(DirectoryUtil.class);
        when(DirectoryUtil.getUser(eq(userUtil), anyString())).thenReturn(remoteUser);

        when(visibilityValidator.isValidVisibilityData(any(JiraServiceContext.class), anyString(), any(Issue.class), anyString(), anyString()))
                .thenReturn(true);

        when(delegatorInterface.findListIteratorByCondition(anyString(), any(EntityCondition.class), anyCollectionOf(String.class), anyListOf(String.class)))
                .thenReturn(worklogIterator);

        when(permissionManager.hasPermission(eq(Permissions.BROWSE), any(Issue.class), eq(remoteUser))).thenReturn(true);
        when(timezoneManager.getTimeZoneforUser(remoteUser)).thenReturn(timezone);

        return timebase;
    }

    protected Worklog prepareWorklog() {
        final MockIssue issue = new MockIssue();
        issue.setProjectId(1L);
        return new WorklogImpl(null, issue, 1L, "author", "comment", new Date(), "groupLevel", 1L, 180L);
    }
}
