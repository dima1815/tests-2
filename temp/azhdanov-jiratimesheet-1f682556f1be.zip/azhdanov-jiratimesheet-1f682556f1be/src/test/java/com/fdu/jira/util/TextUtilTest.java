package com.fdu.jira.util;

import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.fields.CustomField;
import jira.plugin.report.timesheet.AbstractTestCase;
import org.junit.Before;
import org.junit.Test;

import java.util.Locale;
import java.util.TimeZone;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TextUtilTest extends AbstractTestCase {

    protected TimeZone timezone;

    @Before
    public void before() {
        when(applicationProperties.getDefaultBackedString(eq("jira.timetracking.hours.per.day"))).thenReturn("1");
        when(applicationProperties.getDefaultBackedString("jira.timetracking.days.per.week")).thenReturn("2");
        when(configurationService.getMaxFractionDigits()).thenReturn(2);
        when(i18nHelper.getLocale()).thenReturn(Locale.getDefault());
    }

    @Test
    public void testDecimalSeparator() {

        TextUtil textUtil = new TextUtil(i18nHelper, timezone, configurationService);
        assertNotNull(textUtil);
        try {
            textUtil.getHours(101L);
        } catch (Exception e) {
            fail("Must be no exception: default separator must be used.");
        }

        when(configurationService.getDecimalSeparator()).thenReturn(".");
        textUtil = new TextUtil(i18nHelper, timezone, configurationService);
        assertThat(textUtil.getHours(200L), is("0.06"));

        when(configurationService.getDecimalSeparator()).thenReturn(",");
        textUtil = new TextUtil(i18nHelper, timezone, configurationService);
        assertThat(textUtil.getHours(200L), is("0,06"));
    }

    @Test
    public void test_getPlannedTime_1() {

        mockCustomFieldValue("10%");

        final TextUtil textUtil = new TextUtil(i18nHelper, timezone, configurationService);

        assertThat(textUtil.getPlannedTime(mockIssue(0L), 0), is(360L));
    }

    @Test
    public void test_getPlannedTime_2() {

        mockCustomFieldValue("0.5");

        final TextUtil textUtil = new TextUtil(i18nHelper, timezone, configurationService);

        assertThat(textUtil.getPlannedTime(mockIssue(0L), 14400), is(1800L));
    }

    @Test
    public void test_getPlannedTime_Estimated() {
        mockCustomFieldValue("0.5");

        final TextUtil textUtil = new TextUtil(i18nHelper, timezone, configurationService);

        assertThat(textUtil.getPlannedTime(mockIssue(1800L), 900), is(900L));
    }

    @Test
    public void test_getPlannedTime_negativeUtilization() {

        mockCustomFieldValue("-50%");

        final TextUtil textUtil = new TextUtil(i18nHelper, timezone, configurationService);

        assertThat(textUtil.getPlannedTime(mockIssue(0L), 14400), is(3600L));
    }

    @Test
    public void test_getPlannedTime_more1Utilization() {

        mockCustomFieldValue("200%");

        final TextUtil textUtil = new TextUtil(i18nHelper, timezone, configurationService);

        assertThat(textUtil.getPlannedTime(mockIssue(0L), 14400), is(3600L));
    }

    @Test
    public void test_getPlannedTime_wrongUtilization() {

        mockCustomFieldValue("aaa%");

        final TextUtil textUtil = new TextUtil(i18nHelper, timezone, configurationService);

        assertThat(textUtil.getPlannedTime(mockIssue(0L), 14400), is(3600L));
    }

    @Test
    public void test_getPlannedTime_noField() {

        final CustomFieldManager customFieldManager = mock(CustomFieldManager.class);
        when(ComponentManager.getComponentInstanceOfType(CustomFieldManager.class)).thenReturn(customFieldManager);

        final TextUtil textUtil = new TextUtil(i18nHelper, timezone, configurationService);
        assertThat(textUtil.getPlannedTime(mockIssue(0L), 0), is(3600L));
    }

    @Test
    public void test_getPlannedTime_noValue() {

        final CustomFieldManager customFieldManager = mock(CustomFieldManager.class);
        when(ComponentManager.getComponentInstanceOfType(CustomFieldManager.class)).thenReturn(customFieldManager);
        final CustomField customField = mock(CustomField.class);
        when(customFieldManager.getCustomFieldObjectByName(eq("utilization"))).thenReturn(customField);

        final TextUtil textUtil = new TextUtil(i18nHelper, timezone, configurationService);
        assertThat(textUtil.getPlannedTime(mockIssue(0L), 0), is(3600L));
    }

    protected Issue mockIssue(Long estimate) {
        final Issue issue = mock(Issue.class);
        when(issue.getEstimate()).thenReturn(estimate);
        when(issue.getKey()).thenReturn("MOCK-1");
        return issue;
    }

    protected void mockCustomFieldValue(String value) {
        final CustomFieldManager customFieldManager = mock(CustomFieldManager.class);
        final CustomField customField = mock(CustomField.class);
        when(ComponentManager.getComponentInstanceOfType(CustomFieldManager.class)).thenReturn(customFieldManager);
        when(customFieldManager.getCustomFieldObjectByName(eq("utilization"))).thenReturn(customField);
        when(customField.getValue(any(Issue.class))).thenReturn(value);
    }
}
