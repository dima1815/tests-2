package com.fdu.jira.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import jira.plugin.report.timesheet.AbstractTestCase;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class CalendarUtilTest extends AbstractTestCase {

    // check current date is included in month view
    @Test
    public void testDateRange() throws ParseException {
        Locale defaultLocale = Locale.getDefault();
        try {
            Locale.setDefault(new Locale("fi", "FI"));
            TimeZone timezone = TimeZone.getTimeZone("EET");
            Calendar currentDate = Calendar.getInstance(timezone);
            // reportingDate stands for first day of week
            Calendar[] dates = CalendarUtil.getDatesRange(currentDate.getFirstDayOfWeek(), 1, 0, true, timezone);
            Date startDate = dates[0].getTime();
            Date endDate = dates[1].getTime();
            Date workedDate = currentDate.getTime();
            Calendar workedC = CalendarUtil.convertWorkedTimeDate(workedDate, timezone, timezone);
            Date dateOfTheDay = workedC.getTime();
            assertFalse("Out of interval", dateOfTheDay.before(startDate)
                    || !dateOfTheDay.before(endDate));
        } finally {
            Locale.setDefault(defaultLocale);
        }
    }

    @Test
    public void testNumOfWeeks() {
        Calendar start = Calendar.getInstance();
        Calendar end = Calendar.getInstance();
        start.set(2010, Calendar.AUGUST, 23);
        end.set(2010, Calendar.SEPTEMBER, 26);
        assertEquals("numOfWeeks", 5, CalendarUtil.getNumOfWeeks(start.getTime(), end.getTime(), false));
        assertEquals("monthView numOfWeeks", 1, CalendarUtil.getNumOfWeeks(start.getTime(), end.getTime(), true));
        assertEquals("0 numOfWeeks", 1, CalendarUtil.getNumOfWeeks(start.getTime(), start.getTime(), true));
    }

    @Test
    public void test_dateRange_startDate() throws Exception {
        final TimeZone timezone = TimeZone.getTimeZone("EET");
        final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        format.setTimeZone(timezone);
        final Date startDate = format.parse("2013-11-27");
        final Calendar[] range = CalendarUtil.getDatesRange(Calendar.MONDAY, 1, 0, false, timezone, startDate);
        assertThat(format.format(range[0].getTime()), is("2013-11-25"));
        assertThat(format.format(range[1].getTime()), is("2013-12-02"));
    }

    @Test
    public void test_dateRange_startDate_monthView() throws Exception {
        final TimeZone timezone = TimeZone.getTimeZone("EET");
        final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        format.setTimeZone(timezone);
        final Date startDate = format.parse("2013-11-25");
        final Calendar[] range = CalendarUtil.getDatesRange(Calendar.MONDAY, 1, 0, true, timezone, startDate);
        assertThat(format.format(range[0].getTime()), is("2013-11-25"));
        assertThat(format.format(range[1].getTime()), is("2013-12-23"));
    }

    @Test
    public void test_roundByWeekDay() {
        final Calendar day = Calendar.getInstance();
        day.set(2014, Calendar.MAY, 12);
        day.getTime(); // recalculate
        CalendarUtil.roundByWeekDay(day, Calendar.FRIDAY);

        final Calendar expected = Calendar.getInstance();
        expected.set(2014, Calendar.MAY, 9);
        CalendarUtil.roundDate(day);
        CalendarUtil.roundDate(expected);
        assertThat(day.getTime(), is(expected.getTime()));
    }

    @Test
    public void test_roundByWeekDay_sameDay() {
        final Calendar day = Calendar.getInstance();
        day.set(2014, Calendar.MAY, 13);
        day.getTime(); // recalculate
        CalendarUtil.roundByWeekDay(day, Calendar.TUESDAY);

        final Calendar expected = Calendar.getInstance();
        expected.set(2014, Calendar.MAY, 13);
        expected.getTime(); // recalculate
        CalendarUtil.roundDate(day);
        CalendarUtil.roundDate(expected);
        assertThat(day.getTime(), is(expected.getTime()));
    }

    @Test
    public void test_isSameWeek() {
        final Calendar day1 = Calendar.getInstance();
        day1.set(2014, Calendar.MAY, 12);
        day1.getTime(); // recalculate
        final Calendar day2 = Calendar.getInstance();
        day2.set(2014, Calendar.MAY, 15);
        day2.getTime(); // recalculate

        assertFalse(CalendarUtil.isSameWeek(day1, day2, Calendar.TUESDAY));
        assertTrue(CalendarUtil.isSameWeek(day1, day2, Calendar.SUNDAY));
    }

    @Test
    public void test_getReportingDay() {
        final TimeZone timezone = TimeZone.getTimeZone("EET");
        final Calendar date = Calendar.getInstance();
        date.setTimeZone(timezone);
        date.set(2014, Calendar.MAY, 15);
        final boolean monthView = true; 
        assertThat(CalendarUtil.getReportingDay(date.getTime(), Calendar.MONDAY, !monthView, timezone), is(Calendar.THURSDAY));
        date.set(2014, Calendar.JUNE, 15);
        assertThat(CalendarUtil.getReportingDay(date.getTime(), Calendar.MONDAY, !monthView, timezone), is(Calendar.SUNDAY));
        assertThat(CalendarUtil.getReportingDay(null, Calendar.SUNDAY, !monthView, timezone), is(Calendar.SUNDAY));
        assertThat(CalendarUtil.getReportingDay(null, Calendar.MONDAY, !monthView, timezone), is(Calendar.MONDAY));
    }
}
