package com.fdu.jira.util;

import com.google.common.collect.ImmutableSet;
import jira.plugin.report.timesheet.AbstractTestCase;
import org.apache.http.impl.cookie.DateUtils;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class WeekPortletHeaderTest extends AbstractTestCase {

    @Test
    public void test_isBusinessDay() throws Exception {

        final String[] formats = {"yyyy-MM-dd HH:mm"};
        Date date = DateUtils.parseDate("2013-08-20 12:03", formats);   // Tuesday
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        WeekPortletHeader header = new WeekPortletHeader(
                calendar,
                true,
                ImmutableSet.of(Calendar.SUNDAY, Calendar.SATURDAY),
                null,
                Calendar.MONDAY,
                0);
        assertTrue(header.isBusinessDay());

        header = new WeekPortletHeader(
                calendar,
                true,
                ImmutableSet.of(Calendar.TUESDAY, Calendar.MONDAY),
                null,
                Calendar.MONDAY,
                0);
        assertFalse(header.isBusinessDay());

        date = DateUtils.parseDate("2013-08-18 12:03", formats);    // Sunday
        calendar.setTime(date);
        header = new WeekPortletHeader(
                calendar,
                true,
                ImmutableSet.of(Calendar.SUNDAY, Calendar.SATURDAY),
                null,
                Calendar.MONDAY,
                0);
        assertFalse(header.isBusinessDay());
    }
}
