package com.fdu.jira.plugin.report;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.web.action.ProjectActionSupport;
import com.atlassian.jira.web.util.OutlookDate;
import com.atlassian.jira.web.util.OutlookDateManager;
import com.google.common.collect.ImmutableMap;
import jira.plugin.report.timesheet.AbstractTestCase;
import jira.plugin.report.timesheet.TimeBase;
import jira.timesheet.plugin.configuration.ConfigurationService;
import org.apache.commons.lang.time.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AbstractTimebaseReportTest extends AbstractTestCase {

    protected final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    protected ProjectActionSupport action = mock(ProjectActionSupport.class);
    protected ConfigurationService configurationService = mock(ConfigurationService.class);
    protected OutlookDateManager outlookDateManager = mock(OutlookDateManager.class);
    protected OutlookDate outlookDate = mock(OutlookDate.class);

    protected final Map<String, String> errorMap = new HashMap<String, String>();

    @SuppressWarnings("deprecation")
    @Before
    public void setUp() throws Exception {
        final Locale locale = Locale.ENGLISH;
        when(ComponentAccessor.getComponent(OutlookDateManager.class)).thenReturn(outlookDateManager);
        when(outlookDateManager.getOutlookDate(locale)).thenReturn(outlookDate);
        when(i18nHelper.getLocale()).thenReturn(locale);
        when(action.getText("startPropertyKey")).thenReturn("startPropertyValue");
        when(action.getText(Matchers.eq("timesheet.endDateTooLate"), anyInt())).thenReturn("endDatePropertyValue");
        when(configurationService.getMaxDays()).thenReturn(62);
        when(outlookDate.parseDatePicker(anyString())).thenAnswer(new Answer<Date>() {
            public Date answer(InvocationOnMock invocationOnMock) throws Throwable {
                return DATE_FORMAT.parse((String) invocationOnMock.getArguments()[0]);
            }
        });
        doAnswer(new Answer() {
            public Object answer(InvocationOnMock invocationOnMock) throws Throwable {
                return errorMap.put(
                        (String) invocationOnMock.getArguments()[0],
                        (String) invocationOnMock.getArguments()[1]);
            }
        }).when(action).addError(anyString(), anyString());
    }

    @Test
    public void testValidate_success() {
        final AbstractTimebaseReport<TimeBase> report = prepareReport();

        report.validate(action, ImmutableMap.of());
        assertThat(errorMap.size(), is(0));

        report.validate(action, ImmutableMap.of("endDate", "2013-01-01"));
        assertThat(errorMap.size(), is(0));

        report.validate(action, ImmutableMap.of("startDate", DATE_FORMAT.format(DateUtils.addWeeks(new Date(), -1))));
        assertThat(errorMap.size(), is(0));
    }

    @Test
    public void testValidate_after() {
        final AbstractTimebaseReport<TimeBase> report = prepareReport();

        report.validate(action, ImmutableMap.of("startDate", "2013-05-05", "endDate", "2013-01-01"));
        assertThat(errorMap.size(), is(1));
        assertThat(errorMap.get("endDate"), is("startPropertyValue"));
    }

    @Test
    public void testValidate_interval() {
        final AbstractTimebaseReport<TimeBase> report = prepareReport();

        report.validate(action, ImmutableMap.of("startDate", "2012-02-02", "endDate", "2013-01-01"));
        assertThat(errorMap.size(), is(1));
        assertThat(errorMap.get("endDate"), is("endDatePropertyValue"));

        errorMap.clear();
        assertThat(errorMap.size(), is(0));

        report.validate(action, ImmutableMap.of("startDate", DATE_FORMAT.format(DateUtils.addYears(new Date(), -2))));
        assertThat(errorMap.size(), is(1));
        assertThat(errorMap.get("endDate"), is("endDatePropertyValue"));
    }

    protected AbstractTimebaseReport<TimeBase> prepareReport() {
        return new AbstractTimebaseReport<TimeBase>(authenticationContext, null, null, null, null, configurationService) {
            @Override
            protected String generateReport(ProjectActionSupport action, Map params, boolean excelView) throws Exception {
                return null;
            }

            @Override
            protected TimeBase getReportObject() {
                return null;
            }

            @Override
            protected void init(Map params) {
            }

            @Override
            protected Map<String, String> getValidationErrorMessages() {
                return ImmutableMap.of("beforeStartDate", "startPropertyKey");
            }
        };
    }
}
