package com.fdu.jira.plugin.report.timesheet;

import com.atlassian.jira.project.MockProject;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.security.Permissions;
import com.fdu.jira.util.TextUtil;

import jira.plugin.report.timesheet.AbstractTestCase;

import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class ProjectValuesGeneratorTest extends AbstractTestCase {

    private HashMap<String, Object> userParams;

    @Before
    public void setUp() {
        when(salApplicationProperties.getVersion()).thenReturn("6.0");

        final Project project = new MockProject(1L, "projectKey", "Project Name");
        when(projectManager.getProjectObjects()).thenReturn(Arrays.asList(project));
        when(permissionManager.hasPermission(Permissions.BROWSE, project, loginUser)).thenReturn(true);
        when(httpRequest.getParameter("projectid")).thenReturn(null);
        when(httpRequest.getParameter("selectedProjectId")).thenReturn("someString");
        userParams = new HashMap<String, Object>();
        userParams.put("User", loginUser);
   }

    @Test
    public void testGetValues_noProperty() {
        final ProjectValuesGenerator generator = new ProjectValuesGenerator();
        final Map<String, String> values = generator.getValues(userParams);
        assertThat(values.size(), is(2));
        assertThat(values.get(""), is(TextUtil.NONE));
        assertThat(values.get("1"), is("Project Name"));
    }

    @Test
    public void testGetValues_matchedProperty() {
        when(configurationService.getExcludeProjects()).thenReturn(Arrays.asList(StringUtils.split("1")));
        final ProjectValuesGenerator generator = new ProjectValuesGenerator();
        final Map<String, String> values = generator.getValues(userParams);
        assertThat(values.size(), is(1));
        assertThat(values.get(""), is(TextUtil.NONE));
    }

    @Test
    public void testGetValues_matchedPropertyDisabled() {
        when(configurationService.getExcludeProjects()).thenReturn(Arrays.asList(StringUtils.split("1")));
        final ProjectValuesGenerator generator = new ProjectValuesGenerator();
        userParams.put(ProjectValuesGenerator.ALL_PROJECTS, Boolean.TRUE);
        final Map<String, String> values = generator.getValues(userParams);
        assertThat(values.size(), is(2));
        assertThat(values.get(""), is(TextUtil.NONE));
        assertThat(values.get("1"), is("Project Name"));
    }

    @Test
    public void testGetValues_notMatchedProperty() {
        when(configurationService.getExcludeProjects()).thenReturn(Arrays.asList(StringUtils.split("notFoundKey")));
        final ProjectValuesGenerator generator = new ProjectValuesGenerator();
        final Map<String, String> values = generator.getValues(userParams);
        assertThat(values.size(), is(2));
        assertThat(values.get(""), is(TextUtil.NONE));
        assertThat(values.get("1"), is("Project Name"));
    }

    @Test
    public void testGetValues_noRights() {
        when(permissionManager.hasPermission(
                Matchers.eq(Permissions.BROWSE),
                Matchers.<Project>anyObject(),
                Matchers.eq(loginUser))).thenReturn(false);
        when(httpRequest.getParameter("projectid")).thenReturn("value");
        final ProjectValuesGenerator generator = new ProjectValuesGenerator();
        final Map<String, String> values = generator.getValues(userParams);
        assertThat(values.size(), is(1));
        assertThat(values.get(""), is(TextUtil.NONE));
    }
}
