(function (mod) {
    if (typeof exports == "object" && typeof module == "object") // CommonJS
        mod(require("../../lib/codemirror"));
    else if (typeof define == "function" && define.amd) // AMD
        define(["../../lib/codemirror"], mod);
    else // Plain browser env
        mod(CodeMirror);
})(function (CodeMirror) {
    "use strict";

    CodeMirror.defineMode("jbehave", function () {

        return {
            lineComment: "!--",
            tableLineComment: "|--",
            blankLine: function (state) {
//                console.log("### on blankLine");
                state.lineNumber++;
                if (state.inStep) {
                    state.stepBody += "\n";
                }
            },
            startState: function () {
                return {

                    lineNumber: -1,
                    stepNumber: 0,
                    currentStepNumber: 0,

                    inDescription: false,
                    allowDescription: true,

                    inMeta: false,
                    allowMeta: true,
                    allowMetaField: false,

                    inNarrative: false,
                    allowNarrative: true,
                    allowNarrativeInOrderTo: false,
                    allowNarrativeAsA: false,
                    allowNarrativeIWantTo: false,

                    inLifecycle: false,
                    allowLifecycle: false,

                    inLifecycleBefore: false,
                    allowLifecycleBefore: false,

                    inLifecycleAfter: false,
                    allowLifecycleAfter: false,

                    inLifecycleOutcome: false,
                    allowLifecycleOutcome: false,

                    inScenario: false,
                    allowScenario: false,

                    inStep: false,
                    allowSteps: false,
                    allowAndStep: false,

                    inTable: false,

                    inExamples: false,
                    allowExamples: false,

                    lastStepKeyword: null,
                    currentStepKeyword: null,
                    lastStepStartedAt: null,
                    stepStartingKeyword: null,
                    stepBody: null,

                    lastTokenType: null,

                    current: null

                };
            },
            token: function (stream, state) {

                if (stream.sol()) {
                    state.lineNumber++;
                    state.inScenarioTitleLine = false;
                    state.inNarrativeField = false;
                    state.inLifecycleOutcome = false;
                }

                state.lastTokenType = "";

                // LINE COMMENT
                if (stream.sol() && !state.inTable && (stream.match(/!--.*/) || stream.match(/\|--.*/))) {
//                    state.lastTokenType =  "comment";
                    state.lastTokenType += " jb-story-comment";

//                    // TABLE COMMENT
                } else if (stream.sol() && state.inTable && stream.match(/\|--.*/)) {
                    state.lastTokenType += " jb-story-table-comment";

                    // META title
                } else if (state.allowMeta && stream.sol() && stream.match(/(Meta):/)) {

                    state.inMeta = true;
                    state.inDescription = false;
                    state.inTable = false;

                    state.allowDescription = false;
                    state.allowMeta = false;
                    state.allowMetaField = true;

                    state.lastTokenType += " jb-story-meta-title";

                    // META field
                } else if (state.allowMetaField && stream.sol() && stream.match(/@.*/)) {

                    state.inTable = false;
                    state.lastTokenType += " jb-story-meta-field";

                    // Narrative - title
                } else if (state.allowNarrative && stream.sol() && stream.match(/Narrative:/)) {

                    state.inTable = false;
                    state.inDescription = false;
                    state.inNarrative = true;

                    state.allowDescription = false;
                    state.allowMeta = false;
                    state.allowMetaField = false;
                    state.allowNarrative = false;
                    state.allowNarrativeInOrderTo = true;

                    state.allowSteps = false;

                    state.lastTokenType += " jb-story-narrative-title";

                    // Narrative - In order to - keyword
                } else if (state.allowNarrativeInOrderTo && stream.sol() && stream.match(/(In order to )/)) {

                    state.allowNarrativeInOrderTo = false;
                    state.allowNarrativeAsA = true;
                    state.inNarrativeField = true;
                    state.inTable = false;

                    state.lastTokenType += " jb-story-narrative-field-keyword";

                    // Narrative - As a - keyword
                } else if (state.allowNarrativeAsA && stream.sol() && stream.match(/(As a )/)) {

                    state.allowNarrativeAsA = false;
                    state.allowNarrativeIWantTo = true;
                    state.inNarrativeField = true;
                    state.inTable = false;

                    state.lastTokenType += " jb-story-narrative-field-keyword";

                    // Narrative - I want to - keyword
                } else if (state.allowNarrativeIWantTo && stream.sol() && stream.match(/(I want to )/)) {

                    state.allowNarrativeIWantTo = false;
                    state.inNarrativeField = true;
                    state.inTable = false;

                    state.allowScenario = true;
                    state.allowLifecycle = true;

                    state.lastTokenType += " jb-story-narrative-field-keyword";

                    // Narrative - field value
                } else if (state.inNarrativeField && stream.match(/.*/)) {

                    state.lastTokenType += " jb-story-narrative-field-value";
                    state.inTable = false;

                    // Lifecycle
                } else if (state.allowLifecycle && stream.sol() && stream.match(/Lifecycle:/)) {

                    state.inLifecycle = true;

                    state.allowLifecycle = false;
                    state.allowLifecycleBefore = true;
                    state.allowLifecycleAfter = true;
                    state.inTable = false;

                    state.lastTokenType += " jb-story-lifecycle";

                    // Lifecycle - Before
                } else if (state.allowLifecycleBefore && stream.sol() && stream.match(/Before:/)) {

                    state.inStep = false;
                    state.inLifecycleBefore = true;
                    state.inLifecycleAfter = false;
                    state.inTable = false;

                    state.allowLifecycleBefore = false;
                    state.allowSteps = true;
                    state.allowAndStep = false;

                    state.lastStepKeyword = null;
                    state.currentStepKeyword = null;
                    state.lastStepStartedAt = null;

                    state.lastTokenType += " jb-story-lifecycle-before";

                    // Lifecycle - After
                } else if (state.allowLifecycleAfter && stream.sol() && stream.match(/After:/)) {

                    state.inStep = false;
                    state.inLifecycleBefore = false;
                    state.inLifecycleAfter = true;
                    state.inTable = false;

                    state.allowLifecycleBefore = false;
                    state.allowLifecycleAfter = false;
                    state.allowLifecycleOutcome = true;

                    state.allowSteps = false;
                    state.allowAndStep = false;

                    state.lastTokenType += " jb-story-lifecycle-after";

                    // Lifecycle - Outcome keyword
                } else if (state.allowLifecycleOutcome && stream.sol() && stream.match(/Outcome: /)) {

                    state.inStep = false;
                    state.inTable = false;
                    state.inLifecycleOutcome = true;

                    state.allowLifecycleOutcome = false;
                    state.allowScenario = false;

                    state.lastTokenType += " jb-story-lifecycle-outcome-keyword";

                    // Lifecycle - Outcome value
                } else if (state.inLifecycleOutcome && !stream.sol()
                    && (stream.match(/ANY/) || stream.match(/SUCCESS/) || stream.match(/FAILURE/))) {

                    state.allowSteps = true;

                    state.inTable = false;
                    state.lastStepKeyword = null;
                    state.currentStepKeyword = null;
                    state.lastStepStartedAt = null;

                    state.lastTokenType += " jb-story-lifecycle-outcome-value";

                    // SCENARIO keyword
                } else if (state.allowScenario && stream.sol() && stream.match(/(Scenario): /)) {

                    state.inStep = false;
                    state.inLifecycle = false;
                    state.inLifecycleAfter = false;
                    state.inScenario = true;
                    state.inScenarioTitleLine = true;
                    state.inTable = false;

                    state.allowLifecycle = false;
                    state.allowLifecycleBefore = false;
                    state.allowLifecycleAfter = false;
                    state.allowLifecycleOutcome = false;
                    state.allowSteps = true;
                    state.allowAndStep = false;
                    state.allowExamples = false;

                    state.lastStepKeyword = null;
                    state.currentStepKeyword = null;
                    state.lastStepStartedAt = null;

                    state.lastTokenType += " jb-story-scenario-keyword";

                    // SCENARIO title
                } else if (state.inScenarioTitleLine && !stream.sol() && stream.match(/.*/)) {

                    state.inTable = false;
                    state.lastTokenType += " jb-story-scenario-title";

                    // GIVEN
                } else if (state.allowSteps && stream.sol() && stream.match(/(Given )/)) {

                    if (state.currentStepKeyword != null) {
                        state.lastStepKeyword = state.currentStepKeyword;
                    }
                    state.currentStepKeyword = "Given";

                    state.stepStartingKeyword = "Given "; //TODO

                    if (state.inLifecycleAfter) {
                        state.allowSteps = false;
                        state.allowAndStep = false;
                        state.inLifecycleOutcome = false;
                        state.allowLifecycleOutcome = true;
                        state.allowScenario = true;
                    } else {
                        state.allowAndStep = true;
                    }

                    state.inTable = false;
                    state.inStep = true;
                    state.stepNumber++;
                    state.stepBody = "";
                    state.lastStepStartedAt = state.lineNumber;

                    state.inStepBody = false;
                    state.stepBodyStartedAtCh = null;

                    state.currentStepNumber++;

                    state.allowExamples = true;

                    state.lastTokenType += " jb-story-step-keyword given-step";

                    // WHEN
                } else if (state.allowSteps && stream.sol() && stream.match(/(When )/)) {

                    state.inStep = true;

                    if (state.inLifecycleAfter) {
                        state.allowSteps = false;
                        state.allowAndStep = false;
                        state.inLifecycleOutcome = false;
                        state.allowLifecycleOutcome = true;
                        state.allowScenario = true;
                    } else {
                        state.allowAndStep = true;
                    }


                    if (state.currentStepKeyword != null) {
                        state.lastStepKeyword = state.currentStepKeyword;
                    }
                    state.currentStepKeyword = "When";

                    state.inTable = false;
                    state.stepStartingKeyword = "When "; //TODO
                    state.stepNumber++;
                    state.stepBody = "";
                    state.lastStepStartedAt = state.lineNumber;

                    state.inStepBody = false;
                    state.stepBodyStartedAtCh = null;

                    state.currentStepNumber++;

                    state.allowExamples = true;

                    state.lastTokenType += " jb-story-step-keyword when-step";

                    // THEN
                } else if (state.allowSteps && stream.sol() && stream.match(/(Then )/)) {

                    if (state.currentStepKeyword != null) {
                        state.lastStepKeyword = state.currentStepKeyword;
                    }
                    state.currentStepKeyword = "Then";

                    state.stepStartingKeyword = "Then "; //TODO

                    if (state.inLifecycleAfter) {
                        state.allowSteps = false;
                        state.allowAndStep = false;
                        state.inLifecycleOutcome = false;
                        state.allowLifecycleOutcome = true;
                        state.allowScenario = true;
                    } else {
                        state.allowAndStep = true;
                    }

                    state.allowExamples = true;

                    state.inTable = false;
                    state.inStep = true;
                    state.stepNumber++;
                    state.stepBody = "";
                    state.lastStepStartedAt = state.lineNumber;

                    state.inStepBody = false;
                    state.stepBodyStartedAtCh = null;

                    state.currentStepNumber++;

                    state.lastTokenType += " jb-story-step-keyword then-step";

                    // AND
                } else if (state.allowAndStep && stream.sol() && stream.match(/(And )/)) {

                    if (state.inLifecycleAfter) {
                        state.allowSteps = false;
                        state.allowAndStep = false;
                        state.inLifecycleOutcome = false;
                        state.allowLifecycleOutcome = true;
                        state.allowScenario = true;
                    }

                    state.inStep = true;
                    state.inTable = false;

                    state.stepNumber++;
                    state.stepBody = "";
                    state.lastStepStartedAt = state.lineNumber;
                    state.stepStartingKeyword = "And "; //TODO

                    if (state.currentStepKeyword != null) {
                        state.lastStepKeyword = state.currentStepKeyword;
                    }
                    state.currentStepKeyword = state.currentStepKeyword;

                    state.inStepBody = false;
                    state.stepBodyStartedAtCh = null;

                    state.currentStepNumber++;

                    state.lastTokenType += " jb-story-step-keyword " + state.lastStepKeyword + "-step";

                    // Examples
                }else if (state.allowExamples && stream.sol() && stream.match(/(Examples):/)) {

                    state.inExamples = true;
                    state.inStep = false;
                    state.inTable = false;

                    state.allowSteps = false;
                    state.allowAndStep = false;
                    state.allowExamples = false;

                    state.lastTokenType += " jb-story-examples";

                    // Description
                } else if (stream.sol() && state.allowDescription && stream.match(/(.*)/)) {

                    state.inTable = false;
                    state.inDescription = true;
                    state.lastTokenType += " jb-story-description-line";

                    // Step body
                } else if (state.inStep && stream.match(/(.*)/)) {

                    if (state.inStepBody == false) {
                        // this is the first line of the step
                        state.inStepBody = true;
                        state.stepBodyStartedAtCh = stream.column() - stream.current().length;
                    }

                    state.stepBody += stream.current() + "\n";

                    var stepBody = state.stepBody;
                    console.log("stepBody - " + stepBody);

                    state.lastTokenType += " jb-story-step-body";

                    var current = stream.current();
                    if (current.substring(0, 1) == "|") {
                        state.lastTokenType += " jb-story-table-line";
                        if (current.substring(0, 3) != "|--" && !state.inTable) {
                            state.lastTokenType += " jb-story-first-table-line";
                            state.inTable = true;
                        }
                    } else {
                        state.inTable = false;
                    }

                    // Examples body
                } else if (state.inExamples && stream.match(/(.*)/)) {

                    state.lastTokenType += " jb-story-examples-body";

                    var current = stream.current();
                    if (current.substring(0, 1) == "|") {
                        state.lastTokenType += " jb-story-table-line";
                        if (current.substring(0, 3) != "|--" && !state.inTable) {
                            state.lastTokenType += " jb-story-first-table-line";
                            state.inTable = true;
                        }
                    } else {
                        state.inTable = false;
                    }

                    // Fall through
                } else {
                    stream.match(/(.*)/);
                    state.lastTokenType += " jb-story-invalid-token";
                }

                state.current = stream.current();
                return state.lastTokenType;
            }
        };
    });

    CodeMirror.defineMIME("text/x-feature", "gherkin");

});
