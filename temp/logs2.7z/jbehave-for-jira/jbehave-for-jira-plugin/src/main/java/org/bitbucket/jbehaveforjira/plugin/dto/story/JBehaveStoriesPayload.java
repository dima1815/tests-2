package org.bitbucket.jbehaveforjira.plugin.dto.story;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Container for lists of StoryDTO objects.
 *
 * @author stasyukd
 */
@XmlRootElement(name = "stories_payload")
@XmlAccessorType(XmlAccessType.FIELD)
public class JBehaveStoriesPayload {

    @XmlElement
    private List<JBehaveStoryDTO> stories;

    /**
     * Constructor for use via reflection.
     */
    protected JBehaveStoriesPayload() {
    }

    public JBehaveStoriesPayload(List<JBehaveStoryDTO> stories) {
        this.stories = stories;
    }

    public List<JBehaveStoryDTO> getStories() {
        return stories;
    }

}
