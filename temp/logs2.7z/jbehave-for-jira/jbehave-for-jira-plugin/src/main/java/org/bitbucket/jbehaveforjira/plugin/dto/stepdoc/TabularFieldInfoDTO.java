package org.bitbucket.jbehaveforjira.plugin.dto.stepdoc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * DTO for tabular parameter fields.
 *
 * @author stasyukd
 * @since 6.0.0-SNAPSHOT
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class TabularFieldInfoDTO {

    private String fieldName;

    private List<String> allowedValues;

    private List<String> suggestedValues;

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public List<String> getAllowedValues() {
        return allowedValues;
    }

    public void setAllowedValues(List<String> allowedValues) {
        this.allowedValues = allowedValues;
    }

    public List<String> getSuggestedValues() {
        return suggestedValues;
    }

    public void setSuggestedValues(List<String> suggestedValues) {
        this.suggestedValues = suggestedValues;
    }
}
