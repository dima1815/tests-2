package org.bitbucket.jbehaveforjira.plugin.dto.storyreport;

public enum TestStatus {

    PASSED,

    FAILED,

    PENDING,

    NOT_PERFORMED,

    IGNORED

}
