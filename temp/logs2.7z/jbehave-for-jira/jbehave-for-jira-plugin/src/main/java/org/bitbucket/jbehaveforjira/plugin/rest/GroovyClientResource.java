package org.bitbucket.jbehaveforjira.plugin.rest;

import org.apache.commons.lang.Validate;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by Dmytro on 8/15/2014.
 */
@Path("/groovy-client")
public class GroovyClientResource {

    @GET
    @Path("/story-paths-finder")
    @Produces(MediaType.APPLICATION_JSON)
    public String getStoryPathsFinder() {

        String scriptPath = "groovy/GroovyStoryPathsFinder.groovy";
        String groovyScript = loadScript(scriptPath);
        return groovyScript;
    }

    @GET
    @Path("/story-loader")
    @Produces(MediaType.APPLICATION_JSON)
    public String getStoryLoader() {

        String scriptPath = "groovy/GroovyStoryLoader.groovy";
        String groovyScript = loadScript(scriptPath);
        return groovyScript;
    }

    @GET
    @Path("/step-doc-reporter")
    @Produces(MediaType.APPLICATION_JSON)
    public String getStepDocReporter() {

        String scriptPath = "groovy/GroovyStepDocReporter.groovy";
        String groovyScript = loadScript(scriptPath);
        return groovyScript;
    }

    @GET
    @Path("/story-reporter")
    @Produces(MediaType.APPLICATION_JSON)
    public String getStoryReporter() {

        String scriptPath = "groovy/GroovyStoryReporter.groovy";
        String groovyScript = loadScript(scriptPath);
        return groovyScript;
    }

    private String loadScript(String scriptPath) {

        InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(scriptPath);
        Validate.notNull(inputStream);

        BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder sb = new StringBuilder();
        String line = null;
        try {
            line = br.readLine();
            while (line != null) {
                System.out.println("line = " + line);
                sb.append(line);
                sb.append("\n");
                line = br.readLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return sb.toString();
    }
}
