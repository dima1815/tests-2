package org.bitbucket.jbehaveforjira.plugin.listeners;

import com.atlassian.event.api.EventListener;
import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.event.type.EventType;
import com.atlassian.jira.issue.Issue;
import org.bitbucket.jbehaveforjira.plugin.ao.Story;
import org.bitbucket.jbehaveforjira.plugin.ao.StoryDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import java.util.List;

/**
 * @author Maryna Stasyuk
 */
public class IssueDeletedEventListener implements InitializingBean, DisposableBean {

    private static final Logger log = LoggerFactory.getLogger(IssueDeletedEventListener.class);

    private EventPublisher eventPublisher;

    private final StoryDao storyDao;

    public IssueDeletedEventListener(EventPublisher eventPublisher, StoryDao storyDao) {
        this.eventPublisher = eventPublisher;
        this.storyDao = storyDao;
    }

    /**
     * Called when the plugin has been enabled.
     * @throws Exception
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        // register ourselves with the EventPublisher
        eventPublisher.register(this);
    }

    /**
     * Called when the plugin is being disabled or removed.
     * @throws Exception
     */
    @Override
    public void destroy() throws Exception {
        // unregister ourselves with the EventPublisher
        eventPublisher.unregister(this);
    }

    @EventListener
    public void onIssueEvent(IssueEvent issueEvent) {
        Long eventTypeId = issueEvent.getEventTypeId();

        if (eventTypeId.equals(EventType.ISSUE_DELETED_ID)) {
            Issue issue = issueEvent.getIssue();
            String issueKey = issue.getKey();
            String projectKey = issue.getProjectObject().getKey();
            List<Story> stories = storyDao.findByProjectAndIssueKey(projectKey, issueKey);
            if (!stories.isEmpty()) {
                for (Story story : stories) {
                    log.debug("Deleting JBehave story for issue with key - " + issueKey + " in project - " + projectKey + ", due to issue deletion");
                    storyDao.delete(story);
                }
            }
        }
    }
}
