package org.bitbucket.jbehaveforjira.plugin.dto.stepdoc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Parameter info DTO object.
 *
 * @author stasyukd
 * @since 6.0.0-SNAPSHOT
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ParameterInfoDTO {

    private String parameterType;
    private String simpleParameterType;
    private boolean listType;
    private List<String> allowedValues;
    private List<String> suggestedValues;
    private List<TabularFieldInfoDTO> tabularFieldInfos;

    public List<String> getSuggestedValues() {
        return suggestedValues;
    }

    public void setSuggestedValues(List<String> suggestedValues) {
        this.suggestedValues = suggestedValues;
    }

    public List<TabularFieldInfoDTO> getTabularFieldInfos() {
        return tabularFieldInfos;
    }

    public void setTabularFieldInfos(List<TabularFieldInfoDTO> tabularFieldInfos) {
        this.tabularFieldInfos = tabularFieldInfos;
    }

    public String getSimpleParameterType() {
        return simpleParameterType;
    }

    public void setSimpleParameterType(String simpleParameterType) {
        this.simpleParameterType = simpleParameterType;
    }

    public String getParameterType() {
        return parameterType;
    }

    public void setParameterType(String parameterType) {
        this.parameterType = parameterType;
    }

    public boolean isListType() {
        return listType;
    }

    public void setListType(boolean listType) {
        this.listType = listType;
    }

    public List<String> getAllowedValues() {
        return allowedValues;
    }

    public void setAllowedValues(List<String> allowedValues) {
        this.allowedValues = allowedValues;
    }

}
