package org.bitbucket.jbehaveforjira.exampleproject;

/**
 * @author Maryna Stasyuk
 */
public enum Genre {
    Fiction,
    Drama,
    Romance,
    Mystery,
    Fantasy,
    MyGenre,
}
