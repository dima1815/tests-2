package org.bitbucket.jbehaveforjira.exampleproject;

/**
 * @author Maryna Stasyuk
 */
public enum Format {

    Hardcover,
    Paperback,
    Audible,
    eBook
}
