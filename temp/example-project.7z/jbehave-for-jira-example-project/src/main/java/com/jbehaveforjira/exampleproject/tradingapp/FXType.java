package com.jbehaveforjira.exampleproject.tradingapp;

public enum FXType {
    SPOT,
    FORWARD,
    SWAP

}
