package com.jbehaveforjira.exampleproject.steps;

import com.jbehaveforjira.exampleproject.bookstore.Book;
import com.jbehaveforjira.exampleproject.bookstore.BookStore;
import org.jbehave.core.annotations.BeforeScenario;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Maryna Pristrom
 */
public class BookStoreSteps {

    private BookStore bookStore = new BookStore();

    private List<Book> shopingBasket; // simulates shopping basket


//    @Given("the following book: $book")
//    public void givenBook(Book book) {
//
//        bookStore.add(book);
//    }

    @BeforeScenario
    public void resetShoppingBasket() {
        shopingBasket = new ArrayList<Book>();
    }

    @Given("the following books: $books")
    public void givenBooks(List<Book> books) {

        bookStore.add(books);
    }

    @When("I add the following books to my shopping basket: $books")
    public void addBooksToShoppingBasket(List<Book> books) {
        shopingBasket.addAll(books);
    }

    @Then("sum total of my basket should be $sumTotal")
    public void checkBasketTotal(BigDecimal expectedTotal) {

        BigDecimal total = new BigDecimal("0.00");

        for (Book book : shopingBasket) {
            BigDecimal price = book.getPrice();
            total.add(price);
        }

        Assert.assertTrue("Sum total was - " + total + " but expected - " + expectedTotal, total.compareTo(expectedTotal) == 0);
    }

}
