package com.jbehaveforjira.exampleproject;


import com.jbehaveforjira.exampleproject.steps.BookStoreSteps;
import com.jbehaveforjira.exampleproject.steps.SimpleExampleSteps;
import com.jbehaveforjira.exampleproject.steps.TradingAppSteps;
import com.jbehaveforjira.javaclient.JiraStepDocReporter;
import com.jbehaveforjira.javaclient.JiraStoryLoader;
import com.jbehaveforjira.javaclient.JiraStoryPathsFinder;
import com.jbehaveforjira.javaclient.JiraStoryReporter;
import org.jbehave.core.configuration.Keywords;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.junit.JUnitStories;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StepdocReporter;
import org.jbehave.core.reporters.StoryReporter;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.CandidateSteps;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.jbehave.core.steps.ParameterConverters;
import org.junit.Test;

import java.io.File;
import java.util.List;

/**
 * @author Maryna Pristrom
 */
public class TestRunner extends JUnitStories {

    private final String jiraUrl = "http://localhost:2990/jira";

    private final String jiraProject = "DEMO";

//    private final String DEFAULT_ENVIRONMENT = "UAT";
//    private final String DEFAULT_ENVIRONMENT = "TEST";
    private final String DEFAULT_ENVIRONMENT = "DEV";

    public TestRunner() {

        final String environment;
        String envProperty = System.getProperty("environment");
        if (envProperty != null && !envProperty.trim().isEmpty()) {
            environment = envProperty.trim();
        } else {
            environment = DEFAULT_ENVIRONMENT;
        }

        MostUsefulConfiguration configuration = new MostUsefulConfiguration();

        // set custom Jira HTML output format
        configuration.useStoryReporterBuilder(
                new StoryReporterBuilder() {
                    public StoryReporter reporterFor(String storyPath, org.jbehave.core.reporters.Format format) {
                        if (format.equals(org.jbehave.core.reporters.Format.HTML)) {
//                            return new JiraStoryReporter(jiraUrl, jiraProject, "admin", "admin", environment);
//                            return new GroovyStoryReporter(jiraUrl, jiraProject, "admin", "admin", environment);
                            Keywords keywords = keywords();
                            return new JiraStoryReporter(new File("target", "story_report.xml"), keywords,
                                    jiraUrl, jiraProject, "admin", "admin", environment);
                        } else {
                            return super.reporterFor(storyPath, format);
                        }
                    }
                }
                        .withFailureTrace(true)
                        .withFormats(
                                Format.CONSOLE,
                                Format.HTML,
                                Format.STATS
                        )
        );

        // set Jira story loader
        JiraStoryLoader jiraLoader = new JiraStoryLoader(jiraUrl, jiraProject, "admin", "admin");
//        GroovyStoryLoader jiraLoader = new GroovyStoryLoader(jiraUrl, jiraProject, "admin", "admin", true);
        configuration.useStoryLoader(jiraLoader);

        // set Jira step doc reporter
        StepdocReporter stepDocReporter = new JiraStepDocReporter(jiraUrl, jiraProject, "admin", "admin");
//        StepdocReporter stepDocReporter = new GroovyStepDocReporter(jiraUrl, jiraProject, "admin", "admin");
        configuration.useStepdocReporter(stepDocReporter);

        ParameterConverters parameterConverters = configuration.parameterConverters();
        parameterConverters.addConverters(new ParameterConverters.ExamplesTableParametersConverter());
        configuration.useParameterConverters(parameterConverters);

        useConfiguration(configuration);

    }

    @Test
    public void run() throws Throwable {

        Embedder embedder = configuredEmbedder();

        embedder.embedderControls()
                .doIgnoreFailureInStories(false)
                .doIgnoreFailureInView(true)
                .useStoryTimeoutInSecs(Long.MAX_VALUE);

        try {
            embedder.runStoriesAsPaths(storyPaths());
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            // report step docs
            List<CandidateSteps> candidateSteps = embedder.stepsFactory().createCandidateSteps();
            embedder.reportStepdocs(configuration(), candidateSteps);
        }
    }

    @Override
    public InjectableStepsFactory stepsFactory() {
        return new InstanceStepsFactory(configuration(),
                new SimpleExampleSteps(),
                new BookStoreSteps(),
                new TradingAppSteps());
    }

    @Override
    protected List<String> storyPaths() {

        JiraStoryPathsFinder storyFinder = new JiraStoryPathsFinder(jiraUrl, jiraProject, "admin", "admin");
//        StoryPathsFinder storyFinder = new GroovyStoryPathsFinder(jiraUrl, jiraProject, "admin", "admin");
        List<String> paths = storyFinder.findPaths();
        return paths;
    }
}
