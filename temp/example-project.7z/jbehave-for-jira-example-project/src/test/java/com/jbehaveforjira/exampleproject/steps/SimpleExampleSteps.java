package com.jbehaveforjira.exampleproject.steps;

import org.jbehave.core.annotations.*;

/**
 * @author Maryna Pristrom
 */
public class SimpleExampleSteps {

    public static enum Eventtype {
        positive, negative
    }

    public static enum OutcomeKind {
        SUCCESS, FAILURE
    }

    private OutcomeKind outcome;

    @Given("some precondition")
    public void precondition() {
        // implementation here
    }

    @When("some $eventType event occurs")
    @Alias("some <eventType> event occurs")
    public void eventOccurs(Eventtype eventtype) {
        // implementation here
        if (eventtype == Eventtype.positive) {
            outcome = OutcomeKind.SUCCESS;
        } else {
            outcome = OutcomeKind.FAILURE;
        }
    }

    @Then("the outcome should be - $expectedOutcome")
    public void checkOutcome(OutcomeKind expectedOutcome) {
        // implementation here
        if (this.outcome != expectedOutcome) {
            throw new RuntimeException("Expected outcome was not as expected!");
        }

    }

    @When("I execute a step that always fails")
    public void stepThatAlwaysFails() {
        throw new RuntimeException("This step is hardcoded to always fail");
    }

    @Given("some particular $precondition")
    @Alias("some particular <precondition>")
    public void stepWithPrecondition(@Named("precondition") String precondition) {

    }

    @Then("the outcome in this case should be $be_captured")
    @Alias("the outcome in this case should be <be-captured> ")
    public void thenOutcomeShouldBeCaptureD(String beCaptured) {
    }

}
