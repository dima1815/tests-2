package org.bitbucket.jbehaveforjira.exampleproject;

/**
 * @author Maryna Stasyuk
 */
public enum BookGenre {
    Fiction,
    Drama,
    Romance,
    Mystery,
    Fantasy
}
