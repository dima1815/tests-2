package org.bitbucket.jbehaveforjira.exampleproject;

import org.jbehave.core.annotations.Given;

import java.util.List;

/**
 * @author Maryna Stasyuk
 */
public class BookRelatedSteps {

    private BookStore bookStore = new BookStore();

    @Given("the following books: $books")
    public void givenBooks(List<Book> books) {

        bookStore.add(books);
    }

}
