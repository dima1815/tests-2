package org.bitbucket.jbehaveforjira.javaclient;

import org.apache.commons.lang.Validate;
import org.jbehave.core.io.StoryLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Maryna Stasyuk
 */
public class JiraStoryLoader implements StoryLoader {

    private final Logger log = LoggerFactory.getLogger(getClass());

    private final StoryLoader storyLoader;

    private String jiraUrl;

    private String projectKey;

    public JiraStoryLoader(String jiraUrl, String projectKey) {
        this.projectKey = projectKey;

        Validate.notEmpty(jiraUrl);
        this.jiraUrl = jiraUrl;

        this.storyLoader = JiraResourceHelper.loadGroovyResource(
                jiraUrl, "story-loader", "admin", "admin", StoryLoader.class,
                new String[]{jiraUrl, projectKey}, "StoryLoader");
    }

    @Override
    public String loadStoryAsText(String storyPath) {

        String storyAsText = storyLoader.loadStoryAsText(storyPath);
        return storyAsText;
    }

}
