package org.bitbucket.jbehaveforjira.javaclient;

import java.lang.annotation.*;

/**
 * Used to provide meta information for the JBehave parameter fields.
 *
 * @author Maryna Stasyuk
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Documented
public @interface ParameterInfo {

    public static enum EmptyEnum {

    }

    boolean isMandatory() default false;

    String[] allowedValues() default {};

    String[] suggestedValues() default {};

    Class<? extends Enum> suggestedValuesEnum() default EmptyEnum.class;

    String regExPattern() default "";
}


