package org.bitbucket.jbehaveforjira.javaclient;

import java.util.List;

/**
 * Created by Dmytro on 8/15/2014.
 */
public interface StoryPathsFinder {

    List<String> findPaths();

    List<String> findPaths(List<String> includes, List<String> excludes);
}
