package org.bitbucket.jbehaveforjira.javaclient;

import org.jbehave.core.reporters.StepdocReporter;
import org.jbehave.core.steps.Stepdoc;

import java.util.List;

/**
 * @author Maryna Stasyuk
 */
public class JiraStepDocReporter implements StepdocReporter {

    private final String jiraBaseUrl;

    private final String jiraProject;

    private final StepdocReporter stepdocReporter;

    private String createStepDocsPath = "rest/story-res/1.0/step-doc/add";

    public JiraStepDocReporter(String jiraBaseUrl, String jiraProject) {
        this.jiraBaseUrl = jiraBaseUrl;
        this.jiraProject = jiraProject;

        this.stepdocReporter = JiraResourceHelper.loadGroovyResource(
                jiraBaseUrl, "step-doc-reporter", "admin", "admin", StepdocReporter.class,
                new String[]{jiraBaseUrl, jiraProject}, "StepDocReporter");
    }

    @Override
    public void stepdocs(List<Stepdoc> stepdocs, List<Object> stepsInstances) {

        this.stepdocReporter.stepdocs(stepdocs, stepsInstances);
    }

    @Override
    public void stepdocsMatching(String stepAsString, List<Stepdoc> matching, List<Object> stepsIntances) {

        this.stepdocReporter.stepdocsMatching(stepAsString, matching, stepsIntances);
    }

}
