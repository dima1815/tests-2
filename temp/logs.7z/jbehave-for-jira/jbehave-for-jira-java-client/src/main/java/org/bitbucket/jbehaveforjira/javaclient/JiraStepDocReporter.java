package org.bitbucket.jbehaveforjira.javaclient;

import org.jbehave.core.reporters.StepdocReporter;
import org.jbehave.core.steps.Stepdoc;

import java.util.List;

/**
 * @author Maryna Stasyuk
 */
public class JiraStepDocReporter implements StepdocReporter {

    private final StepdocReporter stepdocReporter;

    public JiraStepDocReporter(String jiraBaseUrl, String jiraProject, String jiraUserName, String jiraPassword) {

        String[] constructorArgs = {jiraBaseUrl, jiraProject, jiraUserName, jiraPassword};
        this.stepdocReporter = GroovyResourceHelper.loadGroovyResource(
                jiraBaseUrl, "step-doc-reporter",
                jiraUserName, jiraPassword,
                "StepDocReporter", constructorArgs);
    }

    @Override
    public void stepdocs(List<Stepdoc> stepdocs, List<Object> stepsInstances) {

        this.stepdocReporter.stepdocs(stepdocs, stepsInstances);
    }

    @Override
    public void stepdocsMatching(String stepAsString, List<Stepdoc> matching, List<Object> stepsIntances) {

        this.stepdocReporter.stepdocsMatching(stepAsString, matching, stepsIntances);
    }

}
