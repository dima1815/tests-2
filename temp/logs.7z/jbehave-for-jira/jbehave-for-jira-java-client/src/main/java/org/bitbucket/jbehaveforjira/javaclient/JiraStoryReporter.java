package org.bitbucket.jbehaveforjira.javaclient;

import org.jbehave.core.model.*;
import org.jbehave.core.reporters.StoryReporter;

import java.util.List;
import java.util.Map;

/**
 * @author Maryna Stasyuk
 */
public class JiraStoryReporter implements StoryReporter {

    private final StoryReporter storyReporter;

    private String jiraUrl;

    private String jiraProject;

    private String environment;

    public JiraStoryReporter(String jiraUrl, String jiraProject, String environment) {

        this.jiraUrl = jiraUrl;
        this.jiraProject = jiraProject;
        this.environment = environment;

        this.storyReporter = JiraResourceHelper.loadGroovyResource(
                jiraUrl, "story-reporter", "admin", "admin", StoryReporter.class,
                new String[]{jiraUrl, jiraProject, environment}, "StoryReporter");
    }

    @Override
    public void storyNotAllowed(Story story, String filter) {
        storyReporter.storyNotAllowed(story, filter);
    }

    @Override
    public void storyCancelled(Story story, StoryDuration storyDuration) {
        storyReporter.storyCancelled(story, storyDuration);
    }

    @Override
    public void beforeStory(Story story, boolean givenStory) {
        storyReporter.beforeStory(story, givenStory);
    }

    @Override
    public void afterStory(boolean givenStory) {
        storyReporter.afterStory(givenStory);
    }

    @Override
    public void narrative(Narrative narrative) {
        storyReporter.narrative(narrative);
    }

    @Override
    public void lifecyle(Lifecycle lifecycle) {
        storyReporter.lifecyle(lifecycle);
    }

    @Override
    public void scenarioNotAllowed(Scenario scenario, String filter) {
        storyReporter.scenarioNotAllowed(scenario, filter);
    }

    @Override
    public void beforeScenario(String scenarioTitle) {
        storyReporter.beforeScenario(scenarioTitle);
    }

    @Override
    public void scenarioMeta(Meta meta) {
        storyReporter.scenarioMeta(meta);
    }

    @Override
    public void afterScenario() {
        storyReporter.afterScenario();
    }

    @Override
    public void givenStories(GivenStories givenStories) {
        storyReporter.givenStories(givenStories);
    }

    @Override
    public void givenStories(List<String> storyPaths) {
        storyReporter.givenStories(storyPaths);
    }

    @Override
    public void beforeExamples(List<String> steps, ExamplesTable table) {
        storyReporter.beforeExamples(steps, table);
    }

    @Override
    public void example(Map<String, String> tableRow) {
        storyReporter.example(tableRow);
    }

    @Override
    public void afterExamples() {
        storyReporter.afterExamples();
    }

    @Override
    public void beforeStep(String step) {
        storyReporter.beforeStep(step);
    }

    @Override
    public void successful(String step) {
        storyReporter.successful(step);
    }

    @Override
    public void ignorable(String step) {
        storyReporter.ignorable(step);
    }

    @Override
    public void pending(String step) {
        storyReporter.pending(step);
    }

    @Override
    public void notPerformed(String step) {
        storyReporter.notPerformed(step);
    }

    @Override
    public void failed(String step, Throwable cause) {
        storyReporter.failed(step, cause);
    }

    @Override
    public void failedOutcomes(String step, OutcomesTable table) {
        storyReporter.failedOutcomes(step, table);
    }

    @Override
    public void restarted(String step, Throwable cause) {
        storyReporter.restarted(step, cause);
    }

    @Override
    public void dryRun() {
        storyReporter.dryRun();
    }

    @Override
    public void pendingMethods(List<String> methods) {
        storyReporter.pendingMethods(methods);
    }
}
