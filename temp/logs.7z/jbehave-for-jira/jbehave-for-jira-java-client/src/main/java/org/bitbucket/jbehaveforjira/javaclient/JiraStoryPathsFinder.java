package org.bitbucket.jbehaveforjira.javaclient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;

/**
 * @author Maryna Stasyuk
 */
public class JiraStoryPathsFinder implements StoryPathsFinder {

    private final Logger log = LoggerFactory.getLogger(getClass());

    private final StoryPathsFinder storyPathsFinder;

    private String jiraBaseUrl;

    private String jiraProject;

    public JiraStoryPathsFinder(String jiraBaseUrl, String jiraProject) {

        this.jiraBaseUrl = jiraBaseUrl;
        this.jiraProject = jiraProject;

        this.storyPathsFinder = JiraResourceHelper.loadGroovyResource(
                jiraBaseUrl, "story-paths-finder", "admin", "admin", StoryPathsFinder.class,
                new String[]{jiraBaseUrl, jiraProject}, "StoryPathsFinder");
    }

    @Override
    public List<String> findPaths() {
        return this.findPaths(Collections.EMPTY_LIST, Collections.EMPTY_LIST);
    }

    @Override
    public List<String> findPaths(List<String> includes, List<String> excludes) {

        List<String> paths = storyPathsFinder.findPaths();
        return paths;
    }

}
