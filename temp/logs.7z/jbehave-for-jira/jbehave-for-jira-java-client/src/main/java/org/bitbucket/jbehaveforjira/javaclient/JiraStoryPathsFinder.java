package org.bitbucket.jbehaveforjira.javaclient;

import java.util.Collections;
import java.util.List;

/**
 * @author Maryna Stasyuk
 */
public class JiraStoryPathsFinder implements StoryPathsFinder {

    private final StoryPathsFinder storyPathsFinder;

    public JiraStoryPathsFinder(String jiraBaseUrl, String jiraProject, String jiraUserName, String jiraPassword) {

        String[] constructorArgs = {jiraBaseUrl, jiraProject, jiraUserName, jiraPassword};
        this.storyPathsFinder = GroovyResourceHelper.loadGroovyResource(
                jiraBaseUrl, "story-paths-finder", jiraUserName, jiraPassword,
                "StoryPathsFinder", constructorArgs);
    }

    @Override
    public List<String> findPaths() {

        return this.findPaths(Collections.EMPTY_LIST, Collections.EMPTY_LIST);
    }

    @Override
    public List<String> findPaths(List<String> includes, List<String> excludes) {

        List<String> paths = storyPathsFinder.findPaths(includes, excludes);
        return paths;
    }

}
