package org.bitbucket.jbehaveforjira.javaclient;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import org.jbehave.core.model.StepPattern;
import org.jbehave.core.parsers.RegexPrefixCapturingPatternParser;
import org.jbehave.core.parsers.StepMatcher;
import org.jbehave.core.reporters.StepdocReporter;
import org.jbehave.core.steps.StepType;
import org.jbehave.core.steps.Stepdoc;

import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Maryna Stasyuk
 */
public class GroovyStepDocReporter implements StepdocReporter {

    private final String jiraBaseUrl;

    private final String jiraProject;

    private String createStepDocsPath = "rest/story-res/1.0/step-doc/add";

    private RegexPrefixCapturingPatternParser patternParser;

    public GroovyStepDocReporter(String jiraBaseUrl, String jiraProject) {
        this.jiraBaseUrl = jiraBaseUrl;
        this.jiraProject = jiraProject;
        patternParser = new RegexPrefixCapturingPatternParser();
    }

    @Override
    public void stepdocs(List<Stepdoc> stepdocs, List<Object> stepsInstances) {

        List<StepDocDTO> stepDocDTOs = new ArrayList<StepDocDTO>(stepdocs.size());

        for (Stepdoc stepdoc : stepdocs) {

            String pattern = stepdoc.getPattern();
            StepType stepType = stepdoc.getStepType();
            String startingWord = stepdoc.getStartingWord();

            StepMatcher stepMatcher = patternParser.parseStep(stepType, pattern);
            StepPattern stepPattern = stepMatcher.pattern();
            String resolvedPattern = stepPattern.resolved();
            StepDocDTO stepDocDTO = new StepDocDTO(startingWord, pattern, resolvedPattern, null, null);
            stepDocDTOs.add(stepDocDTO);
        }

        StepDocsPayload stepDocsPayload = new StepDocsPayload(stepDocDTOs);
        uploadToJira(stepDocsPayload);
    }

    private void uploadToJira(StepDocsPayload stepDocsPayload) {

        String loginParams = "?os_username=admin&os_password=admin";
        String postUrl = (jiraBaseUrl
                + "/" + createStepDocsPath + "/"
                + jiraProject
                + loginParams);

        Client client = Client.create();
        WebResource res = client.resource(postUrl);

        String response = res.accept(MediaType.APPLICATION_JSON)
                .type(MediaType.APPLICATION_JSON)
                .post(String.class, stepDocsPayload);

        System.out.println("response - " + response);

    }

    @Override
    public void stepdocsMatching(String stepAsString, List<Stepdoc> matching, List<Object> stepsIntances) {
        // ignored
    }

    @XmlRootElement
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class StepDocDTO {

        private String startingWord;
        private String pattern;
        private String resolvedPattern;
        private String groupedRegExpPattern;
        private List<Integer> parameterGroups = new ArrayList<Integer>();

        protected StepDocDTO() {
        }

        public StepDocDTO(String startingWord, String pattern, String resolvedPattern, String groupedRegExpPattern, List<Integer> parameterGroups) {
            this.startingWord = startingWord;
            this.pattern = pattern;
            this.resolvedPattern = resolvedPattern;
            this.groupedRegExpPattern = groupedRegExpPattern;
            this.parameterGroups = parameterGroups;
        }


        public String getStartingWord() {
            return startingWord;
        }

        public String getPattern() {
            return pattern;
        }

        public String getResolvedPattern() {
            return resolvedPattern;
        }

        public String getGroupedRegExpPattern() {
            return groupedRegExpPattern;
        }

        public List<Integer> getParameterGroups() {
            return parameterGroups;
        }

        public void setGroupedRegExpPattern(String groupedRegExpPattern) {
            this.groupedRegExpPattern = groupedRegExpPattern;
        }

        public void setParameterGroups(List<Integer> parameterGroups) {
            this.parameterGroups = parameterGroups;
        }

        @Override
        public String toString() {
            return "StepDocDTO{" +
                    "startingWord='" + startingWord + '\'' +
                    ", pattern='" + pattern + '\'' +
                    ", resolvedPattern='" + resolvedPattern + '\'' +
                    ", groupedRegExpPattern='" + groupedRegExpPattern + '\'' +
                    ", parameterGroups=" + parameterGroups +
                    '}';
        }
    }

    @XmlRootElement
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class StepDocsPayload {

        private List<StepDocDTO> stepDocs;

        protected StepDocsPayload() {
        }

        public StepDocsPayload(List<StepDocDTO> stepDocs) {
            this.stepDocs = stepDocs;
        }

        public List<StepDocDTO> getStepDocs() {
            return stepDocs;
        }
    }
}




