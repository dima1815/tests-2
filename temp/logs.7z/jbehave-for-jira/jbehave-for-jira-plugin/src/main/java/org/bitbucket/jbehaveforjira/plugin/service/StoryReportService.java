package org.bitbucket.jbehaveforjira.plugin.service;

import com.atlassian.activeobjects.tx.Transactional;
import org.bitbucket.jbehaveforjira.plugin.dto.storyreport.JBehaveStoryReportDTO;

import java.util.List;

@Transactional
public interface StoryReportService {

    void addStoryTestReport(String projectKey, String issueKey, JBehaveStoryReportDTO storyReportDTO);

    List<JBehaveStoryReportDTO> findStoryReports(String projectKey, String issueKey);

    void deleteForIssue(String projectKey, String issueKey);
}
