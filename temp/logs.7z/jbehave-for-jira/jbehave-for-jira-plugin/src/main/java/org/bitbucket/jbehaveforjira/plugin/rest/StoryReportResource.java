package org.bitbucket.jbehaveforjira.plugin.rest;

import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.security.JiraAuthenticationContext;
import org.apache.commons.lang.Validate;
import org.bitbucket.jbehaveforjira.plugin.dto.storyreport.JBehaveStoryReportDTO;
import org.bitbucket.jbehaveforjira.plugin.dto.storyreport.JBehaveStoryReportsPayload;
import org.bitbucket.jbehaveforjira.plugin.service.StoryReportService;
import org.bitbucket.jbehaveforjira.plugin.service.StoryService;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.List;

/**
 * Contains rest api methods related to processing of Story objects.
 *
 * @author stasyukd
 * @since 2.0.0-SNAPSHOT
 */
@Path("/story-report")
public class StoryReportResource {

    private Logger log = LoggerFactory.getLogger(this.getClass());

    private final StoryService storyService;

    private final StoryReportService storyReportService;

    private SearchService searchService;
    private JiraAuthenticationContext authenticationContext;

    public StoryReportResource(StoryService storyService,
                               StoryReportService storyReportService,
                               SearchService searchService,
                               JiraAuthenticationContext authenticationContext) {
        this.storyService = storyService;
        this.storyReportService = storyReportService;
        this.searchService = searchService;
        this.authenticationContext = authenticationContext;
    }

    @POST
    @Path("/add/{projectKey}/{issueKey}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public String addStoryTestReport(
            @PathParam("projectKey") String projectKey,
            @PathParam("issueKey") String issueKey,
            String payload) {

        ObjectMapper mapper = new ObjectMapper();
        JBehaveStoryReportDTO storyReportDTO = null;
        try {
            storyReportDTO = mapper.readValue(payload, JBehaveStoryReportDTO.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        storyReportService.addStoryTestReport(projectKey, issueKey, storyReportDTO);
        return "success";
    }

    @POST
    @Path("/add-for-path/{projectKey}/{storyPath}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public String addStoryTestReportForPath(
            @PathParam("projectKey") String projectKey,
            @PathParam("storyPath") String storyPath,
            String payload) {

        Validate.notNull(storyPath);
        Validate.isTrue(storyPath.endsWith(".story"));
        String issueKey = storyPath.substring(0, storyPath.lastIndexOf(".story"));

        return this.addStoryTestReport(projectKey, issueKey, payload);
    }



    @GET
    @Path("/find/{projectKey}/{issueKey}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public JBehaveStoryReportsPayload findStoryTestReport(
            @PathParam("projectKey") String projectKey,
            @PathParam("issueKey") String issueKey) {

        List<JBehaveStoryReportDTO> storyTestReports = storyReportService.findStoryReports(projectKey, issueKey);

        JBehaveStoryReportsPayload storyTestReportsPayloadDTO = new JBehaveStoryReportsPayload(storyTestReports);
        return storyTestReportsPayloadDTO;
    }

    @DELETE
    @Path("/delete/{projectKey}/{issueKey}")
    public Response deleteStoryTestReport(
            @PathParam("projectKey") String projectKey,
            @PathParam("issueKey") String issueKey) {

        storyReportService.deleteForIssue(projectKey, issueKey);
        return Response.ok("Successful deletion from server!").build();
    }
}
