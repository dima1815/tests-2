package org.bitbucket.jbehaveforjira.plugin.dto.story;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * @author Maryna Stasyuk
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class StoryPaths {

    private List<String> paths;

    public List<String> getPaths() {
        return paths;
    }

    public void setPaths(List<String> paths) {
        this.paths = paths;
    }
}
