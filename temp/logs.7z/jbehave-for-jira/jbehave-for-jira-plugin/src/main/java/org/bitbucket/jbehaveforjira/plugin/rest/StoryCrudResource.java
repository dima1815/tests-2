package org.bitbucket.jbehaveforjira.plugin.rest;

import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.security.JiraAuthenticationContext;
import org.apache.commons.lang.Validate;
import org.bitbucket.jbehaveforjira.plugin.dto.story.JBehaveStoryDTO;
import org.bitbucket.jbehaveforjira.plugin.service.StoryService;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;

@Path("/crud")
public class StoryCrudResource {

    private Logger log = LoggerFactory.getLogger(this.getClass());

    private final StoryService storyService;

    private SearchService searchService;

    private JiraAuthenticationContext authenticationContext;

    public StoryCrudResource(StoryService storyService, SearchService searchService,
                             JiraAuthenticationContext authenticationContext) {
        this.storyService = storyService;
        this.searchService = searchService;
        this.authenticationContext = authenticationContext;
    }

    @POST
    @Path("/save/{projectKey}/{issueKey}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.TEXT_PLAIN)
    public JBehaveStoryDTO save(@PathParam("projectKey") String projectKey,
                          @PathParam("issueKey") String issueKey,
                          String storyPayload) {

        Validate.notNull(projectKey);
        Validate.notNull(issueKey);

        // TODO - decide what to do about the null parameters below?
        ObjectMapper mapper = new ObjectMapper();
        JBehaveStoryDTO storyDTO = null;
        try {
            storyDTO = mapper.readValue(storyPayload, JBehaveStoryDTO.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        log.debug("saving story:\n" + storyDTO);

        JBehaveStoryDTO savedStoryDTO = storyService.saveOrUpdate(storyDTO);
        Validate.notNull(savedStoryDTO.getVersion());

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // ignore
        }

        return savedStoryDTO;
    }

    @DELETE
    @Path("/delete/{storyId}")
    public Response delete(@PathParam("storyId") Long storyId) {
        storyService.delete(storyId);
        return Response.ok("Successful deletion from server!").build();
    }

    @DELETE
    @Path("/delete/{projectKey}/{issueKey}")
    public Response delete(@PathParam("projectKey") String projectKey, @PathParam("issueKey") String issueKey) {
        Validate.notEmpty(projectKey);
        Validate.notEmpty(issueKey);
        storyService.delete(projectKey, issueKey);
        return Response.ok("Successful deletion from server!").build();
    }

}
