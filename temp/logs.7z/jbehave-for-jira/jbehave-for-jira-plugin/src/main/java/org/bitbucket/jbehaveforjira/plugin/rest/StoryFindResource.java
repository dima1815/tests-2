package org.bitbucket.jbehaveforjira.plugin.rest;

import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.security.JiraAuthenticationContext;
import org.apache.commons.lang.Validate;
import org.bitbucket.jbehaveforjira.plugin.dto.story.JBehaveStoriesPayload;
import org.bitbucket.jbehaveforjira.plugin.dto.story.JBehaveStoryDTO;
import org.bitbucket.jbehaveforjira.plugin.dto.story.StoryPathsPayload;
import org.bitbucket.jbehaveforjira.plugin.service.StepDocsService;
import org.bitbucket.jbehaveforjira.plugin.service.StoryReportService;
import org.bitbucket.jbehaveforjira.plugin.service.StoryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Path("/find")
public class StoryFindResource {

    private Logger log = LoggerFactory.getLogger(this.getClass());

    private final StoryService storyService;

    private final StoryReportService storyReportService;

    private final StepDocsService stepDocsSerivce;

    private SearchService searchService;

    private JiraAuthenticationContext authenticationContext;

    public StoryFindResource(StoryService storyService,
                             StoryReportService storyReportService,
                             StepDocsService stepDocsSerivce, SearchService searchService,
                             JiraAuthenticationContext authenticationContext) {
        this.storyService = storyService;
        this.storyReportService = storyReportService;
        this.stepDocsSerivce = stepDocsSerivce;
        this.searchService = searchService;
        this.authenticationContext = authenticationContext;
    }

    @GET
    @Path("/story-paths/{projectKey}")
    @Produces({MediaType.APPLICATION_JSON})
    public StoryPathsPayload listStoryPaths(@PathParam("projectKey") String projectKey,
                                     @QueryParam("appendVersionToPath")
                                     @DefaultValue("true") boolean includeVersionInPath) {

        Validate.notEmpty(projectKey);

        List<JBehaveStoryDTO> stories = storyService.findByProjectKey(projectKey);
        List<String> paths = new ArrayList<String>(stories.size());
        for (JBehaveStoryDTO story : stories) {
            StringBuilder storyPathSb = new StringBuilder(story.getProjectKey() + "/" + story.getIssueKey());
            if (includeVersionInPath) {
                Long version = story.getVersion();
                Validate.notNull(version);
                storyPathSb.append("." + version);
            }
            storyPathSb.append(".story");
            String storyPath = storyPathSb.toString();
            paths.add(storyPath);
        }
        StoryPathsPayload pathsModel = new StoryPathsPayload();
        pathsModel.setPaths(paths);

        return pathsModel;
    }

    @GET
    @Path("/for-project/{projectKey}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
    public JBehaveStoriesPayload findForProject(@PathParam("projectKey") String projectKey) {
        List<JBehaveStoryDTO> stories = storyService.findByProjectKey(projectKey);
        JBehaveStoriesPayload payload = new JBehaveStoriesPayload(stories);
        return payload;
    }

    @GET
    @Path("/for-issue/{projectKey}/{issueKey}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findForIssue(
            @PathParam("projectKey") String projectKey,
            @PathParam("issueKey") String issueKey) {

        JBehaveStoryDTO storyDTO = storyService.findByProjectAndIssueKey(projectKey, issueKey);

        Response response;
        if (storyDTO != null) {
            response = Response.ok(storyDTO, MediaType.APPLICATION_JSON).build();
        } else {
            response = Response.noContent().build();
        }
        return response;
    }

    @GET
    @Path("/for-path/{projectKey}/{storyPath}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
    public Response findForPath(
            @PathParam("projectKey") String projectKey,
            @PathParam("storyPath") String storyPath,
            @QueryParam("versionInPath")
            @DefaultValue("false") boolean versionInPath,
            @QueryParam("asString")
            @DefaultValue("false") boolean asString) {

        String issueKey;
        if (versionInPath) {
            String regexPattern = "(.*)\\.([0-9]*)(\\.story)";
            Pattern p = Pattern.compile(regexPattern);
            Matcher matcher = p.matcher(storyPath);
            if (matcher.matches()) {
                String version = matcher.group(2);
                log.debug("version in issue key is - " + version);
                issueKey = matcher.group(1);
            } else {
                throw new IllegalArgumentException("If story version is part of story path then the path must match pattern - " + regexPattern);
            }
        } else {
            issueKey = storyPath.substring(0, storyPath.lastIndexOf(".story"));
        }

        Validate.notNull(storyPath);
        Validate.isTrue(storyPath.endsWith(".story"));

        JBehaveStoryDTO storyDTO = storyService.findByProjectAndIssueKey(projectKey, issueKey);

        Response response;
        if (storyDTO != null) {
            if (asString) {
                String storyAsString = storyDTO.getAsString();
                response = Response.ok(storyAsString, MediaType.TEXT_PLAIN).build();
            } else {
                response = Response.ok(storyDTO, MediaType.APPLICATION_JSON).build();
            }
        } else {
            response = Response.noContent().build();
        }
        return response;
    }
}
