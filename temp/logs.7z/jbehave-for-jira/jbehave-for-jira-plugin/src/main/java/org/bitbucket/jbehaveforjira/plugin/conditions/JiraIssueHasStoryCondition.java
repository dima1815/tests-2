package org.bitbucket.jbehaveforjira.plugin.conditions;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.project.Project;
import com.atlassian.plugin.PluginParseException;
import com.atlassian.plugin.web.Condition;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStory;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStoryDao;

import java.util.List;
import java.util.Map;

public class JiraIssueHasStoryCondition implements Condition {

    private JBehaveStoryDao storyDao;

    public JiraIssueHasStoryCondition(JBehaveStoryDao storyDao) {

        this.storyDao = storyDao;
    }

    @Override
    public void init(Map<String, String> params) throws PluginParseException {
    }

    @Override
    public boolean shouldDisplay(Map<String, Object> context) {

        Project project = (Project) context.get("project");
        String projectKey = project.getKey();
        Issue issue = (Issue) context.get("issue");
        String isssueKey = issue.getKey();
        List<JBehaveStory> byProjectAndIssueKey = storyDao.findByProjectAndIssueKey(projectKey, isssueKey);

        return byProjectAndIssueKey.isEmpty() ? false : true;
    }
}
