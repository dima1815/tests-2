package org.bitbucket.jbehaveforjira.plugin.ao;

import com.atlassian.activeobjects.external.ActiveObjects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;

public final class StoryReportDao {

    private final Logger log = LoggerFactory.getLogger(getClass());

    private final ActiveObjects ao;

    public StoryReportDao(ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }

    public StoryReport createStoryHtmlReport() {
        return ao.create(StoryReport.class);
    }

    public void delete(StoryReport storyHtmlReport) {
        ao.delete(storyHtmlReport);
    }

    public StoryReport get(Integer id) {
        return ao.get(StoryReport.class, id);
    }

    public List<StoryReport> findAll() {
        return newArrayList(ao.find(StoryReport.class));
    }

}
