package org.bitbucket.jbehaveforjira.plugin.dto.storyreport;

/**
 * @author Maryna Stasyuk
 */
public enum TestStatus {

    PASSED,

    FAILED,

    PENDING,

    NOT_PERFORMED,

    IGNORED

}
