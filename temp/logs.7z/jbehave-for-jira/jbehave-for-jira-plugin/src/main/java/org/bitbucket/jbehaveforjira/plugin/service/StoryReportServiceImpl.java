            Story story = byIssueKey.get(0);
            StoryReport[] storyTestReports = story.getStoryReports();
package org.bitbucket.jbehaveforjira.plugin.service;

import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.security.JiraAuthenticationContext;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStory;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStoryDao;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStoryReport;
import org.bitbucket.jbehaveforjira.plugin.ao.JBehaveStoryReportDao;
import org.bitbucket.jbehaveforjira.plugin.dto.storyreport.JBehaveStoryReportDTO;
import org.bitbucket.jbehaveforjira.plugin.dto.storyreport.StoryReportDTOUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StoryReportServiceImpl implements StoryReportService {

    private JBehaveStoryReportDao storyReportDao;

    private JBehaveStoryDao storyDao;

    public StoryReportServiceImpl(IssueService is,
                                  JiraAuthenticationContext authenticationContext,
                                  JBehaveStoryDao storyDao,
                                  JBehaveStoryReportDao storyReportDao) {
        this.storyDao = storyDao;
        this.storyReportDao = storyReportDao;
    }

    public void addStoryTestReport(String projectKey, String issueKey, JBehaveStoryReportDTO storyReportDTO) {

        List<JBehaveStory> byIssueKey = storyDao.findByProjectAndIssueKey(projectKey, issueKey);
        if (byIssueKey.isEmpty()) {
            throw new IllegalArgumentException("Failed to set story test status, " +
                    "issue with key " + issueKey + " for project key - " + projectKey + " could not be found.");
        } else if (byIssueKey.size() > 1) {
            throw new RuntimeException("More than one story was found for issue key - " + issueKey);
        } else {

            JBehaveStory story = byIssueKey.get(0);

            // first we delete any storyReport that exists for the same environment as in the received reportDTO
            StoryReport[] storyHtmlReports = story.getStoryReports();
            String reportedEnvironment = storyReportDTO.getEnvironment();
            if (storyHtmlReports.length > 0) {
                // find one for the reportedEnvironment if exists and delete it since it will be replaced by the one received
                for (JBehaveStoryReport testReport : storyHtmlReports) {
                    String storedEnv = testReport.getEnvironment();
                    if (storedEnv.equals(reportedEnvironment)) {
                        storyReportDao.delete(testReport);
                        break;
                    }
                }
            }

            JBehaveStoryReport storyHtmlReport = storyReportDao.createStoryHtmlReport();
            storyHtmlReport.setStory(story);
            StoryReportDTOUtils.fromDTOToModel(storyReportDTO, storyHtmlReport);
            storyHtmlReport.save();
        }

    }

    @Override
    public List<JBehaveStoryReportDTO> findStoryReports(String projectKey, String issueKey) {
        List<JBehaveStory> byIssueKey = storyDao.findByProjectAndIssueKey(projectKey, issueKey);
        if (byIssueKey.isEmpty()) {
            return Collections.emptyList();
        } else if (byIssueKey.size() > 1) {
            throw new RuntimeException("More than one story was found for issue key - " + issueKey);
        } else {
            JBehaveStory story = byIssueKey.get(0);

            StoryReport[] storyTestReports = story.getStoryReports();
            if (storyTestReports.length == 0) {
                // createStoryReport a new report
                return Collections.emptyList();
            } else {
                List<JBehaveStoryReportDTO> storyReportDTOs = new ArrayList<JBehaveStoryReportDTO>(storyTestReports.length);
                for (JBehaveStoryReport storyTestReport : storyTestReports) {
                    JBehaveStoryReportDTO storyReportDTO = StoryReportDTOUtils.fromModelToDTO(storyTestReport);
                    storyReportDTOs.add(storyReportDTO);
                }
                return storyReportDTOs;
            }
        }
    }

    @Override
    public void deleteForIssue(String projectKey, String issueKey) {

        List<JBehaveStory> byIssueKey = storyDao.findByProjectAndIssueKey(projectKey, issueKey);
        if (byIssueKey.isEmpty()) {
            throw new IllegalArgumentException("Failed to set story test status, " +
                    "issue with key " + issueKey + " for project key - " + projectKey + " could not be found.");
        } else if (byIssueKey.size() > 1) {
            throw new RuntimeException("More than one story was found for issue key - " + issueKey);
        } else {
            JBehaveStory story = byIssueKey.get(0);
            JBehaveStoryReport[] storyTestReports = story.getStoryReports();
            if (storyTestReports.length != 0) {
                for (JBehaveStoryReport storyTestReport : storyTestReports) {
                    storyReportDao.delete(storyTestReport);
                }
            }
        }
    }
}
