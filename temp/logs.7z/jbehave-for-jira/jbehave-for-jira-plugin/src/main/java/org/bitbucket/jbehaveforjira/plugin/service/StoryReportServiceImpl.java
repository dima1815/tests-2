package org.bitbucket.jbehaveforjira.plugin.service;

import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.security.JiraAuthenticationContext;
import org.bitbucket.jbehaveforjira.plugin.ao.Story;
import org.bitbucket.jbehaveforjira.plugin.ao.StoryDao;
import org.bitbucket.jbehaveforjira.plugin.ao.StoryReport;
import org.bitbucket.jbehaveforjira.plugin.ao.StoryReportDao;
import org.bitbucket.jbehaveforjira.plugin.dto.storyreport.JiraStoryHtml;
import org.bitbucket.jbehaveforjira.plugin.dto.storyreport.StoryReportDTOUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Dmytro on 4/8/2014.
 */
public class StoryReportServiceImpl implements StoryReportService {

    private StoryReportDao storyReportDao;

    private StoryDao storyDao;

    public StoryReportServiceImpl(IssueService is,
                                  JiraAuthenticationContext authenticationContext,
                                  StoryDao storyDao,
                                  StoryReportDao storyReportDao) {
        this.storyDao = storyDao;
        this.storyReportDao = storyReportDao;
    }

    public void addStoryTestReport(String projectKey, String issueKey, JiraStoryHtml storyReportDTO) {

        List<Story> byIssueKey = storyDao.findByProjectAndIssueKey(projectKey, issueKey);
        if (byIssueKey.isEmpty()) {
            throw new IllegalArgumentException("Failed to set story test status, " +
                    "issue with key " + issueKey + " for project key - " + projectKey + " could not be found.");
        } else if (byIssueKey.size() > 1) {
            throw new RuntimeException("More than one story was found for issue key - " + issueKey);
        } else {

            Story story = byIssueKey.get(0);

            // first we delete any storyReport that exists for the same environment as in the received reportDTO
            StoryReport[] storyHtmlReports = story.getStoryHtmlReports();
            String reportedEnvironment = storyReportDTO.getEnvironment();
            if (storyHtmlReports.length > 0) {
                // find one for the reportedEnvironment if exists and delete it since it will be replaced by the one received
                for (StoryReport testReport : storyHtmlReports) {
                    String storedEnv = testReport.getEnvironment();
                    if (storedEnv.equals(reportedEnvironment)) {
                        storyReportDao.delete(testReport);
                        break;
                    }
                }
            }

            // now we createStoryReport a new report for the reported environment
            StoryReport storyHtmlReport = storyReportDao.createStoryHtmlReport();
            storyHtmlReport.setStory(story);
            StoryReportDTOUtils.fromDTOToModel(storyReportDTO, storyHtmlReport);
            storyHtmlReport.save();
        }

    }

    @Override
    public List<JiraStoryHtml> findStoryReports(String projectKey, String issueKey) {
        List<Story> byIssueKey = storyDao.findByProjectAndIssueKey(projectKey, issueKey);
        if (byIssueKey.isEmpty()) {
            return Collections.emptyList();
        } else if (byIssueKey.size() > 1) {
            throw new RuntimeException("More than one story was found for issue key - " + issueKey);
        } else {
            Story story = byIssueKey.get(0);

            StoryReport[] storyTestReports = story.getStoryHtmlReports();
            if (storyTestReports.length == 0) {
                // createStoryReport a new report
                return Collections.emptyList();
            } else {
                List<JiraStoryHtml> storyReportDTOs = new ArrayList<JiraStoryHtml>(storyTestReports.length);
                for (StoryReport storyTestReport : storyTestReports) {
                    JiraStoryHtml storyReportDTO = StoryReportDTOUtils.fromModelToDTO(storyTestReport);
                    storyReportDTOs.add(storyReportDTO);
                }
                return storyReportDTOs;
            }
        }
    }

    @Override
    public void deleteForIssue(String projectKey, String issueKey) {

        List<Story> byIssueKey = storyDao.findByProjectAndIssueKey(projectKey, issueKey);
        if (byIssueKey.isEmpty()) {
            throw new IllegalArgumentException("Failed to set story test status, " +
                    "issue with key " + issueKey + " for project key - " + projectKey + " could not be found.");
        } else if (byIssueKey.size() > 1) {
            throw new RuntimeException("More than one story was found for issue key - " + issueKey);
        } else {
            Story story = byIssueKey.get(0);
            StoryReport[] storyTestReports = story.getStoryHtmlReports();
            if (storyTestReports.length != 0) {
                for (StoryReport storyTestReport : storyTestReports) {
                    storyReportDao.delete(storyTestReport);
                }
            }
        }
    }
}
