package org.bitbucket.jbehaveforjira.plugin.conditions;

import com.atlassian.plugin.PluginParseException;
import com.atlassian.plugin.web.Condition;
import com.atlassian.crowd.embedded.api.User;

import java.util.Map;

public class ProfileUserEqualsCurrentUser implements Condition {

    @Override
    public void init(Map<String, String> params) throws PluginParseException {
    }

    @Override
    public boolean shouldDisplay(Map<String, Object> context) {
        final User profileUser = (User) context.get("profileUser");
        final User currentUser = (User) context.get("currentUser");
        return profileUser.equals(currentUser);
    }
}
