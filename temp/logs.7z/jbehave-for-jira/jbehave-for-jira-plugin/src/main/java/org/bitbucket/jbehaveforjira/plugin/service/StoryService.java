package org.bitbucket.jbehaveforjira.plugin.service;

import com.atlassian.activeobjects.tx.Transactional;
import org.bitbucket.jbehaveforjira.plugin.dto.story.JBehaveStoryDTO;

import java.util.List;

@Transactional
public interface StoryService {

    JBehaveStoryDTO findByProjectAndIssueKey(String projectKey, String issueKey);

    List<JBehaveStoryDTO> findByProjectKey(String projectKey);

    JBehaveStoryDTO findById(int storyId);

    void delete(Long storyId);

    void delete(String projectKey, String issueKey);

    JBehaveStoryDTO saveOrUpdate(JBehaveStoryDTO storyDTO);
}


