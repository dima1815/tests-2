package org.bitbucket.jbehaveforjira.plugin.service;

import com.atlassian.activeobjects.tx.Transactional;
import org.bitbucket.jbehaveforjira.plugin.dto.story.JiraStory;

import java.util.List;

@Transactional
public interface StoryService {

    JiraStory findByProjectAndIssueKey(String projectKey, String issueKey);

    List<JiraStory> findByProjectKey(String projectKey);

    JiraStory findById(int storyId);

    void delete(Long storyId);

    void delete(String projectKey, String issueKey);

    JiraStory saveOrUpdate(JiraStory storyDTO);
}


