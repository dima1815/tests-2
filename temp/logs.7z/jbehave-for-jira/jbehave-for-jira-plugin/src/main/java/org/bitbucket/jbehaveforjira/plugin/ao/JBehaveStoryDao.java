package org.bitbucket.jbehaveforjira.plugin.ao;

import com.atlassian.activeobjects.external.ActiveObjects;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;

public final class JBehaveStoryDao {

    private final Logger log = LoggerFactory.getLogger(getClass());

    private final ActiveObjects ao;

    public JBehaveStoryDao(ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }

    public JBehaveStory create() {
        final JBehaveStory story = ao.create(JBehaveStory.class);
        return story;
    }

    public void delete(JBehaveStory story) {
        ao.delete(story);
    }

    public JBehaveStory get(Integer id) {
        return ao.get(JBehaveStory.class, id);
    }

    public List<JBehaveStory> findAll() {
        return newArrayList(ao.find(JBehaveStory.class));
    }

    public List<JBehaveStory> findByProjectAndIssueKey(String projectKey, String issueKey) {
        String[] params = new String[]{projectKey, issueKey};
        Query query = Query.select().where("PROJECT_KEY = ? AND ISSUE_KEY = ?", params);
        JBehaveStory[] result = ao.find(JBehaveStory.class, query);
        return newArrayList(result);
    }

    public List<JBehaveStory> findByProjectKey(String projectKey) {
        String[] params = new String[]{projectKey};
        Query query = Query.select().where("PROJECT_KEY = ?", params);
        JBehaveStory[] result = ao.find(JBehaveStory.class, query);
        return newArrayList(result);
    }
}
