function StoryModel() {
    this.projectKey = null;
    this.issueKey = null;
    this.version = null;
    this.asString = null;
}