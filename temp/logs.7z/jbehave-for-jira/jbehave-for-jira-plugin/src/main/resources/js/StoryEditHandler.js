//var editButtonHandler;
//
//function StoryEditHandler() {
//
//    editButtonHandler = this;
//
//    this.debugOn = true;
//
//    this.debug = function (msg) {
//        if (this.debugOn) {
//            console.log("[DEBUG StoryEditHandler] " + msg);
//        }
//    }
//
//    this.init = function () {
//        this.debug("initialized");
//    }
//
//
//    this.saveStory = function (event) {
//
//        this.debug("> saveStory");
//
//        this.bindInputElementsToModel();
//
//        // remove the asString field as we are saving from the rich editor
//        storyController.currentStory.asString = null;
//        storyController.saveStoryAsModel();
//
//        event.preventDefault();
//        this.debug("# saveStory");
//    }
//
//}