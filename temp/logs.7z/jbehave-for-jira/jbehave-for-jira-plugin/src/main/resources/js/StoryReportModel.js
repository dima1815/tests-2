//function StoryReportModel() {
//
//    this.environment = "";
//    this.storyPath = "";
//    this.storyVersion = "";
//    this.status = "";
//    this.totalScenarios = "";
//    this.totalScenariosPassed = "";
//    this.totalScenariosFailed = "";
//    this.totalScenariosPending = "";
//    this.totalScenariosSkipped = "";
//    this.totalScenariosNotPerformed = "";
//    this.htmlReport = "";
//}