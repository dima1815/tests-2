package org.bitbucket.jbehaveforjira.javaclient;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author Maryna Stasyuk
 */
public class GroovyStoryPathsFinder implements StoryPathsFinder {

    private final Logger log = LoggerFactory.getLogger(getClass());

    private String jiraBaseUrl;

    private String projectKey;

    public GroovyStoryPathsFinder(String jiraBaseUrl, String projectKey) {
        this.jiraBaseUrl = jiraBaseUrl;
        this.projectKey = projectKey;
        Validate.notEmpty(projectKey);
    }

    public List<String> findPaths() {
        return this.findPaths(Collections.EMPTY_LIST, Collections.EMPTY_LIST);
    }

    public List<String> findPaths(List<String> includes, List<String> excludes) {

        List<String> paths = new ArrayList<String>();

        URI jiraSearchUrl = null;
        try {
            String fullPath = jiraBaseUrl + "/rest/story-res/1.0/find/story-paths/" + projectKey;
            fullPath += "?os_username=admin&os_password=admin";
            jiraSearchUrl = new URI(fullPath);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        Client client = Client.create();
        WebResource res = client.resource(jiraSearchUrl);
        res.type(MediaType.APPLICATION_JSON);
//        res.type(MediaType.TEXT_PLAIN);
        ClientResponse response = res.get(ClientResponse.class);
        log.info("response - " + response);
        if (response.getStatus() == 200) {

            int length = response.getLength();
            MediaType type = response.getType();
            StoryPaths storyPaths = response.getEntity(StoryPaths.class);

            if (storyPaths.getPaths() != null && !storyPaths.getPaths().isEmpty()) {
                paths = storyPaths.getPaths();
            }

        } else {
            int status = response.getStatus();
            Response.StatusType statusInfo = response.getStatusInfo();
            throw new RuntimeException("Error occurred while trying to find Jira story paths. " +
                    "Response status was - " + status + ", status info - " + statusInfo);
        }

        return paths;
    }

    @XmlRootElement
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class StoryPaths {

        private List<String> paths;

        public List<String> getPaths() {
            return paths;
        }

        public void setPaths(List<String> paths) {
            this.paths = paths;
        }
    }

}



