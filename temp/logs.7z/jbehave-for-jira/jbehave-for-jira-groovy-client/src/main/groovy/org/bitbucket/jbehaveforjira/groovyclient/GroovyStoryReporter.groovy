package org.bitbucket.jbehaveforjira.groovyclient

import com.sun.jersey.api.client.Client
import com.sun.jersey.api.client.WebResource
import org.apache.commons.lang.StringUtils
import org.apache.commons.lang.Validate
import org.jbehave.core.configuration.Keywords
import org.jbehave.core.i18n.LocalizedKeywords
import org.jbehave.core.model.*
import org.jbehave.core.reporters.HtmlOutput
import org.jbehave.core.reporters.PrintStreamOutput
import org.jbehave.core.reporters.StackTraceFormatter
import org.jbehave.core.reporters.StoryReporter
import org.jbehave.core.steps.StepCreator

import javax.ws.rs.core.MediaType
import javax.xml.bind.annotation.XmlAccessType
import javax.xml.bind.annotation.XmlAccessorType
import javax.xml.bind.annotation.XmlRootElement
import java.util.regex.Matcher
import java.util.regex.Pattern

/**
 * @author Maryna Pristrom
 */
public class GroovyStoryReporter implements StoryReporter {


    private String loginParams;
    public static enum TestStatus {

        PASSED,

        FAILED,

        PENDING,

        NOT_PERFORMED,

        IGNORED

    }

    private String basePostPath;

    private final CustomHtmlOutput htmlOutput;

    private boolean compressFailureTrace;

    private boolean reportFailureTrace;

    private LocalizedKeywords keywords;

    private PrintStream printStream;

    private String environment;

    private Properties outputPatterns;

    private String jiraBaseUrl;

    private String jiraProject;

    private String addTestReportPath = "rest/story-res/1.0/story-report/add-for-path";

    private String storyPath;

    private Long jiraVersion;

    private TestStatus status;

    private int totalScenarios;

    private int totalScenariosPassed;

    private int totalScenariosFailed;

    private int totalScenariosPending;

    private int totalScenariosIgnored;

    private int totalScenariosNotPerformed;

    private TestStatus currentScenarioStatus;

    private final List<Byte> bytesList;

    public GroovyStoryReporter(String jiraBaseUrl, String jiraProject, String username, String password, String environment) {

        this.loginParams = "?os_username=" + username + "&os_password=" + password;
        this.basePostPath = jiraBaseUrl + "/rest/jbehave-for-jira/1.0/story-test/add-for-path/";

        this.bytesList = new LinkedList<Byte>();
        OutputStream outStream = new OutputStream() {

            @Override
            public void write(int b) throws IOException {
                bytesList.add((byte) b);
            }

        };

        this.printStream = new PrintStream(outStream);

        this.jiraBaseUrl = jiraBaseUrl;
        this.jiraProject = jiraProject;
        this.environment = environment;

        this.outputPatterns = new Properties();
        this.outputPatterns = mergeCustomPatterns(outputPatterns);
        this.keywords = new LocalizedKeywords();
        this.reportFailureTrace = true;
        this.compressFailureTrace = false;

        this.htmlOutput = new CustomHtmlOutput(printStream, outputPatterns, keywords,
                reportFailureTrace, compressFailureTrace);
    }

    public void narrative(Narrative narrative) {
        htmlOutput.narrative(narrative);
    }

    @Override
    public void lifecyle(Lifecycle lifecycle) {
        htmlOutput.lifecyle(lifecycle);
    }

    @Override
    public void beforeScenario(String title) {

        this.totalScenarios++;
        this.currentScenarioStatus = TestStatus.PASSED; // assume pass initially

        htmlOutput.beforeScenario(title);
    }

    @Override
    public void scenarioMeta(Meta meta) {
        htmlOutput.scenarioMeta(meta);
    }

    @Override
    public void afterScenario() {

        htmlOutput.afterScenario();

        switch (this.currentScenarioStatus) {
            case TestStatus.PASSED:
                totalScenariosPassed++;
                break;
            case TestStatus.FAILED:
                totalScenariosFailed++;
                break;
            case TestStatus.PENDING:
                totalScenariosPending++;
                break;
            case TestStatus.IGNORED:
                totalScenariosIgnored++;
                break;
            case TestStatus.NOT_PERFORMED:
                totalScenariosNotPerformed++;
                break;
        }
    }

    @Override
    public void givenStories(GivenStories givenStories) {
        htmlOutput.givenStories(givenStories);
    }

    @Override
    public void givenStories(List<String> storyPaths) {
        htmlOutput.givenStories(storyPaths);
    }

    @Override
    public void beforeExamples(List<String> steps, ExamplesTable table) {
//        htmlOutput.beforeExamples(steps, table);
        htmlOutput.print(htmlOutput.format("beforeExamples", "{0}\n", keywords.examplesTable()));
//        for (String step : steps) {
//            htmlOutput.print(htmlOutput.format("examplesStep", "{0}\n", step));
//        }
        htmlOutput.print(htmlOutput.format("beforeExamplesTable", ""));
        htmlOutput.print(htmlOutput.formatTable(table));
        htmlOutput.print(htmlOutput.format("afterExamplesTable", ""));
    }

    @Override
    public void example(Map<String, String> tableRow) {

        htmlOutput.example(tableRow);
//        print(format("example", "\n{0} {1}\n", keywords.examplesTableRow(), tableRow));
    }

    @Override
    public void afterExamples() {
        htmlOutput.afterExamples();
    }

    @Override
    public void beforeStep(String step) {
        htmlOutput.beforeStep(step);
    }

    @Override
    public void scenarioNotAllowed(Scenario scenario, String filter) {

        htmlOutput.scenarioNotAllowed(scenario, filter);
        if (this.currentScenarioStatus == TestStatus.PASSED /*i.e. if it has not been set to some other status yet*/) {
            this.currentScenarioStatus = TestStatus.IGNORED;
        }
    }

    private String[] splitIntoKeywordAndBody(String step) {
        int firstSpace = step.indexOf(" ");
        if (firstSpace != -1) {
            String keyword = step.substring(0, firstSpace + 1);
            String stepBody = step.substring(firstSpace + 1);
            String[] result = new String[2];
            result[0] = keyword;
            result[1] = stepBody;
            return result;
        } else {
            return null;
        }
    }

    @Override
    public void successful(String step) {

        String[] tokens = this.splitIntoKeywordAndBody(step);
        if (tokens != null) {
            htmlOutput.print(htmlOutput.format("successfulStep", "{0} {1}\n", tokens[0], tokens[1], "(SUCCESSFUL)"));
        } else {
            htmlOutput.successful(step);
        }
    }

    @Override
    public void ignorable(String step) {
        htmlOutput.ignorable(step);
    }

    @Override
    public void failed(String step, Throwable storyFailure) {

        String[] tokens = splitIntoKeywordAndBody(step);
        if (tokens != null) {
            htmlOutput.failed(step, storyFailure);
            Throwable cause = storyFailure.getCause()
            String stackTrace = new StackTraceFormatter(htmlOutput.compressFailureTrace()).stackTrace(cause);
            Throwable underlyingCause = cause;
            while (underlyingCause.getCause() != null) {
                underlyingCause = underlyingCause.getCause();
            }
            String underlyingErrorMsg = "Underlying error - " + underlyingCause.getMessage();
            String timeAsString = "" + new Date().getTime()
            String uniqueId = timeAsString.substring(timeAsString.length() - 6);
            htmlOutput.print(htmlOutput.format("failedStep", "{0} {1} ({2})\n({3})\n",
                    tokens[0], tokens[1],
                    htmlOutput.keywords.failed(),
                    storyFailure.getCause(),
                    stackTrace, underlyingErrorMsg, uniqueId));
        } else {
            htmlOutput.failed(step, storyFailure);
        }
        this.currentScenarioStatus = TestStatus.FAILED;
    }

    @Override
    public void failedOutcomes(String step, OutcomesTable table) {
        htmlOutput.failedOutcomes(step, table);
    }

    @Override
    public void restarted(String step, Throwable cause) {
        htmlOutput.restarted(step, cause);
    }

    @Override
    public void dryRun() {
        htmlOutput.dryRun();
    }

    @Override
    public void pendingMethods(List<String> methods) {
        htmlOutput.pendingMethods(methods);
    }

    @Override
    public void pending(String step) {

        String[] tokens = this.splitIntoKeywordAndBody(step);
        if (tokens != null) {
            htmlOutput.print(htmlOutput.format("pendingStep", "{0}{1} ({2})\n", tokens[0], tokens[1], keywords.pending()));
        } else {
            htmlOutput.pending(step);
        }

        if (this.currentScenarioStatus != TestStatus.FAILED) { // fail status has priority over pending
            this.currentScenarioStatus = TestStatus.PENDING;
        }
    }

    @Override
    public void notPerformed(String step) {

        String[] tokens = this.splitIntoKeywordAndBody(step);
        if (tokens != null) {
            htmlOutput.print(htmlOutput.format("notPerformedStep", "{0}{1} ({2})\n", tokens[0], tokens[1], keywords.notPerformed()));
        } else {
            htmlOutput.notPerformed(step);
        }
    }


    @Override
    public void storyNotAllowed(Story story, String filter) {
        htmlOutput.storyNotAllowed(story, filter);
    }

    @Override
    public void storyCancelled(Story story, StoryDuration storyDuration) {
        htmlOutput.storyCancelled(story, storyDuration);
    }

    @Override
    public void beforeStory(Story story, boolean givenStory) {

        this.status = TestStatus.PASSED; // assume passed at start, and then change to other if failed/pending, etc.

        storyPath = story.getPath();

        if (!givenStory && !storyPath.equals("BeforeStories") && !storyPath.equals("AfterStories")) {
            // extract version
            String regexPattern = "(.*)\\.([0-9]*)(\\.story)";
            Pattern p = Pattern.compile(regexPattern);
            Matcher matcher = p.matcher(storyPath);
            if (matcher.matches()) {
                String versionStr = matcher.group(2);
                jiraVersion = Long.parseLong(versionStr);
            } else {
                throw new IllegalArgumentException("JiraStory path must match pattern - " + regexPattern);
            }
        }

        htmlOutput.beforeStory(story, givenStory);
        htmlOutput.description(story);
        htmlOutput.meta(story);
    }

    @Override
    public void afterStory(boolean givenStory) {

        htmlOutput.afterStory(givenStory);

        if (!givenStory && !storyPath.equals("BeforeStories") && !storyPath.equals("AfterStories")) {

            // set story status
            if (totalScenariosFailed > 0) {
                this.status = TestStatus.FAILED;
            } else if (totalScenariosPending > 0) {
                this.status = TestStatus.PENDING;
            } else if (totalScenariosIgnored == totalScenarios) {
                this.status = TestStatus.IGNORED;
            } else {
                this.status = TestStatus.PASSED;
            }

            String storyReport = bytesListToString(this.bytesList);
            sendStoryReport(storyReport);
        }

    }

    private static String bytesListToString(List<Byte> writtenBytes) {

        Byte[] bytes = writtenBytes.toArray(new Byte[writtenBytes.size()]);
        byte[] bytesArray = new byte[bytes.length];
        for (int i = 0; i < bytes.length; i++) {
            Byte aByte = bytes[i];
            bytesArray[i] = aByte;
        }

        String str = new String(bytesArray);
        return str;
    }

    protected void sendStoryReport(String testReport) {

        Validate.notNull(status);
        Validate.notEmpty(testReport);

        StoryReport storyHtmlReportDTO = new StoryReport(environment, storyPath, jiraVersion, status, testReport);

        storyHtmlReportDTO.setTotalScenarios(totalScenarios);
        storyHtmlReportDTO.setTotalScenariosPassed(totalScenariosPassed);
        storyHtmlReportDTO.setTotalScenariosFailed(totalScenariosFailed);
        storyHtmlReportDTO.setTotalScenariosPending(totalScenariosPending);
        storyHtmlReportDTO.setTotalScenariosSkipped(totalScenariosIgnored);
        storyHtmlReportDTO.setTotalScenariosNotPerformed(totalScenariosNotPerformed);

        // remove the version part from story path
        // extract version
        String regexPattern = "(.*)\\.([0-9]*)(\\.story)";
        Pattern p = Pattern.compile(regexPattern);
        Matcher matcher = p.matcher(storyPath);
        if (matcher.matches()) {
            storyPath = matcher.group(1) + matcher.group(3);
        } else {
            throw new IllegalArgumentException("JiraStory path must match pattern - " + regexPattern);
        }

        String postUrl = this.basePostPath + storyPath + loginParams;

        Client client = Client.create();
        WebResource res = client.resource(postUrl);

        String response = res.accept(MediaType.APPLICATION_JSON)
                .type(MediaType.APPLICATION_JSON)
                .post(String.class, storyHtmlReportDTO);

        System.out.println("response - " + response);
    }


    public static String markTableCorrectly(String text, CustomHtmlOutput htmlOutput) {

        String tableStartMarker = StepCreator.PARAMETER_TABLE_START;
        tableStartMarker = (String) htmlOutput.escape(PrintStreamOutput.Format.HTML, tableStartMarker)[0];

        String tableEndMarker = StepCreator.PARAMETER_TABLE_END;
        tableEndMarker = (String) htmlOutput.escape(PrintStreamOutput.Format.HTML, tableEndMarker)[0];

        if (text.contains("&#9252;")) {

            // use case for successful steps

            StringBuilder sb = new StringBuilder();
            String[] tokens = text.split("\\&#9252;");

            for (int i = 0; i < tokens.length; i++) {
                String token = tokens[i];
                boolean isTableStartLine = false;
                boolean isTableEndLine = false;
                if (token.startsWith("|")) {
                    // table line
                    if (i == 0 || (i != 0 && !tokens[i - 1].startsWith("|"))) {
                        // if previous line was not a table line then open the table tag
                        sb.append(tableStartMarker);
                        sb.append(token);
                        isTableStartLine = true;
                    }
                    if (i == tokens.length - 1 || !tokens[i + 1].startsWith("|")) {
                        // if this is the last line or the next line is not a table line
                        String beforePart = token.substring(0, token.lastIndexOf("|") + 1);
                        sb.append(beforePart);
                        sb.append(tableEndMarker);
                        String afterPart = token.substring(token.lastIndexOf("|") + 1);
                        sb.append(afterPart);
                        isTableEndLine = true;
                    }
                    if (!isTableStartLine && !isTableEndLine) {
                        // table line that is not first or last line in that table
                        sb.append(token);
                    }
                    if (i != 0 && i != tokens.length - 1) {
                        sb.append("\n");
                    }
                } else {
                    if (i != 0) {
                        sb.append("\n");
                    }
                    sb.append(token);
                }
            }

            String result = sb.toString();
            return result;

        } else {

            // use case for failed steps, for some reason those do not contain the invisible character markers
            StringBuilder sb = new StringBuilder();
            String[] lines = text.split("\n");
            boolean inTable = false;
            for (int i = 0; i < lines.length; i++) {
                String line = lines[i];
                if (!inTable && line.startsWith("|")) {
                    inTable = true;
                    sb.append(tableStartMarker);
                }
                if (inTable && (i == (lines.length - 1) || !lines[i + 1].startsWith("|"))) {
                    // this is alst table line
                    int lastPipe = line.lastIndexOf("|");
                    sb.append(line.substring(0, lastPipe + 1));
                    sb.append(tableEndMarker);
                    sb.append(line.substring(lastPipe + 1));
                    inTable = false;
                } else {
                    sb.append(line);
                }
                if (i != (lines.length - 1)) {
                    sb.append("\n");
                }
            }

            String result = sb.toString();
            return result;
        }
    }

    private static Properties mergeCustomPatterns(Properties outputPatterns) {
        Properties patterns = new CustomHTMLFormatPatterns().getPatterns();
        patterns.putAll(outputPatterns);
        return patterns;
    }

    /**
     * @author Maryna Pristrom
     */
    public static class CustomHTMLFormatPatterns {

        public Properties getPatterns() {
            return patterns;
        }

        private final Properties patterns;

        public CustomHTMLFormatPatterns() {

            patterns = new Properties();

            patterns.setProperty("dryRun", "<div class=\"dryRun\">{0}</div>\n");

            // story
            patterns.setProperty("beforeStory", "<div class=\"story-report\">\n");

            patterns.setProperty("description",
                    "<div class='cm-jb-story-description-line'>{0}</div>\n<br>")

            patterns.setProperty("afterStory", "</div>\n");
            // TODO - canceled story?
            patterns.setProperty("storyCancelled", "<div class=\"cancelled\">{0} ({1} {2} s)</div>\n");

            // meta
            patterns.setProperty("metaStart",
                    "<div>\n" +
                            "<div class=\"cm-jb-story-meta-title\">{0}</div>\n");
            patterns.setProperty("metaProperty", "<div class=\"cm-jb-story-meta-field\">{0}{1} {2}</div>\n");
            patterns.setProperty("metaEnd", "</div>\n<br>");

            // TODO - where is this filter?
            patterns.setProperty("filter", "<div class=\"filter\">{0}</div>\n");

            patterns.setProperty("narrative",
                    "<div class=\"narrative\">" +
                            "<div class=\"cm-jb-story-narrative-title\">{0}</div>\n" +
                            "<div>" +
                            "<span class=\"cm-jb-story-narrative-field-keyword\">{1}</span> " +
                            "<span class=\"cm-jb-story-narrative-field-value\">{2}</span>" +
                            "</div>\n" +
                            "<div>" +
                            "<span class=\"cm-jb-story-narrative-field-keyword\">{3}</span> " +
                            "<span class=\"cm-jb-story-narrative-field-value\">{4}</span>" +
                            "</div>\n" +
                            "<div>" +
                            "<span class=\"cm-jb-story-narrative-field-keyword\">{5}</span> " +
                            "<span class=\"cm-jb-story-narrative-field-value\">{6}</span>" +
                            "</div>\n" +
                            "</div>\n<br>");

            patterns.setProperty("lifecycleStart",
                    "<div class=\"lifecycle\">" +
                            "<div class=\"cm-jb-story-lifecycle\">{0}</div>"
            );
            patterns.setProperty("lifecycleEnd", "</div><br>");
            patterns.setProperty("lifecycleBeforeStart",
                    "<div class=\"before\">" +
                            "<div class=\"cm-jb-story-lifecycle-before\">{0}</div>"
            );
            patterns.setProperty("lifecycleBeforeEnd", "</div>");
            patterns.setProperty("lifecycleAfterStart",
                    "<div class=\"after\">" +
                            "<div class=\"cm-jb-story-lifecycle-after\">{0}</div>"
            );
            patterns.setProperty("lifecycleAfterEnd", "</div>");
            patterns.setProperty("lifecycleStep", "<div class=\"cm-jb-story-step-body\">{0}</div>\n");

            patterns.setProperty("beforeScenario",
                    "<div>\n" +
                            "<div>" +
                            "<span class=\"cm-jb-story-scenario-keyword\">{0} </span>" +
                            "<span class=\"cm-jb-story-scenario-title\">{1}</span>" +
//                            "<span class=\"scenario_status_badge\"></span>" +
//                            " <span class=\"aui-lozenge aui-lozenge-error\">failed</span>" +
                            "</div>\n"
            );
            patterns.setProperty("afterScenario", "</div>\n<br>");
//            patterns.setProperty("afterScenarioWithFailure", "<pre class=\"failure\">{0}</pre>\n</div>\n<br>");
            patterns.setProperty("afterScenarioWithFailure", "</div>\n<br>");

            patterns.setProperty("givenStories", "<div class=\"givenStories\">{0} {1}</div>\n");
            patterns.setProperty("givenStoriesStart", "<div class=\"givenStories\">{0}\n");
            patterns.setProperty("givenStory", "<div class=\"givenStory\">{0} {1}</div>\n");
            patterns.setProperty("givenStoriesEnd", "</div>\n");

//            patterns.setProperty("pendingMethod", "<div><pre class=\"pending\">{0}</pre></div>\n");
            patterns.setProperty("pendingMethod", "");

            patterns.setProperty("successful", "<div class=\"step successful\">{0}</div>\n");
            patterns.setProperty("successfulStep",
                    "<div class=\"jb-story-report-step matched-step\">" +
                            "<span class=\"cm-jb-story-step-keyword\">{0}</span>" +
                            "<span class=\"cm-jb-story-step-body\">{1}</span>" +
                            "<div class=\"cm-jb-story-step-successful-message\">{2}</div>" +
                            "</div>\n");

            patterns.setProperty("failed", "");
            patterns.setProperty("failedStep",
                    "<div class=\"jb-story-report-step matched-step\">" +
                            "<span class=\"cm-jb-story-step-keyword failed\">{0}</span><span class=\"cm-jb-story-step-body failed\">{1}</span>" +
                            "<div class=\"cm-jb-story-step-failed-keyword\">({2})</div>" +
                            "<div class=\"cm-jb-story-step-failed-message\">{3}</div>" +
                            // failure trace formatting
                            "<div class=\"cm-jb-story-step-failed-message\">{5} " +
                            "<a replace-text=\"hide trace\" " +
                            "class=\"failure-trace-expander-trigger\" " +
                            "failure-trace-container=\"failure-trace-content-{6}\">show trace</a>" +
                            "<div id=\"failure-trace-content-{6}\" style=\"display: none;\" class=\"cm-jb-story-step-failed-message\">" +
                            "<pre class=\"failure\">{4}</pre>" +
                            "</div>" +
                            "</div>" +
                            "</div>\n");

            patterns.setProperty("ignorable", "<div class=\"step ignorable\">{0}</div>\n");

//            patterns.setProperty("pending", "<div class=\"step pending\"><span class=\"aui-icon aui-icon-small aui-iconfont-add\"></span>{0} <span class=\"keyword pending\">({1})</span></div>\n");
            patterns.setProperty("pending", "");
            patterns.setProperty("pendingStep",
                    "<div class=\"jb-story-report-step matched-step\">" +
                            "<span class=\"cm-jb-story-step-keyword\">{0}</span><span class=\"cm-jb-story-step-body\">{1}</span>" +
                            "<div class=\"cm-jb-story-keyword-pending\">({2})" +
//                            "<a replace-text=\"hide signature\" class=\"pending-method-signature-expander-trigger\">show signature</a>" +
//                            "<div style=\"display: none;\" class=\"pending-method-signature-expander-content\">{3}</div>" +
                            "</div>" +
                            "</div>\n");

            patterns.setProperty("notPerformed", "<div class=\"step notPerformed\">{0} <span class=\"keyword notPerformed\">({1})</span></div>\n");
            patterns.setProperty("notPerformedStep",
                    "<div class=\"jb-story-report-step matched-step\">" +
                            "<span class=\"cm-jb-story-step-keyword\">{0}</span><span class=\"cm-jb-story-step-body\">{1}</span>" +
                            "<div class=\"cm-jb-story-keyword-notPerformed\">({2})</div>" +
                            "</div>\n");

            patterns.setProperty("restarted", "<div class=\"step restarted\">{0} <span class=\"message restarted\">{1}</span></div>\n");

            patterns.setProperty("outcomesTableStart", "<div class=\"outcomes\"><table>\n");
            patterns.setProperty("outcomesTableHeadStart", "<thead>\n<tr>\n");
            patterns.setProperty("outcomesTableHeadCell", "<th>{0}</th>");
            patterns.setProperty("outcomesTableHeadEnd", "</tr>\n</thead>\n");
            patterns.setProperty("outcomesTableBodyStart", "<tbody>\n");
            patterns.setProperty("outcomesTableRowStart", "<tr class=\"{0}\">\n");
            patterns.setProperty("outcomesTableCell", "<td>{0}</td>");
            patterns.setProperty("outcomesTableRowEnd", "</tr>\n");
            patterns.setProperty("outcomesTableBodyEnd", "</tbody>\n");
            patterns.setProperty("outcomesTableEnd", "</table></div>\n");

//            patterns.setProperty("beforeExamples", "<div class=\"examples\">\n<h3>{0}</h3>\n");
            patterns.setProperty("beforeExamples", "<div class=\"examples\">\n<div class=\"cm-jb-story-examples\">{0}</div>\n");
            patterns.setProperty("beforeExamplesTable", "<div class=\"cm-jb-story-examples-body\">\n");
            patterns.setProperty("afterExamplesTable", "</div>\n");
            patterns.setProperty("examplesStep", "<div class=\"step\">{0}</div>\n");
            patterns.setProperty("afterExamples", "</div>\n");

            patterns.setProperty("examplesTableStart", "<table class=\"tabular-parameter\">\n");
            patterns.setProperty("examplesTableHeadStart", "<thead>\n<tr>\n");
            patterns.setProperty("examplesTableHeadCell", "<th>{0}</th>");
            patterns.setProperty("examplesTableHeadEnd", "</tr>\n</thead>\n");
            patterns.setProperty("examplesTableBodyStart", "<tbody>\n");
            patterns.setProperty("examplesTableRowStart", "<tr>\n");
            patterns.setProperty("examplesTableCell", "<td>{0}</td>");
            patterns.setProperty("examplesTableRowEnd", "</tr>\n");
            patterns.setProperty("examplesTableBodyEnd", "</tbody>\n");
            patterns.setProperty("examplesTableEnd", "</table>\n");

//            patterns.setProperty("example", "\n<h3 class=\"example\">{0} {1}</h3>\n");
            patterns.setProperty("example", "\n<div class=\"jb-scenario-example\">{0} {1}</div>\n");

            patterns.setProperty("parameterValueStart", "<span class=\"cm-jb-story-step-body matched-step step-parameter\">");
            patterns.setProperty("parameterValueEnd", "</span>");
            patterns.setProperty("parameterValueNewline", "<br/>");
        }
    }

    @XmlRootElement
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class StoryReport {

        private String environment;

        private String storyPath;

        private Long storyVersion;

        public TestStatus status;

        private Integer totalScenarios;

        private Integer totalScenariosPassed;

        private Integer totalScenariosFailed;

        private Integer totalScenariosPending;

        private Integer totalScenariosSkipped;

        private Integer totalScenariosNotPerformed;

        private String htmlReport;

        protected StoryReport() {
        }

        public StoryReport(String environment, String storyPath,
                           Long storyVersion, TestStatus status, String htmlReport) {
            this.environment = environment;
            this.storyPath = storyPath;
            this.storyVersion = storyVersion;
            this.status = status;
            this.htmlReport = htmlReport;
        }

        public String getEnvironment() {
            return environment;
        }

        public void setEnvironment(String environment) {
            this.environment = environment;
        }

        public String getStoryPath() {
            return storyPath;
        }

        public void setStoryPath(String storyPath) {
            this.storyPath = storyPath;
        }

        public Long getStoryVersion() {
            return storyVersion;
        }

        public void setStoryVersion(Long storyVersion) {
            this.storyVersion = storyVersion;
        }

        public TestStatus getStatus() {
            return status;
        }

        public void setStatus(TestStatus status) {
            this.status = status;
        }

        public String getHtmlReport() {
            return htmlReport;
        }

        public void setHtmlReport(String htmlReport) {
            this.htmlReport = htmlReport;
        }

        public Integer getTotalScenarios() {
            return totalScenarios;
        }

        public void setTotalScenarios(Integer totalScenarios) {
            this.totalScenarios = totalScenarios;
        }

        public Integer getTotalScenariosPassed() {
            return totalScenariosPassed;
        }

        public void setTotalScenariosPassed(Integer totalScenariosPassed) {
            this.totalScenariosPassed = totalScenariosPassed;
        }

        public Integer getTotalScenariosFailed() {
            return totalScenariosFailed;
        }

        public void setTotalScenariosFailed(Integer totalScenariosFailed) {
            this.totalScenariosFailed = totalScenariosFailed;
        }

        public Integer getTotalScenariosPending() {
            return totalScenariosPending;
        }

        public void setTotalScenariosPending(Integer totalScenariosPending) {
            this.totalScenariosPending = totalScenariosPending;
        }

        public Integer getTotalScenariosSkipped() {
            return totalScenariosSkipped;
        }

        public void setTotalScenariosSkipped(Integer totalScenariosSkipped) {
            this.totalScenariosSkipped = totalScenariosSkipped;
        }

        public Integer getTotalScenariosNotPerformed() {
            return totalScenariosNotPerformed;
        }

        public void setTotalScenariosNotPerformed(Integer totalScenariosNotPerformed) {
            this.totalScenariosNotPerformed = totalScenariosNotPerformed;
        }

    }

    public static class CustomHtmlOutput extends HtmlOutput {

        protected final Keywords keywords;

        public CustomHtmlOutput(PrintStream printStream, Properties outputPatterns, LocalizedKeywords keywords,
                                boolean reportFailureTrace, boolean compressFailureTrace) {
            super(printStream, outputPatterns, keywords, reportFailureTrace, compressFailureTrace);
            this.keywords = keywords;
        }

        @Override
        protected void print(String text) {
            text = GroovyStoryReporter.markTableCorrectly(text, this);
            super.print(text);
        }

        @Override
        public Object[] escape(PrintStreamOutput.Format format, Object... args) {
            return super.escape(format, args);
        }

        @Override
        public void beforeStory(Story story, boolean givenStory) {
            print(format("beforeStory", ""));
        }

        public void description(Story story) {
            Description desc = story.getDescription();
            if (desc != null && StringUtils.isNotBlank(desc.asString())) {
                print(format("description", "{0}\n", story.getDescription().asString()));
            }
        }

        public void meta(Story story) {
            Meta meta = story.getMeta();
            if (meta != null && !story.getMeta().isEmpty()) {
                print(format("metaStart", "{0}\n", keywords.meta()));
                for (String name : meta.getPropertyNames()) {
                    print(format("metaProperty", "{0}{1} {2}", keywords.metaProperty(), name, meta.getProperty(name)));
                }
                print(format("metaEnd", "\n"));
            }
        }
    }
}



