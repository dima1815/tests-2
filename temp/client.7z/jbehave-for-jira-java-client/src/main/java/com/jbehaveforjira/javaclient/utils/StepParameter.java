package com.jbehaveforjira.javaclient.utils;

/**
 * @author Maryna Pristrom
 */
public interface StepParameter {

    /**
     * Converts current instance into string representation.
     * @return
     */
    String asString();

    /**
     * Populates given instance from the specified string representation.
     * @param asString
     */
    void fromString(String asString);

}