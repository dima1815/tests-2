package com.jbehaveforjira.javaclient;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.jbehave.core.io.StoryLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Maryna Pristrom
 */
public class JiraStoryLoader implements StoryLoader {

    private final Logger log = LoggerFactory.getLogger(getClass());

    private String jiraBaseUrl;

    private String projectKey;

    private String username;

    private String password;

    private String downloadedStoriesDir;

    private String loadStoryPath = "rest/jbehave-for-jira/1.0/find/for-path/";

    public JiraStoryLoader(String jiraBaseUrl, String projectKey, String username, String password) {
        this(jiraBaseUrl, projectKey, username, password, null);
    }

    public JiraStoryLoader(String jiraBaseUrl, String projectKey, String username, String password, String downloadDir) {
        this.jiraBaseUrl = jiraBaseUrl;
        this.projectKey = projectKey;
        this.username = username;
        this.password = password;
        this.downloadedStoriesDir = downloadDir;
    }

    @Override
    public String loadStoryAsText(String storyPath) {

        URI jiraSearchUrl = null;
        try {
            String fullPath = jiraBaseUrl + "/" + loadStoryPath;
            fullPath += storyPath;
            fullPath += "?os_username=" + this.username
                    + "&os_password=" + this.password
                    + "&asString=true";
            log.debug("full story path is - " + fullPath);
            jiraSearchUrl = new URI(fullPath);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        Client client = Client.create();
        WebResource res = client.resource(jiraSearchUrl);
        ClientResponse response = res.type(MediaType.APPLICATION_JSON).get(ClientResponse.class);
        log.info("response - " + response);

        if (response.getStatus() == 200) {
            String story = response.getEntity(String.class);

            if (downloadedStoriesDir != null && !downloadedStoriesDir.trim().isEmpty()) {
                this.writeModelToFile(storyPath, story);
            }

            return story;
        } else {
            int status = response.getStatus();
            Response.StatusType statusInfo = response.getStatusInfo();
            throw new RuntimeException("Error occurred while trying to find Jira story paths. " +
                    "Response status was - " + status + ", status info - " + statusInfo);
        }

    }

    private void writeModelToFile(String storyPath, String storyModel) {

        // trim story version from story path
        // extract version
        String actualStoryPath;
        String regexPattern = "(.*)\\.([0-9]*)(\\.story)";
        Pattern p = Pattern.compile(regexPattern);
        Matcher matcher = p.matcher(storyPath);
        if (matcher.matches()) {
            actualStoryPath = matcher.group(1) + matcher.group(3);
        } else {
            throw new IllegalArgumentException("Jira story path must match pattern - " + regexPattern);
        }

        PrintWriter pw = null;
        try {
            File storiesDir = new File(downloadedStoriesDir);
            if (storiesDir.exists()) {
                if (!storiesDir.isDirectory()) {
                    throw new RuntimeException("Specified download directory must not be an existing file!");
                }
            } else {
                storiesDir.mkdirs();
            }
            File outFile = new File(storiesDir, actualStoryPath);
            outFile.getParentFile().mkdirs();
            FileWriter fw = new FileWriter(outFile.getAbsoluteFile());
            pw = new PrintWriter(fw);
            pw.print(storyModel);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (pw != null) {
                pw.close();
            }
        }

    }

}
