package com.jbehaveforjira.javaclient.matchers;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

import java.util.Arrays;
import java.util.Collection;

/**
 * @author Maryna Pristrom
 */
public class IsInByReflection <T> extends BaseMatcher<T> {

    private final Collection<T> collection;

    public IsInByReflection(Collection<T> collection) {
        this.collection = collection;
    }

    public IsInByReflection(T[] elements) {
        collection = Arrays.asList(elements);
    }

    @Override
    public boolean matches(Object o) {
        return collection.contains(o);
    }

    @Override
    public void describeTo(Description buffer) {
        buffer.appendText("One of :\n");
        buffer.appendValueList("{", ", ", "}", collection);
    }

}
