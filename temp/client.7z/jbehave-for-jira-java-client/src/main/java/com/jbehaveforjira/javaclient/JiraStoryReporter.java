package com.jbehaveforjira.javaclient;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import freemarker.ext.beans.BeansWrapper;
import freemarker.template.TemplateHashModel;
import freemarker.template.TemplateModelException;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.configuration.Keywords;
import org.jbehave.core.model.*;
import org.jbehave.core.reporters.*;
import org.jbehave.core.steps.StepCreator;

import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Maryna Pristrom
 */
public class JiraStoryReporter implements StoryReporter {

    public static enum TestStatus {

        passed,

        failed,

        pending,

        not_performed,

        ignored,

        comment

    }

    private String basePostPath;
    private String loginParams;

    private final File file;
    private final Keywords keywords;
    private final TemplateProcessor processor;
    private final String templatePath;
    private OutputStory outputStory = new OutputStory();
    private OutputScenario outputScenario = new OutputScenario();
    private OutputStep failedStep;
    private String environment;

    public JiraStoryReporter(File file, Keywords keywords,
                             String jiraBaseUrl, String jiraProject, String username, String password, String environment) {
        this(file, keywords, new FreemarkerProcessor(), "ftl/jira-jbehave-html-output.ftl", jiraBaseUrl, jiraProject, username, password, environment);
    }

    public JiraStoryReporter(File file, Keywords keywords, TemplateProcessor processor, String templatePath,
                             String jiraBaseUrl, String jiraProject, String username, String password, String environment) {
        this.file = file;
        this.keywords = keywords;
        this.processor = processor;
        this.templatePath = templatePath;
        this.loginParams = "?os_username=" + username + "&os_password=" + password;
        this.basePostPath = jiraBaseUrl + "/rest/jbehave-for-jira/1.0/story-report/add-for-path/";
        this.environment = environment;
    }

    public void storyNotAllowed(Story story, String filter) {
        this.outputStory.notAllowedBy = filter;
    }

    public void beforeStory(Story story, boolean givenStory) {
        if (!givenStory) {
            this.outputStory = new OutputStory();
            this.outputStory.description = story.getDescription().asString();
            this.outputStory.path = story.getPath();
        }
        if (!story.getMeta().isEmpty()) {
            this.outputStory.meta = new OutputMeta(story.getMeta());
        }
    }

    public void narrative(Narrative narrative) {
        if (!narrative.isEmpty()) {
            this.outputStory.narrative = new OutputNarrative(narrative);
        }
    }

    public void lifecyle(Lifecycle lifecycle) {
        if (!lifecycle.isEmpty()) {
            this.outputStory.lifecycle = new OutputLifecycle(lifecycle);
        }
    }


    public void scenarioNotAllowed(Scenario scenario, String filter) {
        this.outputScenario.notAllowedBy = filter;
    }

    public void beforeScenario(String title) {
        if (this.outputScenario.currentExample == null) {
            this.outputScenario = new OutputScenario();
            this.failedStep = null;
        }
        this.outputScenario.title = title;
    }

    public void beforeStep(String step) {
    }

    public void successful(String step) {
        this.outputScenario.addStep(new OutputStep(step, TestStatus.passed));
    }

    public void ignorable(String step) {
        this.outputScenario.addStep(new OutputStep(step, TestStatus.ignored));
    }

    public void pending(String step) {
        this.outputScenario.addStep(new OutputStep(step, TestStatus.pending));
    }

    public void notPerformed(String step) {
        this.outputScenario.addStep(new OutputStep(step, TestStatus.not_performed));
    }

    public void failed(String step, Throwable storyFailure) {
        this.failedStep = new FailedOutputStep(step, TestStatus.failed, storyFailure);
        this.outputScenario.addStep(failedStep);
    }

    public void failedOutcomes(String step, OutcomesTable table) {
        failed(step, table.failureCause());
        this.failedStep.outcomes = table;
    }

    public void givenStories(GivenStories givenStories) {
        if (!givenStories.getStories().isEmpty()) {
            this.outputScenario.givenStories = givenStories;
        }
    }

    public void givenStories(List<String> storyPaths) {
        givenStories(new GivenStories(StringUtils.join(storyPaths, ",")));
    }

    public void scenarioMeta(Meta meta) {
        if (!meta.isEmpty()) {
            this.outputScenario.meta = new OutputMeta(meta);
        }
    }

    public void beforeExamples(List<String> steps, ExamplesTable table) {
        this.outputScenario.examplesTable = table;
    }

    public void example(Map<String, String> parameters) {
        this.outputScenario.examples.add(parameters);
        this.outputScenario.currentExample = parameters;
    }

    public void afterExamples() {
        this.outputScenario.currentExample = null;
    }

    public void dryRun() {
    }

    public void afterScenario() {
        if (this.outputScenario.currentExample == null) {

            // set scenario status
            if (failedStep != null) {
                this.outputScenario.outcome = TestStatus.failed.name();
            } else if (this.outputScenario.pendingMethods != null) {
                this.outputScenario.outcome = TestStatus.pending.name();
            } else {
                // check if all steps were skipped
                List<OutputStep> scenarioSteps = outputScenario.steps;
                boolean allSkipped = true;
                for (OutputStep scenarioStep : scenarioSteps) {
                    TestStatus stepOutcome = scenarioStep.outcome;
                    if (stepOutcome != TestStatus.not_performed) {
                        allSkipped = false;
                        break;
                    }
                }
                if (allSkipped) {
                    this.outputScenario.outcome = TestStatus.not_performed.name();
                } else {
                    // check if all ignored
                    boolean allIgnored = true;
                    for (OutputStep scenarioStep : scenarioSteps) {
                        TestStatus stepOutcome = scenarioStep.outcome;
                        if (stepOutcome != TestStatus.ignored) {
                            allIgnored = false;
                            break;
                        }
                    }
                    if (allIgnored) {
                        this.outputScenario.outcome = TestStatus.ignored.name();
                    } else {
                        this.outputScenario.outcome = TestStatus.passed.name();
                    }
                }
            }

            this.outputStory.scenarios.add(outputScenario);
        }
    }

    public void pendingMethods(List<String> methods) {
        this.outputScenario.pendingMethods = methods;
    }

    public void restarted(String step, Throwable cause) {
        this.outputScenario.addStep(new OutputRestart(step, cause.getMessage()));
    }

    public void storyCancelled(Story story, StoryDuration storyDuration) {
        this.outputStory.cancelled = true;
        this.outputStory.storyDuration = storyDuration;
    }

    public void afterStory(boolean givenStory) {
        if (!givenStory && !outputStory.getPath().equals("AfterStories") && !outputStory.getPath().equals("BeforeStories")) {

            Map<String, Object> model = newDataModel();
            model.put("story", outputStory);
            model.put("keywords", new OutputKeywords(keywords));

            BeansWrapper wrapper = BeansWrapper.getDefaultInstance();
            TemplateHashModel enumModels = wrapper.getEnumModels();
            TemplateHashModel escapeEnums;
            try {

                String escapeModeEnum = EscapeMode.class.getCanonicalName();
                escapeEnums = (TemplateHashModel) enumModels.get(escapeModeEnum);
                model.put("EscapeMode", escapeEnums);

            } catch (TemplateModelException e) {
                throw new IllegalArgumentException(e);
            }

            write(file, templatePath, model);

            // write to string stream
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            OutputStreamWriter outStreamWriter = new OutputStreamWriter(out);
            processor.process(templatePath, model, outStreamWriter);
            String report = out.toString();
            sendStoryReport(report, outputStory);

        }
    }

    private File write(File file, String resource, Map<String, Object> dataModel) {
        try {

            // write to file
            File parentFile = file.getParentFile();
            if (parentFile != null) {
                parentFile.mkdirs();
            }
            Writer writer = new FileWriter(file);
            processor.process(resource, dataModel, writer);
            writer.close();

            return file;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(resource, e);
        }
    }

    protected void sendStoryReport(String testReport, OutputStory outputStory) {

        Validate.notEmpty(testReport);

        // extract version
        long jiraVersion;
        String actualStoryPath;
        String regexPattern = "(.*)\\.([0-9]*)(\\.story)";
        Pattern p = Pattern.compile(regexPattern);
        Matcher matcher = p.matcher(outputStory.getPath());
        if (matcher.matches()) {
            actualStoryPath = matcher.group(1) + matcher.group(3);
            String versionStr = matcher.group(2);
            jiraVersion = Long.parseLong(versionStr);
        } else {
            throw new IllegalArgumentException("JiraStory path must match pattern - " + regexPattern);
        }

        List<OutputScenario> scenarios = outputStory.getScenarios();
        int totalScenarios = 0;
        int totalPassed = 0;
        int totalFailed = 0;
        int totalPending = 0;
        int totalNotPerformed = 0;
        int totalIgnored = 0;
        for (OutputScenario scenario : scenarios) {
            totalScenarios++;
            String outcome = scenario.getOutcome();
            if (TestStatus.passed.name().equals(outcome)) {
                totalPassed++;
            } else if (TestStatus.failed.name().equals(outcome)) {
                totalFailed++;
            } else if (TestStatus.pending.name().equals(outcome)) {
                totalPending++;
            } else if (TestStatus.not_performed.name().equals(outcome)) {
                totalNotPerformed++;
            } else if (TestStatus.ignored.name().equals(outcome)) {
                totalIgnored++;
            }
        }

        TestStatus storyStatus;
        if (totalFailed > 0) {
            storyStatus = TestStatus.failed;
        } else if (totalPending > 0) {
            storyStatus = TestStatus.pending;
        } else if (totalNotPerformed > 0 && totalNotPerformed == totalScenarios) {
            storyStatus = TestStatus.not_performed;
        } else if (totalIgnored > 0 && totalIgnored == totalScenarios) {
            storyStatus = TestStatus.ignored;
        } else {
            storyStatus = TestStatus.passed;
        }

        StoryReport storyHtmlReportDTO = new StoryReport(environment,
                outputStory.getPath(), jiraVersion, storyStatus, testReport);

        storyHtmlReportDTO.setTotalScenarios(totalScenarios);
        storyHtmlReportDTO.setTotalScenariosPassed(totalPassed);
        storyHtmlReportDTO.setTotalScenariosFailed(totalFailed);
        storyHtmlReportDTO.setTotalScenariosPending(totalPending);
        storyHtmlReportDTO.setTotalScenariosIgnored(totalIgnored);
        storyHtmlReportDTO.setTotalScenariosNotPerformed(totalNotPerformed);

        // extract version

        String postUrl = this.basePostPath + actualStoryPath + loginParams;

        Client client = Client.create();
        WebResource res = client.resource(postUrl);

        String response = res.accept(MediaType.APPLICATION_JSON)
                .type(MediaType.APPLICATION_JSON)
                .post(String.class, storyHtmlReportDTO);

        System.out.println("response - " + response);
    }

    private Map<String, Object> newDataModel() {
        return new HashMap<String, Object>();
    }

    public static class OutputKeywords {

        private final Keywords keywords;

        public OutputKeywords(Keywords keywords) {
            this.keywords = keywords;
        }

        public String getLifecycle() {
            return keywords.lifecycle();
        }

        public String getBefore() {
            return keywords.before();
        }

        public String getAfter() {
            return keywords.after();
        }

        public String getMeta() {
            return keywords.meta();
        }

        public String getMetaProperty() {
            return keywords.metaProperty();
        }

        public String getNarrative() {
            return keywords.narrative();
        }

        public String getInOrderTo() {
            return keywords.inOrderTo();
        }

        public String getAsA() {
            return keywords.asA();
        }

        public String getiWantTo() {
            return keywords.iWantTo();
        }

        public String getSoThat() {
            return keywords.soThat();
        }

        public String getScenario() {
            return keywords.scenario();
        }

        public String getGivenStories() {
            return keywords.givenStories();
        }

        public String getExamplesTable() {
            return keywords.examplesTable();
        }

        public String getExamplesTableRow() {
            return keywords.examplesTableRow();
        }

        public String getExamplesTableHeaderSeparator() {
            return keywords.examplesTableHeaderSeparator();
        }

        public String getExamplesTableValueSeparator() {
            return keywords.examplesTableValueSeparator();
        }

        public String getExamplesTableIgnorableSeparator() {
            return keywords.examplesTableIgnorableSeparator();
        }

        public String getGiven() {
            return keywords.given();
        }

        public String getWhen() {
            return keywords.when();
        }

        public String getThen() {
            return keywords.then();
        }

        public String getAnd() {
            return keywords.and();
        }

        public String getIgnorable() {
            return keywords.ignorable();
        }

        public String getPending() {
            return keywords.pending();
        }

        public String getNotPerformed() {
            return keywords.notPerformed();
        }

        public String getFailed() {
            return keywords.failed();
        }

        public String getDryRun() {
            return keywords.dryRun();
        }

        public String getStoryCancelled() {
            return keywords.storyCancelled();
        }

        public String getDuration() {
            return keywords.duration();
        }

        public String getYes() {
            return keywords.yes();
        }

        public String getNo() {
            return keywords.no();
        }
    }

    public static class OutputStory {
        private String description;
        private String path;
        private OutputMeta meta;
        private OutputNarrative narrative;
        private OutputLifecycle lifecycle;
        private String notAllowedBy;
        private List<OutputScenario> scenarios = new ArrayList<OutputScenario>();
        private boolean cancelled;
        private StoryDuration storyDuration;

        public String getDescription() {
            return description;
        }

        public String getPath() {
            return path;
        }

        public OutputMeta getMeta() {
            return meta;
        }

        public OutputNarrative getNarrative() {
            return narrative;
        }

        public OutputLifecycle getLifecycle() {
            return lifecycle;
        }

        public String getNotAllowedBy() {
            return notAllowedBy;
        }

        public List<OutputScenario> getScenarios() {
            return scenarios;
        }

        public boolean isCancelled() {
            return cancelled;
        }

        public StoryDuration getStoryDuration() {
            return storyDuration;
        }
    }

    public static class OutputMeta {

        private final Meta meta;

        public OutputMeta(Meta meta) {
            this.meta = meta;
        }

        public Map<String, String> getProperties() {
            Map<String, String> properties = new HashMap<String, String>();
            for (String name : meta.getPropertyNames()) {
                properties.put(name, meta.getProperty(name));
            }
            return properties;
        }

    }

    public static class OutputNarrative {
        private final Narrative narrative;

        public OutputNarrative(Narrative narrative) {
            this.narrative = narrative;
        }

        public String getInOrderTo() {
            return narrative.inOrderTo();
        }

        public String getAsA() {
            return narrative.asA();
        }

        public String getiWantTo() {
            return narrative.iWantTo();
        }

        public String getSoThat() {
            return narrative.soThat();
        }

        public boolean isAlternative() {
            return narrative.isAlternative();
        }

    }

    public static class OutputLifecycle {

        private final Lifecycle lifecycle;

        public OutputLifecycle(Lifecycle lifecycle) {
            this.lifecycle = lifecycle;
        }

        public List<OutputStep> getBeforeSteps() {

            List<OutputStep> beforeSteps = new ArrayList<OutputStep>();
            List<String> beforeStrSteps = lifecycle.getBeforeSteps();
            if (beforeStrSteps != null) {
                for (String beforeStrStep : beforeStrSteps) {
                    OutputStep step = new OutputStep(beforeStrStep, TestStatus.passed);
                    beforeSteps.add(step);
                }
            }
            return beforeSteps;
        }

        public List<OutputStep> getAfterSteps() {

            List<OutputStep> afterSteps = new ArrayList<OutputStep>();

            List<String> afterStrSteps = lifecycle.getAfterSteps();
            lifecycle.getAfterSteps(AfterScenario.Outcome.FAILURE);
            if (afterStrSteps != null) {
                afterSteps = new ArrayList<OutputStep>();
                for (String afterStrStep : afterStrSteps) {
                    OutputStep step = new OutputStep(afterStrStep, TestStatus.passed);
                    afterSteps.add(step);
                }
            }

            return afterSteps;
        }

        public List<OutputStep> getAfterSteps(String strOutcome) {

            AfterScenario.Outcome outcome = AfterScenario.Outcome.valueOf(strOutcome);

            List<String> strAfterSteps = lifecycle.getAfterSteps(outcome);
            List<OutputStep> afterSteps = new ArrayList<OutputStep>(strAfterSteps.size());
            for (String strAfterStep : strAfterSteps) {
                OutputStep step = new OutputStep(strAfterStep, TestStatus.passed);
                afterSteps.add(step);
            }

            return afterSteps;
        }

        public List<String> getOutcomes() {

            AfterScenario.Outcome[] outcomes = AfterScenario.Outcome.values();
            List<String> strOutcomes = new ArrayList<String>(outcomes.length);
            for (AfterScenario.Outcome outcome : outcomes) {
                strOutcomes.add(outcome.name());
            }
            return strOutcomes;
        }
    }

    public static class OutputScenario {
        private String title;
        private String outcome;
        private List<OutputStep> steps = new ArrayList<OutputStep>();
        private OutputMeta meta;
        private List<String> pendingMethods;
        private GivenStories givenStories;
        private String notAllowedBy;

        private ExamplesTable examplesTable;
        private Map<String, String> currentExample;
        private List<Map<String, String>> examples = new ArrayList<Map<String, String>>();
        private Map<Map<String, String>, List<OutputStep>> stepsByExample = new HashMap<Map<String, String>, List<OutputStep>>();

        public String getTitle() {
            return title;
        }

        public void addStep(OutputStep outputStep) {
            if (examplesTable == null) {
                steps.add(outputStep);
            } else {
                List<OutputStep> currentExampleSteps = stepsByExample.get(currentExample);
                if (currentExampleSteps == null) {
                    currentExampleSteps = new ArrayList<OutputStep>();
                    stepsByExample.put(currentExample, currentExampleSteps);
                }
                currentExampleSteps.add(outputStep);
            }
        }

        public List<String> getPendingMethods() {
            return pendingMethods;
        }

        public String getOutcome() {
            return outcome;
        }

        public List<OutputStep> getSteps() {
            return steps;
        }

        public List<OutputStep> getStepsByExample(Map<String, String> example) {
            List<OutputStep> steps = stepsByExample.get(example);
            if (steps == null) {
                return new ArrayList<OutputStep>();
            }
            return steps;
        }

        public OutputMeta getMeta() {
            return meta;
        }

        public GivenStories getGivenStories() {
            return givenStories;
        }

        public String getNotAllowedBy() {
            return notAllowedBy;
        }

        public ExamplesTable getExamplesTable() {
            return examplesTable;
        }

        public List<Map<String, String>> getExamples() {
            return examples;
        }

    }

    public static class OutputRestart extends OutputStep {

        public OutputRestart(String step, String outcome) {
            super(step, TestStatus.failed);
        }

    }

    public static class FailedOutputStep extends OutputStep {

        public FailedOutputStep(String step, TestStatus outcome, Throwable storyFailure) {
            this.step = step;
            this.outcome = outcome;
            this.failure = storyFailure;
            parse();
        }
    }

    public static class OutputStep {

        protected String step;

        protected List<OutputStepToken> stepTokens;

        protected TestStatus outcome;

        protected Throwable failure;

        protected OutcomesTable outcomes;

        protected OutputStep() {
        }

        public OutputStep(String step, TestStatus outcome) {

            this.step = step;
            this.outcome = outcome;
            parse();
        }

        protected void parse() {

            stepTokens = new ArrayList<OutputStepToken>();

            // check for comment line
            if (step.startsWith("!--") && outcome == TestStatus.ignored) {

                // add comment line
                stepTokens.add(new OutputStepToken(OutputStepToken.StepTokenType.COMMENT, step));
                this.outcome = TestStatus.comment;

            } else {

                int indexOfFirstSpace = step.indexOf(" ");
                Validate.isTrue(indexOfFirstSpace > -1);

                String keyword = step.substring(0, indexOfFirstSpace);
                stepTokens.add(new OutputStepToken(OutputStepToken.StepTokenType.KEYWORD, keyword));

                String stepBody = step.substring(indexOfFirstSpace);
                stepBody = remarkBody(stepBody);

                // find any parameter markers
                Pattern simpleParamPattern = Pattern.compile(
                        "(.*?)"
                                // have to use '+' quantifier as parameterized steps are marked with invisible markers two times
                                + "((\\" + StepCreator.PARAMETER_VALUE_START + ")+)"
                                + "(.*?)"
                                + "((\\" + StepCreator.PARAMETER_VALUE_END + ")+)"
                                + "(.*)"
                        , Pattern.DOTALL
                );
                Pattern tableParamPattern = Pattern.compile(
                        "(.*?)"
                                + "(\\" + StepCreator.PARAMETER_TABLE_START + ")"
                                + "(.*?)"
                                + "(\\" + StepCreator.PARAMETER_TABLE_END + ")"
                                + "(.*)"
                        , Pattern.DOTALL
                );
                int pos = 0;
                Matcher simpleParamMatcher = simpleParamPattern.matcher(stepBody);
                Matcher tableParamMatcher = tableParamPattern.matcher(stepBody);
                while (pos < stepBody.length()) {

                    if (simpleParamMatcher.find(pos)) {
                        // simple parameter
                        String beforeParam = simpleParamMatcher.group(1);
                        if (beforeParam != null) {
                            stepTokens.add(new OutputStepToken(OutputStepToken.StepTokenType.TEXT, beforeParam));
                        }
                        String paramValue = simpleParamMatcher.group(4);
                        stepTokens.add(new OutputStepToken(OutputStepToken.StepTokenType.PARAMETER, paramValue));
                        pos = simpleParamMatcher.end(5);
                    } else if (tableParamMatcher.find(pos)) {
                        // tabular parameter
                        String beforeParam = tableParamMatcher.group(1);
                        if (beforeParam != null) {
                            stepTokens.add(new OutputStepToken(OutputStepToken.StepTokenType.TEXT, beforeParam));
                        }
                        String paramValue = tableParamMatcher.group(3);
                        stepTokens.add(new TabularParameterStepToken(paramValue));
                        pos = tableParamMatcher.end(4);
                    } else {
                        // no marked parameters left
                        String remainingText = stepBody.substring(pos);
                        stepTokens.add(new OutputStepToken(OutputStepToken.StepTokenType.TEXT, remainingText));
                        pos = stepBody.length();
                    }

                }

            }
        }

        public String getStep() {
            return step;
        }

        public List<OutputStepToken> getStepTokens() {
            return stepTokens;
        }

        public String getOutcome() {
            return outcome.name();
        }

        public Throwable getFailure() {
            return failure;
        }

        public String getFailureCause() {
            if (failure != null) {
                return new StackTraceFormatter(false).stackTrace(failure);
            }
            return "";
        }

        public String getUnderlyingErrorMsg() {
            Throwable underlyingCause = failure;
            while (underlyingCause.getCause() != null) {
                underlyingCause = underlyingCause.getCause();
            }
            String message = underlyingCause.getMessage();
            if (message == null && underlyingCause instanceof OutcomesTable.OutcomesFailed) {
                message = "Outcomes Failed";
            }
            return message;
        }

        public OutcomesTable getOutcomes() {
            return outcomes;
        }

        public String getOutcomesFailureCause() {
            if (outcomes.failureCause() != null) {
                return new StackTraceFormatter(false).stackTrace(outcomes.failureCause());
            }
            return "";
        }

        private static String escapeString(String string) {
            return StringEscapeUtils.escapeHtml(string);
        }

        private boolean containsTable(String text) {
            return text.contains(StepCreator.PARAMETER_TABLE_START) && text.contains(StepCreator.PARAMETER_TABLE_END);
        }

        private String remarkBody(String stepBody) {

            // custom work around for the fact that JBehave's step creator doesn't recognize custom types annotated
            // with AsParameters as tabular parameters

            String[] lines = stepBody.split(StepCreator.PARAMETER_VALUE_NEWLINE);

            if (lines.length == 1) {
                return stepBody;
//                if (this.outcome == TestStatus.failed) {
//                    // check if parsed error occurred
//                    if (this.failure instanceof ExamplesTable.ParametersNotMappableToType
//                            || (
//                                this.failure instanceof UUIDExceptionWrapper
//                                &&
//                                ((UUIDExceptionWrapper)this.failure).getCause() instanceof ExamplesTable.ParametersNotMappableToType
//                                )
//                        ) {
//                        // use case when we might have failed to parse the table parameter into custom type
//                        // in this case we do still want to render them as table parameter in the story report
//                        StringBuilder sb = new StringBuilder();
//                        String[] bodyLines = stepBody.split("\n");
//                        boolean inTable = false;
//                        for (int i = 0; i < bodyLines.length; i++) {
//                            String bodyLine = bodyLines[i];
//                            if (!inTable && bodyLine.startsWith("|") && bodyLine.endsWith("|") && !bodyLine.startsWith("|--")) {
//                                inTable = true;
//                                sb.append(StepCreator.PARAMETER_TABLE_START);
//                            }
//                            if (inTable && (i == (bodyLines.length - 1) || !bodyLines[i + 1].startsWith("|"))) {
//                                // this is last table line
//                                int lastPipe = bodyLine.lastIndexOf("|");
//                                sb.append(bodyLine.substring(0, lastPipe + 1));
//                                sb.append(StepCreator.PARAMETER_TABLE_END);
//                                sb.append(bodyLine.substring(lastPipe + 1));
//                                inTable = false;
//                            } else {
//                                sb.append(bodyLine);
//                            }
//                            if (i != (bodyLines.length - 1)) {
//                                sb.append("\n");
//                            }
//                        }
//                        String result = sb.toString();
//                        return result;
//                    } else {
//                        return stepBody;
//                    }
//                } else {
//                    return stepBody;
//                }
            } else {

//                boolean tableMarkedAlready = text.contains(StepCreator.PARAMETER_TABLE_START);

                // use case for incorrectly marked tables
                StringBuilder sb = new StringBuilder();
                boolean inTable = false;
                for (int i = 0; i < lines.length; i++) {
                    String line = lines[i];
                    if (!inTable && line.startsWith("|")) {
                        inTable = true;
                        sb.append(StepCreator.PARAMETER_TABLE_START);
                    }
                    if (inTable && (i == (lines.length - 1) || !lines[i + 1].startsWith("|"))) {
                        // this is last table line
                        int lastPipe = line.lastIndexOf("|");
                        sb.append(line.substring(0, lastPipe + 1));
                        sb.append(StepCreator.PARAMETER_TABLE_END);
                        sb.append(line.substring(lastPipe + 1));
                        inTable = false;
                    } else {
                        sb.append(line);
                    }
                    if (i != (lines.length - 1)) {
                        sb.append("\n");
                    }
                }

                String result = sb.toString();
                return result;
            }
        }

//        @SuppressWarnings("serial")
//        public static class StepFormattingFailed extends RuntimeException {
//
//            public StepFormattingFailed(String stepPattern, String parameterPattern, List<OutputParameter> parameters,
//                                        RuntimeException cause) {
//                super("Failed to format step '" + stepPattern + "' with parameter pattern '" + parameterPattern
//                        + "' and parameters: " + parameters, cause);
//            }
//
//        }

    }

    public static class OutputStepToken {

        public static enum StepTokenType {
            KEYWORD,
            TEXT,
            PARAMETER,
            TABULAR_PARAMETER,
            COMMENT
        }

        private StepTokenType type;
        private String asString;

        protected OutputStepToken(StepTokenType type, String asString) {
            this.asString = asString;
            this.type = type;
        }

        public StepTokenType getType() {
            return type;
        }

        public String asString() {
            return asString;
        }
    }

    public static class TabularParameterStepToken extends OutputStepToken {

        private ExamplesTable table;

        protected TabularParameterStepToken(String asString) {
            super(StepTokenType.TABULAR_PARAMETER, asString);
            table = new ExamplesTable(asString);
        }

        public ExamplesTable getTable() {
            return table;
        }
    }

    @XmlRootElement
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class StoryReport {

        private String environment;

        private String storyPath;

        private Long storyVersion;

        public TestStatus status;

        private Integer totalScenarios;

        private Integer totalScenariosPassed;

        private Integer totalScenariosFailed;

        private Integer totalScenariosPending;

        private Integer totalScenariosIgnored;

        private Integer totalScenariosNotPerformed;

        private String htmlReport;

        protected StoryReport() {
        }

        public StoryReport(String environment, String storyPath,
                           Long storyVersion, TestStatus status, String htmlReport) {
            this.environment = environment;
            this.storyPath = storyPath;
            this.storyVersion = storyVersion;
            this.status = status;
            this.htmlReport = htmlReport;
        }

        public String getEnvironment() {
            return environment;
        }

        public void setEnvironment(String environment) {
            this.environment = environment;
        }

        public String getStoryPath() {
            return storyPath;
        }

        public void setStoryPath(String storyPath) {
            this.storyPath = storyPath;
        }

        public Long getStoryVersion() {
            return storyVersion;
        }

        public void setStoryVersion(Long storyVersion) {
            this.storyVersion = storyVersion;
        }

        public TestStatus getStatus() {
            return status;
        }

        public void setStatus(TestStatus status) {
            this.status = status;
        }

        public String getHtmlReport() {
            return htmlReport;
        }

        public void setHtmlReport(String htmlReport) {
            this.htmlReport = htmlReport;
        }

        public Integer getTotalScenarios() {
            return totalScenarios;
        }

        public void setTotalScenarios(Integer totalScenarios) {
            this.totalScenarios = totalScenarios;
        }

        public Integer getTotalScenariosPassed() {
            return totalScenariosPassed;
        }

        public void setTotalScenariosPassed(Integer totalScenariosPassed) {
            this.totalScenariosPassed = totalScenariosPassed;
        }

        public Integer getTotalScenariosFailed() {
            return totalScenariosFailed;
        }

        public void setTotalScenariosFailed(Integer totalScenariosFailed) {
            this.totalScenariosFailed = totalScenariosFailed;
        }

        public Integer getTotalScenariosPending() {
            return totalScenariosPending;
        }

        public void setTotalScenariosPending(Integer totalScenariosPending) {
            this.totalScenariosPending = totalScenariosPending;
        }

        public Integer getTotalScenariosIgnored() {
            return totalScenariosIgnored;
        }

        public void setTotalScenariosIgnored(Integer totalScenariosIgnored) {
            this.totalScenariosIgnored = totalScenariosIgnored;
        }

        public Integer getTotalScenariosNotPerformed() {
            return totalScenariosNotPerformed;
        }

        public void setTotalScenariosNotPerformed(Integer totalScenariosNotPerformed) {
            this.totalScenariosNotPerformed = totalScenariosNotPerformed;
        }

    }

}


