package com.jbehaveforjira.javaclient.utils;

/**
 * Specialized subtype of RuntimeException for throwing when an error occurs during step parameter conversion.
 *
 * @author Maryna Pristrom
 */
public class StepParameterConversionException extends RuntimeException {

    public StepParameterConversionException() {
    }

    public StepParameterConversionException(String message) {
        super(message);
    }

    public StepParameterConversionException(String message, Throwable cause) {
        super(message, cause);
    }

    public StepParameterConversionException(Throwable cause) {
        super(cause);
    }

    public StepParameterConversionException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
