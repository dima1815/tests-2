package com.jbehaveforjira.javaclient.utils;

import org.jbehave.core.steps.ParameterConverters;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.asList;

/**
 * Custom converter for any types that implement StepParameter interface
 *
 * @author Maryna Pristrom
 */
public class StepParameterListConverter implements ParameterConverters.ParameterConverter {

    private final StepParameterConverter stepParamConverter;

    private String valueSeparator;

    public StepParameterListConverter() {
        this(",");
    }

    public StepParameterListConverter(String valueSeparator) {
        this.stepParamConverter = new StepParameterConverter();
        this.valueSeparator = valueSeparator;
    }

    @Override
    public boolean accept(Type type) {
        if (type instanceof ParameterizedType) {
            Type rawType = rawType(type);
            Type argumentType = argumentType(type);
            return List.class.isAssignableFrom((Class<?>) rawType) && stepParamConverter.accept(argumentType);
        }
        return false;
    }

    @Override
    public Object convertValue(String value, Type type) {
        Type argumentType = argumentType(type);
        List<String> values = trim(asList(value.split(valueSeparator)));
        List<Object> typedValues = new ArrayList<Object>();
        for (String string : values) {
            typedValues.add(stepParamConverter.convertValue(string, argumentType));
        }
        return typedValues;
    }

    private Type rawType(Type type) {
        return ((ParameterizedType) type).getRawType();
    }

    private Type argumentType(Type type) {
        return ((ParameterizedType) type).getActualTypeArguments()[0];
    }

    private static List<String> trim(List<String> values) {
        List<String> trimmed = new ArrayList<String>();
        for (String value : values) {
            trimmed.add(value.trim());
        }
        return trimmed;
    }
}
