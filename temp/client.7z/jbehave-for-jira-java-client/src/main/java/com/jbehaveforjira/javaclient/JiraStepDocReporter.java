package com.jbehaveforjira.javaclient;

import com.sun.jersey.api.client.Client;
import org.apache.commons.lang.Validate;
import org.codehaus.jackson.map.ObjectMapper;
import org.jbehave.core.annotations.AsParameters;
import org.jbehave.core.annotations.Parameter;
import org.jbehave.core.model.StepPattern;
import org.jbehave.core.parsers.RegexPrefixCapturingPatternParser;
import org.jbehave.core.parsers.StepMatcher;
import org.jbehave.core.parsers.StepPatternParser;
import org.jbehave.core.reporters.StepdocReporter;
import org.jbehave.core.steps.StepType;
import org.jbehave.core.steps.Stepdoc;

import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Maryna Pristrom
 */
public class JiraStepDocReporter implements StepdocReporter {

    private final String reportStepDocUrl;

    private final StepPatternParser patternParser;

    public JiraStepDocReporter(String jiraBaseUrl, String jiraProject, String jiraUserName, String jiraPassword) {
        this(jiraBaseUrl, jiraProject, jiraUserName, jiraPassword, new RegexPrefixCapturingPatternParser());
    }

    public JiraStepDocReporter(String jiraBaseUrl, String jiraProject, String jiraUserName, String jiraPassword, StepPatternParser stepPatternParser) {
        this.reportStepDocUrl = (jiraBaseUrl + "/rest/jbehave-for-jira/1.0/step-doc/add/" + jiraProject
                + "?os_username=" + jiraUserName
                + "&os_password=" + jiraPassword);
        this.patternParser = stepPatternParser;
    }

    @Override
    public void stepdocs(List<Stepdoc> stepdocs, List<Object> stepsInstances) {

        List<StepDocDTO> stepDocDTOs = new ArrayList<StepDocDTO>(stepdocs.size());

        for (Stepdoc stepdoc : stepdocs) {

            StepDocDTO stepDocDTO = new StepDocDTO();

            String pattern = stepdoc.getPattern();
            stepDocDTO.pattern = pattern;

            StepType stepType = stepdoc.getStepType();

            String startingWord = stepdoc.getStartingWord();
            stepDocDTO.startingWord = startingWord;

            Object stepsInstance = stepdoc.getStepsInstance();
            Class<?> stepsClass = stepsInstance.getClass();
            String stepClassName = stepsClass.getName();
            stepDocDTO.stepClassName = stepClassName;

            String methodSignature = stepdoc.getMethodSignature();
            stepDocDTO.stepMethodSignature = methodSignature;

            StepMatcher stepMatcher = patternParser.parseStep(stepType, pattern);
            StepPattern stepPattern = stepMatcher.pattern();
            String resolvedPattern = stepPattern.resolved();
            stepDocDTO.resolvedPattern = resolvedPattern;
            setGroupedPatternOnStepDoc(stepDocDTO);

            Method method = stepdoc.getMethod();
            Type[] genericParameterTypes = method.getGenericParameterTypes();
            Annotation[][] parametersAnnotations = method.getParameterAnnotations();
            List<ParameterMetaInfo> parameterInfos = new ArrayList<ParameterMetaInfo>(genericParameterTypes.length);

            for (int i = 0; i < genericParameterTypes.length; i++) {

                Type genericParameterType = genericParameterTypes[i];

                // find if annotated with ParameterInfo
                Annotation[] parameterAnnotations = parametersAnnotations[i];
                ParameterInfo paramInfoAnnotation = null;
                for (int j = 0; j < parameterAnnotations.length; j++) {
                    Annotation annotation = parameterAnnotations[j];
                    if (ParameterInfo.class.isAssignableFrom(annotation.getClass())) {
                        paramInfoAnnotation = (ParameterInfo) annotation;
                        break;
                    }
                }

                ParameterMetaInfo parameterInfo = new ParameterMetaInfo();
                if (genericParameterType instanceof ParameterizedType) {
                    ParameterizedType parameterizedType = (ParameterizedType) genericParameterType;
                    Class<?> rawType = (Class<?>) parameterizedType.getRawType();
                    if (rawType.getName().equals(List.class.getName())) {
                        Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
                        if (actualTypeArguments.length == 1) {
                            Type actualTypeArgument = actualTypeArguments[0];
                            if (actualTypeArgument instanceof Class<?>) {
                                Class<?> classType = (Class<?>) actualTypeArgument;
                                populateParameterInfo(parameterInfo, classType, paramInfoAnnotation);
                                parameterInfo.listType = true;
                            }
                        } else {
                            // if there are more type arguments, we ignore such cases
                        }
                    } else {
                        // we ignore any other generic parameter types
                    }
                } else if (genericParameterType instanceof Class) {
                    Class classType = (Class) genericParameterType;
                    populateParameterInfo(parameterInfo, classType, paramInfoAnnotation);
                } else {
                    // we do not provide any meta information in this case
                }
                parameterInfos.add(parameterInfo);
            }
            stepDocDTO.parameterInfos = parameterInfos;

            if (parameterInfos.size() != stepDocDTO.parameterGroups.size()) {
                // this should not happen, but it may if the developer made a mistake in matching the number of method parameters to
                // number of parameters in pattern
                System.out.println("[WARN] Number of resolved parameters doesn't match number of gathered parameter infos, for class - "
                        + stepDocDTO.stepClassName + " and method - " + stepDocDTO.stepMethodSignature);
//                throw new IllegalStateException("Number of resolved parameters doesn't match number of gathered parameter infos");
            }

            List<Integer> parameterGroups = stepDocDTO.parameterGroups;
            if (!parameterGroups.isEmpty()) {

                // set parameter boundaries in pattern
                String groupedRegExpPattern = stepDocDTO.groupedRegExpPattern;
                Validate.notNull(groupedRegExpPattern);
                Pattern groupedPattern = Pattern.compile(groupedRegExpPattern, Pattern.DOTALL);
                Matcher matcher = groupedPattern.matcher(stepdoc.getPattern());
                boolean matches = matcher.matches();
                Validate.isTrue(matches, "Error - pattern should have matched");
                List<Integer> parameterBoundaries = new ArrayList<Integer>(parameterGroups.size() * 2);
                for (Integer parameterGroup : parameterGroups) {
                    int groupStart = matcher.start(parameterGroup);
                    parameterBoundaries.add(groupStart);
                    int groupEnd = matcher.end(parameterGroup);
                    parameterBoundaries.add(groupEnd);
                }
                stepDocDTO.paramBoundInPattern = parameterBoundaries;

                // set extended pattern
                int totalGroups = matcher.groupCount();
                StringBuilder sb = new StringBuilder();
                int paramGroupIndex = 0;
                for (int i = 0; i < totalGroups; i++) {
                    int groupNumber = i + 1;
                    String groupText = matcher.group(groupNumber);
                    if (parameterGroups.contains(groupNumber)) {
                        // group is a parameter, check its parameter info
                        ParameterMetaInfo parameterInfo = parameterInfos.get(paramGroupIndex);
                        Validate.notNull(parameterInfo);
                        List<TabularFieldMetaInfo> tabularFieldInfos = parameterInfo.tabularFieldInfos;
                        if (tabularFieldInfos != null && !tabularFieldInfos.isEmpty()) {
                            // replace the parameter name with parameter field names in tabular format
                            int totalPipes = 0;
                            sb.append("\n");
                            sb.append("|");
                            totalPipes++;
                            for (TabularFieldMetaInfo tabularFieldInfo : tabularFieldInfos) {
                                sb.append(tabularFieldInfo.fieldName);
                                sb.append("|");
                                totalPipes++;
                            }
                            sb.append("\n");
                            // we add another line which contains same number of pipes as an empty values row, ready for user to fil in
                            for (int j = 0; j < totalPipes; j++) {
                                sb.append("|");
                            }
                            sb.append("\n");
                        } else {
                            sb.append(groupText);
                        }
                        paramGroupIndex++;
                    } else {
                        sb.append(groupText);
                    }
                }
                String extendedPattern = sb.toString();
                stepDocDTO.extendedPattern = extendedPattern;

                // set extended pattern parameter boundaries
                matcher = groupedPattern.matcher(extendedPattern);
                matches = matcher.matches();
                Validate.isTrue(matches, "Error - extended pattern should have matched");
                List<Integer> extendedParameterBoundaries = new ArrayList<Integer>(parameterGroups.size() * 2);
                for (Integer parameterGroup : parameterGroups) {
                    int groupStart = matcher.start(parameterGroup);
                    extendedParameterBoundaries.add(groupStart);
                    int groupEnd = matcher.end(parameterGroup);
                    extendedParameterBoundaries.add(groupEnd);
                }
                stepDocDTO.paramBoundInExtendPattern = extendedParameterBoundaries;

            }

            stepDocDTOs.add(stepDocDTO);
        }

        StepDocsPayload stepDocsPayload = new StepDocsPayload();
        stepDocsPayload.stepDocs = stepDocDTOs;
        uploadToJira(stepDocsPayload);
    }

    private void populateParameterInfo(ParameterMetaInfo parameterMetaInfo, Class classType, ParameterInfo paramInfoAnnotation) {

        String parameterType = classType.getName();
        parameterMetaInfo.parameterType = parameterType;
        String simpleName = classType.getSimpleName();
        parameterMetaInfo.simpleParameterType = simpleName;
        Annotation asParamAnnotation = classType.getAnnotation(AsParameters.class);

        if (asParamAnnotation != null) {
            parameterMetaInfo.tabularFieldInfos = this.workoutTabularParameterInfos(classType);
        } else {
            this.populateSimpleParameterInfo(parameterMetaInfo, classType, paramInfoAnnotation);
        }
    }

    private void populateSimpleParameterInfo(ParameterMetaInfo parameterMetaInfo, Class classType, ParameterInfo paramInfoAnnotation) {

        // not a table type, but still may be a list type
        // check if enum
        if (classType.isEnum()) {
            Object[] enumConstants = classType.getEnumConstants();
            List<String> allowedvalues = new ArrayList<String>(enumConstants.length);
            for (Object enumConstant : enumConstants) {
                Enum e = (Enum) enumConstant;
                allowedvalues.add(e.toString());
            }
            parameterMetaInfo.allowedValues = allowedvalues;
        } else {
            // not an enum so check for allowed or suggested values
            if (paramInfoAnnotation != null) {
                if (paramInfoAnnotation.allowedValues().length > 0) {
                    List<String> allowedValues = Arrays.asList(paramInfoAnnotation.allowedValues());
                    parameterMetaInfo.allowedValues = allowedValues;
                } else if (paramInfoAnnotation.suggestedValuesEnum() != com.jbehaveforjira.javaclient.ParameterInfo.EmptyEnum.class) {
                    Class susggestedValuesEnum = paramInfoAnnotation.suggestedValuesEnum();
                    Object[] suggestedConstants = susggestedValuesEnum.getEnumConstants();
                    List<String> suggestedValues = new ArrayList<String>();
                    for (Object enumConstant : suggestedConstants) {
                        Enum enumField = (Enum) enumConstant;
                        String enumName = enumField.toString();
                        suggestedValues.add(enumName);
                    }
                    parameterMetaInfo.suggestedValues = suggestedValues;
                } else if (paramInfoAnnotation.suggestedValues().length > 0) {
                    // suggested values are set
                    List<String> suggestedValues = Arrays.asList(paramInfoAnnotation.suggestedValues());
                    parameterMetaInfo.suggestedValues = suggestedValues;
                }

                // format
                String pattern = paramInfoAnnotation.formatPattern();
                if (!pattern.trim().isEmpty()) {
                    parameterMetaInfo.formatPattern = pattern;
                    String formatDisplayText = paramInfoAnnotation.formatDisplayText();
                    if (!formatDisplayText.trim().isEmpty()) {
                        parameterMetaInfo.formatDisplayText = formatDisplayText;
                    }
                }
            }

        }
    }

    private List<TabularFieldMetaInfo> workoutTabularParameterInfos(Class classType) {

        List<TabularFieldMetaInfo> tabularFieldInfos = new ArrayList<TabularFieldMetaInfo>();

        // parameter can be represented as a table
        Field[] declaredFields = classType.getDeclaredFields();

        for (Field declaredField : declaredFields) {

            TabularFieldMetaInfo tabularFieldInfo = new TabularFieldMetaInfo();

            // field name
            Parameter fieldAnnotation = declaredField.getAnnotation(Parameter.class);
            String fieldName;
            if (fieldAnnotation != null) {
                fieldName = fieldAnnotation.name();
            } else {
                fieldName = declaredField.getName();
            }
            tabularFieldInfo.fieldName = fieldName;

            ParameterInfo parameterInfo = declaredField.getAnnotation(ParameterInfo.class);

            // allowed field values, i.e. in case of enum
            Class<?> fieldType = declaredField.getType();
            Object[] enumConstants = fieldType.getEnumConstants();

            if (fieldType == Boolean.class || fieldType == boolean.class) {
                // boolean use case
                List<String> allowedValues = new ArrayList<String>();
                allowedValues.add("true");
                allowedValues.add("false");
                tabularFieldInfo.allowedValues = allowedValues;
            } else if (enumConstants != null && enumConstants.length > 0) {
                List<String> allowedValues = new ArrayList<String>();
                Class<? extends Enum> enumFieldType = (Class<? extends Enum>) fieldType;
                for (Object enumConstant : enumConstants) {
                    Enum enumField = (Enum) enumConstant;
                    String enumName = enumField.toString();
                    allowedValues.add(enumName);
                }

                tabularFieldInfo.allowedValues = allowedValues;
            } else {
                // not an enum type or a boolean, so check for allowed values annotation
                if (parameterInfo != null) {
                    if (parameterInfo.allowedValues().length > 0) {
                        List<String> allowedValues = Arrays.asList(parameterInfo.allowedValues());
                        tabularFieldInfo.allowedValues = allowedValues;
                    } else if (parameterInfo.suggestedValuesEnum() != com.jbehaveforjira.javaclient.ParameterInfo.EmptyEnum.class) {
                        Class susggestedValuesEnum = parameterInfo.suggestedValuesEnum();
                        Object[] suggestedConstants = susggestedValuesEnum.getEnumConstants();
                        List<String> suggestedValues = new ArrayList<String>();
                        for (Object enumConstant : suggestedConstants) {
                            Enum enumField = (Enum) enumConstant;
                            String enumName = enumField.toString();
                            suggestedValues.add(enumName);
                        }
                        tabularFieldInfo.suggestedValues = suggestedValues;
                    } else if (parameterInfo.suggestedValues().length > 0) {
                        // suggested values are set
                        List<String> suggestedValues = Arrays.asList(parameterInfo.suggestedValues());
                        tabularFieldInfo.suggestedValues = suggestedValues;
                    }
                }

            }

            if (parameterInfo != null) {
                // is mandatory
                tabularFieldInfo.mandatory = parameterInfo.isMandatory();
                // format
                String pattern = parameterInfo.formatPattern();
                if (!pattern.trim().isEmpty()) {
                    tabularFieldInfo.formatPattern = pattern;
                    String formatDisplayText = parameterInfo.formatDisplayText();
                    if (!formatDisplayText.trim().isEmpty()) {
                        tabularFieldInfo.formatDisplayText = formatDisplayText;
                    }
                }
            }

            tabularFieldInfos.add(tabularFieldInfo);
        }

        return tabularFieldInfos;
    }

    private void uploadToJira(StepDocsPayload stepDocsPayload) {

        ObjectMapper mapper = new ObjectMapper();
        String payloadAsString;
        try {
            payloadAsString = mapper.writeValueAsString(stepDocsPayload);
        } catch (IOException e) {
            throw new RuntimeException("Error occurred while trying to serialize object of type - "
                    + StepDocsPayload.class.getName() + " to json.", e);
        }

        Client client = Client.create();
        String response = client.resource(this.reportStepDocUrl)
                .accept(MediaType.APPLICATION_JSON)
                .type(MediaType.APPLICATION_JSON)
                .post(String.class, payloadAsString);

        if (!response.startsWith("success")) {
            throw new RuntimeException("Failed to upload step doc! Server returned error message - " + response);
        }
    }

    @Override
    public void stepdocsMatching(String stepAsString, List<Stepdoc> matching, List<Object> stepsIntances) {
        // ignored
    }

    private void setGroupedPatternOnStepDoc(StepDocDTO stepDocDTO) {

        String resolvedPattern = stepDocDTO.resolvedPattern;
        StringBuilder groupedPatternBuilder = new StringBuilder();
        List<Integer> parameterGroups = new ArrayList<Integer>();

        int pos = 0;
        int groupCount = 0;

        Pattern openBracePattern = Pattern.compile("(?<!\\\\)\\(");
        Matcher openBraceMatcher = openBracePattern.matcher(resolvedPattern);
        Pattern closeBracePattern = Pattern.compile("(?<!\\\\)\\)");
        Matcher closeBraceMatcher = closeBracePattern.matcher(resolvedPattern);

        boolean openBraceFound = openBraceMatcher.find(pos);
        while (openBraceFound && pos < resolvedPattern.length()) {

            // we want to group everything before that opening brace
            groupedPatternBuilder.append("(");
            groupedPatternBuilder.append(resolvedPattern.substring(pos, openBraceMatcher.start()));
            groupedPatternBuilder.append(")");
            groupCount++;

            boolean closeBraceFound = closeBraceMatcher.find(openBraceMatcher.start());
            Validate.isTrue(closeBraceFound, "Couldn't find closing matching brace in pattern - " + resolvedPattern);
            groupedPatternBuilder.append(resolvedPattern.substring(openBraceMatcher.start(), closeBraceMatcher.end()));
            groupCount++;
            parameterGroups.add(groupCount);

            pos = closeBraceMatcher.end();

            openBraceFound = openBraceMatcher.find(pos);
        }

        // there are no more parameter groups so we simply append any string into last group
        if (pos < resolvedPattern.length()) {
            groupedPatternBuilder.append("(");
            groupedPatternBuilder.append(resolvedPattern.substring(pos));
            groupedPatternBuilder.append(")");
        }

        String groupedPattern = groupedPatternBuilder.toString();
        if (groupedPattern.isEmpty()) {
            // reg exp pattern did not contain any groups
            groupedPattern = "(" + resolvedPattern + ")";
        }
        stepDocDTO.groupedRegExpPattern = groupedPattern;
        stepDocDTO.parameterGroups = parameterGroups;
    }

    @XmlRootElement
    @XmlAccessorType(XmlAccessType.FIELD)
    private class TabularFieldMetaInfo {

        public String fieldName;

        public boolean mandatory;

        public List<String> allowedValues;

        public List<String> suggestedValues;

        public String formatPattern;

        public String formatDisplayText;
    }

    @XmlRootElement
    @XmlAccessorType(XmlAccessType.FIELD)
    private class ParameterMetaInfo {

        public String parameterType;

        public String simpleParameterType;

        public boolean listType;

        public List<String> allowedValues;

        public List<String> suggestedValues;

        public String formatPattern;

        public String formatDisplayText;

        public List<TabularFieldMetaInfo> tabularFieldInfos;
    }

    @XmlRootElement
    @XmlAccessorType(XmlAccessType.FIELD)
    private class StepDocDTO {

        public String startingWord;

        public String pattern;

        public List<Integer> paramBoundInPattern;

        public String extendedPattern;

        public List<Integer> paramBoundInExtendPattern;

        public String resolvedPattern;

        public String groupedRegExpPattern;

        public String stepClassName;

        public String stepMethodSignature;

        public List<Integer> parameterGroups = new ArrayList<Integer>();

        public List<ParameterMetaInfo> parameterInfos = new ArrayList<ParameterMetaInfo>();
    }

    @XmlRootElement
    @XmlAccessorType(XmlAccessType.FIELD)
    private static class StepDocsPayload {

        public List<StepDocDTO> stepDocs;
    }
}





