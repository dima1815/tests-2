package com.jbehaveforjira.javaclient;

import java.util.List;

/**
 * @author Maryna Pristrom
 */
public interface StoryPathsFinder {

    List<String> findPaths();

    List<String> findPaths(List<String> includes, List<String> excludes);
}
