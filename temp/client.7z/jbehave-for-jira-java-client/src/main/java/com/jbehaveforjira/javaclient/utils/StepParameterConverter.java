package com.jbehaveforjira.javaclient.utils;

import org.jbehave.core.steps.ParameterConverters;

import java.lang.reflect.Type;

/**
 * Custom converter for any types that implement StepParameter interface
 *
 * @author Maryna Pristrom
 */
public class StepParameterConverter implements ParameterConverters.ParameterConverter {

    @Override
    public boolean accept(Type type) {
        if (type instanceof Class<?>) {
            Class<?> clazz = (Class<?>) type;
            return StepParameter.class.isAssignableFrom(clazz);
        }
        return false;
    }

    @Override
    public Object convertValue(String value, Type type) {

        Class<?> clazz = (Class<?>) type;

        if (clazz.isEnum()) {

            // we handle enum types slightly differently as the implementation inside individual enum constants
            // should normally throw an exception if a given enum constant doesn't match the specified value. We need to try all enum
            // constants before actually failing conversion.
            Object[] enumConstants = clazz.getEnumConstants();
            String[] allowedValues = new String[enumConstants.length];
            for (int i = 0; i < enumConstants.length; i++) {
                Object enumConstant = enumConstants[i];
                StepParameter toFromEnum = (StepParameter) enumConstant;
                try {
                    toFromEnum.fromString(value);
                    return toFromEnum;
                } catch (RuntimeException e) {
                    // ignore;
                    allowedValues[i] = toFromEnum.asString();
                }
            }
            throw new IllegalArgumentException("Failed to convert step parameter value - '" + value + "' into enum of type - " + clazz.getSimpleName()
                    + ". Allowed values are: " + allowedValues);
        } else {
            try {
                StepParameter newInstance = (StepParameter) clazz.newInstance();
                newInstance.fromString(value);
                return newInstance;
            } catch (InstantiationException e) {
                throw new StepParameterConversionException("Failed to convert step parameter string value - '" + value + "' into instance of type - "
                        + clazz.getSimpleName(), e);
            } catch (IllegalAccessException e) {
                throw new StepParameterConversionException("Failed to convert step parameter string value - '" + value + "' into instance of type - "
                        + clazz.getSimpleName(), e);
            }
        }
    }
}