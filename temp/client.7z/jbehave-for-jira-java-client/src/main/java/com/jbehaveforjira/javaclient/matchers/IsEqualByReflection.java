package com.jbehaveforjira.javaclient.matchers;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.apache.commons.lang.Validate;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * @author Maryna Pristrom
 */
public class IsEqualByReflection<T> extends BaseMatcher<T> {

    private final T actualValue;

    private final Field[] allFields;

    private final List<String> fieldsToExclude;

    private static List<Field> unequalFields = new ArrayList<Field>();

    private static List<Field> ignoredFields = new ArrayList<Field>();

    public IsEqualByReflection(T actualValue) {
        this(actualValue, new String[0]);
    }

    public IsEqualByReflection(T actualValue, String... fieldsToExclude) {

        Validate.notNull(actualValue);
        Validate.notNull(fieldsToExclude);

        this.actualValue = actualValue;

        allFields = actualValue.getClass().getDeclaredFields();
        for (Field field : allFields) {
            field.setAccessible(true);
        }

        this.fieldsToExclude = Arrays.asList(fieldsToExclude);
    }

    public static enum FieldEqualsState {
        equal, unequal, ignored
    }

    public static class FieldMetaInfo {

        private String stringValue;

        private FieldEqualsState equalsState;

        public FieldMetaInfo(String stringValue, FieldEqualsState equalsState) {
            this.stringValue = stringValue;
            this.equalsState = equalsState;
        }

        public String getStringValue() {
            return stringValue;
        }

        public FieldEqualsState getEqualsState() {
            return equalsState;
        }
    }

    @Override
    public void describeTo(Description description) {

        description.appendText("Equal to:\n");

        StringWriter out;
        try {
            InputStream in = getClass().getResourceAsStream("/ftl/isEqualByReflectionMatcher.ftl");
            Template t = new Template("isEqualByReflectionMatcher", new InputStreamReader(in), new Configuration());
            out = new StringWriter();

            HashMap<String, Object> templateModel = new HashMap<String, Object>();
            String actualValueClassName = actualValue.getClass().getSimpleName();
            templateModel.put("className", actualValueClassName);

            HashMap<String, FieldMetaInfo> fieldInfos = new HashMap<String, FieldMetaInfo>(this.allFields.length);
            templateModel.put("fieldInfos", fieldInfos);
            for (Field field : this.allFields) {
                String fieldName = field.getName();
                Object fieldValue = field.get(actualValue);
                String stringFieldValue;
                if (fieldValue != null) {
                    stringFieldValue = fieldValue.toString();
                } else {
                    stringFieldValue = "null";
                }
                FieldEqualsState equalsStatus;
                if (this.unequalFields.contains(field)) {
                    equalsStatus = FieldEqualsState.unequal;
                } else if (this.ignoredFields.contains(field)) {
                    equalsStatus = FieldEqualsState.ignored;
                } else {
                    equalsStatus = FieldEqualsState.equal;
                }
                FieldMetaInfo fieldMetaInfo = new FieldMetaInfo(stringFieldValue, equalsStatus);
                fieldInfos.put(fieldName, fieldMetaInfo);
            }

            t.process(templateModel, out);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (TemplateException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }

        String transformedTemplate = out.toString();
        description.appendText(transformedTemplate + "\n");
    }

    @Override
    public boolean matches(Object expectedValue) {
        Validate.notNull(expectedValue);
        return areEqual(actualValue, expectedValue);
    }

    private boolean areEqual(Object actualValue, Object expectedValue) {

        if (expectedValue != null && actualValue.getClass().isArray()) {
            throw new IllegalArgumentException("Comparison of Array types is not supported by this matcher");
        }

        return compareByReflection(actualValue, expectedValue);
    }

    private boolean compareByReflection(Object actualValue, Object expectedValue) {

        Validate.notNull(actualValue);

        try {

            for (Field field : allFields) {
                String fieldName = field.getName();
                if (fieldsToExclude.contains(fieldName)) {
                    ignoredFields.add(field);
                } else {
                    Object actualField = field.get(actualValue);
                    Object expectedField = field.get(expectedValue);
                    if (actualField != null) {
                        if (!actualField.equals(expectedField)) {
                            this.unequalFields.add(field);
                        }
                    } else if (expectedField != null) {
                        this.unequalFields.add(field);
                    }
                }
            }

            if (unequalFields.isEmpty()) {
                return true;
            } else {
                return false;
            }

        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }


}
